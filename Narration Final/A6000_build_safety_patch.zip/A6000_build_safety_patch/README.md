# A6000 container build diagnosis and proposed patch

## Finding

The original build can put substantial pressure on the Docker host's CPU and
system RAM. It compiles llama.cpp for seven CUDA architectures using every
visible logical CPU, without a dedicated builder memory limit. This is the
strongest build-related risk found in the supplied files. It does **not** prove
that memory exhaustion caused the reported server shutdown. No server logs,
hardware telemetry, build transcript, or provider event log was supplied.

An actual NVIDIA RTX A6000 is compute capability 8.6. The original architecture
list includes `86`, so an A6000-specific architecture mismatch is not indicated.
The image build compiles and downloads software/weights; it does not perform
model inference. GPU VRAM and host system RAM are separate resources.

This is a proposed source patch, with local static and mocked-command validation.
A complete image build and inference test were not performed: the review
environment has no Docker daemon/CLI or NVIDIA GPU. See `VALIDATION.txt` for the
checks that were actually run.

## Contents and installation

The `overlay/` directory contains the deployment files to apply to the original
`A6000_server_deploy` folder. It is a patch bundle, not a standalone replacement
for the application source. `changes.diff` is available for review. The original
application, model choices, and Python package pins are used by the patch.

After extracting this ZIP next to the original folder:

```bash
cp -a A6000_build_safety_patch/overlay/. A6000_server_deploy/
cd A6000_server_deploy
```

This copies the changed Dockerfile, Compose configuration, sample configuration,
and build/check scripts. It does not replace an existing `config.env`. If you have
customized the original deployment files, review `changes.diff` and merge those
customizations before copying the overlay.

The helper saves build output under `logs/`, prevents overlapping builds in the
same project, and stops its own builder on completion or failure while retaining
its build cache. The patch excludes those local logs/lock files from the image
build context.

Collect the host evidence below before retrying. When the host has adequate free
RAM and Docker storage, the revised workflow is:

```bash
bash scripts/build_limited.sh
bash scripts/check_gpu.sh
docker compose --env-file config.env -f docker/compose.yaml up -d
```

`bash scripts/up.sh` runs those same steps and stops if a step fails. The build
script requires Docker Engine, Compose v2 with `build --builder`, and Buildx
0.14 or later. The runtime checks additionally require a compatible NVIDIA host
driver and NVIDIA Container Toolkit. Building the image does not need a GPU.

## Build protection

- Native compilation defaults to `BUILD_JOBS=1`, replacing `-j"$(nproc)"`.
- The helper uses a separate Docker-container BuildKit builder with CPU and RAM
  limits. It does not change the globally selected builder.
- Default CPU quota is one CPU. Default builder RAM is one quarter of the Docker
  host's reported total memory, capped at 8 GiB. The helper verifies the configured
  limits and refuses a budget above half the host's reported total RAM.
- The builder's RAM-plus-swap limit equals its RAM limit, preventing this builder
  from consuming swap. BuildKit runs one independent work step at a time, and the
  helper builds `llm` and then `tts` separately.
- Hitting the builder's memory limit may terminate the build. These limits reduce
  host resource pressure; they do not guarantee protection against hardware,
  power, kernel, Docker-daemon, disk-space, or unrelated-workload failures.
- One compiler job may still need substantial RAM. A multi-architecture build may
  be slow. GPU memory does not provide additional host compiler RAM.

The resource budget is configurable through the shell. This example is a **4 GiB
builder ceiling**, not a claim that every build completes within 4 GiB:

```bash
BUILD_MEMORY_MIB=4096 BUILD_CPUS=1 bash scripts/build_limited.sh
```

Check that the host has that much *available* RAM plus operating-system headroom;
the helper's total-memory check cannot know how much RAM other workloads need.
The limits apply to the builder's container, not to every Docker-daemon operation
or to image-storage use. Leave free disk space for weights, CUDA packages, image
layers, exports, and build cache.

Use the helper to obtain the hard builder limits. A direct
`docker compose ... build` still receives the one-job compiler default, but does
not by itself create or select this limited builder. Compose's `--memory` build
option is not supported by BuildKit.

## GPU portability

The patch exposes `CUDA_ARCHITECTURES` through `config.env` and retains the
original multi-target default:

```dotenv
BUILD_JOBS=1
CUDA_ARCHITECTURES="75;80;86;89;90;100;120"
GPU_DEVICE_ID=0
```

The selected GPU is exposed as device zero inside both services. This is normal
container device remapping; the internal `cuda:0` is not an A6000 model lock.

For a deployment that is specifically confirmed to use an RTX A6000, setting
`CUDA_ARCHITECTURES="86"` substantially narrows the native compilation workload.
An image built that way is no longer the broad multi-target build. Keep the list
when moving the same image across supported GPU families.

| Hardware/runtime | Status of the supplied stack |
| --- | --- |
| NVIDIA RTX A6000 | Its `86` architecture is included. A compatible driver, sufficient memory, and successful runtime checks are still required. |
| Other NVIDIA GPUs in the selected native architecture list | The LLM is compiled for those targets. Whole-stack support also depends on the separately installed PyTorch/CUDA libraries and the model workload. |
| Older NVIDIA GPUs, such as Pascal/Volta | Their targets are absent from the original default. Rebuild with appropriate targets supported by the pinned toolkit/backend, then test both services. |
| NVIDIA Blackwell, including RTX 50-series | The LLM list includes Blackwell targets, but TTS pins Torch/Torchaudio 2.5.1+cu121. Whole-stack Blackwell support requires a coordinated Torch, torchaudio, CUDA-library and related lock update, followed by validation. |
| AMD or Intel GPU | This CUDA/NVML/NVIDIA-Compose deployment does not implement the required alternative backend. |
| ARM/Jetson host | The direct Torch wheels and FFmpeg binary are Linux x86_64/amd64. The patch makes that image platform explicit; it does not add native ARM support. |

Changing the CUDA base image alone does not update the CUDA kernels bundled in
the PyTorch wheels. PyTorch 2.7 introduced Blackwell support with CUDA 12.8 builds;
the original TTS lock is older. Installing a new `torch` alone while retaining
old exact torchaudio, CUDA-library, and Triton pins is not a coordinated upgrade.

The native build now sets `GGML_NATIVE=OFF`, avoiding compilation specifically for
the builder's CPU. The pinned backend still has an x86 CPU instruction baseline,
including AVX2/BMI2/FMA/F16C defaults; this does not promise every x86 CPU works.
The unused embedded llama.cpp UI and optional NCCL/OpenSSL integrations are
disabled for this existing single-GPU, local-HTTP deployment.

## Runtime behavior and checks

`scripts/check_gpu.sh` checks the already-built images. It does not load the
models. It reports the actual Torch/CUDA/GPU information, executes small CUDA
matrix multiplication and convolution operations, and verifies that llama.cpp
reports a CUDA device. `nvidia-smi` alone would not exercise these application
libraries. A passing check is followed by normal service startup and a short
generation request through each API; only that last step validates model use.

If you explicitly configure `TTS_DEVICE=cpu`, the TTS probe runs its small tests
on CPU and reports that choice. It does not silently switch a failing CUDA setup
to CPU. The LLM still requires a working CUDA device.

The original LLM already uses automatic GPU-layer fitting and CPU KV cache. These
behaviors are preserved. The patch exposes the existing context and GPU-budget
settings through Compose, so changing them in `config.env` now reaches the apps.
There is no automatic CPU fallback for the LLM service in this code.

The LLM's default 11 GB ceiling minus 1.5 GB reserve is a sampled **whole-device**
usage threshold. On a sufficiently large GPU it stops the LLM around 9.5 GB of
total device usage, including TTS and other processes. The TTS process has its
own Torch allocator allowance. The shared lock serializes operations but keeps
weights resident, so both models must fit together. CPU KV cache and CPU-offloaded
weights also consume host RAM. None of these runtime GPU settings limits build
memory.

For explicit host-RAM caps on the running services, the optional
`docker/compose.runtime-limits.yaml` requires you to choose budgets. For example,
after checking that these budgets leave adequate memory for the host and other
workloads:

```bash
LLM_MEMORY_LIMIT=8g TTS_MEMORY_LIMIT=4g \
  docker compose --env-file config.env -f docker/compose.yaml \
  -f docker/compose.runtime-limits.yaml up -d
```

These are example ceilings, not measured model requirements. An undersized cap
can terminate a service. Reuse this override file on subsequent `up` commands;
the basic `up.sh` does not apply this optional runtime override.

## Determine what happened to the server

On the original host, collect:

```bash
uptime
last -x -n 12
nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv
free -h
df -h
sudo journalctl -k -b -1 --no-pager | tail -n 200
sudo journalctl -b -1 -p warning..alert --no-pager | tail -n 200
```

Use `-b 0` instead of `-b -1` if the machine did not reboot and you are examining
the current boot. Use `journalctl --list-boots` to select the correct boot if
there have been multiple restarts. Previous-boot logs may be unavailable when
persistent journaling was disabled.

| Evidence | What it would support |
| --- | --- |
| Kernel `Out of memory`, `oom-kill`, or `Killed process` entries during the build | Host or cgroup memory pressure; inspect the surrounding entries to determine which. |
| Build exit 137/SIGKILL without kernel evidence | A killed process; exit 137 alone does not prove OOM. |
| No reboot, but an SSH timeout while CPU/RAM/storage are saturated | A host that became unresponsive or lost connectivity rather than necessarily powering off. |
| A new boot with a kernel panic/watchdog/hardware error | A host-level failure requiring the corresponding kernel/hardware investigation. |
| Abrupt power loss or provider stop event | Check provider instance events or the server's BMC/IPMI event log for power/thermal/platform causes. |
| CUDA unavailable, missing kernel image, driver mismatch, or CUDA OOM at service startup | A runtime compatibility or GPU-memory failure; this normally fails the service instead of switching off a physical server. |

Preserve the last portion of the original build output, including the stage that
was running. The exact command used is useful because the archive also contains
separate native installation scripts with a different build path.

## Evidence reviewed

Original ZIP locations:

- `docker/Dockerfile`, line 39 (architecture list), line 55 (all-core compile),
  lines 72–82 and 110–121 (build-time model/download operations).
- `docker/compose.yaml`, GPU reservations and lack of build resource controls.
- `scripts/up.sh`, lines 7–8 (build both services and then start).
- `tts/requirements.txt`, lines 99–100 (Torch/torchaudio 2.5.1+cu121 x86_64 wheels).
- `llm/pipeline_core/runtime.py`, automatic fitting, memory monitor, and CPU KV.
- `llm/pipeline_core/llama_session.py`, CUDA-only service session.
- `tts/kokoro_fit_core.py`, explicit CUDA requirement and allocator budget.

Primary references consulted:

1. [Docker: resource constraints and host OOM risks](https://docs.docker.com/engine/containers/resource_constraints/)
2. [Docker: BuildKit solver parallelism](https://docs.docker.com/build/buildkit/configure/)
3. [Docker: resource options for the Docker-container builder](https://docs.docker.com/build/builders/drivers/docker-container/)
4. [Docker Compose build options](https://docs.docker.com/reference/cli/docker/compose/build/)
5. [NVIDIA GPU compute capabilities](https://developer.nvidia.com/cuda/gpus)
6. [PyTorch 2.7 and Blackwell/CUDA 12.8](https://pytorch.org/blog/pytorch-2-7/)
7. [CUDA 12.8.1 release notes](https://docs.nvidia.com/cuda/archive/12.8.1/cuda-toolkit-release-notes/index.html)
8. [CUDA minor-version compatibility and limitations](https://docs.nvidia.com/deploy/cuda-compatibility/minor-version-compatibility.html)

NVIDIA's CUDA 12.x minor-compatibility minimum and the driver version associated
with CUDA 12.8.1 are different numbers. Some older drivers can run qualifying
workloads with restrictions, especially around PTX and newer features. Verify
the actual host driver and application workload rather than assuming the CUDA
base image supplies or upgrades the host driver.
