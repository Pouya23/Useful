#!/usr/bin/env bash
# Requires Linux Docker Engine, Compose v2 with build --builder, Buildx >= 0.14.
# Overrides are shell environment variables, e.g. BUILD_MEMORY_MIB=4096 bash scripts/build_limited.sh.
# BUILD_MEMORY_MIB is the builder's RAM limit, not a required amount of host RAM.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
die() { printf 'Build stopped: %s\n' "$*" >&2; exit 1; }
for command in docker awk sha256sum flock tee; do
  command -v "$command" >/dev/null || die "Required command is missing: $command"
done
umask 077
exec 9>.build-limited.lock
flock -n 9 || die 'Another limited build is already running in this project.'
[[ -f config.env ]] || cp config.env.example config.env

compose_version="$(docker compose version --short)" || die 'Docker Compose v2 is required.'
[[ "$compose_version" =~ ^v?([0-9]+)\. ]] && (( BASH_REMATCH[1] >= 2 )) || die 'Docker Compose v2 is required.'
compose_help="$(docker compose build --help)" || die 'Cannot inspect Compose build support.'
[[ "$compose_help" == *--builder* ]] || die 'Update Docker Compose: build --builder is required.'
buildx_version="$(docker buildx version)" || die 'Docker Buildx >= 0.14 is required.'
[[ "$buildx_version" =~ [[:space:]]v?([0-9]+)\.([0-9]+)\. ]] || die 'Cannot determine Buildx version.'
(( BASH_REMATCH[1] > 0 || BASH_REMATCH[2] >= 14 )) || die 'Update Buildx to >= 0.14 for default-load support.'

# Query the selected Docker daemon, which may be remote; do not use local /proc.
host_info="$(docker info --format '{{.MemTotal}} {{.NCPU}} {{.MemoryLimit}} {{.SwapLimit}} {{.CPUCfsQuota}} {{.CPUCfsPeriod}} {{.ID}}')" || die 'Cannot reach Docker Engine.'
read -r host_bytes host_cpus memory_ok swap_ok quota_ok period_ok engine_id <<< "$host_info"
[[ "$host_bytes" =~ ^[1-9][0-9]*$ && "$host_cpus" =~ ^[1-9][0-9]*$ && -n "$engine_id" ]] || die 'Docker did not report usable host capacity.'
[[ "$memory_ok $swap_ok $quota_ok $period_ok" == 'true true true true' ]] || die 'Docker host must support memory, swap, and CPU quota limits.'
host_mib=$((host_bytes / 1048576))
default_mib=$((host_mib / 4))
(( default_mib <= 8192 )) || default_mib=8192
memory_mib="${BUILD_MEMORY_MIB:-$default_mib}"
cpus="${BUILD_CPUS:-1}"
[[ "$memory_mib" =~ ^[1-9][0-9]{0,8}$ ]] || die 'BUILD_MEMORY_MIB must be a positive integer in MiB.'
[[ "$cpus" =~ ^[1-9][0-9]{0,4}$ ]] || die 'BUILD_CPUS must be a positive integer.'
(( memory_mib <= host_mib / 2 )) || die 'BUILD_MEMORY_MIB must leave at least half the Docker host RAM outside the builder.'
(( cpus <= host_cpus )) || die 'BUILD_CPUS exceeds the Docker host CPU count.'
memory_bytes=$((memory_mib * 1048576))
cpu_quota=$((cpus * 100000))
config=docker/buildkitd.toml
[[ -f "$config" ]] || die "Missing $config"
key="$( { printf '%s\n' "$ROOT" "$engine_id" "$memory_bytes" "$cpu_quota"; sha256sum "$config"; } | sha256sum | awk '{print $1}')"
builder="narration-limited-${key:0:20}"
node="${builder}0"
container="buildx_buildkit_$node"

# A matching name alone never authorizes reuse. Check the actual managed container.
verify_container() {
  local actual
  actual="$(docker inspect --format "{{.HostConfig.Memory}} {{.HostConfig.MemorySwap}} {{.HostConfig.CpuQuota}} {{.HostConfig.CpuPeriod}} {{range .Config.Env}}{{if eq . \"NARRATION_BUILDER_ID=$key\"}}owned{{end}}{{end}}" "$container")" || die "Cannot verify $builder. Existing builders are never removed automatically."
  [[ "$actual" == "$memory_bytes $memory_bytes $cpu_quota 100000 owned" ]] || die "Builder $builder has unverified ownership or different resource limits; refusing to reuse it."
}
verify_builder() {
  local details names driver
  details="$(docker buildx inspect "$builder")" || die "Cannot inspect $builder."
  driver="$(awk '$1 == "Driver:" {print $2}' <<< "$details")"
  names="$(awk '$1 == "Name:" {print $2}' <<< "$details")"
  [[ "$driver" == docker-container && "$names" == "$builder"$'\n'"$node" ]] || die "Builder $builder must have exactly one docker-container node."
  [[ "$details" == *'default-load="true"'* ]] || die "Builder $builder does not have verified automatic image loading."
}
builders="$(docker buildx ls --format '{{.Builder.Name}}')" || die 'Cannot list builder names.'
if [[ $'\n'"$builders"$'\n' == *$'\n'"$builder"$'\n'* ]]; then
  verify_builder
  verify_container
else
  docker buildx create --name "$builder" --node "$node" --driver docker-container \
    --buildkitd-config "$config" --driver-opt "memory=$memory_bytes" \
    --driver-opt "memory-swap=$memory_bytes" --driver-opt "cpu-quota=$cpu_quota" \
    --driver-opt cpu-period=100000 --driver-opt default-load=true \
    --driver-opt "env.NARRATION_BUILDER_ID=$key" >/dev/null
fi
# Stop only this verified/just-created builder; retain its cache and all other builders.
trap 'docker buildx stop "$builder" >/dev/null 2>&1 || true' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
docker buildx inspect --bootstrap "$builder" >/dev/null
verify_builder
verify_container
running_config="$(docker exec "$container" cat /etc/buildkit/buildkitd.toml)" || die 'Cannot verify the running BuildKit configuration.'
awk '
  /^[[:space:]]*\[/ {section=$0; gsub(/[[:space:]]/, "", section)}
  section == "[worker.oci]" && /^[[:space:]]*max-parallelism[[:space:]]*=/ {
    value=$0; sub(/#.*/, "", value); gsub(/[[:space:]]/, "", value)
    found++; if (value != "max-parallelism=1") bad=1
  }
  END {exit !(found == 1 && !bad)}
' <<< "$running_config" || die 'BuildKit worker max-parallelism must be exactly 1.'

mkdir -p logs
log="logs/build-$(date -u +%Y%m%dT%H%M%SZ)-$$.log"
printf 'Builder: %s; CPU limit: %s; RAM limit: %s MiB; swap: disabled.\n' "$builder" "$cpus" "$memory_mib" | tee "$log"
printf 'Build log: %s/%s\n' "$ROOT" "$log"
export DOCKER_BUILDKIT=1 COMPOSE_BAKE=false COMPOSE_PARALLEL_LIMIT=1 BUILDKIT_PROGRESS=plain
for service in llm tts; do
  printf '\nBuilding %s\n' "$service" | tee -a "$log"
  docker compose --env-file config.env -f docker/compose.yaml --progress plain \
    build --builder "$builder" "$service" 2>&1 | tee -a "$log" || die "The $service build failed; see $log. No services were started."
done
printf 'Both images built and loaded. No services were started.\n' | tee -a "$log"
