#!/usr/bin/env bash
# Check prebuilt GPU images without loading models or starting API services.
set -euo pipefail

project_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
cd -- "$project_root"
fail() { printf 'GPU check: %s\n' "$*" >&2; exit 1; }
command -v docker >/dev/null || fail 'Docker is not installed or is not on PATH.'
[[ -f config.env ]] || fail 'Missing config.env; copy config.env.example and configure it first.'
compose=(docker compose --env-file config.env -f docker/compose.yaml)

# Fail before any run if either image is missing; this script must not build/pull.
images=$("${compose[@]}" config --images) || fail 'Cannot resolve Compose image names.'
[[ -n "$images" ]] || fail 'Compose did not report any prebuilt images.'
while IFS= read -r image; do
    [[ -n "$image" ]] || continue
    docker image inspect "$image" >/dev/null 2>&1 || fail "Image $image is unavailable locally. Build it before running this check."
done <<<"$images"

status=0
printf 'Checking TTS operations on its configured device...\n'
if ! "${compose[@]}" run --rm --no-deps -T --pull never --entrypoint python tts -u - <<'PY'
from contextlib import nullcontext
import os
import platform
import sys

try:
    import torch
    import torch.nn.functional as F

    device = os.environ.get("TTS_DEVICE", "cuda:0")
    if device not in {"cpu", "cuda:0"}:
        raise ValueError("TTS_DEVICE must be cpu or cuda:0.")
    print(f"CPU platform: {platform.machine()}; Python: {platform.python_version()}")
    print(f"PyTorch: {torch.__version__}; bundled CUDA: {torch.version.cuda}")
    if device == "cuda:0":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA unavailable; check host driver and NVIDIA Container Toolkit.")
        torch.cuda.set_device(0)
        print(f"GPU: {torch.cuda.get_device_name(0)}; capability: {torch.cuda.get_device_capability(0)}")
        print(f"Compiled Torch architectures: {torch.cuda.get_arch_list()}")
        if not torch.backends.cudnn.is_available():
            raise RuntimeError("cuDNN is unavailable in this PyTorch image.")
        print(f"cuDNN: {torch.backends.cudnn.version()}")
        convolution_backend = torch.backends.cudnn.flags(enabled=True, benchmark=False, deterministic=True)
    else:
        print("TTS configured CPU: no TTS GPU execution verified.")
        convolution_backend = nullcontext()
    with torch.inference_mode():
        matrix = torch.ones((32, 32), device=device)
        product = matrix @ matrix
        with convolution_backend:
            convolution = F.conv1d(
                torch.ones((1, 4, 32), device=device),
                torch.ones((8, 4, 3), device=device),
            )
        if device == "cuda:0":
            torch.cuda.synchronize()
        if not torch.allclose(product, torch.full_like(product, 32)):
            raise RuntimeError("TTS matrix multiply returned an incorrect result.")
        if not torch.allclose(convolution, torch.full_like(convolution, 12)):
            raise RuntimeError("TTS convolution returned an incorrect result.")
    print(f"PASS: TTS image executed matrix multiply and convolution on {device}.")
except Exception as exc:
    print(f"FAIL: TTS device check: {type(exc).__name__}: {exc}", file=sys.stderr)
    sys.exit(1)
PY
then
    printf 'FAIL: TTS image device check failed.\n' >&2
    status=1
fi

printf 'Checking LLM CUDA device discovery...\n'
if output=$("${compose[@]}" run --rm --no-deps -T --pull never \
    --entrypoint /opt/llama/bin/llama-server llm --list-devices 2>&1); then
    printf '%s\n' "$output"
    if grep -Eq '^[[:space:]]*CUDA[0-9]+:[[:space:]]+[^[:space:]]' <<<"$output"; then
        printf 'PASS: LLM image reports a CUDA device.\n'
    else
        printf 'FAIL: LLM image did not report an available CUDA device.\n' >&2
        status=1
    fi
else
    printf '%s\n' "$output" >&2
    printf 'FAIL: llama-server --list-devices failed; check its build, CPU compatibility, and GPU driver.\n' >&2
    status=1
fi

if (( status == 0 )); then
    printf 'Runtime checks passed for the configured TTS device and LLM CUDA discovery. Model loading, inference, and memory fit still require a separate test.\n'
fi
exit "$status"
