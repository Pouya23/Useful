#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"
[[ -f config.env ]] || cp config.env.example config.env
export DOCKER_BUILDKIT=1
bash scripts/build_limited.sh
bash scripts/check_gpu.sh
docker compose --env-file config.env -f docker/compose.yaml up -d
docker compose --env-file config.env -f docker/compose.yaml ps
