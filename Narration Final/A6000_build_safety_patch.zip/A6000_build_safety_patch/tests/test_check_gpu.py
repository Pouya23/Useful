"""Exercise check_gpu.sh control flow with a fake Docker CLI; no GPU required."""
import ast
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "overlay/scripts/check_gpu.sh"
MOCK_DOCKER = r'''
import json, os, pathlib, sys
args = sys.argv[1:]
with open(os.environ["CHECK_GPU_TEST_LOG"], "a") as stream:
    stream.write(json.dumps({"args": args, "cwd": os.getcwd()}) + "\n")
case = os.environ.get("CHECK_GPU_TEST_CASE", "ok")
if args[:2] == ["image", "inspect"]:
    sys.exit(1 if case == "missing_image" and args[-1] == "test/llm:local" else 0)
if args[:5] != ["compose", "--env-file", "config.env", "-f", "docker/compose.yaml"]:
    sys.exit("Unexpected Docker command")
if args[5:] == ["config", "--images"]:
    print("test/tts:local\ntest/llm:local")
    sys.exit(0)
if args[5] != "run":
    sys.exit("Only config and run are allowed")
if args[args.index("--entrypoint") + 1] == "python":
    pathlib.Path(os.environ["CHECK_GPU_TEST_PAYLOAD"]).write_text(sys.stdin.read())
    print("Mock TTS check")
    sys.exit(1 if case == "tts_failure" else 0)
if args[-2:] != ["llm", "--list-devices"]:
    sys.exit("Unexpected LLM invocation")
if case == "llm_failure":
    sys.exit("Unable to load libcuda.so.1")
print("Available devices:")
if case == "no_cuda":
    print("  CPU: Mock CPU")
    print("error: CUDA0: initialization failed")
else:
    print("  CUDA0: Mock NVIDIA GPU (8192 MiB, 7000 MiB free)")
'''

# Execute the actual embedded probe without importing Torch. CUDA is deliberately
# unavailable; CPU tensor stubs record which operations the probe reaches.
CPU_TORCH_STUB = r'''
import contextlib, sys, types
class NoCUDA:
    def is_available(self):
        print("STUB: CUDA queried")
        return False
    def __getattr__(self, name):
        raise AssertionError("Unexpected GPU API access: " + name)
class Tensor:
    def __init__(self, shape, value=1):
        self.shape, self.value = shape, value
    def __matmul__(self, other):
        print("STUB: CPU matmul")
        return Tensor((self.shape[0], other.shape[1]), self.shape[1] * self.value * other.value)
def ones(shape, *, device):
    if device != "cpu":
        raise AssertionError("CPU test allocated a tensor on " + device)
    return Tensor(shape)
def conv1d(data, weight):
    print("STUB: CPU conv1d")
    return Tensor((data.shape[0], weight.shape[0], data.shape[-1] - weight.shape[-1] + 1),
                  weight.shape[1] * weight.shape[2] * data.value * weight.value)
torch = types.ModuleType("torch")
torch.__version__ = "cpu-test-stub"
torch.version = types.SimpleNamespace(cuda="unavailable")
torch.cuda = torch.backends = NoCUDA()
torch.inference_mode = contextlib.nullcontext
torch.ones = ones
torch.full_like = lambda tensor, value: Tensor(tensor.shape, value)
torch.allclose = lambda left, right: left.shape == right.shape and left.value == right.value
torch.nn = types.ModuleType("torch.nn")
torch.nn.functional = types.ModuleType("torch.nn.functional")
torch.nn.functional.conv1d = conv1d
sys.modules.update({"torch": torch, "torch.nn": torch.nn, "torch.nn.functional": torch.nn.functional})
'''


class GpuCheckTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="gpu_check_test_")
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.root = self.base / "project with spaces"
        (self.root / "scripts").mkdir(parents=True)
        (self.root / "docker").mkdir()
        shutil.copyfile(SCRIPT, self.root / "scripts/check_gpu.sh")
        (self.root / "config.env").write_text("GPU_DEVICE_ID=2\n")
        (self.root / "docker/compose.yaml").write_text("services: {}\n")
        fake_bin = self.base / "bin"
        fake_bin.mkdir()
        docker = fake_bin / "docker"
        docker.write_text(f"#!{sys.executable}\n" + MOCK_DOCKER)
        docker.chmod(0o755)
        self.log = self.base / "calls.jsonl"
        self.payload = self.base / "gpu_payload.py"
        self.env = dict(os.environ, PATH=f"{fake_bin}:{os.environ['PATH']}",
                        CHECK_GPU_TEST_LOG=str(self.log),
                        CHECK_GPU_TEST_PAYLOAD=str(self.payload))

    def run_check(self, case="ok"):
        result = subprocess.run(
            ["bash", str(self.root / "scripts/check_gpu.sh")], cwd=self.base,
            env=dict(self.env, CHECK_GPU_TEST_CASE=case), capture_output=True,
            text=True, timeout=10,
        )
        self.calls = [json.loads(line) for line in self.log.read_text().splitlines()] if self.log.exists() else []
        self.runs = [call["args"] for call in self.calls if "run" in call["args"]]
        return result

    def test_success_runs_two_isolated_prebuilt_checks(self):
        result = self.run_check()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Runtime checks passed", result.stdout)
        self.assertEqual(len(self.runs), 2)
        self.assertTrue(all(call["cwd"] == str(self.root) for call in self.calls))
        for args in self.runs:
            self.assertIn("--rm", args)
            self.assertIn("--no-deps", args)
            self.assertIn("-T", args)
            self.assertEqual(args[args.index("--pull") + 1], "never")
            self.assertNotIn("--build", args)
            self.assertNotIn("--service-ports", args)
            self.assertNotIn("--gpus", args)  # The selected GPU comes from Compose.
        self.assertEqual(self.runs[0][-3:], ["tts", "-u", "-"])
        self.assertEqual(self.runs[1][-2:], ["llm", "--list-devices"])
        ast.parse(self.payload.read_text())

    def test_missing_image_fails_before_running_containers(self):
        result = self.run_check("missing_image")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("unavailable locally", result.stderr)
        self.assertEqual(self.runs, [])

    def test_tts_failure_still_checks_llm_and_fails_overall(self):
        result = self.run_check("tts_failure")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(len(self.runs), 2)
        self.assertIn("TTS image device check failed", result.stderr)
        self.assertIn("PASS: LLM", result.stdout)

    def test_llm_process_failure_propagates(self):
        result = self.run_check("llm_failure")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Unable to load libcuda.so.1", result.stderr)
        self.assertIn("--list-devices failed", result.stderr)

    def test_success_exit_without_cuda_device_is_failure(self):
        result = self.run_check("no_cuda")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("did not report an available CUDA device", result.stderr)
        self.assertNotIn("Runtime checks passed", result.stdout)

    def test_missing_config_is_actionable_and_does_not_run_docker(self):
        (self.root / "config.env").unlink()
        result = self.run_check()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Missing config.env", result.stderr)
        self.assertEqual(self.calls, [])


class EmbeddedTtsProbeTest(unittest.TestCase):
    def run_probe(self, device):
        payload = SCRIPT.read_text().split("<<'PY'\n", 1)[1].split("\nPY\n", 1)[0]
        return subprocess.run(
            [sys.executable, "-c", CPU_TORCH_STUB + "\n" + payload],
            env=dict(os.environ, TTS_DEVICE=device), capture_output=True, text=True, timeout=10,
        )

    def test_explicit_cpu_executes_both_operations_without_querying_cuda(self):
        result = self.run_probe("cpu")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("TTS configured CPU: no TTS GPU execution verified", result.stdout)
        self.assertIn("STUB: CPU matmul", result.stdout)
        self.assertIn("STUB: CPU conv1d", result.stdout)
        self.assertIn("convolution on cpu", result.stdout)
        self.assertNotIn("STUB: CUDA queried", result.stdout)

    def test_cuda_unavailable_fails_without_automatic_cpu_fallback(self):
        result = self.run_probe("cuda:0")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("CUDA unavailable", result.stderr)
        self.assertNotIn("STUB: CPU", result.stdout)

    def test_unsupported_tts_device_is_rejected_before_operations(self):
        result = self.run_probe("cuda:1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("TTS_DEVICE must be cpu or cuda:0", result.stderr)
        self.assertNotIn("STUB:", result.stdout)


if __name__ == "__main__":
    unittest.main()
