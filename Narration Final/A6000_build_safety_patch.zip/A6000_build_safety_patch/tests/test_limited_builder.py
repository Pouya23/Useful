"""Exercise the real shell helper against a fake Docker CLI, never a daemon."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


OVERLAY = Path(__file__).resolve().parents[1] / "overlay"
MOCK_DOCKER = r'''#!/usr/bin/env python3
import json, os, pathlib, re, sys
a = sys.argv[1:]
folder = pathlib.Path(os.environ["MOCK_DOCKER_DIR"])
with (folder / "calls.jsonl").open("a") as f:
    f.write(json.dumps(a) + "\n")
state_path = folder / "state.json"
s = json.loads(state_path.read_text()) if state_path.exists() else {}
def save():
    state_path.write_text(json.dumps(s))
def value(flag):
    return a[a.index(flag) + 1]
if a[:2] == ["compose", "version"]:
    print(os.environ.get("MOCK_COMPOSE_VERSION", "2.30.3"))
elif a[:3] == ["compose", "build", "--help"]:
    print("--builder string" if os.environ.get("MOCK_BUILDER_FLAG", "1") == "1" else "--no-cache")
elif a[:2] == ["buildx", "version"]:
    print("github.com/docker/buildx v" + os.environ.get("MOCK_BUILDX_VERSION", "0.17.1") + " test")
elif a[0] == "info":
    print(os.environ.get("MOCK_HOST_BYTES", str(64 * 1024**3)), "16", os.environ.get("MOCK_MEMORY_SUPPORT", "true"), "true true true mock-engine")
elif a[:2] == ["buildx", "ls"]:
    print(s.get("name", ""))
elif a[:2] == ["buildx", "create"]:
    assert "--use" not in a
    assert not s, "Existing builders must not be overwritten"
    s.update(name=value("--name"), node=value("--node"), driver=value("--driver"), options={})
    for i, arg in enumerate(a):
        if arg == "--driver-opt":
            key, val = a[i + 1].split("=", 1)
            s["options"][key] = val
    s["config"] = pathlib.Path(value("--buildkitd-config")).read_text()
    save()
    print(s["name"])
elif a[:2] == ["buildx", "inspect"]:
    assert s["name"] in a
    print("Name:", s["name"])
    print("Driver:", s["driver"])
    print("Nodes:\nName:", s["node"])
    print("Endpoint: default")
    print("Driver Options:", " ".join(k + "=" + json.dumps(v) for k, v in s["options"].items()))
elif a[0] == "inspect":
    assert a[-1] == "buildx_buildkit_" + s["node"]
    o = s["options"]
    owner = o.get("env.NARRATION_BUILDER_ID", "missing")
    marker = "owned" if "NARRATION_BUILDER_ID=" + owner + '"' in value("--format") else ""
    print(o["memory"], o["memory-swap"], o["cpu-quota"], o["cpu-period"], marker)
elif a[0] == "exec":
    assert a[2:] == ["cat", "/etc/buildkit/buildkitd.toml"]
    print(s["config"])
elif a[:2] == ["buildx", "stop"]:
    assert a[-1] == s["name"]
elif a[0] == "compose" and "build" in a:
    assert value("--builder") == s["name"]
    assert value("--env-file") == "config.env"
    assert value("-f") == "docker/compose.yaml"
    assert os.environ["COMPOSE_PARALLEL_LIMIT"] == "1"
    assert os.environ["COMPOSE_BAKE"] == "false"
    print("Mock build " + a[-1])
    if a[-1] == os.environ.get("MOCK_FAIL_SERVICE"):
        sys.exit(17)
else:
    raise SystemExit("Unexpected Docker command: " + repr(a))
'''


class LimitedBuilderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="limited-builder-")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.project = self.root / "project with spaces"
        for name in ("scripts", "docker"):
            (self.project / name).mkdir(parents=True, exist_ok=True)
        shutil.copy2(OVERLAY / "scripts/build_limited.sh", self.project / "scripts/build_limited.sh")
        shutil.copy2(OVERLAY / "docker/buildkitd.toml", self.project / "docker/buildkitd.toml")
        (self.project / "docker/compose.yaml").write_text("services: {}\n")
        (self.project / "config.env.example").write_text("LLM_IMAGE=example/llm:test\nTTS_IMAGE=example/tts:test\n")
        self.bin = self.root / "bin"
        self.bin.mkdir()
        (self.bin / "docker").write_text(MOCK_DOCKER)
        (self.bin / "docker").chmod(0o755)
        self.env = os.environ.copy()
        for name in ("BUILD_CPUS", "BUILD_MEMORY_MIB"):
            self.env.pop(name, None)
        self.env.update(PATH=str(self.bin) + os.pathsep + self.env["PATH"], MOCK_DOCKER_DIR=str(self.root))

    def run_helper(self, **overrides):
        return subprocess.run(
            ["bash", str(self.project / "scripts/build_limited.sh")],
            cwd=self.root, env={**self.env, **overrides}, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15,
        )

    def calls(self):
        p = self.root / "calls.jsonl"
        return [json.loads(line) for line in p.read_text().splitlines()] if p.exists() else []

    def state(self):
        return json.loads((self.root / "state.json").read_text())

    def alter(self, change):
        state = self.state()
        change(state)
        (self.root / "state.json").write_text(json.dumps(state))

    def builds(self):
        return [a for a in self.calls() if a[0] == "compose" and "build" in a and "--help" not in a]

    def test_new_builder_has_caps_serial_builds_local_loading_and_cleanup(self):
        result = self.run_helper()
        self.assertEqual(result.returncode, 0, result.stderr)
        options = self.state()["options"]
        self.assertEqual(options["memory"], str(8 * 1024**3))
        self.assertEqual(options["memory-swap"], options["memory"])
        self.assertEqual(options["cpu-quota"], "100000")
        self.assertEqual(options["cpu-period"], "100000")
        self.assertEqual(options["default-load"], "true")
        self.assertEqual([a[-1] for a in self.builds()], ["llm", "tts"])
        self.assertEqual(self.calls()[-1][:2], ["buildx", "stop"])
        self.assertTrue((self.project / "config.env").exists())
        logs = list((self.project / "logs").glob("*.log"))
        self.assertEqual(len(logs), 1)
        self.assertIn("Mock build tts", logs[0].read_text())
        self.assertFalse(any("--use" in a or "up" in a or "rm" in a or "prune" in a for a in self.calls()))

    def test_default_memory_is_quarter_on_smaller_daemon(self):
        result = self.run_helper(MOCK_HOST_BYTES=str(12 * 1024**3))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.state()["options"]["memory"], str(3 * 1024**3))

    def test_explicit_limits_apply(self):
        result = self.run_helper(BUILD_MEMORY_MIB="4096", BUILD_CPUS="2")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.state()["options"]["memory"], str(4 * 1024**3))
        self.assertEqual(self.state()["options"]["cpu-quota"], "200000")

    def test_existing_owned_builder_is_verified_and_reused(self):
        self.assertEqual(self.run_helper().returncode, 0)
        result = self.run_helper()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(sum(a[:2] == ["buildx", "create"] for a in self.calls()), 1)
        self.assertEqual(len(self.builds()), 4)

    def test_failure_stops_builder_and_never_builds_next_service(self):
        result = self.run_helper(MOCK_FAIL_SERVICE="llm")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("llm build failed", result.stderr)
        self.assertEqual([a[-1] for a in self.builds()], ["llm"])
        self.assertEqual(self.calls()[-1][:2], ["buildx", "stop"])
        self.assertFalse(any("up" in a for a in self.calls()))

    def test_invalid_or_excessive_limits_never_create_builder(self):
        for overrides in ({"BUILD_MEMORY_MIB": "0"}, {"BUILD_MEMORY_MIB": "-1"},
                          {"BUILD_MEMORY_MIB": "40000"}, {"BUILD_CPUS": "2.5"}, {"BUILD_CPUS": "17"}):
            with self.subTest(overrides=overrides):
                self.assertNotEqual(self.run_helper(**overrides).returncode, 0)
        self.assertFalse(any(a[:2] == ["buildx", "create"] for a in self.calls()))

    def test_unsupported_tools_and_host_stop_before_build_creation(self):
        for overrides in ({"MOCK_COMPOSE_VERSION": "1.29.2"}, {"MOCK_BUILDER_FLAG": "0"},
                          {"MOCK_BUILDX_VERSION": "0.13.1"}, {"MOCK_MEMORY_SUPPORT": "false"}):
            with self.subTest(overrides=overrides):
                self.assertNotEqual(self.run_helper(**overrides).returncode, 0)
        self.assertFalse(any(a[:2] == ["buildx", "create"] for a in self.calls()))

    def test_resource_mismatch_prevents_reuse_without_stopping_external_builder(self):
        self.assertEqual(self.run_helper().returncode, 0)
        before = len(self.calls())
        self.alter(lambda state: state["options"].update(memory="0"))
        result = self.run_helper()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("different resource limits", result.stderr)
        self.assertFalse(any(a[:2] in (["buildx", "create"], ["buildx", "stop"]) for a in self.calls()[before:]))
        self.assertEqual(len(self.builds()), 2)

    def test_ownership_collision_is_rejected(self):
        self.assertEqual(self.run_helper().returncode, 0)
        self.alter(lambda state: state["options"].update({"env.NARRATION_BUILDER_ID": "another-project"}))
        result = self.run_helper()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("unverified ownership", result.stderr)
        self.assertEqual(len(self.builds()), 2)

    def test_changed_driver_or_image_loading_is_rejected(self):
        self.assertEqual(self.run_helper().returncode, 0)
        self.alter(lambda state: state.update(driver="docker"))
        self.assertNotEqual(self.run_helper().returncode, 0)
        self.alter(lambda state: state.update(driver="docker-container"))
        self.alter(lambda state: state["options"].update({"default-load": "false"}))
        self.assertNotEqual(self.run_helper().returncode, 0)
        self.assertEqual(len(self.builds()), 2)

    def test_changed_worker_parallelism_is_rejected(self):
        self.assertEqual(self.run_helper().returncode, 0)
        self.alter(lambda state: state.update(config="[worker.oci]\nmax-parallelism = 8\n"))
        result = self.run_helper()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("max-parallelism", result.stderr)
        self.assertEqual(len(self.builds()), 2)

    def test_config_is_never_executed_or_echoed(self):
        (self.project / "config.env").write_text("SECRET=private-test-value\nSIDE_EFFECT=$(touch was-executed)\n")
        result = self.run_helper()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertFalse((self.project / "was-executed").exists())
        text = result.stdout + result.stderr + "".join(p.read_text() for p in (self.project / "logs").glob("*.log"))
        self.assertNotIn("private-test-value", text)


if __name__ == "__main__":
    unittest.main()
