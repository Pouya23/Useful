# Changes and validation

The supplied `modular_qwen_pipeline` directory was read without modifying it. The new `LLM` folder is a collection of executable scripts and their internal helper modules, not an installable library.

## Preserved behavior

The original system/task prompt, source/sample handling, default sampling (temperature 0.7, top-p 0.8, top-k 20), per-round seed sequence, word-count policy, decimal duration-to-word rounding, output-token budgets, exact context admission, truncation rejection, single-GPU isolation, sampled GPU guards, default CPU KV placement and native prefix reuse are retained. Each round still receives the complete original brief, latest text and latest feedback. Generation history remains in artifacts rather than accumulating in prompts.

The source already implemented automatic retry fitting, estimated/API acceptance, saving generations and closest-round selection. These behaviors were retained and strengthened rather than duplicated. `--max-retries` still counts revisions after the draft; `--max-rounds` adds a total-generation convention.

## Improvements

1. Removed hosted-platform setup code, paths, branches and examples; removed runtime pip installation and implicit model downloads.
2. Added model/revision/digest configuration, preserving pinned Qwen defaults. Native custom GGUFs use their native instruct templates. Transformers chooses its original Qwen class/prefill or a supported Auto causal model. All worker model loading is offline.
3. Cached the static original-context serialization once per job and normalized style-sample tokens once per job. Prompt bytes remain identical for equivalent requests.
4. Made streamed word counting incremental: linear total work and constant progress-counter state rather than repeatedly storing and recounting growing text. Word-count semantics, including Unicode and punctuation boundaries, are unchanged.
5. Applied Torch inference mode inside the generation thread; the previous outer context was thread-local and did not cover streaming generation. A model exception now ends the stream and propagates instead of leaving the consumer waiting forever.
6. Removed an unnecessary copied candidate result. Cached deterministic duration measurements for identical texts within a run. Added explicit `final.txt`/`final.json` and persisted the selected fit inside `job.json`.
7. Validated API host/IPv6, speech settings and finite positive duration responses. Added CLI speech/transport settings and proxy isolation for local API calls. API keys remain absent from saved credentials.
8. Retained out-of-spec API candidates as saved rounds, directed them toward valid text length, and excluded unmeasured candidates from accurate best-of selection. A run with no measurable candidate reports the API limitation truthfully.
9. Made memory ceiling/reserve configurable for the A6000, retaining the original defaults. Unregistered closed sessions from atexit; removed unnecessary retained job references. Startup errors now clean up the native session even before the server has started.
10. Replaced host-specific download/install scripts with conda bootstrap, frozen complete wheel sets, curl downloads, checksum verification, compatible-wheel checks, and offline pip installation. No source-distribution fallback and no merging of incompatible Torch stacks.
11. The native source build targets Ubuntu 20.04 directly, with a fixed commit and configurable CUDA architectures. Disabled prebuilt UI downloads and unused native HTTPS/NCCL dependencies. Kept NVIDIA driver installation separate from toolkit provisioning.

## Verified

- **73 tests passed under Python 3.11.11.** Tests include the original prompt digest, draft/revision policies, truncation failure retention, retry counts, earlier-round best selection, final-file persistence, duration checks, adapter contracts, incremental Unicode word progress and a real local HTTP `/duration` request with `X-API-Key`. The HTTP test confirms that `success:false` at status 200 is handled as a valid natural-duration response.
- Bash syntax checks passed for both installation/build scripts.
- Python source compilation passed.
- Complete dependency closure checked against each pinned package's published metadata, including environment markers/extras, Python 3.11.11 requirements and wheel availability for Linux x86_64/glibc 2.31: **13 native, 60 Transformers, 207 vLLM packages**, no missing/conflicting declared dependencies. Evidence: `locks/audit.json` and `locks/*-artifacts.json`.
- CPU microbenchmarks against the original scripts confirmed equal prompts. With a 96,000-character source, cached prompt assembly took approximately 0.0020 versus 0.0655 seconds per 100 calls (32× for that helper). For 2,000 streamed word pieces, incremental progress took approximately 0.0025 versus 1.812 seconds (734× for that helper). Raw measurements and scope are in `cpu_benchmark.json`. These are illustrative helper costs, not end-to-end generation speedups.

## Still requires hardware validation

This workspace is Windows; the Ubuntu installer, CUDA source compilation, model loading, real GPU generation, VRAM peaks and actual Kokoro service were not executed here. Dependency metadata/wheel compatibility checks do not prove binary/kernel compatibility on your particular driver. No guarantee of identical sampled text or improved GPU throughput is made; swapping models, engines, quantization or Torch versions can affect outputs even with equal seeds.

The approximately 11 GB GPU was not identified by model. The default native build covers SM 6.1/7.5/8.6; adjust it for your actual card. Begin with native Q5_K_M and CPU KV, then use the retained sequential comparison script for A6000 measurements. Modern vLLM's CUDA 13 profile is intended for a compatible A6000/driver, not an arbitrary old card.

Accurate mode uses the server's natural Kokoro duration plan, not encoded audio duration or its post-stretch target. `/duration` accepts only 10–1000 words and targets ≤1800 seconds. If all candidates fall outside its input limits, no exact closest duration exists; the script reports that and retains every round rather than inventing a duration. Transport/HTTP failures preserve generated artifacts and stop the run.

NVML remains a sampled guard, not a hard allocator cap; its default sampling rate and fail-closed behavior are preserved. CPU KV saves GPU memory at a possible speed cost. Optional higher memory/GPU-KV settings are explicit deployment choices.
