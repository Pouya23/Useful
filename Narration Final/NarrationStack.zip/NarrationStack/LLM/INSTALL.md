# Ubuntu 20.04: complete installation and use

Keep this `LLM` folder beside `containers/` in the extracted NarrationStack. Run the files directly; do not install this project with pip. Python is provided by a fixed Miniconda installer, and the environment is named **LLM**.

## 1. Choose paths, proxy and inference stack

```bash
cd /your/path/LLM
export DOWNLOAD_DIR="/your/chosen/path/LLM-downloads"
export CONDA_ROOT="$HOME/miniconda-LLM"
export DOWNLOAD_PROXY="socks5h://YOUR_PROXY_IP:YOUR_PROXY_PORT"
export PROFILE=native
```

`DOWNLOAD_DIR` holds the Miniconda installer, wheel sets, CUDA installer, source archive, weights (with the commands below), temporary CUDA extraction files and manifests. Installed files live in `CONDA_ROOT`; compiled native files live in `LLM/runtime`. No proxy/IP/path is hardcoded.

The small `native` profile runs llama.cpp and is the starting configuration for your approximately 11 GB GPU. `transformers` adds the original Transformers/NF4 path with official CUDA 11.8 Torch. `vllm` supplies the original vLLM path with its own CUDA 13.0 Torch dependency set. Choose one profile per environment. To compare all three, create separate `CONDA_ROOT` prefixes, each containing an environment named LLM, and pass their Python paths to `compare_engines.py`.

For a proxy issuing its own certificates, use its CA file:

```bash
export CURL_CA_BUNDLE="/path/to/proxy-ca.pem"
```

If your particular proxy only works with curl's insecure mode, explicitly opt in:

```bash
export CURL_INSECURE=1
```

The installer still verifies fixed SHA256 digests for Miniconda, wheels and llama.cpp source. NVIDIA publishes an MD5 checksum for its CUDA 12.2.2 runfile; that is checked too. Downloading through curl never configures pip's network access. No direct-network fallback bypasses your chosen proxy.

## 2. Ubuntu system prerequisites

Python and Python libraries need not be installed. A working NVIDIA driver is required for GPU execution. The native CUDA 12.2.2 configuration uses driver **535.104.05 or newer**, compatible with your installed **535.183.01**. Your test GPU is a **GTX 1080 Ti (Pascal SM 6.1)**; the native default build includes SM 6.1, 7.5 and 8.6. The RTX A6000 uses SM 8.6. Choose a driver that supports both your actual card and the selected runtime.

On a normal Ubuntu 20.04 installation, prepare the OS utilities/compiler:

```bash
sudo apt-get update
sudo apt-get install -y curl ca-certificates build-essential pkg-config
```

Those commands manage Ubuntu's signed OS packages. They do not install Python or use pip. If the server's apt transport also cannot use the proxy, download its `.deb` artifacts through curl using this alternative **after apt package lists have been populated**:

```bash
mkdir -p "$DOWNLOAD_DIR/os-debs"
sudo apt-get --print-uris --yes install curl ca-certificates build-essential pkg-config \
  | sed -n "s/^'\([^']*\)' \([^ ]*\) .*/\1 \2/p" \
  > "$DOWNLOAD_DIR/os-debs/downloads.txt"
while read -r url filename; do
  curl --fail --location --retry 5 --proxy "$DOWNLOAD_PROXY" \
    --output "$DOWNLOAD_DIR/os-debs/$filename" "$url"
done < "$DOWNLOAD_DIR/os-debs/downloads.txt"
sudo apt-get -o Dir::Cache::archives="$DOWNLOAD_DIR/os-debs" \
  --no-download --yes install curl ca-certificates build-essential pkg-config
dpkg-query -W curl ca-certificates gcc g++ make libc6 libc6-dev \
  > "$DOWNLOAD_DIR/os-debs/installed-versions.txt"
```

If curl itself is absent and apt is inaccessible, transfer the matching Ubuntu curl/CA `.deb` packages from another machine first. This bootstrap cannot fetch files before any download tool exists. OS patch versions come from your Ubuntu repositories; application libraries below are all pinned independently.

## 3. Create LLM, download pinned wheels, install offline

```bash
bash install_ubuntu.sh
source "$CONDA_ROOT/etc/profile.d/conda.sh"
conda activate "$CONDA_ROOT/envs/LLM"
source runtime/activate_python.sh
python --version
```

The installer downloads **Miniconda3-py311_25.1.1-2-Linux-x86_64.sh**, verifies its SHA256, installs it and clones its bundled packages offline into LLM. It then downloads only the frozen compatible wheels through curl and installs them with `pip --no-index --no-deps --require-hashes`. No pip/conda network resolution is needed. It runs `pip check` and the CPU regression suite.

Offline cloning disables external plugins, uses the built-in classic solver and the bootstrap's own `pkgs` cache, and creates/activates an absolute prefix. This avoids the network/TOS failure in your log and interference from the active Python 3.9 base/user `.condarc`. Activate that exact prefix in your parent shell after the script finishes. The installer also installs `../containers/common.lock` for Flask/Swagger/API dependencies, so both the CLI and API imports work in the host environment; retain the entire NarrationStack folder structure.

Every application dependency, including transitive dependencies, is listed with an exact version:

- [`locks/native.txt`](locks/native.txt): 13 packages, including tests and native build tools.
- [`locks/transformers.txt`](locks/transformers.txt): 58 packages, including all Torch CUDA runtime libraries.
- [`locks/vllm.txt`](locks/vllm.txt): 207 packages, including the complete vLLM dependency closure.
- `locks/*-artifacts.json`: frozen wheel filenames, URLs and SHA256 digests for Python 3.11 / Linux x86_64 / glibc 2.31.
- `DOWNLOAD_DIR/manifests/conda-explicit.txt` and `conda-packages.json`: every bundled conda package, exact version/build, including Python and its native libraries.
- `DOWNLOAD_DIR/manifests/pip-PROFILE.txt`: the complete installed Python distribution inventory.

Pinned core versions: Python **3.11.11**, conda bootstrap **25.1.1**, pip **25.0.1**, setuptools **80.9.0**, wheel **0.45.1**, nvidia-ml-py **12.575.51**, wrapt **1.17.3**, psutil **7.1.0**, packaging **25.0**, pytest **8.4.2**, CMake **3.31.6**, Ninja **1.11.1.4**. Transformers profile: Transformers **5.13.0**, Accelerate **1.15.0**, bitsandbytes **0.50.2**, Torch **2.6.0+cu118** (official Linux CUDA 11.8 build). vLLM profile: vLLM **0.31.0**, vllm-bnb-plugin **0.0.3**, Torch **2.13.0**, Transformers **5.17.0**, bitsandbytes **0.50.2**. Use the lock files for the full lists, not only this summary.

The vLLM 0.31 release's PyPI build uses CUDA 13.0. Use an appropriate **580-series or newer driver** and a supported GPU. It is intended here for the A6000. vLLM requires compute capability ≥7.5; CUDA 13 also drops pre-Turing support. Your GTX 1080 Ti cannot run that profile; use native or Transformers. The installer checks this before downloading the application wheels. The native CUDA 12.2.2 route avoids that dependency stack.

## 4. Build the native server on Ubuntu 20.04

Building on your OS avoids importing release binaries compiled against a newer glibc. The fixed source is llama.cpp **b11384**, commit `0faee5004297c3bcfa40b7bf11750127b8c1fd7d`.

```bash
export CUDA_ARCHS="61;75;86"
export BUILD_JOBS=4
bash build_native.sh
source runtime/activate_native.sh
"$LLAMA_SERVER" --version
```

This downloads and installs the CUDA toolkit **12.2.2** to `DOWNLOAD_DIR/cuda-12.2.2` without replacing the driver. For an existing toolkit, set `CUDA_ROOT=/absolute/path/to/cuda-12.2.2`. To build just for the A6000 set `CUDA_ARCHS=86`. Lower `BUILD_JOBS` if the host has little RAM. The build enables CUDA and the server, disables native-CPU tuning for portability, and uses the pinned CMake/Ninja wheels.

## 5. Download the original model through curl

```bash
python download_model.py --kind gguf \
  --download-dir "$DOWNLOAD_DIR/models"
export GGUF_MODEL="$DOWNLOAD_DIR/models/Qwen3.5-9B-Q5_K_M.gguf"
```

This preserves the original 6,577,841,376-byte Q5_K_M model, pinned HF commit and SHA256. Generation will never implicitly download a model or install packages.

For the Transformers or vLLM path, explicitly download the original HF model instead:

```bash
python download_model.py --kind hf \
  --download-dir "$DOWNLOAD_DIR/models/Qwen3.5-9B-HF"
```

The downloader freezes a branch to a commit and saves `download-provenance.json`. It obtains safetensors weights and tokenizer/config files. These commands support public HF repositories; for gated models download authorized files separately and pass their local directory to `--model`.

## 6. Estimated duration: default mode

```bash
python run_pipeline.py \
  --engine llama_cpp --server "$LLAMA_SERVER" --gguf-model "$GGUF_MODEL" \
  --duration-seconds 180 --speaking-rate-wpm 130 --duration-tolerance 0.10 \
  --max-retries 5 --estimate \
  --title "Maintenance of pipe handling systems" \
  --instructions "Write clear spoken training using the supplied sources." \
  --point "Report defects and follow approved procedures." \
  --source /path/to/reference.txt --sample /path/to/style-example.txt \
  --gpu-index 0 --context-tokens 32768 --kv-cache-device cpu \
  --show-progress --output /path/to/new-run-directory
```

The output directory must not already exist. Repeat `--source`, `--sample` or `--point` for more inputs; samples and sources are optional. At 180 seconds and 130 WPM the target is 390 words and the 10% band is **351–429 words**. The first in-range generation ends the loop immediately.

`--max-retries 5` permits one draft plus at most five revisions. `--max-rounds 5` instead permits at most five total generations, including the draft. At the limit, the closest candidate to the band wins; ties use target error, then the earlier round. No truncating/padding text to force a fit.

## 7. Accurate duration: use your Kokoro server

```bash
# Optional; the environment variable avoids exposing a key in the command line.
export DURATION_API_KEY="YOUR_KEY_IF_REQUIRED"
python run_pipeline.py \
  --engine llama_cpp --server "$LLAMA_SERVER" --gguf-model "$GGUF_MODEL" \
  --duration-seconds 180 --speech-duration-tolerance 0.05 \
  --no-estimate --max-rounds 6 \
  --duration-api-host 192.168.1.50 --duration-api-port 8080 \
  --duration-api-scheme http --duration-api-timeout 120 \
  --voice am_onyx --lang-code a --speech-speed 1.0 \
  --atempo-min 0.93 --atempo-max 1.15 \
  --title "Maintenance of pipe handling systems" \
  --source /path/to/reference.txt --output /path/to/new-accurate-run
```

`--duration-api-key` is also supported. The key is sent as `X-API-Key` and redacted from saved fit settings. API requests bypass environment download proxies by default; add `--duration-api-use-proxy` only if this server also needs one.

The acceptable range here is **171–189 seconds**, comparing `estimated_natural_duration_s`. This is the supplied server's sample-exact **natural Kokoro plan**, not measured encoded audio. `success:false` at HTTP 200 only means its tempo window does not fit; the natural duration remains usable. Comparing `estimated_final_duration_s` would be misleading because a stretched fit usually equals the requested duration.

Requests use only the allowed JSON fields. The default seed is 42, split pattern is `"\n+"`, sample rate 48000 and bitrate 320. Targets must be ≤1800 seconds. Text outside 10–1000 words / 100,000 characters is saved and directed toward a valid size without pretending it has an accurate measurement. If no candidate can be measured, the run reports that limitation instead of inventing an exact best result. Transport/HTTP/invalid-response failures stop the run with all already-generated texts retained; there is no silent switch to estimates.

## 8. Swap models and use the A6000

For any instruct GGUF architecture supported by the pinned llama.cpp build:

```bash
python run_pipeline.py --engine llama_cpp \
  --server "$LLAMA_SERVER" --gguf-model /path/to/another-instruct-model.gguf \
  --duration-seconds 180 --max-retries 5 \
  --vram-limit-gb 48 --headroom-gb 2 --kv-cache-device gpu
```

Optionally add `--model-sha256 EXPECTED_DIGEST`. The model must carry its own native chat template. Changing a model changes generation behavior; the writing workflow stays the same.

For other locally downloaded text models using Transformers:

```bash
python run_pipeline.py --engine transformers \
  --model /path/to/downloaded-hf-model --duration-seconds 180 \
  --vram-limit-gb 48 --headroom-gb 2 --dtype auto
```

Or `--engine vllm` in its matching environment. `--model-revision COMMIT` supports pre-cached HF repository IDs; local directories are easier with this proxy. Engines run offline. Transformers uses its original Qwen3.5 chunked prefill when appropriate, and an Auto causal-model loader for other supported text models. Model support is bounded by the chosen engine/version, NF4 support and GPU capacity.

## Outputs and auxiliary scripts

Under `output/jobs/JOB_ID/`, each generation is saved as a numbered text file. `passes.json`, `job.json`, `fit_rounds.json` and `fit_summary.json` retain metrics and selection. **`final.txt` is the selected narration; `final.json` is its full result**, including a possibly unmet fit at retry exhaustion. Raw input/output and GPU telemetry remain under the session directory.

`maintenance_example.py` retains the fictional interactive training example. Set `LLAMA_SERVER` and `LLM_GGUF_MODEL` first. `compare_engines.py` retains the sequential comparison; use its `--gguf-model`, `--server`, `--transformers-python` and `--vllm-python` options. Its jobs permit human feedback independently of the CLI's automatic retry cap.

## Sources used to check compatibility

- [Miniconda release/checksum index](https://repo.anaconda.com/miniconda/)
- [PyTorch version/CUDA installation matrix](https://docs.pytorch.org/get-started/previous-versions/)
- [NVIDIA CUDA 12.2.2 Linux installation guide](https://docs.nvidia.com/cuda/archive/12.2.2/cuda-installation-guide-linux/)
- [NVIDIA CUDA 12.2.2 published checksums](https://developer.download.nvidia.com/compute/cuda/12.2.2/docs/sidebar/md5sum.txt)
- [vLLM 0.31.0 release, including CUDA 13 PyPI builds](https://github.com/vllm-project/vllm/releases/tag/v0.31.0)
- [vLLM GPU requirements](https://docs.vllm.ai/en/v0.31.0/getting_started/installation/gpu/)
