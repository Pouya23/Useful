# Original pipeline: execution map

This map was written from the supplied Python files before changing their execution path.

1. `run_pipeline.py` invokes the CLI. Parse engine, writing brief, sources, samples, duration, word-rate, tolerance, GPU, context and output settings.
2. Read source/sample files as UTF-8, accepting a BOM. Construct and validate `WritingRequest`. Reject contradictory word bounds, invalid durations and impossible direction requests.
3. Convert duration to words: round seconds × WPM / 60 half-up. Apply the relative tolerance, flooring the lower bound and ceiling the upper bound, clamped to 20–20,000 words.
4. Validate automatic fitting settings. Estimate mode is the default. API mode requires a host and port. The original already implements five **revisions after the draft**, not five total generations.
5. Open one resident inference session. Create a fresh output directory. Select llama.cpp, Transformers or vLLM. Acquire a GPU UUID advisory lock. Start fail-closed NVML telemetry and a sampled memory guard.
6. Native path: optionally install Python dependencies; provision the native runtime on the hosted platform; obtain/check the pinned Qwen GGUF. Inspect its metadata and native chat template. Start an owned CUDA server over a private Unix socket. Fit GPU layers while retaining the requested context and CPU KV default. Check actual GPU offload evidence.
7. Python path: isolate the selected GPU by UUID; launch a resident worker. Load pinned Qwen weights with NF4 through Transformers, or bitsandbytes through vLLM. Retain one model for all rounds. Chunk prefill and bound memory. No sharding, silent CPU fallback or input trimming.
8. Create a job. Build the original context prefix from the complete brief. Samples supply style; sources supply evidence. Preserve the original system/task instructions. Include only the current draft and feedback, not accumulated generation history.
9. Compute the output-token allowance. Render the model's native chat template with thinking disabled. Count actual prompt tokens and reject overflow before inference.
10. Generate exactly one completion at temperature 0.7, top-p 0.8, top-k 20, with seed 42 + attempted completion count. Native engine reuses matching prefixes; Python engines initially do not.
11. Measure latency and sampled GPU usage. Save input JSON, raw output JSON, generation/validation events, per-round text, `passes.json` and `job.json`. Reject truncation, empty text and model control/thinking tokens; retain failed raw output for inspection.
12. Count words locally, derive automatic length feedback, estimate seconds, detect exact sample overlap and report source/quality limitations. No model self-scoring call.
13. Measure fit. Estimate mode compares word count with step 3. API mode posts text and target to `/duration` and compares **natural speech duration** with target × (1 ± speech tolerance). HTTP 200 with `success:false` is still a valid measurement.
14. Save round fit metrics. Stop immediately when in range. Otherwise generate one revision from the latest accepted text. Estimate mode repairs the word band; API mode requests a shorter/longer text even when its word count looked acceptable.
15. At the retry limit choose minimum distance to the acceptable band, then minimum error to the target, then earliest round. An earlier draft can win. Save selection summary and accept that result.
16. Print duration and output location. Terminate the owned server/worker and descendants, then stop telemetry, save lifecycle reports and release the GPU lock.

Auxiliary scripts: `maintenance_example.py` supplies a fictional training brief and interactive editorial rounds; `compare_engines.py` runs the three engines sequentially with identical brief/feedback and writes a comparison CSV. Tests cover prompts, word rules, revisions, fit selection, progress and adapter contracts.

# Improved scripts: preserved sequence and deliberate changes

Steps 1–16 remain in the same order. The application is run directly as scripts; there is no build/installable library. `pipeline_core/` contains their internal implementation.

- Setup and all artifact downloads move into explicit curl-based installer/download scripts. Generation never invokes pip or implicitly fetches a model. Hosted-platform provisioning is removed.
- CLI model identifier/path and revision select Hugging Face models; GGUF paths select native models. The default Qwen retains its pinned identity and digest. Custom GGUFs can require a supplied SHA256.
- The original prompt remains byte-identical for equivalent requests. Its serialized static prefix is cached once per job; overlap sample tokenization is cached once per job.
- Streaming progress tracks whitespace words incrementally, avoiding recounting the entire generated text for every streamed piece. Full text replacement remains supported.
- Transformers keeps its architecture-specific Qwen prefill path, and uses a causal-model Auto loader with ordinary generation for other supported text architectures. Inference mode also applies inside the streaming thread, which now terminates the stream on errors.
- Fit selection retains only round metrics and one result per candidate, avoiding a second text/result copy. Exact duplicate texts reuse their duration measurement. The final selected text and full result are saved explicitly and reflected in `job.json`.
- API host, scheme, voice, language, speed, tempo bounds and timeout become CLI settings. Validation rejects malformed/nonfinite duration responses. Local API requests bypass download proxies by default.
- Optional GPU-memory ceiling/headroom settings support server GPUs; defaults retain the original 10.5 GB ceiling and 1.5 GB reserve. Guard sampling and failure behavior are preserved.
- `--max-retries N` retains N revisions after the initial draft. `--max-rounds N` optionally sets a total-generation limit including the draft. Acceptance and tie-breaking remain unchanged.

`CHANGES_AND_VALIDATION.md` records checks and practical limits; `INSTALL.md` gives Ubuntu 20.04 installation and CLI examples.
