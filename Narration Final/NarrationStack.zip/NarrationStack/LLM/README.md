# LLM narration scripts

Read [`PIPELINE_MAP.md`](PIPELINE_MAP.md) first for the original execution sequence and its improved counterpart. [`INSTALL.md`](INSTALL.md) contains the complete Ubuntu 20.04 setup, exact dependency locks, proxy/curl workflow, model downloads and CLI examples.

Run `python run_pipeline.py --help`. The application is supplied as runnable scripts with internal helpers in `pipeline_core/`; no project installation or library packaging is required.

Default behavior: one draft, then at most five revisions; stop at the first in-range generation, otherwise select the closest saved candidate. Word estimates are the default. Use `--no-estimate` for the external Kokoro `/duration` plan and `--speech-duration-tolerance` for its acceptance band. Use `--max-rounds` when the limit should include the draft.

Models: `--gguf-model` selects native instruct GGUFs; `--model` and `--model-revision` select locally downloaded/cached Hugging Face models. All generation is offline. The original Qwen models, prompts and sampling remain the defaults.

Each round is saved. The selected result is `output/jobs/JOB_ID/final.txt` and `final.json`; metadata includes the selected round and whether it met tolerance.

For your old approximately 11 GB card, begin with the native profile and CPU KV. The A6000 can use `--vram-limit-gb 48 --headroom-gb 2 --kv-cache-device gpu`. Exact GPU support and driver requirements are covered in the installation guide.

See [`CHANGES_AND_VALIDATION.md`](CHANGES_AND_VALIDATION.md) for verification evidence and hardware-testing limits. The supplied source folder was left untouched.
