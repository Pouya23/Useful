"""Flask + Swagger: two functional endpoints, POST generation with live SSE."""
import hmac
import os
import threading

from flask import Flask, Response, jsonify, request, stream_with_context
from flask_swagger_ui import get_swaggerui_blueprint
from pydantic import ValidationError
from werkzeug.exceptions import HTTPException

from api_contracts import GenerateRequest, ProgressRequest
from api_store import QueueFull


def openapi_document():
    error = {"description": "Machine-readable error JSON", "content": {"application/json": {"schema": {"type": "object"}}}}
    success = {"description": "Accepted async job, or live SSE for async=false", "content": {
        "application/json": {"schema": {"type": "object"}}, "text/event-stream": {"schema": {"type": "string"}}}}
    schemas = {}
    for model in (GenerateRequest, ProgressRequest):
        schema = model.model_json_schema(ref_template="#/components/schemas/{model}")
        schemas.update(schema.pop("$defs", {}))
        schemas[model.__name__] = schema
    def body(model):
        return {"required": True, "content": {"application/json": {"schema": {"$ref": f"#/components/schemas/{model}"}}}}
    security = [{"ApiKeyAuth": []}] if os.getenv("LLM_API_KEY") else []
    return {"openapi": "3.1.0", "info": {"title": "LLM narration API", "version": "1.0.0"},
        "servers": [{"url": "/"}], "components": {"schemas": schemas,
            "securitySchemes": {"ApiKeyAuth": {"type": "apiKey", "in": "header", "name": "X-API-Key"}}},
        "paths": {
            "/generate": {"post": {"summary": "Generate with retry fitting; async=true returns job_id, false streams real deltas",
                "security": security, "requestBody": body("GenerateRequest"),
                "responses": {"200": success, "202": success, "401": error, "422": error, "503": error},
                "x-sse-events": ["accepted", "round_start", "token", "round_end", "retry", "completed", "error"]}},
            "/progress": {"post": {"summary": "Get job progress and authoritative final result", "security": security,
                "requestBody": body("ProgressRequest"), "responses": {"200": error, "404": error, "422": error, "401": error}},
                "get": {"summary": "Poll job by UUID", "security": security, "parameters": [
                    {"name": "job_id", "in": "query", "required": True, "schema": {"type": "string"}}],
                    "responses": {"200": error, "404": error, "422": error, "401": error}}}}}


def create_app(service):
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024
    streams = threading.BoundedSemaphore(int(os.getenv("LLM_MAX_OPEN_STREAMS", "8")))
    app.register_blueprint(get_swaggerui_blueprint("/docs", "/openapi.json", config={"app_name": "LLM API"}), url_prefix="/docs")
    @app.before_request
    def authenticate():
        key = os.getenv("LLM_API_KEY", "")
        if request.path in {"/generate", "/progress"} and key and not hmac.compare_digest(request.headers.get("X-API-Key", ""), key):
            return jsonify(success=False, error={"code": "unauthorized", "message": "A valid X-API-Key is required"}), 401
    @app.errorhandler(ValidationError)
    @app.errorhandler(ValueError)
    def invalid(exc):
        return jsonify(success=False, error={"code": "invalid_specifications", "message": str(exc)}), 422
    @app.errorhandler(QueueFull)
    def full(exc):
        return jsonify(success=False, error={"code": "queue_full", "message": str(exc)}), 503, {"Retry-After": "10"}
    @app.errorhandler(HTTPException)
    def http_error(exc):
        return jsonify(success=False, error={"code": exc.name.lower().replace(" ", "_"), "message": exc.description}), exc.code
    @app.errorhandler(Exception)
    def unexpected(exc):
        app.logger.exception("API operation failed")
        return jsonify(success=False, error={"code": "internal_error", "message": "Inspect server logs"}), 500
    @app.post("/generate")
    def generate():
        if not request.is_json:
            return jsonify(success=False, error={"code": "content_type", "message": "Send application/json"}), 415
        spec = GenerateRequest.model_validate(request.get_json())
        acquired = False
        if not spec.async_:
            acquired = streams.acquire(blocking=False)
            if not acquired:
                return jsonify(success=False, error={"code": "stream_capacity", "message": "Too many open SSE requests; use async=true or retry"}), 503
        try:
            job_id = service.submit(spec)
        except BaseException:
            if acquired:
                streams.release()
            raise
        if spec.async_:
            return jsonify(success=True, job_id=job_id, status="queued", progress_url=f"/progress?job_id={job_id}"), 202
        def events():
            try:
                yield from service.store.stream(job_id)
            finally:
                streams.release()
        response = Response(stream_with_context(events()), mimetype="text/event-stream", headers={
            "Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no", "X-Job-Id": job_id})
        return response
    @app.route("/progress", methods=["GET", "POST"])
    def progress():
        if request.method == "GET":
            query = ProgressRequest.model_validate({"job_id": request.args.get("job_id") or request.args.get("uuid")})
        else:
            if not request.is_json:
                return jsonify(success=False, error={"code": "content_type", "message": "Send application/json"}), 415
            query = ProgressRequest.model_validate(request.get_json())
        found = service.store.get(query.job_id)
        if found is None:
            return jsonify(success=False, error={"code": "job_not_found", "message": "Unknown job_id"}), 404
        return jsonify(found)
    @app.get("/health")
    def health():
        from pipeline_core.engines.registry import engine_workers
        available = sorted(engine_workers())
        if not available:
            available = sorted({"llama_cpp", os.getenv('LLM_PROFILE', 'native')} - {"native"})
        alive = service.worker.is_alive()
        return jsonify(success=alive, ready=alive, worker_alive=alive,
                       model_loaded=service.session is not None, device="cuda:0",
                       installed_engines=available), 200 if alive else 503
    @app.get("/openapi.json")
    def schema():
        return jsonify(openapi_document())
    return app
