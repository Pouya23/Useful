"""Typed HTTP form of the main CLI; file inputs may also be supplied inline."""
import os
from pathlib import Path
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictInt, StrictStr, model_validator

from pipeline_core.engines.base import MODEL_ID


class Reference(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: StrictStr
    text: StrictStr = Field(min_length=1, max_length=1_000_000)
    description: StrictStr = "User-supplied reference"


class GenerateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    async_: StrictBool = Field(default=True, alias="async")
    duration_seconds: float = Field(gt=0, strict=True)
    title: StrictStr = "Maintenance of pipe handling systems"
    instructions: StrictStr = "Write clear spoken training using the supplied sources."
    point: list[StrictStr] = Field(default_factory=list)
    sample: list[StrictStr] = Field(default_factory=list, description="UTF-8 paths under INPUT_ROOT; use samples for inline text")
    source: list[StrictStr] = Field(default_factory=list, description="UTF-8 paths under INPUT_ROOT; use sources for inline references")
    samples: list[StrictStr] = Field(default_factory=list)
    sources: list[Reference] = Field(default_factory=list)
    speaking_rate_wpm: float = Field(default=130, ge=40, le=300, strict=True)
    duration_tolerance: float = Field(default=.1, ge=0, le=.5, strict=True)
    speech_duration_tolerance: float = Field(default=.1, ge=0, le=.5, strict=True)
    max_retries: StrictInt = Field(default=5, ge=0)
    max_rounds: StrictInt | None = Field(default=None, ge=1)
    estimate: StrictBool = True
    seed: StrictInt = Field(default=42, ge=0, le=2**32-102)
    engine: Literal["llama_cpp", "transformers", "vllm"] | None = None
    model: StrictStr | None = None
    model_revision: StrictStr | None = None
    model_sha256: StrictStr | None = Field(default=None, pattern=r"^[0-9a-fA-F]{64}$")
    gguf_model: StrictStr | None = None
    server: StrictStr | None = None
    worker_python: StrictStr | None = None
    gpu_index: StrictInt = Field(default=0, ge=0, le=0, description="Only one GPU is exposed to this container")
    context_tokens: StrictInt = Field(default=32768, ge=512, le=262144)
    max_output_tokens: StrictInt | None = Field(default=None, gt=0, le=262144)
    dtype: Literal["auto", "float16", "bfloat16"] = "auto"
    kv_cache_device: Literal["cpu", "gpu"] = "cpu"
    prefill_chunk_tokens: StrictInt = Field(default=512, ge=1)
    vram_limit_gb: float | None = Field(default=None, gt=0, strict=True)
    headroom_gb: float | None = Field(default=None, gt=0, strict=True)
    show_progress: StrictBool = False
    output: StrictStr | None = Field(default=None, description="Optional relative artifact subdirectory under this job")
    duration_api_host: StrictStr | None = None
    duration_api_port: StrictInt | None = Field(default=None, ge=1, le=65535)
    duration_api_key: StrictStr | None = None
    duration_api_scheme: Literal["http", "https"] = "http"
    duration_api_timeout: float = Field(default=120, gt=0, strict=True)
    duration_api_use_proxy: StrictBool = False
    voice: StrictStr = "am_onyx"
    lang_code: Literal["a", "b"] = "a"
    speech_speed: float = Field(default=1, ge=.25, le=4, strict=True)
    atempo_min: float = Field(default=.93, ge=.125, le=8, strict=True)
    atempo_max: float = Field(default=1.15, ge=.125, le=8, strict=True)

    @property
    def revisions(self):
        return self.max_retries if self.max_rounds is None else self.max_rounds - 1

    @model_validator(mode="after")
    def validate_policy(self):
        if not self.estimate and self.duration_seconds > 1800:
            raise ValueError("/duration target must be <=1800 seconds")
        if self.atempo_min > self.atempo_max:
            raise ValueError("atempo_min must not exceed atempo_max")
        if self.output and (Path(self.output).is_absolute() or ".." in Path(self.output).parts):
            raise ValueError("output must be a relative subdirectory without traversal")
        return self


class ProgressRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    job_id: StrictStr

    @model_validator(mode="before")
    @classmethod
    def normalize_uuid(cls, data):
        if not isinstance(data, dict):
            return data
        data = dict(data)
        if "uuid" in data:
            if "job_id" in data:
                raise ValueError("Use job_id or uuid, not both")
            data["job_id"] = data.pop("uuid")
        value = data.get("job_id")
        if not isinstance(value, str):
            raise ValueError("job_id must be a UUID string")
        try:
            data["job_id"] = UUID(value).hex
        except (ValueError, AttributeError) as exc:
            raise ValueError("job_id must be a valid UUID") from exc
        return data


def safe_path(value, root, *, must_exist=True):
    path = Path(value).expanduser().resolve()
    root = Path(root).resolve()
    if not path.is_relative_to(root):
        raise ValueError(f"Path must be inside {root}")
    if must_exist and not path.is_file():
        raise ValueError(f"Input file missing: {path}")
    return path
