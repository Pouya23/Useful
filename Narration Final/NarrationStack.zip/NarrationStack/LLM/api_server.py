"""Production LLM entry point: Waitress, one job worker, one exposed CUDA GPU."""
import logging
import os
from pathlib import Path
import sys
import signal
import argparse

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "containers"))
from gpu_gate import GpuGate
from waitress import serve
from api_app import create_app
from api_service import LlmService


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(os.getenv('LLM_DATA_DIR','/data')),help='Persistent output base; generated artifacts use UTC timestamps')
    args=parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    import pynvml
    pynvml.nvmlInit()
    try:
        pynvml.nvmlDeviceGetMemoryInfo(pynvml.nvmlDeviceGetHandleByIndex(0))
    finally:
        pynvml.nvmlShutdown()
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    service = LlmService(args.output, gate=GpuGate(directory=os.getenv('GPU_LOCK_DIR',str(args.output/'gpu-locks'))))
    def shutdown(*_):
        service.stop.set()
        service.wake.set()
        raise SystemExit(0)
    signal.signal(signal.SIGTERM, shutdown)
    try:
        serve(create_app(service), host="0.0.0.0", port=int(os.getenv("HTTP_PORT", "8000")),
              threads=int(os.getenv("HTTP_THREADS", "32")), channel_timeout=3600,
              max_request_body_size=2 * 1024 * 1024)
    finally:
        service.close()


if __name__ == "__main__":
    main()
