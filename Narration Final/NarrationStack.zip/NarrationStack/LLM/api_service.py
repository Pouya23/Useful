"""One durable LLM worker, resident model reuse, real token events and original fit loop."""
from contextlib import nullcontext
from dataclasses import replace
import json
import logging
import os
from pathlib import Path
import sys
import threading
import time
import uuid

from api_contracts import GenerateRequest, safe_path
from api_store import JobStore
from pipeline_core.engines.base import EngineSettings, MODEL_ID, MODEL_REVISION
from pipeline_core.engines.registry import engine_workers, resolve_worker
from pipeline_core.duration_api import DurationApiConfig
from pipeline_core.fit import FitSettings, revise_until_fit
from pipeline_core.requests import Source, WritingRequest, count_words
from pipeline_core.artifacts import artifact_path, new_artifact_dir
from pipeline_core.session import WritingSession


def make_request(spec):
    root = Path(os.getenv("INPUT_ROOT", "/inputs"))
    def read(path):
        path = safe_path(path, root)
        if path.stat().st_size > 1_000_000:
            raise ValueError("Reference/sample file exceeds 1 MB; reduce it explicitly")
        return path.read_text(encoding="utf-8-sig")
    sources = [Source(f"file-{i}", read(p), p) for i, p in enumerate(spec.source)]
    sources += [Source(p.id, p.text, p.description) for p in spec.sources]
    brief = WritingRequest(spec.title, instructions=spec.instructions, required_points=tuple(spec.point),
                           samples=tuple([*spec.samples, *(read(p) for p in spec.sample)]), sources=tuple(sources),
                           duration_seconds=spec.duration_seconds, speaking_rate_wpm=spec.speaking_rate_wpm,
                           duration_tolerance=spec.duration_tolerance)
    brief.validate()
    return brief


def engine_settings(spec, *, check_paths=True):
    profile = os.getenv("LLM_PROFILE", "native")
    engine = spec.engine or os.getenv("LLM_ENGINE", "llama_cpp")
    workers = engine_workers()
    if engine != "llama_cpp" and engine != profile and engine not in workers:
        raise ValueError(f"Image profile {profile!r} does not contain the {engine!r} worker; choose the matching build profile")
    model_root = Path(os.getenv("MODELS_ROOT", "/models"))
    gguf = spec.gguf_model or os.getenv("LLM_GGUF_MODEL", "/models/llm/Qwen3.5-9B-Q5_K_M.gguf")
    server = spec.server or os.getenv("LLAMA_SERVER", "/opt/llama/bin/llama-server")
    model = spec.model or os.getenv("LLM_MODEL", MODEL_ID)
    if ".." in Path(model).parts:
        raise ValueError("model cannot contain path traversal")
    worker = resolve_worker(engine, spec.worker_python, restricted=True) or sys.executable
    if check_paths:
        if engine == "llama_cpp":
            gguf = str(safe_path(gguf, model_root))
            server = str(safe_path(server, os.getenv("SERVER_ROOT", "/opt/llama/bin")))
        elif Path(model).is_absolute():
            resolved = Path(model).resolve()
            if not resolved.is_relative_to(model_root.resolve()) or not resolved.is_dir():
                raise ValueError("Local HF model must be a directory under MODELS_ROOT")
    settings = EngineSettings(name=engine, hf_model=model,
        revision=spec.model_revision or (MODEL_REVISION if model == MODEL_ID else None),
        server=server, gguf_model=gguf, worker_python=worker, gpu_index=0,
        context_tokens=spec.context_tokens if "context_tokens" in spec.model_fields_set else int(os.getenv("LLM_CONTEXT_TOKENS", "32768")),
        kv_cache_device=spec.kv_cache_device if "kv_cache_device" in spec.model_fields_set else os.getenv("LLM_KV_CACHE_DEVICE", "cpu"),
        dtype=spec.dtype, show_progress=spec.show_progress, model_sha256=spec.model_sha256,
        prefill_chunk_tokens=spec.prefill_chunk_tokens,
        vram_limit_gb=spec.vram_limit_gb or float(os.getenv("LLM_VRAM_LIMIT_GB", "10.5")),
        headroom_gb=spec.headroom_gb or float(os.getenv("LLM_HEADROOM_GB", "1.5")))
    settings.validate()
    return settings


def fit_settings(spec):
    config = None
    if not spec.estimate:
        config = DurationApiConfig(
            host=spec.duration_api_host or os.getenv("DURATION_API_HOST", "tts"),
            port=spec.duration_api_port or int(os.getenv("DURATION_API_PORT", "8000")),
            api_key=spec.duration_api_key or os.getenv("DURATION_API_KEY") or None,
            scheme=spec.duration_api_scheme, timeout_seconds=spec.duration_api_timeout,
            voice=spec.voice, lang_code=spec.lang_code, speed=spec.speech_speed,
            atempo_min=spec.atempo_min, atempo_max=spec.atempo_max, use_proxy=spec.duration_api_use_proxy)
    result = FitSettings(spec.revisions, spec.estimate, spec.speech_duration_tolerance, config)
    result.validate()
    return result


class StreamingBackend:
    def __init__(self, backend, job, token, start, gate):
        self.backend, self.job, self.token, self.start, self.gate = backend, job, token, start, gate
    def __getattr__(self, name):
        return getattr(self.backend, name)
    def complete(self, messages, **kwargs):
        self.start(len(self.job.calls), kwargs.get("progress_word_limit", 650))
        target = self.backend.server
        target.token_callback = self.token
        try:
            with self.gate:
                return self.backend.complete(messages, **kwargs)
        finally:
            target.token_callback = None


class LlmService:
    def __init__(self, data_dir, *, session_factory=WritingSession, gate=None, validate_paths=True, start_worker=True):
        self.root = Path(data_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        # Reuse the pipeline's OS advisory lock for this data volume.
        from pipeline_core.runtime import _DeviceLock
        self.lease = _DeviceLock("llm-service:" + str(self.root.resolve()))
        self.lease.acquire()
        self.store = JobStore(self.root)
        self.factory, self.gate = session_factory, gate or nullcontext()
        self.validate_paths = validate_paths
        self.session = self.settings = None
        self.stop, self.wake = threading.Event(), threading.Event()
        self.maximum = int(os.getenv("LLM_MAX_PENDING_JOBS", "32"))
        self.worker = threading.Thread(target=self.work, daemon=True, name="llm-job-worker")
        if start_worker:
            self.worker.start()

    def submit(self, spec):
        engine_settings(spec, check_paths=self.validate_paths)
        fit_settings(spec)
        # Snapshot file contents now; queued jobs cannot observe changed input files later.
        brief = make_request(spec)
        payload = spec.model_dump(by_alias=True, exclude_unset=True)
        payload.update(sample=[], source=[], samples=list(brief.samples),
                       sources=[{"id": s.id, "text": s.text, "description": s.description} for s in brief.sources])
        job_id = self.store.submit(payload, self.maximum)
        self.wake.set()
        return job_id

    def get_session(self, settings):
        if self.session is not None and settings != self.settings:
            self.session.close()
            self.session = None
        if self.session is None:
            directory = self.root / "sessions" / uuid.uuid4().hex
            candidate = self.factory(settings, output=directory, render=lambda _: None)
            with self.gate:
                self.session = candidate.__enter__()
            self.settings = settings
        return self.session

    def run(self, row):
        job_id = row["job_id"]
        spec = GenerateRequest.model_validate_json(row["request_json"])
        fit = fit_settings(spec)
        session = self.get_session(engine_settings(spec, check_paths=self.validate_paths))
        job = session.new_job(make_request(spec), max_output_tokens=spec.max_output_tokens, seed=spec.seed)
        if spec.output:
            job.output = new_artifact_dir(self.store.directory(job_id) / spec.output, 'generation')
        round_index, word_limit, partial, last_update = 0, 650, "", 0.0
        rounds = spec.revisions + 1
        def start(index, limit):
            nonlocal round_index, word_limit, partial
            round_index, word_limit, partial = index, max(1, limit or 650), ""
            self.store.update(job_id, "generating", index, 99 * index / rounds)
            self.store.event(job_id, "round_start", {"round_index": index, "maximum_rounds": rounds, "reset_text": True})
        def token(payload):
            nonlocal partial, last_update
            if self.stop.is_set():
                raise RuntimeError("Service is shutting down; partial round retained")
            replacement = payload.get("replace_from")
            partial = partial + payload["text"] if replacement is None else partial[:replacement] + payload["text"]
            self.store.event(job_id, "token", {"round_index": round_index, **payload})
            now = time.monotonic()
            if now - last_update >= .25:
                fraction = min(.95, count_words(partial) / word_limit)
                self.store.update(job_id, "generating", round_index, 99 * (round_index + fraction) / rounds)
                last_update = now
        def measured(entry):
            index = entry["round_index"]
            self.store.update(job_id, "fit_checked", index, 99 * (index + 1) / rounds)
            self.store.event(job_id, "round_end", entry)
            if not entry["fit"]["within_range"] and index < spec.revisions:
                self.store.event(job_id, "retry", {"round_index": index, "next_round_index": index + 1,
                    "reason": "outside_tolerance", "fit": entry["fit"], "remaining_retries": spec.revisions - index})
        job.backend = StreamingBackend(job.backend, job, token, start, self.gate)
        job.draft()
        result = revise_until_fit(job, fit, on_fit=measured, progress=lambda _: None)
        result["artifact_directory"] = str(job.output)
        self.store.event(job_id, "completed", {"success": True, "result": result})
        self.store.finish(job_id, result=result)

    def work(self):
        try:
            while not self.stop.is_set():
                row = self.store.claim()
                if row is None:
                    self.wake.wait(.5)
                    self.wake.clear()
                    continue
                try:
                    self.run(row)
                except Exception as exc:
                    logging.exception("LLM job %s failed", row["job_id"])
                    error = {"code": "generation_failed", "message": str(exc)}
                    self.store.event(row["job_id"], "error", {"success": False, "error": error})
                    self.store.finish(row["job_id"], error=error)
                    if self.session is not None:
                        self.session.close()
                        self.session = self.settings = None
        finally:
            if self.session is not None:
                self.session.close()
                self.session = None
            self.lease.release()

    def close(self):
        self.stop.set()
        self.wake.set()
        if self.worker.is_alive():
            self.worker.join(timeout=30)
        else:
            self.lease.release()
