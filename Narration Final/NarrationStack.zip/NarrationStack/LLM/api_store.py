"""Durable LLM queue and append-only SSE journal; no client backpressure on inference."""
import contextlib
import json
from pathlib import Path
import sqlite3
import threading
import time
import uuid
from pipeline_core.artifacts import artifact_path, new_artifact_dir


class QueueFull(RuntimeError):
    pass


class JobStore:
    def __init__(self, directory):
        self.root = Path(directory)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "llm_jobs.sqlite3"
        self.events_changed = threading.Condition()
        self.event_ids = {}
        with self.connection() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS jobs (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, job_id TEXT UNIQUE NOT NULL,
                    request_json TEXT NOT NULL, status TEXT NOT NULL,
                    created REAL NOT NULL, started REAL, finished REAL,
                    stage TEXT NOT NULL, progress REAL NOT NULL DEFAULT 0,
                    round_index INTEGER NOT NULL DEFAULT 0,
                    result_json TEXT, error_json TEXT);
                CREATE INDEX IF NOT EXISTS llm_pending ON jobs(status,seq);
            """)
            if 'artifact_dir' not in {row[1] for row in db.execute('PRAGMA table_info(jobs)')}:
                db.execute('ALTER TABLE jobs ADD COLUMN artifact_dir TEXT')
        self.path.chmod(0o600)
        with self.connection() as db:
            interrupted = db.execute("SELECT job_id FROM jobs WHERE status='running'").fetchall()
        for row in interrupted:
            self.finish(row["job_id"], error={"code": "service_restarted", "message": "Server restarted during inference; saved rounds retained. Submit a new job."})
            self.event(row["job_id"], "error", self.get(row["job_id"])["error"])

    @contextlib.contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        finally:
            db.close()

    def directory(self, job_id):
        with self.connection() as db:
            row=db.execute('SELECT artifact_dir FROM jobs WHERE job_id=?',(job_id,)).fetchone()
        return artifact_path(row['artifact_dir']) if row and row['artifact_dir'] else self.root / "jobs" / job_id

    def submit(self, payload, maximum):
        job_id = uuid.uuid4().hex
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            count = db.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0]
            if count >= maximum:
                raise QueueFull("LLM queue is full")
            directory = new_artifact_dir(self.root / 'jobs', job_id)
            directory.chmod(0o700)
            (directory / "events.jsonl").touch(mode=0o600)
            db.execute("INSERT INTO jobs(job_id,request_json,status,created,stage) VALUES(?,?,'queued',?,'queued')",
                       (job_id, json.dumps(payload, allow_nan=False), time.time()))
            db.execute('UPDATE jobs SET artifact_dir=? WHERE job_id=?',(str(directory),job_id))
        self.event(job_id, "accepted", {"job_id": job_id, "status": "queued", "success": True})
        return job_id

    def claim(self):
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY seq LIMIT 1").fetchone()
            if row:
                db.execute("UPDATE jobs SET status='running',started=?,stage='loading_model' WHERE job_id=?", (time.time(), row["job_id"]))
        return dict(row) if row else None

    def get(self, job_id):
        with self.connection() as db:
            row = db.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            if not row:
                return None
            ahead = db.execute("SELECT COUNT(*) FROM jobs WHERE seq<? AND status IN ('running','queued')", (row["seq"],)).fetchone()[0] if row["status"] == "queued" else 0
        return {"success": row["status"] != "failed", "job_id": job_id, "status": row["status"],
                "stage": row["stage"], "progress_percent": row["progress"], "round_index": row["round_index"],
                "queue_position": ahead, "elapsed_seconds": max(0, (row["finished"] or time.time()) - row["started"]) if row["started"] else 0,
                "progress_is_estimate": True, "progress_basis": "fraction of maximum round budget, using word progress within each round",
                "result": json.loads(row["result_json"]) if row["result_json"] else None,
                "error": json.loads(row["error_json"]) if row["error_json"] else None}

    def update(self, job_id, stage, round_index, percent):
        with self.connection() as db:
            db.execute("UPDATE jobs SET stage=?,round_index=?,progress=MAX(progress,?) WHERE job_id=?",
                       (stage, round_index, min(99, max(0, percent)), job_id))

    def finish(self, job_id, result=None, error=None):
        with self.connection() as db:
            db.execute("UPDATE jobs SET status=?,stage=?,finished=?,result_json=?,error_json=?,progress=CASE WHEN ? THEN 100 ELSE progress END WHERE job_id=?",
                       ("completed" if result is not None else "failed", "completed" if result is not None else "failed", time.time(),
                        json.dumps(result, allow_nan=False) if result is not None else None,
                        json.dumps(error) if error else None, result is not None, job_id))
        with self.events_changed:
            self.events_changed.notify_all()

    def event(self, job_id, kind, payload):
        path = self.directory(job_id) / "events.jsonl"
        with self.events_changed:
            if job_id not in self.event_ids:
                last = 0
                if path.exists():
                    with path.open(encoding="utf-8") as stream:
                        for line in stream:
                            if line.strip():
                                last = json.loads(line)["id"]
                self.event_ids[job_id] = last
            self.event_ids[job_id] += 1
            item = {"id": self.event_ids[job_id], "event": kind, "data": {"job_id": job_id, **payload}}
            with path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(item, ensure_ascii=False, allow_nan=False) + "\n")
                stream.flush()
            self.events_changed.notify_all()

    def stream(self, job_id):
        with (self.directory(job_id) / "events.jsonl").open(encoding="utf-8") as stream:
            while True:
                # Read/park atomically with event publication to avoid missed wakeups.
                with self.events_changed:
                    line = stream.readline()
                    if not line:
                        status = self.get(job_id)["status"]
                        if status in {"failed", "completed"}:
                            # A terminal journal event is published before finishing.
                            return
                        changed = self.events_changed.wait(timeout=15)
                        if changed:
                            continue
                if line:
                    item = json.loads(line)
                    yield f"id: {item['id']}\nevent: {item['event']}\ndata: {json.dumps(item['data'], ensure_ascii=False)}\n\n"
                else:
                    yield ": heartbeat\n\n"
