#!/usr/bin/env bash
# Source build on Ubuntu 20.04 avoids newer-glibc release binaries.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
: "${DOWNLOAD_DIR:?Set DOWNLOAD_DIR}"
: "${CONDA_PREFIX:?Activate the LLM conda environment first}"
CUDA_ROOT="${CUDA_ROOT:-$DOWNLOAD_DIR/cuda-12.2.2}"
CUDA_ARCHS="${CUDA_ARCHS:-61;75;86}" # GTX 1080 Ti, Turing, A6000; change for your card.
BUILD_JOBS="${BUILD_JOBS:-4}" # nvcc builds can use substantial host RAM.
for tool in curl gcc g++ make; do
  command -v "$tool" >/dev/null || { echo "Missing $tool. Install OS build tools (see INSTALL.md)." >&2; exit 2; }
done
CURL=(bash "$ROOT/../containers/curl_retry.sh" --fail --location --retry 5 --retry-delay 2 --connect-timeout 60)
[[ -z "${DOWNLOAD_PROXY:-}" ]] || CURL+=(--proxy "$DOWNLOAD_PROXY")
[[ -z "${CURL_CA_BUNDLE:-}" ]] || CURL+=(--cacert "$CURL_CA_BUNDLE")
[[ "${CURL_INSECURE:-0}" != 1 ]] || CURL+=(--insecure)
mkdir -p "$DOWNLOAD_DIR" "$ROOT/runtime"
DOWNLOAD_DIR="$(cd -- "$DOWNLOAD_DIR" && pwd)"
CUDA_RUN=cuda_12.2.2_535.104.05_linux.run
CUDA_MD5=a32d82924645e0369c14acaebd54bff1
if [[ ! -x "$CUDA_ROOT/bin/nvcc" ]]; then
  if [[ ! -f "$DOWNLOAD_DIR/$CUDA_RUN" ]]; then
    "${CURL[@]}" --continue-at - -o "$DOWNLOAD_DIR/$CUDA_RUN.part" \
      "https://developer.download.nvidia.com/compute/cuda/12.2.2/local_installers/$CUDA_RUN"
    printf '%s  %s\n' "$CUDA_MD5" "$DOWNLOAD_DIR/$CUDA_RUN.part" | md5sum -c -
    mv -- "$DOWNLOAD_DIR/$CUDA_RUN.part" "$DOWNLOAD_DIR/$CUDA_RUN"
  fi
  printf '%s  %s\n' "$CUDA_MD5" "$DOWNLOAD_DIR/$CUDA_RUN" | md5sum -c -
  # Toolkit only; preserve the installed NVIDIA driver. User-owned prefix, no sudo.
  mkdir -p "$DOWNLOAD_DIR/tmp"
  sh "$DOWNLOAD_DIR/$CUDA_RUN" --silent --toolkit --toolkitpath="$CUDA_ROOT" \
    --defaultroot="$CUDA_ROOT" --tmpdir="$DOWNLOAD_DIR/tmp" --no-man-page
fi
"$CUDA_ROOT/bin/nvcc" --version | grep -q 'release 12.2,' || { echo 'This build pins CUDA 12.2.x. Set CUDA_ROOT to the compatible toolkit.' >&2; exit 2; }
export PATH="$CUDA_ROOT/bin:$CONDA_PREFIX/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_ROOT/lib64:$CONDA_PREFIX/lib:${LD_LIBRARY_PATH:-}"
COMMIT=0faee5004297c3bcfa40b7bf11750127b8c1fd7d
SOURCE_SHA=67c10b895e534bac0cf6ce107e08570f13a3e66d5550eef927cc74e03b2bebf7
ARCHIVE="$DOWNLOAD_DIR/llama-$COMMIT.tar.gz"
if [[ ! -f "$ARCHIVE" ]]; then
  CURL_EXPECTED_SHA256="$SOURCE_SHA" "${CURL[@]}" --continue-at - -o "$ARCHIVE.part" "https://codeload.github.com/ggml-org/llama.cpp/legacy.tar.gz/$COMMIT"
  printf '%s  %s\n' "$SOURCE_SHA" "$ARCHIVE.part" | sha256sum -c -
  mv -- "$ARCHIVE.part" "$ARCHIVE"
fi
printf '%s  %s\n' "$SOURCE_SHA" "$ARCHIVE" | sha256sum -c -
SOURCE="$ROOT/runtime/llama-$COMMIT"
if [[ ! -d "$SOURCE" ]]; then
  mkdir -p "$SOURCE"
  tar -xzf "$ARCHIVE" --strip-components=1 -C "$SOURCE"
fi
BUILD_DIR="$SOURCE/build"
if [[ -f "$BUILD_DIR/CMakeCache.txt" ]] && ! grep -Fq "CMAKE_CUDA_COMPILER:FILEPATH=$CUDA_ROOT/bin/nvcc" "$BUILD_DIR/CMakeCache.txt"; then
  BUILD_DIR="$SOURCE/build-cuda1222"
fi
BUILD_KEY="$(printf '%s\n' "$SOURCE_SHA" "$CUDA_ROOT" "$CUDA_ARCHS" 'narration-native-flags-v1' "$(gcc -dumpfullversion)" "$(cmake --version | head -n1)" | sha256sum | cut -d' ' -f1)"
if [[ -f "$BUILD_DIR/.narration-build-key" && "$(cat "$BUILD_DIR/.narration-build-key")" == "$BUILD_KEY" && -f "$BUILD_DIR/.narration-server-sha256" ]]; then
  if (cd "$BUILD_DIR" && sha256sum -c .narration-server-sha256 >/dev/null 2>&1); then
    printf 'export LLAMA_SERVER=%q\nexport LD_LIBRARY_PATH=%q:"${LD_LIBRARY_PATH:-}"\n' \
      "$BUILD_DIR/bin/llama-server" "$CUDA_ROOT/lib64:$CONDA_PREFIX/lib" > "$ROOT/runtime/activate_native.sh"
    echo 'Native build verified; compilation skipped.'
    exit 0
  fi
fi
cmake -S "$SOURCE" -B "$BUILD_DIR" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DGGML_CUDA=ON -DGGML_CUDA_NCCL=OFF -DLLAMA_CURL=OFF \
  -DCMAKE_CUDA_COMPILER="$CUDA_ROOT/bin/nvcc" \
  -DCMAKE_CUDA_ARCHITECTURES="$CUDA_ARCHS" -DGGML_NATIVE=OFF \
  -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_EXAMPLES=OFF -DLLAMA_BUILD_TOOLS=ON \
  -DLLAMA_BUILD_SERVER=ON -DLLAMA_BUILD_APP=OFF -DLLAMA_BUILD_UI=OFF \
  -DLLAMA_USE_PREBUILT_UI=OFF -DLLAMA_OPENSSL=OFF \
  -DLLAMA_BUILD_NUMBER=11384 -DLLAMA_BUILD_COMMIT=0faee50
cmake --build "$BUILD_DIR" --target llama-server --parallel "$BUILD_JOBS"
printf '%s\n' "$BUILD_KEY" > "$BUILD_DIR/.narration-build-key"
(cd "$BUILD_DIR" && sha256sum bin/llama-server > .narration-server-sha256)
mkdir -p "$DOWNLOAD_DIR/manifests"
{
  printf 'llama.cpp b11384 commit=%s\nCUDA toolkit=12.2.2\narchitectures=%s\n' "$COMMIT" "$CUDA_ARCHS"
  "$CUDA_ROOT/bin/nvcc" --version
  gcc --version
  cmake --version
  [[ ! -f "$DOWNLOAD_DIR/$CUDA_RUN" ]] || sha256sum "$DOWNLOAD_DIR/$CUDA_RUN"
  sha256sum "$ARCHIVE"
} > "$DOWNLOAD_DIR/manifests/native-build.txt"
# Save an activation fragment with shell-escaped absolute paths.
printf 'export LLAMA_SERVER=%q\nexport LD_LIBRARY_PATH=%q:"${LD_LIBRARY_PATH:-}"\n' \
  "$BUILD_DIR/bin/llama-server" "$CUDA_ROOT/lib64:$CONDA_PREFIX/lib" > "$ROOT/runtime/activate_native.sh"
echo "Built llama-server. Run: source '$ROOT/runtime/activate_native.sh'"
