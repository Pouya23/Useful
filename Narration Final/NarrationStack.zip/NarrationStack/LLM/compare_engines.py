"""Replay the same maintenance brief and feedback sequentially on each engine.

Quality is for human inspection. This script does not invent model self-scores.
Worker interpreters can differ to avoid conflicting Torch requirements.

Every revision keeps the same --duration-seconds word band. Do not pass
length_direction alone here: that clears the numeric range by design in revise().
"""

import argparse
import csv
from dataclasses import replace
from pathlib import Path
from maintenance_example import BRIEF
from pipeline_core import EngineSettings, WritingSession
from pipeline_core.duration import DurationPolicy


def feedback_rounds(duration_seconds: float):
    """Same duration target every round; quality / concision only."""
    return (
        {
            "quality_feedback": (
                "Make transitions smoother and the voice more natural. "
                "Preserve the supported safety content."
            ),
            "duration_seconds": duration_seconds,
        },
        {
            "quality_feedback": (
                "Make the narration more concise while staying inside the target duration band. "
                "Preserve the supported safety content."
            ),
            "duration_seconds": duration_seconds,
        },
        {
            "quality_feedback": (
                "Keep the maintenance sequence clear and avoid repetitive phrasing. "
                "Stay inside the target duration band."
            ),
            "duration_seconds": duration_seconds,
        },
    )


def _banner(settings, *, index: int, total: int, duration_seconds: float) -> None:
    policy = DurationPolicy(duration_seconds, BRIEF.speaking_rate_wpm, BRIEF.duration_tolerance)
    low, high = policy.word_range()
    worker = settings.worker_python or "(same as parent Python)"
    print("\n" + "=" * 72, flush=True)
    print(
        f"ENGINE {index}/{total}: {settings.name}",
        flush=True,
    )
    print(
        f"  duration_seconds={duration_seconds}  word_range=[{low}, {high}]  "
        f"target_words={policy.target_words}",
        flush=True,
    )
    if settings.name == "llama_cpp":
        print(f"  server={settings.server}  gguf_model={settings.gguf_model}", flush=True)
    else:
        print(f"  worker_python={worker}", flush=True)
    print("=" * 72 + "\n", flush=True)


def compare(settings_list, output, *, duration_seconds=180):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    brief = replace(BRIEF, duration_seconds=duration_seconds)
    rounds = feedback_rounds(duration_seconds)
    summary = []
    total = len(settings_list)
    for index, settings in enumerate(settings_list, 1):
        _banner(settings, index=index, total=total, duration_seconds=duration_seconds)
        engine_output = output / settings.name
        # No concurrent models: the previous with block confirms cleanup first.
        with WritingSession(settings, output=engine_output) as session:
            job = session.new_job(brief)
            job.draft()
            for feedback in rounds:
                job.revise(**feedback)  # Exactly one call, unless no change is needed.
            job.accept()
            for pass_number, event in enumerate(job.calls, 1):
                usage = event.get("usage", {})
                elapsed = event["latency_seconds"]
                tokens = usage.get("completion_tokens")
                summary.append(
                    {
                        "engine": settings.name,
                        "stage": event["stage"],
                        "seconds": elapsed,
                        "output_tokens": tokens,
                        "output_tokens_per_end_to_end_second": tokens / elapsed
                        if tokens is not None and elapsed > 0
                        else None,
                        "peak_total_vram_gb": event["total_device_peak_gb"],
                        "text_file": str(job.output / f"{pass_number:02d}_{event['stage']}.txt"),
                        "quality_score_by_user": "",
                    }
                )
        print(f"Finished engine: {settings.name}", flush=True)
    with (output / "comparison.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    print("Comparison saved:", output / "comparison.csv")
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--duration-seconds", type=float, default=180)
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--server")
    parser.add_argument("--gguf-model")
    parser.add_argument("--transformers-python")
    parser.add_argument("--vllm-python")
    args = parser.parse_args()
    settings = [
        EngineSettings(
            name="llama_cpp", server=args.server, gguf_model=args.gguf_model, gpu_index=args.gpu_index
        ),
        EngineSettings(name="transformers", worker_python=args.transformers_python, gpu_index=args.gpu_index),
        EngineSettings(name="vllm", worker_python=args.vllm_python, gpu_index=args.gpu_index),
    ]
    compare(settings, args.output, duration_seconds=args.duration_seconds)


if __name__ == "__main__":
    main()
