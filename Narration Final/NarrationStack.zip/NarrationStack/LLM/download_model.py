#!/usr/bin/env python3
"""Explicit curl model downloader; freeze HF revisions and verify LFS SHA256."""
import argparse
import json
import os
from pathlib import Path, PurePosixPath
from urllib.parse import quote
import subprocess

from download_packages import curl_json, download, curl_options, sha256
from pipeline_core.model import MODEL
from pipeline_core.engines.base import MODEL_ID, MODEL_REVISION


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kind", choices=["gguf", "hf"], default="gguf")
    parser.add_argument("--model", help="HF repository; GGUF default is the original pinned quantization")
    parser.add_argument("--revision")
    parser.add_argument("--filename", help="GGUF filename inside the HF repository")
    parser.add_argument("--sha256", help="Optional required digest for custom GGUF")
    parser.add_argument("--download-dir", type=Path, required=True)
    args = parser.parse_args(argv)
    repo = args.model or (MODEL["repository"] if args.kind == "gguf" else MODEL["upstream"])
    revision = args.revision or (MODEL["revision"] if repo == MODEL["repository"] else MODEL_REVISION if repo == MODEL_ID else "main")
    if args.kind == "gguf":
        filename = args.filename or (MODEL["filename"] if repo == MODEL["repository"] else None)
        if not filename:
            parser.error("Custom GGUF repositories require --filename")
        checksum = args.sha256 or (MODEL["sha256"] if repo == MODEL["repository"] and revision == MODEL["revision"] and filename == MODEL["filename"] else None)
        path = PurePosixPath(filename)
        if path.is_absolute() or ".." in path.parts:
            parser.error("Unsafe filename")
        destination = args.download_dir / path.name
        download(f"https://huggingface.co/{repo}/resolve/{revision}/{quote(filename)}", destination, checksum)
        print(f"Model: {destination.resolve()}\nSHA256: {sha256(destination)}")
        return
    # API result freezes main/branch to its current immutable commit.
    info = curl_json(f"https://huggingface.co/api/models/{repo}/revision/{quote(revision, safe='')}?blobs=true")
    commit = info["sha"]
    args.download_dir.mkdir(parents=True, exist_ok=True)
    selected = []
    for item in info["siblings"]:
        filename = item["rfilename"]
        path = PurePosixPath(filename)
        if path.is_absolute() or ".." in path.parts or "\\" in filename:
            raise ValueError("Unsafe model filename")
        if filename.endswith((".safetensors", ".json", ".txt", ".model", ".jinja", ".tiktoken")):
            selected.append(item)
    if not any(x["rfilename"].endswith(".safetensors") for x in selected):
        raise ValueError("This downloader requires safetensors weights; no suitable weights found")
    manifest = []
    for item in selected:
        filename = item["rfilename"]
        destination = args.download_dir / filename
        checksum = item.get("lfs", {}).get("sha256")
        download(f"https://huggingface.co/{repo}/resolve/{commit}/{quote(filename)}", destination, checksum)
        manifest.append({"filename": filename, "sha256": sha256(destination)})
    (args.download_dir / "download-provenance.json").write_text(json.dumps(
        {"repository": repo, "revision": commit, "files": manifest}, indent=2), encoding="utf-8")
    print(f"Model directory: {args.download_dir.resolve()}\nFrozen commit: {commit}")


if __name__ == "__main__":
    main()
