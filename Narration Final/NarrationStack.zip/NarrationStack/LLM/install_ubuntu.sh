#!/usr/bin/env bash
# Ubuntu 20.04 x86_64. Create LLM first, curl every application artifact, install offline.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
: "${DOWNLOAD_DIR:?Set DOWNLOAD_DIR to the directory for ALL downloaded artifacts}"
PROFILE="${PROFILE:-native}"  # native | transformers | vllm
CONDA_ROOT="${CONDA_ROOT:-$HOME/miniconda-LLM}"
case "$PROFILE" in native|transformers|vllm) ;; *) echo 'Invalid PROFILE' >&2; exit 2;; esac
[[ "$(uname -m)" == x86_64 ]] || { echo 'This lock set requires x86_64' >&2; exit 2; }
mkdir -p "$DOWNLOAD_DIR"
DOWNLOAD_DIR="$(cd -- "$DOWNLOAD_DIR" && pwd)"
export DOWNLOAD_DIR
command -v curl >/dev/null || { echo 'Install curl first: sudo apt-get update && sudo apt-get install -y curl ca-certificates' >&2; exit 2; }
CURL=(curl --fail --location --retry 5 --retry-delay 2 --connect-timeout 60)
[[ -z "${DOWNLOAD_PROXY:-}" ]] || CURL+=(--proxy "$DOWNLOAD_PROXY")
[[ -z "${CURL_CA_BUNDLE:-}" ]] || CURL+=(--cacert "$CURL_CA_BUNDLE")
[[ "${CURL_INSECURE:-0}" != 1 ]] || CURL+=(--insecure)

INSTALLER=Miniconda3-py311_25.1.1-2-Linux-x86_64.sh
INSTALLER_SHA=d8c1645776c0758214e4191c605abe5878002051316bd423f2b14b22d6cb4251
if [[ ! -x "$CONDA_ROOT/bin/conda" ]]; then
  if [[ ! -f "$DOWNLOAD_DIR/$INSTALLER" ]]; then
    "${CURL[@]}" --continue-at - --output "$DOWNLOAD_DIR/$INSTALLER.part" \
      "https://repo.anaconda.com/miniconda/$INSTALLER"
    printf '%s  %s\n' "$INSTALLER_SHA" "$DOWNLOAD_DIR/$INSTALLER.part" | sha256sum -c -
    mv -- "$DOWNLOAD_DIR/$INSTALLER.part" "$DOWNLOAD_DIR/$INSTALLER"
  fi
  printf '%s  %s\n' "$INSTALLER_SHA" "$DOWNLOAD_DIR/$INSTALLER" | sha256sum -c -
  bash "$DOWNLOAD_DIR/$INSTALLER" -b -k -p "$CONDA_ROOT"
  printf '%s\n' "$INSTALLER_SHA" > "$CONDA_ROOT/.llm-bootstrap-sha256"
fi
[[ -f "$CONDA_ROOT/.llm-bootstrap-sha256" && "$(cat "$CONDA_ROOT/.llm-bootstrap-sha256")" == "$INSTALLER_SHA" ]] || {
  echo 'CONDA_ROOT is not the pinned LLM bootstrap. Choose a fresh CONDA_ROOT.' >&2; exit 2;
}
source "$ROOT/../containers/conda_offline.sh"
clone_offline_env "$CONDA_ROOT" LLM
source "$CONDA_ROOT/etc/profile.d/conda.sh"
conda activate "$CONDA_ROOT/envs/LLM"
python -c 'import sys; assert sys.version_info[:3] == (3,11,11), sys.version'
if [[ "${CHECK_GPU:-1}" == 1 ]]; then
  python "$ROOT/../containers/check_gpu.py" --profile "$PROFILE"
fi
mkdir -p "$DOWNLOAD_DIR/manifests"
conda list --explicit > "$DOWNLOAD_DIR/manifests/conda-explicit.txt"
conda list --json > "$DOWNLOAD_DIR/manifests/conda-packages.json"
if [[ -f "$CONDA_PREFIX/.llm-profile" ]] && [[ "$(cat "$CONDA_PREFIX/.llm-profile")" != "$PROFILE" ]]; then
  echo 'This LLM environment already has another profile. Use another CONDA_ROOT to keep the stacks isolated.' >&2
  exit 2
fi
COMMON_WHEELS="$DOWNLOAD_DIR/wheels-common"
python "$ROOT/download_packages.py" "$ROOT/../containers/common.lock" "$COMMON_WHEELS" --jobs "${DOWNLOAD_JOBS:-4}"
export PIP_NO_INDEX=1 PIP_DISABLE_PIP_VERSION_CHECK=1
python -m pip install --no-index --no-deps --require-hashes -r "$COMMON_WHEELS/install-wheels.txt"
WHEELS="$DOWNLOAD_DIR/wheels-$PROFILE"
python "$ROOT/download_packages.py" "$ROOT/locks/$PROFILE.txt" "$WHEELS" --jobs "${DOWNLOAD_JOBS:-4}"
export PIP_NO_INDEX=1 PIP_DISABLE_PIP_VERSION_CHECK=1
python -m pip install --no-index --no-deps --require-hashes -r "$WHEELS/install-wheels.txt"
python -m pip check
python "$ROOT/../containers/write_runtime_env.py" --environment "$CONDA_PREFIX" --output "$ROOT/runtime/activate_python.sh"
source "$ROOT/runtime/activate_python.sh"
if [[ "${CHECK_GPU:-1}" == 1 && "$PROFILE" != native ]]; then
  python "$ROOT/../containers/check_gpu.py" --profile "$PROFILE" --torch
fi
printf '%s\n' "$PROFILE" > "$CONDA_PREFIX/.llm-profile"
python -m pip freeze --all > "$DOWNLOAD_DIR/manifests/pip-$PROFILE.txt"
cd "$ROOT"
python -m pytest -q tests
echo "Ready: conda environment LLM, profile=$PROFILE"
printf 'Activate from your own shell: source %q; conda activate %q\n' "$CONDA_ROOT/etc/profile.d/conda.sh" "$CONDA_ROOT/envs/LLM"
printf 'Then source %q\n' "$ROOT/runtime/activate_python.sh"
echo "Run build_native.sh to build the CUDA llama.cpp server; download_model.py to obtain weights."
