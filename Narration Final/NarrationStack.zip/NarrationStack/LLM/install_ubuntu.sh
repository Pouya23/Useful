#!/usr/bin/env bash
# Ubuntu 20.04 x86_64. Create LLM first, curl every application artifact, install offline.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
: "${DOWNLOAD_DIR:?Set DOWNLOAD_DIR to the directory for ALL downloaded artifacts}"
PROFILE="${PROFILE:-native}"  # native | transformers | vllm
CONDA_ROOT="${CONDA_ROOT:-$HOME/miniconda-LLM}"
case "$PROFILE" in native|transformers|vllm) ;; *) echo 'Invalid PROFILE' >&2; exit 2;; esac
[[ "$(uname -m)" == x86_64 ]] || { echo 'This lock set requires x86_64' >&2; exit 2; }
mkdir -p "$DOWNLOAD_DIR"
DOWNLOAD_DIR="$(cd -- "$DOWNLOAD_DIR" && pwd)"
export DOWNLOAD_DIR
command -v curl >/dev/null || { echo 'Install curl first: sudo apt-get update && sudo apt-get install -y curl ca-certificates' >&2; exit 2; }
CURL=(curl --fail --location --retry 5 --retry-delay 2 --connect-timeout 60)
[[ -z "${DOWNLOAD_PROXY:-}" ]] || CURL+=(--proxy "$DOWNLOAD_PROXY")
[[ -z "${CURL_CA_BUNDLE:-}" ]] || CURL+=(--cacert "$CURL_CA_BUNDLE")
[[ "${CURL_INSECURE:-0}" != 1 ]] || CURL+=(--insecure)

INSTALLER=Miniconda3-py311_25.1.1-2-Linux-x86_64.sh
INSTALLER_SHA=d8c1645776c0758214e4191c605abe5878002051316bd423f2b14b22d6cb4251
if [[ ! -x "$CONDA_ROOT/bin/conda" ]]; then
  if [[ ! -f "$DOWNLOAD_DIR/$INSTALLER" ]]; then
    "${CURL[@]}" --continue-at - --output "$DOWNLOAD_DIR/$INSTALLER.part" \
      "https://repo.anaconda.com/miniconda/$INSTALLER"
    printf '%s  %s\n' "$INSTALLER_SHA" "$DOWNLOAD_DIR/$INSTALLER.part" | sha256sum -c -
    mv -- "$DOWNLOAD_DIR/$INSTALLER.part" "$DOWNLOAD_DIR/$INSTALLER"
  fi
  printf '%s  %s\n' "$INSTALLER_SHA" "$DOWNLOAD_DIR/$INSTALLER" | sha256sum -c -
  bash "$DOWNLOAD_DIR/$INSTALLER" -b -k -p "$CONDA_ROOT"
  printf '%s\n' "$INSTALLER_SHA" > "$CONDA_ROOT/.llm-bootstrap-sha256"
fi
[[ -f "$CONDA_ROOT/.llm-bootstrap-sha256" && "$(cat "$CONDA_ROOT/.llm-bootstrap-sha256")" == "$INSTALLER_SHA" ]] || {
  echo 'CONDA_ROOT is not the pinned LLM bootstrap. Choose a fresh CONDA_ROOT.' >&2; exit 2;
}
source "$CONDA_ROOT/etc/profile.d/conda.sh"
if [[ ! -d "$CONDA_ROOT/envs/LLM" ]]; then
  # The fixed installer contains the entire conda/Python dependency closure.
  # Clone from its local package cache: no channel access, solver or pip download.
  conda create --offline --yes --name LLM --clone "$CONDA_ROOT"
fi
conda activate LLM
python -c 'import sys; assert sys.version_info[:3] == (3,11,11), sys.version'
mkdir -p "$DOWNLOAD_DIR/manifests"
conda list --explicit > "$DOWNLOAD_DIR/manifests/conda-explicit.txt"
conda list --json > "$DOWNLOAD_DIR/manifests/conda-packages.json"
if [[ -f "$CONDA_PREFIX/.llm-profile" ]] && [[ "$(cat "$CONDA_PREFIX/.llm-profile")" != "$PROFILE" ]]; then
  echo 'This LLM environment already has another profile. Use another CONDA_ROOT to keep the stacks isolated.' >&2
  exit 2
fi
WHEELS="$DOWNLOAD_DIR/wheels-$PROFILE"
python "$ROOT/download_packages.py" "$ROOT/locks/$PROFILE.txt" "$WHEELS" --jobs "${DOWNLOAD_JOBS:-4}"
export PIP_NO_INDEX=1 PIP_DISABLE_PIP_VERSION_CHECK=1
python -m pip install --no-index --no-deps --require-hashes -r "$WHEELS/install-wheels.txt"
python -m pip check
printf '%s\n' "$PROFILE" > "$CONDA_PREFIX/.llm-profile"
python -m pip freeze --all > "$DOWNLOAD_DIR/manifests/pip-$PROFILE.txt"
cd "$ROOT"
python -m pytest -q tests
echo "Ready: conda environment LLM, profile=$PROFILE"
echo "Run build_native.sh to build the CUDA llama.cpp server; download_model.py to obtain weights."
