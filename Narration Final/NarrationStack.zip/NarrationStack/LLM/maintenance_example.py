"""Python-only example matching the maintenance brief used in the model comparison.

Run from this script directory with a configured local CUDA runtime and model.
All sample/reference text below is fictional training material, not an approved SOP.
For real equipment, replace REFERENCE with the approved manufacturer/site documents.
"""

import os
from pipeline_core import EngineSettings, WritingSession, Source, WritingRequest, review_interactively

SAMPLE_1 = """Reliable pipe handling starts with equipment that is maintained consistently.
Before maintenance is planned, the team reviews the equipment's condition, the reported
defects and the manufacturer's maintenance instructions. Everyone should understand which
parts of the system will be worked on and who is responsible for the task.

Maintenance must follow the approved site procedure, including isolation and control of
stored energy. Once the equipment is in the approved condition for the work, authorized
personnel inspect the relevant rollers, gripping surfaces, guards, hoses and connections.
Leaks, unusual wear and damaged components are recorded and referred for assessment rather
than treated as normal. Lubrication and replacement work follow the specified maintenance
requirements. Before the system returns to service, the responsible person confirms that
the required checks and records are complete."""

SAMPLE_2 = """A good maintenance record explains what was found, what was done and what still
needs attention. For a pipe handling system, useful observations may concern the condition
of guides and rollers, gripping components, hydraulic connections, protective guards or
control devices. Descriptions should be clear enough for the next person to understand the
defect without guessing.

Work is carried out by authorized personnel using the applicable manufacturer instructions
and site maintenance procedure. Isolation and stored energy controls are part of that
procedure. A component that needs further assessment stays out of service as directed by
the responsible person. The handover includes outstanding defects, the work completed and
the results of the prescribed checks. Return to service follows the approved process;
finishing a repair does not by itself establish that the entire system is ready."""

REFERENCE = """FICTIONAL DEMO REFERENCE: Maintenance of pipe handling systems.
Use the relevant manufacturer's maintenance instructions, site procedure and authorized
maintenance personnel. Plan the work from condition reports and outstanding defects.
Follow the approved procedure for isolation and control of stored energy; no specific
isolation sequence is supplied in this reference. Inspect the applicable rollers, guides,
gripping components, guards, hydraulic hoses and connections, and control/safety devices
as specified for the actual system. Report leaks, wear, loose or damaged components and
abnormal operation for assessment. Keep equipment with unresolved defects out of service
as directed by the responsible person. Lubrication, adjustment and replacement follow
manufacturer requirements; this reference supplies no torque, pressure or service interval.
Prescribed functional checks and authorized handover/return to service follow the approved
procedure. Record condition findings, maintenance completed, checks and outstanding defects.
Never infer equipment-specific steps from this general training reference."""

BRIEF = WritingRequest(
    title="Maintenance of pipe handling systems",
    instructions="Write practical spoken training for workers and supervisors. Explain why "
    "maintenance matters, how work is planned, what condition checks cover, and "
    "how defects and return to service are handled. Use connected prose.",
    required_points=(
        "Plan maintenance using condition reports and manufacturer instructions.",
        "Use authorized personnel and the approved isolation and stored energy procedure.",
        "Cover rollers, guides and gripping components.",
        "Cover guards, hydraulic hoses/connections and applicable control or safety devices.",
        "Report defects and keep unresolved equipment out of service as directed.",
        "Follow manufacturer requirements for lubrication, adjustment and replacement.",
        "Complete prescribed checks, records and authorized return to service.",
    ),
    samples=(SAMPLE_1, SAMPLE_2),  # Set () to omit writing samples.
    sources=(Source("maintenance-demo", REFERENCE, "Synthetic example reference"),),
    duration_seconds=180,
    speaking_rate_wpm=130,
    duration_tolerance=0.10,
)


def main():
    # Keep this session open to process more briefs without loading the model again.
    # CPU KV preserves the tested configuration; optional GPU KV uses extra VRAM.
    with WritingSession(EngineSettings(name="llama_cpp", context_tokens=32768,
                                     gguf_model=os.environ.get("LLM_GGUF_MODEL"))) as model:
        job = model.new_job(BRIEF)
        initial = job.draft()  # ONE direct generation; full text is printed.
        print("Initial words:", initial["word_count"])
        final = review_interactively(job)
        # The measured word count generates length feedback AUTOMATICALLY.
        # Unlimited rounds: each round makes at most ONE generation and shows its text.
        # Enter accepts when length is met; /done accepts the current draft explicitly.
        # Programmatic alternative: job.revise(quality_feedback="Improve tone.")
        # Then: job.revise(length_direction="shorter")
        # Then: job.revise(duration_seconds=150)
        print("Final words:", final["word_count"])
        print("Length met:", not final["length_feedback"]["needs_length_revision"])
        print("Saved texts and metrics:", job.output)


if __name__ == "__main__":
    main()
