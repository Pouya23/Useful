"""Fast Qwen writer: direct draft and unlimited visible feedback rounds."""

from .requests import Source, WritingError, WritingRequest, count_words
from .writer import FastQwenSession, FastWritingJob, automatic_length_feedback, review_interactively
from .fit import FitSettings, revise_until_fit
from .session import WritingSession
from .engines.base import EngineSettings
from .duration import DurationPolicy

__all__ = [
    "FastQwenSession",
    "FastWritingJob",
    "Source",
    "WritingError",
    "WritingRequest",
    "automatic_length_feedback",
    "count_words",
    "review_interactively",
    "revise_until_fit",
    "FitSettings",
    "WritingSession",
    "EngineSettings",
    "DurationPolicy",
]
