"""Shared timestamped output naming for CLI and resident API sessions."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'containers'))
from output_paths import artifact_path, new_artifact_dir
