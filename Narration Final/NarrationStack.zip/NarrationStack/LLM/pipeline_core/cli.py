"""Readable command line: brief → draft → length-fit revisions (max retries)."""

import argparse
import os
from pathlib import Path

from .requests import Source, WritingRequest, WritingError
from .fit import FitSettings, revise_until_fit
from .duration_api import DurationApiConfig
from .session import WritingSession
from .engines.base import EngineSettings, MODEL_ID, MODEL_REVISION


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Local LLM: narration draft and automatic duration-fit revisions"
    )
    parser.add_argument("--engine", choices=["llama_cpp", "transformers", "vllm"], default="llama_cpp")
    parser.add_argument("--model", default=MODEL_ID, help="HF model ID or downloaded local model directory")
    parser.add_argument("--model-revision", help="HF commit/revision; default Qwen uses its original pinned commit")
    parser.add_argument("--model-sha256", help="Optional required SHA256 for --gguf-model")
    parser.add_argument("--vram-limit-gb", type=float, default=10.5, help="Decimal GB ceiling; original default retained")
    parser.add_argument("--headroom-gb", type=float, default=1.5)
    parser.add_argument("--prefill-chunk-tokens", type=int, default=512)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max-rounds", type=int, help="Total generations including the draft; overrides --max-retries")
    parser.add_argument("--duration-seconds", type=float, required=True)
    parser.add_argument("--speaking-rate-wpm", type=float, default=130)
    parser.add_argument("--duration-tolerance", type=float, default=0.10)
    parser.add_argument(
        "--speech-duration-tolerance",
        type=float,
        default=0.10,
        help="Relative band around --duration-seconds when --no-estimate uses POST /duration",
    )
    parser.add_argument(
        "--max-retries",
        type=int,
        default=5,
        help="Max length-repair revision rounds after the initial draft (generations saved each round)",
    )
    parser.add_argument(
        "--estimate",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="If true (default), accept by word-count estimate; if false, use POST /duration",
    )
    parser.add_argument("--duration-api-host", help="Host for accurate-mode POST /duration")
    parser.add_argument("--duration-api-port", type=int, help="Port for accurate-mode POST /duration")
    parser.add_argument("--duration-api-key", help="Optional X-API-Key for the duration API")
    parser.add_argument("--duration-api-scheme", choices=["http", "https"], default="http")
    parser.add_argument("--duration-api-timeout", type=float, default=120)
    parser.add_argument("--duration-api-use-proxy", action="store_true", help="Use environment proxies for this API")
    parser.add_argument("--voice", default="am_onyx")
    parser.add_argument("--lang-code", choices=["a", "b"], default="a")
    parser.add_argument("--speech-speed", type=float, default=1)
    parser.add_argument("--atempo-min", type=float, default=0.93)
    parser.add_argument("--atempo-max", type=float, default=1.15)
    parser.add_argument("--title", default="Maintenance of pipe handling systems")
    parser.add_argument("--instructions", default="Write clear spoken training using the supplied sources.")
    parser.add_argument("--point", action="append", default=[])
    parser.add_argument("--sample", type=Path, action="append", default=[])
    parser.add_argument("--source", type=Path, action="append", default=[])
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--context-tokens", type=int, default=32768)
    parser.add_argument("--max-output-tokens", type=int)
    parser.add_argument("--worker-python")
    parser.add_argument("--dtype", choices=["auto", "float16", "bfloat16"], default="auto")
    parser.add_argument("--server")
    parser.add_argument("--gguf-model")
    parser.add_argument("--kv-cache-device", choices=["cpu", "gpu"], default="cpu")
    parser.add_argument(
        "--show-progress",
        action="store_true",
        help="Print generation progress as a percentage (words so far / max word-range)",
    )
    parser.add_argument("--output", type=Path, help="Reusable output base; creates a unique UTC-timestamped run and artifact names")
    return parser


def _fit_settings(args: argparse.Namespace) -> FitSettings:
    duration_api = None
    host = args.duration_api_host
    port = args.duration_api_port
    api_key = args.duration_api_key or os.environ.get("DURATION_API_KEY")
    if host is not None or port is not None or api_key:
        if not host or port is None:
            raise WritingError("Provide both --duration-api-host and --duration-api-port together")
        duration_api = DurationApiConfig(
            host=host, port=port, api_key=api_key,
            scheme=args.duration_api_scheme, timeout_seconds=args.duration_api_timeout,
            use_proxy=args.duration_api_use_proxy, voice=args.voice, lang_code=args.lang_code,
            speed=args.speech_speed, atempo_min=args.atempo_min, atempo_max=args.atempo_max,
        )
        duration_api.validate()
    if args.max_rounds is not None and args.max_rounds < 1:
        raise WritingError("--max-rounds must be at least 1")
    settings = FitSettings(
        max_retries=args.max_retries if args.max_rounds is None else args.max_rounds - 1,
        estimate=args.estimate,
        speech_duration_tolerance=args.speech_duration_tolerance,
        duration_api=duration_api,
    )
    settings.validate()
    return settings


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    brief = WritingRequest(
        title=args.title,
        instructions=args.instructions,
        required_points=tuple(args.point),
        samples=tuple(p.read_text(encoding="utf-8-sig") for p in args.sample),
        sources=tuple(
            Source(f"source-{i}", p.read_text(encoding="utf-8-sig"), str(p))
            for i, p in enumerate(args.source, 1)
        ),
        duration_seconds=args.duration_seconds,
        speaking_rate_wpm=args.speaking_rate_wpm,
        duration_tolerance=args.duration_tolerance,
    )
    brief.validate()
    fit = _fit_settings(args)
    if not fit.estimate and args.duration_seconds > 1800:
        raise WritingError("The duration API accepts targets of at most 1800 seconds")
    settings = EngineSettings(
        name=args.engine,
        gpu_index=args.gpu_index,
        context_tokens=args.context_tokens,
        worker_python=args.worker_python,
        dtype=args.dtype,
        server=args.server,
        gguf_model=args.gguf_model,
        kv_cache_device=args.kv_cache_device,
        show_progress=args.show_progress,
        hf_model=args.model,
        revision=args.model_revision or (MODEL_REVISION if args.model == MODEL_ID else None),
        model_sha256=args.model_sha256,
        vram_limit_gb=args.vram_limit_gb,
        headroom_gb=args.headroom_gb,
        prefill_chunk_tokens=args.prefill_chunk_tokens,
    )
    settings.validate()
    with WritingSession(settings, output=args.output) as session:
        job = session.new_job(brief, max_output_tokens=args.max_output_tokens, seed=args.seed)
        job.draft()
        final = revise_until_fit(job, fit)
        if final.get("fit", {}).get("measured_duration_seconds") is not None:
            print("Measured speech duration:", round(final["fit"]["measured_duration_seconds"], 2), "seconds")
        print("Estimated duration:", round(final["estimated_duration_seconds"], 1), "seconds")
        print("Selected final text:", job.output / "final.txt")
        print("Saved texts and round metrics:", session.output)
    return 0
