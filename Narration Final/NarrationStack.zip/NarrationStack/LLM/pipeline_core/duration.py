"""Deterministic narration timing estimates, independent of the inference engine."""

import math
from decimal import Decimal, ROUND_HALF_UP, ROUND_FLOOR, ROUND_CEILING
from dataclasses import dataclass


@dataclass(frozen=True)
class DurationPolicy:
    seconds: float
    words_per_minute: float = 130.0
    tolerance: float = 0.10

    def validate(self):
        for name, value in (
            ("seconds", self.seconds),
            ("words_per_minute", self.words_per_minute),
            ("tolerance", self.tolerance),
        ):
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f"{name} must be a finite number")
        if self.seconds <= 0 or not 40 <= self.words_per_minute <= 300:
            raise ValueError("Use positive seconds and a speaking rate between 40 and 300 words/minute")
        if not 0 <= self.tolerance <= 0.5:
            raise ValueError("tolerance must be between 0 and 0.5")
        if not 20 <= self.target_words <= 20000:
            raise ValueError("Duration and rate must imply between 20 and 20000 target words")

    @property
    def target_words(self):
        target = Decimal(str(self.seconds)) * Decimal(str(self.words_per_minute)) / 60
        return int(target.to_integral_value(rounding=ROUND_HALF_UP))

    def word_range(self):
        self.validate()
        target, tolerance = Decimal(self.target_words), Decimal(str(self.tolerance))
        return (
            max(20, int((target * (1 - tolerance)).to_integral_value(rounding=ROUND_FLOOR))),
            min(20000, int((target * (1 + tolerance)).to_integral_value(rounding=ROUND_CEILING))),
        )

    def estimate_seconds(self, word_count):
        self.validate()
        return word_count * 60 / self.words_per_minute
