"""HTTP client for the Kokoro planning POST /duration endpoint (no audio)."""

from __future__ import annotations

import json
import math
import ipaddress
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from .requests import WritingError, count_words


ALLOWED_SAMPLE_RATES = frozenset({8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000})
ALLOWED_BITRATES = frozenset({64, 96, 128, 160, 192, 224, 256, 320})


@dataclass(frozen=True)
class DurationApiConfig:
    host: str
    port: int
    api_key: str | None = None
    voice: str = "am_onyx"
    lang_code: str = "a"
    speed: float = 1.0
    atempo_min: float = 0.93
    atempo_max: float = 1.15
    timeout_seconds: float = 120.0
    scheme: str = "http"
    use_proxy: bool = False

    def validate(self) -> None:
        self.base_url()
        if self.lang_code not in {"a", "b"} or not isinstance(self.voice, str) or not self.voice.startswith((self.lang_code + "m_", self.lang_code + "f_")):
            raise WritingError("voice must start with am_/af_ for a or bm_/bf_ for b")
        for name, low, high in (("speed", 0.25, 4), ("atempo_min", 0.125, 8), ("atempo_max", 0.125, 8), ("timeout_seconds", 0.001, 86400)):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
                raise WritingError(f"{name} must be finite and between {low} and {high}")
        if self.atempo_min > self.atempo_max:
            raise WritingError("atempo_min must not exceed atempo_max")

    def base_url(self) -> str:
        if not isinstance(self.host, str):
            raise WritingError("duration API host must be a hostname or IP")
        host = self.host.strip()
        if not host:
            raise WritingError("duration API host must be nonempty")
        if type(self.port) is not int or not 1 <= self.port <= 65535:
            raise WritingError("duration API port must be an integer from 1 to 65535")
        if self.scheme not in {"http", "https"} or any(c in host for c in "/?#@\\\r\n\t "):
            raise WritingError("Provide only a hostname/IP; set the API scheme separately")
        if ":" in host:
            try:
                ipaddress.IPv6Address(host.strip("[]"))
            except ValueError as exc:
                raise WritingError("Invalid IPv6 API host") from exc
            host = "[" + host.strip("[]") + "]"
        return f"{self.scheme}://{host}:{self.port}"


def _validate_request_text(text: str) -> str:
    if not isinstance(text, str):
        raise WritingError("duration API text must be a string")
    cleaned = text.strip()
    if not cleaned:
        raise WritingError("duration API text must be nonempty")
    if len(cleaned) > 100_000:
        raise WritingError("duration API text exceeds 100,000 characters")
    words = len(cleaned.split())
    if not 10 <= words <= 1000:
        raise WritingError("duration API text must contain 10-1000 words")
    return cleaned


def plan_duration(
    text: str,
    desired_duration: float,
    config: DurationApiConfig,
    *,
    seed: int = 42,
    sample_rate: int = 48000,
    bitrate_kbps: int = 320,
    split_pattern: str | None = r"\n+",
) -> dict[str, Any]:
    """POST /duration and return the JSON body. Raises WritingError on transport/HTTP errors."""
    cleaned = _validate_request_text(text)
    config.validate()
    if (
        isinstance(desired_duration, bool)
        or not isinstance(desired_duration, (int, float))
        or not math.isfinite(desired_duration)
        or not (desired_duration > 0 and desired_duration <= 1800)
    ):
        raise WritingError("desired_duration must be > 0 and <= 1800 seconds")
    if sample_rate not in ALLOWED_SAMPLE_RATES:
        raise WritingError(f"sample_rate must be one of {sorted(ALLOWED_SAMPLE_RATES)}")
    if bitrate_kbps not in ALLOWED_BITRATES:
        raise WritingError(f"bitrate_kbps must be one of {sorted(ALLOWED_BITRATES)}")
    if sample_rate < 32000 and bitrate_kbps > 160:
        raise WritingError("bitrate_kbps must be <= 160 when sample_rate is below 32000")
    if split_pattern not in {r"\n+", None}:
        raise WritingError('split_pattern must be "\\n+" or null')
    if type(seed) is not int or not 0 <= seed <= 2**32 - 1:
        raise WritingError("seed must be an integer from 0 to 2^32-1")

    body: dict[str, Any] = {
        "text": cleaned,
        "desired_duration": float(desired_duration),
        "voice": config.voice,
        "lang_code": config.lang_code,
        "speed": config.speed,
        "atempo_min": config.atempo_min,
        "atempo_max": config.atempo_max,
        "seed": seed,
        "sample_rate": sample_rate,
        "bitrate_kbps": bitrate_kbps,
    }
    if split_pattern is not None:
        body["split_pattern"] = split_pattern
    else:
        body["split_pattern"] = None

    url = f"{config.base_url()}/duration"
    headers = {"Content-Type": "application/json", "Accept": "application/json", "User-Agent": "qwen-writer/1.0"}
    if config.api_key:
        headers["X-API-Key"] = config.api_key
    request = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST"
    )
    try:
        opener = urllib.request.build_opener() if config.use_proxy else urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request, timeout=config.timeout_seconds) as response:
            raw_bytes = response.read(1_048_577)
            if len(raw_bytes) > 1_048_576:
                raise WritingError("duration API response exceeds 1 MiB")
            raw = raw_bytes.decode("utf-8")
            status = getattr(response, "status", 200)
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        raise WritingError(f"duration API HTTP {exc.code}: {detail[:2000]}") from exc
    except urllib.error.URLError as exc:
        raise WritingError(f"duration API unreachable at {url}: {exc}") from exc
    except TimeoutError as exc:
        raise WritingError(f"duration API timed out at {url}") from exc

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise WritingError("duration API returned non-JSON") from exc
    if status != 200:
        raise WritingError(f"duration API HTTP {status}: {payload!r}")
    if not isinstance(payload, dict):
        raise WritingError("duration API JSON must be an object")
    if "estimated_natural_duration_s" not in payload:
        raise WritingError("duration API response missing estimated_natural_duration_s")
    validate_duration_response(payload)
    return payload


def validate_duration_response(payload: dict) -> float:
    value = payload.get("estimated_natural_duration_s")
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise WritingError("duration API natural duration must be finite and positive")
    return float(value)
