"""Engine adapters. Importing this package never imports Torch or vLLM."""

from .base import EngineSettings

__all__ = ["EngineSettings"]
