"""Small common interface; heavy packages are imported only inside workers."""

from dataclasses import dataclass
import math
import re
from typing import Protocol

MODEL_ID = "Qwen/Qwen3.5-9B"
MODEL_REVISION = "c202236235762e1c871ad0ccb60c8ee5ba337b9a"


@dataclass(frozen=True)
class EngineSettings:
    name: str = "llama_cpp"
    context_tokens: int = 32768
    gpu_index: int = 0
    worker_python: str | None = None
    hf_model: str = MODEL_ID
    revision: str | None = MODEL_REVISION
    server: str | None = None
    gguf_model: str | None = None
    kv_cache_device: str = "cpu"
    prefill_chunk_tokens: int = 512
    dtype: str = "auto"
    show_progress: bool = False
    model_sha256: str | None = None
    local_files_only: bool = True
    vram_limit_gb: float = 10.5
    headroom_gb: float = 1.5

    def validate(self):
        if self.model_sha256 is not None and not re.fullmatch(r"[0-9a-fA-F]{64}", self.model_sha256):
            raise ValueError("model_sha256 must contain exactly 64 hexadecimal characters")
        for name in ("vram_limit_gb", "headroom_gb"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if self.headroom_gb >= self.vram_limit_gb:
            raise ValueError("headroom_gb must be smaller than vram_limit_gb")
        if not isinstance(self.hf_model, str) or not self.hf_model.strip():
            raise ValueError("model must be a model ID or local directory")
        if self.dtype not in {"auto", "float16", "bfloat16"}:
            raise ValueError("dtype must be auto, float16 or bfloat16")
        if self.name not in {"llama_cpp", "transformers", "vllm"}:
            raise ValueError("Choose llama_cpp, transformers, or vllm")
        if type(self.context_tokens) is not int or not 512 <= self.context_tokens <= 262144:
            raise ValueError("context_tokens must be 512..262144")
        if type(self.gpu_index) is not int or self.gpu_index < 0:
            raise ValueError("gpu_index must be a nonnegative integer")
        if type(self.prefill_chunk_tokens) is not int or self.prefill_chunk_tokens < 1:
            raise ValueError("prefill_chunk_tokens must be positive")
        if self.kv_cache_device not in {"cpu", "gpu"}:
            raise ValueError("kv_cache_device must be cpu or gpu")
        if type(self.show_progress) is not bool:
            raise ValueError("show_progress must be a boolean")


class Engine(Protocol):
    effective_context_size: int

    def complete(self, messages: list[dict], **sampling) -> dict: ...
    def close(self) -> None: ...


def admit(prompt_tokens, output_tokens, context_tokens):
    """Reject an oversized prompt intact, before allocating its generation cache."""
    if type(output_tokens) is not int or output_tokens <= 0:
        raise ValueError("max_tokens must be a positive integer")
    if prompt_tokens + output_tokens + 16 > context_tokens:
        raise ValueError(
            f"Context overflow: {prompt_tokens} prompt + {output_tokens} output + 16 reserve > {context_tokens}. Reduce input or output explicitly."
        )
