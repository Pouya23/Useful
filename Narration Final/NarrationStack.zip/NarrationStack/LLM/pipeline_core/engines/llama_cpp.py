"""Use the original guarded native engine, through the same session API."""

from ..llama_session import FastQwenSession


def create_session(settings, **options):
    return FastQwenSession(
        server=settings.server,
        model=settings.gguf_model,
        context_tokens=settings.context_tokens,
        gpu_index=settings.gpu_index,
        kv_cache_device=settings.kv_cache_device,
        show_progress=settings.show_progress,
        model_sha256=settings.model_sha256,
        vram_limit_gb=settings.vram_limit_gb,
        headroom_gb=settings.headroom_gb,
        **options,
    )
