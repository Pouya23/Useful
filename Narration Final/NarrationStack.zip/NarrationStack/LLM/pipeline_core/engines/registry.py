"""Deployment-owned interpreter allowlist; never import a GPU engine to select it."""
import json
import os
from pathlib import Path
import sys


def engine_workers():
    configured = os.getenv("LLM_ENGINE_REGISTRY")
    path = Path(configured) if configured else Path(sys.prefix) / ".llm-engines.json"
    if not path.exists():
        if configured:
            raise ValueError(f"Configured engine registry does not exist: {path}")
        return {}
    document = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(document, dict) or document.get("schema_version") != 1:
        raise ValueError("Invalid engine registry schema")
    workers = document.get("workers")
    if not isinstance(workers, dict) or any(k not in {"llama_cpp", "transformers", "vllm"}
                                          or not isinstance(v, str) or not Path(v).is_absolute()
                                          for k, v in workers.items()):
        raise ValueError("Engine registry must contain named engines and absolute interpreter paths")
    return workers


def resolve_worker(engine, explicit=None, *, restricted=False):
    workers = engine_workers()
    selected = workers.get(engine)
    if workers and engine not in workers and not explicit:
        raise ValueError(f"Engine {engine!r} is not installed; rerun setup with profile=compatible (native + Transformers) or all (adds vLLM on supported hardware)")
    if restricted and explicit and Path(explicit).resolve() != Path(selected or sys.executable).resolve():
        raise ValueError("worker_python must match this engine's deployment-registered interpreter")
    result = explicit or selected
    if result and not Path(result).is_file():
        raise ValueError(f"Engine interpreter is missing: {result}; reinstall the selected profile")
    return result
