"""Hardware-selected computation / NF4 weights, with bounded chunked prefill."""

import hashlib
import inspect
import threading
import time
from .base import admit
from ..progress import make_reporter


class TransformersEngine:
    def __init__(self, settings, memory_fraction):
        import torch
        from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, Qwen3_5ForConditionalGeneration

        self.torch = torch
        self.settings = settings
        self.effective_context_size = settings.context_tokens
        if not torch.cuda.is_available():
            raise RuntimeError(
                "CUDA is not available to this worker. Often the installed PyTorch CUDA "
                f"build (torch {torch.__version__}, cuda {torch.version.cuda}) is newer than "
                "the NVIDIA driver; install a torch build that matches the driver "
                "(for CUDA 12.2 drivers, use a cu121 wheel) or upgrade the driver."
            )
        if torch.cuda.device_count() != 1:
            raise RuntimeError(
                f"The worker must see exactly one CUDA GPU; saw {torch.cuda.device_count()}"
            )
        torch.cuda.set_per_process_memory_fraction(memory_fraction, 0)
        use_bfloat16 = settings.dtype == "bfloat16" or (
            settings.dtype == "auto" and torch.cuda.is_bf16_supported()
        )
        compute_dtype = torch.bfloat16 if use_bfloat16 else torch.float16
        self.compute_dtype_name = "bfloat16" if use_bfloat16 else "float16"
        self.tokenizer = AutoTokenizer.from_pretrained(
            settings.hf_model, revision=settings.revision, trust_remote_code=False,
            local_files_only=settings.local_files_only,
        )
        config = AutoConfig.from_pretrained(settings.hf_model, revision=settings.revision,
                                          trust_remote_code=False, local_files_only=settings.local_files_only)
        self.qwen_prefill = config.model_type == "qwen3_5"
        loader = Qwen3_5ForConditionalGeneration if self.qwen_prefill else AutoModelForCausalLM
        quantization = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=compute_dtype,
            bnb_4bit_use_double_quant=True,
        )
        self.model = loader.from_pretrained(
            settings.hf_model,
            revision=settings.revision,
            trust_remote_code=False,
            quantization_config=quantization,
            dtype=compute_dtype,
            device_map={"": 0},
            local_files_only=settings.local_files_only,
        ).eval()
        parameters = inspect.signature(self.model.forward).parameters
        self.logits_keyword = next((name for name in ("logits_to_keep", "num_logits_to_keep") if name in parameters), None)
        if any(str(device) not in {"0", "cuda:0"} for device in self.model.hf_device_map.values()):
            raise RuntimeError("CPU/disk offload or multiple GPUs are not allowed")

    def prompt_ids(self, messages):
        rendered = self.tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True, enable_thinking=False
        )
        ids = self.tokenizer(rendered, add_special_tokens=False, return_tensors="pt")["input_ids"]
        return rendered, ids

    def prompt_tokens(self, messages):
        return self.prompt_ids(messages)[1].shape[1]

    def complete(
        self,
        messages,
        *,
        max_tokens,
        temperature,
        top_p,
        top_k,
        seed,
        json_schema=None,
        show_progress=False,
        progress_word_limit=None,
    ):
        if json_schema is not None:
            raise ValueError("This writing pipeline does not request JSON generation")
        torch = self.torch
        rendered, input_ids = self.prompt_ids(messages)
        prompt_count = input_ids.shape[1]
        admit(prompt_count, max_tokens, self.effective_context_size)
        input_ids = input_ids.to("cuda:0")
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        started = time.perf_counter()
        reporter = make_reporter(show_progress, progress_word_limit, ipc=True)
        callback = getattr(self, "token_callback", None)
        # Cache only this pass. Exclude the last token so generate() always has
        # one uncached input token and never repeats the full prompt prefill.
        cache = None
        with torch.inference_mode():
            for start in range(0, prompt_count - 1 if self.qwen_prefill else 0, self.settings.prefill_chunk_tokens):
                end = min(start + self.settings.prefill_chunk_tokens, prompt_count - 1)
                output = self.model(
                    input_ids=input_ids[:, start:end],
                    position_ids=torch.arange(start, end, device="cuda:0").view(1, 1, -1).expand(4, 1, -1),
                    attention_mask=torch.ones((1, end), device="cuda:0", dtype=torch.long),
                    past_key_values=cache,
                    use_cache=True,
                    logits_to_keep=1,
                )
                cache = output.past_key_values
                del output
            generate_kwargs = dict(
                input_ids=input_ids,
                attention_mask=torch.ones_like(input_ids),
                past_key_values=cache,
                max_new_tokens=max_tokens,
                do_sample=True,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                min_p=0.0,
                repetition_penalty=1.0,
                use_cache=True,
                return_dict_in_generate=False,
                pad_token_id=self.tokenizer.eos_token_id,
            )
            if self.logits_keyword:
                generate_kwargs[self.logits_keyword] = 1
            if reporter is None and callback is None:
                generated = self.model.generate(**generate_kwargs)
            else:
                from transformers import TextIteratorStreamer

                class TokenStreamer(TextIteratorStreamer):
                    # Keep the official tokenizer's word/Unicode buffering; each
                    # generated token ID is still sent immediately, even if text
                    # must wait for a decodable boundary.
                    def put(inner, value):
                        prompt = inner.skip_prompt and inner.next_tokens_are_prompt
                        inner.last_delta = ""
                        value = value.cpu() if callback else value
                        super().put(value)
                        if callback and not prompt:
                            callback({"text": inner.last_delta, "token_ids": value.reshape(-1).tolist(),
                                      "unit": "model_token"})

                    def on_finalized_text(inner, text, stream_end=False):
                        inner.last_delta = text
                        super().on_finalized_text(text, stream_end=stream_end)
                        if callback and stream_end and text:
                            callback({"text": text, "token_ids": [], "unit": "decoder_flush"})

                streamer = TokenStreamer(self.tokenizer, skip_prompt=True, skip_special_tokens=callback is not None)
                generate_kwargs["streamer"] = streamer
                holder: dict = {}

                def _run():
                    try:
                        # Inference mode is thread-local; the outer context does not cover this thread.
                        with torch.inference_mode():
                            holder["generated"] = self.model.generate(**generate_kwargs)
                    except BaseException as exc:  # noqa: BLE001 - re-raise after stream drain
                        holder["error"] = exc
                        streamer.on_finalized_text("", stream_end=True)

                worker = threading.Thread(target=_run, daemon=True)
                worker.start()
                try:
                    for piece in streamer:
                        if reporter:
                            reporter.append_text(piece)
                finally:
                    worker.join()
                    if reporter:
                        reporter.finish()
                if "error" in holder:
                    raise holder["error"]
                generated = holder["generated"]
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - started
        new_tokens = generated[0, prompt_count:].tolist()
        eos = self.model.generation_config.eos_token_id
        eos_ids = {eos} if isinstance(eos, int) else set(eos or [])
        finish = "stop" if new_tokens and new_tokens[-1] in eos_ids else "length"
        result = {
            # Preserve unexpected control/thinking tokens for shared validation.
            "text": self.tokenizer.decode(
                new_tokens[:-1] if finish == "stop" else new_tokens, skip_special_tokens=False
            ),
            "finish_reason": finish,
            "usage": {"prompt_tokens": prompt_count, "completion_tokens": len(new_tokens)},
            "rendered_prompt_sha256": hashlib.sha256(rendered.encode()).hexdigest(),
            "engine_seconds": elapsed,
            "quantization": "bitsandbytes NF4 double quant; " + self.compute_dtype_name + " compute",
            "prefix_cache": False,
        }
        del generated, cache, input_ids
        return result

    def close(self):
        del self.model
        self.torch.cuda.empty_cache()
