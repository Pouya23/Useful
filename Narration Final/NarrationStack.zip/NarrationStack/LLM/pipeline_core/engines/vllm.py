"""Single-GPU eager vLLM with an explicit memory budget and NF4 weights.

vLLM loads the model in-process inside the worker; there is no HTTP server, so
Unix domain sockets do not apply to this engine.
"""

import hashlib
import time
from .base import admit
from ..progress import make_reporter


class VllmEngine:
    def __init__(self, settings, memory_fraction):
        import sys

        if sys.platform != "linux":
            raise RuntimeError("vLLM requires Linux (Linux/WSL), not native Windows")
        import torch
        if not torch.cuda.is_available() or torch.cuda.get_device_capability(0) < (7, 5):
            raise RuntimeError("This vLLM build requires a Turing-or-newer GPU and a CUDA 13-compatible driver; GTX 1080 Ti is unsupported")
        from transformers import AutoTokenizer
        from vllm import LLM

        self.settings = settings
        self.effective_context_size = settings.context_tokens
        self.tokenizer = AutoTokenizer.from_pretrained(
            settings.hf_model, revision=settings.revision, trust_remote_code=False,
            local_files_only=settings.local_files_only,
        )
        self.model = LLM(
            model=settings.hf_model,
            revision=settings.revision,
            tokenizer_revision=settings.revision,
            dtype=settings.dtype,
            quantization="bitsandbytes",
            tensor_parallel_size=1,
            max_model_len=settings.context_tokens,
            max_num_seqs=1,
            max_num_batched_tokens=settings.prefill_chunk_tokens,
            enable_chunked_prefill=True,
            enforce_eager=True,
            enable_prefix_caching=False,
            gpu_memory_utilization=memory_fraction,
            trust_remote_code=False,
            limit_mm_per_prompt={"image": 0, "video": 0},
        )

    def prompt_ids(self, messages):
        rendered = self.tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True, enable_thinking=False
        )
        return rendered, self.tokenizer.encode(rendered, add_special_tokens=False)

    def prompt_tokens(self, messages):
        return len(self.prompt_ids(messages)[1])

    def complete(
        self,
        messages,
        *,
        max_tokens,
        temperature,
        top_p,
        top_k,
        seed,
        json_schema=None,
        show_progress=False,
        progress_word_limit=None,
    ):
        from vllm import SamplingParams

        if json_schema is not None:
            raise ValueError("This writing pipeline does not request JSON generation")
        rendered, ids = self.prompt_ids(messages)
        admit(len(ids), max_tokens, self.effective_context_size)
        reporter = make_reporter(show_progress, progress_word_limit, ipc=True)
        sampling_kwargs = dict(
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            min_p=0.0,
            seed=seed,
            repetition_penalty=1.0,
            skip_special_tokens=False,
        )
        sampling = SamplingParams(**sampling_kwargs)
        started = time.perf_counter()
        callback = getattr(self, "token_callback", None)
        if callback or reporter is not None:
            # Drive the same resident engine one scheduler step at a time.
            # Never replay a buffered final completion as if it were live.
            import uuid
            request_id = uuid.uuid4().hex
            engine = self.model.llm_engine
            engine.add_request(request_id, {"prompt_token_ids": ids}, sampling)
            previous_text, previous_tokens = "", 0
            final = None
            try:
                while engine.has_unfinished_requests():
                    for result in engine.step():
                        if result.request_id != request_id or not result.outputs:
                            continue
                        candidate = result.outputs[0]
                        common = 0
                        for left, right in zip(previous_text, candidate.text):
                            if left != right:
                                break
                            common += 1
                        new_ids = list(candidate.token_ids[previous_tokens:])
                        if callback and (new_ids or candidate.text != previous_text):
                            callback({"text": candidate.text[common:], "token_ids": new_ids,
                                      "replace_from": common if common < len(previous_text) else None,
                                      "unit": "model_token"})
                        if reporter is not None:
                            reporter.update_text(candidate.text)
                        previous_text, previous_tokens = candidate.text, len(candidate.token_ids)
                        if result.finished:
                            final = result
                if final is None:
                    raise RuntimeError("vLLM stream ended without a final completion")
                results = [final]
            except BaseException:
                engine.abort_request([request_id])
                raise
        else:
            results = self.model.generate([{"prompt_token_ids": ids}], sampling, use_tqdm=False)
        elapsed = time.perf_counter() - started
        output = results[0].outputs[0]
        if reporter is not None:
            reporter.update_text(output.text)
            reporter.finish()
        return {
            "text": output.text,
            "finish_reason": output.finish_reason,
            "usage": {"prompt_tokens": len(ids), "completion_tokens": len(output.token_ids)},
            "rendered_prompt_sha256": hashlib.sha256(rendered.encode()).hexdigest(),
            "engine_seconds": elapsed,
            "quantization": "vLLM bitsandbytes in-flight 4bit",
            "prefix_cache": False,
        }

    def close(self):
        # Worker process exit is the authoritative cleanup for vLLM subprocesses.
        del self.model
