"""Automatic length-fit loop: stop in-range, else best-of after max retries."""

from __future__ import annotations

import copy
import json
import math
from dataclasses import asdict, dataclass
from typing import Any, Callable

from .duration import DurationPolicy
from .duration_api import DurationApiConfig, plan_duration, validate_duration_response
from .length import automatic_length_feedback
from .requests import WritingError, WritingRequest, count_words
from .telemetry import save_json


@dataclass(frozen=True)
class FitSettings:
    """CLI-driven acceptance policy for generation rounds."""

    max_retries: int = 5
    estimate: bool = True
    speech_duration_tolerance: float = 0.10
    duration_api: DurationApiConfig | None = None

    def validate(self) -> None:
        if type(self.max_retries) is not int or self.max_retries < 0:
            raise WritingError("max_retries must be a nonnegative integer")
        if type(self.estimate) is not bool:
            raise WritingError("estimate must be a boolean")
        if (
            isinstance(self.speech_duration_tolerance, bool)
            or not isinstance(self.speech_duration_tolerance, (int, float))
            or not 0 <= float(self.speech_duration_tolerance) <= 0.5
        ):
            raise WritingError("speech_duration_tolerance must be between 0 and 0.5")
        if not self.estimate:
            if self.duration_api is None:
                raise WritingError(
                    "Accurate duration fit requires --duration-api-host and --duration-api-port "
                    "(or set estimate=True)"
                )
            self.duration_api.validate()


def speech_duration_range(desired_seconds: float, tolerance: float) -> tuple[float, float]:
    if (
        isinstance(desired_seconds, bool)
        or not isinstance(desired_seconds, (int, float))
        or not math.isfinite(desired_seconds)
        or desired_seconds <= 0
    ):
        raise WritingError("desired duration must be a positive number")
    if isinstance(tolerance, bool) or not isinstance(tolerance, (int, float)) or not math.isfinite(tolerance) or not 0 <= tolerance <= 0.5:
        raise WritingError("speech_duration_tolerance must be between 0 and 0.5")
    return desired_seconds * (1.0 - tolerance), desired_seconds * (1.0 + tolerance)


def distance_to_range(value: float, low: float, high: float) -> float:
    if value < low:
        return low - value
    if value > high:
        return value - high
    return 0.0


def measure_fit(
    text: str,
    request: WritingRequest,
    settings: FitSettings,
    *,
    plan: Callable[..., dict[str, Any]] = plan_duration,
) -> dict[str, Any]:
    """Return whether text is in range and how far it is from the accepted band."""
    settings.validate()
    if request.duration_seconds is None:
        raise WritingError("Fit loop requires duration_seconds on the writing request")
    desired = float(request.duration_seconds)
    words = count_words(text)

    if settings.estimate:
        policy = DurationPolicy(desired, request.speaking_rate_wpm, request.duration_tolerance)
        low_w, high_w = policy.word_range()
        target = policy.target_words
        distance = distance_to_range(float(words), float(low_w), float(high_w))
        action = "keep"
        if words < low_w:
            action = "expand"
        elif words > high_w:
            action = "shorten"
        return {
            "mode": "estimate",
            "within_range": distance == 0.0,
            "measured_words": words,
            "word_range": [low_w, high_w],
            "target_words": target,
            "measured_duration_seconds": None,
            "duration_range": None,
            "desired_duration_seconds": desired,
            "distance": distance,
            "absolute_error_to_target": abs(words - target),
            "automatic_action": action,
            "duration_api": None,
        }

    assert settings.duration_api is not None
    api_words = len(text.split())
    if not 10 <= api_words <= 1000 or len(text.strip()) > 100_000:
        # The API cannot measure this candidate. Retain it, repair its text, and
        # never let an unmeasured candidate win an accurate-mode best-of selection.
        return {
            "mode": "accurate", "within_range": False, "measurement_valid": False,
            "measured_words": words, "word_range": [10, 1000], "target_words": None,
            "measured_duration_seconds": None,
            "duration_range": list(speech_duration_range(desired, settings.speech_duration_tolerance)),
            "desired_duration_seconds": desired, "distance": None, "absolute_error_to_target": None,
            "automatic_action": "expand" if api_words < 10 else "shorten", "duration_api": None,
            "measurement_error": "Text is outside /duration limits (10–1000 words; 100,000 characters)",
        }
    payload = plan(text, desired, settings.duration_api)
    measured = validate_duration_response(payload)
    low_s, high_s = speech_duration_range(desired, float(settings.speech_duration_tolerance))
    distance = distance_to_range(measured, low_s, high_s)
    action = "keep"
    if measured < low_s:
        action = "expand"
    elif measured > high_s:
        action = "shorten"
    return {
        "mode": "accurate",
        "within_range": distance == 0.0,
        "measured_words": words,
        "word_range": list(request.word_range()) if request.word_range() else None,
        "target_words": None,
        "measured_duration_seconds": measured,
        "duration_range": [low_s, high_s],
        "desired_duration_seconds": desired,
        "distance": distance,
        "absolute_error_to_target": abs(measured - desired),
        "automatic_action": action,
        "duration_api": payload,
    }


def select_best(candidates: list[dict[str, Any]]) -> dict[str, Any]:
    """Prefer in-range; otherwise closest to the band, then closest to the target."""
    if not candidates:
        raise WritingError("No generation candidates to select from")
    measured = [item for item in candidates if item["fit"].get("measurement_valid", True)]
    if not measured:
        raise WritingError("No candidate could be measured by /duration; all texts and round metrics are saved")
    return min(
        measured,
        key=lambda item: (
            0 if item["fit"]["within_range"] else 1,
            item["fit"]["distance"],
            item["fit"]["absolute_error_to_target"],
            item["round_index"],
        ),
    )


def revise_until_fit(
    job: Any,
    settings: FitSettings,
    *,
    plan: Callable[..., dict[str, Any]] = plan_duration,
    progress: Callable[[str], None] = print,
    on_fit: Callable[[dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    """After draft(): revise for length until in range or max_retries, then accept best."""
    settings.validate()
    if job.initial is None:
        raise WritingError("Call draft() successfully before revise_until_fit()")

    candidates: list[dict[str, Any]] = []
    fit_cache: dict[str, dict[str, Any]] = {}

    def consider(result: dict[str, Any], *, round_index: int, stage: str) -> dict[str, Any]:
        key = result["text"]
        fit = fit_cache.get(key)
        if fit is None:
            fit = measure_fit(key, job.request, settings, plan=plan)
            fit_cache[key] = fit
        entry = {
            "round_index": round_index,
            "stage": stage,
            "text": result["text"],
            "result": result,
            "fit": fit,
        }
        candidates.append(entry)
        distance_label = f"{fit['distance']:.4g}" if fit["distance"] is not None else "unmeasured"
        progress(
            "Fit check "
            f"(round {round_index}, {fit['mode']}): within={fit['within_range']} "
            f"distance={distance_label} action={fit['automatic_action']}"
        )
        save_json(
            job.output / "fit_rounds.json",
            [
                {
                    "round_index": c["round_index"],
                    "stage": c["stage"],
                    "fit": c["fit"],
                    "word_count": count_words(c["text"]),
                }
                for c in candidates
            ],
        )
        if on_fit is not None:
            on_fit({"round_index": round_index, "stage": stage, "fit": fit})
        return fit

    fit = consider(job.initial, round_index=0, stage="draft")
    if fit["within_range"]:
        accepted = job.accept()
        return _finalize(job, accepted, candidates, settings, selected=candidates[0])

    for attempt in range(1, settings.max_retries + 1):
        action = candidates[-1]["fit"]["automatic_action"]
        if settings.estimate:
            # Word-band revise: empty feedback triggers one automatic length repair when unmet.
            revised = job.revise()
        else:
            # Duration acceptance can disagree with word estimates; force a directed repair.
            if action == "expand":
                revised = job.revise(length_direction="longer")
            elif action == "shorten":
                revised = job.revise(length_direction="shorter")
            else:
                revised = job.revise(
                    quality_feedback=(
                        "Adjust spoken length to the target duration band without changing coverage."
                    )
                )
        fit = consider(revised, round_index=attempt, stage=f"revision_{attempt}")
        if fit["within_range"]:
            accepted = job.accept()
            return _finalize(job, accepted, candidates, settings, selected=candidates[-1])

    best = select_best(candidates)
    # Install the best text as the accepted final even if it was an earlier round.
    job.final = copy.deepcopy(best["result"])
    job.final["fit_selection"] = {
        "selected_round_index": best["round_index"],
        "selected_stage": best["stage"],
        "reason": "best_of_max_retries",
        "fit": best["fit"],
    }
    job._save()
    accepted = job.accept()
    progress(
        f"Max retries ({settings.max_retries}) reached; selected round "
        f"{best['round_index']} ({best['stage']}) as closest to range"
    )
    return _finalize(job, accepted, candidates, settings, selected=best)


def _finalize(
    job: Any,
    accepted: dict[str, Any],
    candidates: list[dict[str, Any]],
    settings: FitSettings,
    *,
    selected: dict[str, Any],
) -> dict[str, Any]:
    summary = {
        "estimate": settings.estimate,
        "max_retries": settings.max_retries,
        "speech_duration_tolerance": settings.speech_duration_tolerance,
        "duration_api": asdict(settings.duration_api) if settings.duration_api else None,
        "rounds": len(candidates),
        "selected_round_index": selected["round_index"],
        "selected_stage": selected["stage"],
        "selected_fit": selected["fit"],
        "stopped_in_range": selected["fit"]["within_range"],
    }
    # Never persist API keys in job artifacts.
    if summary["duration_api"] is not None:
        summary["duration_api"]["api_key"] = bool(settings.duration_api and settings.duration_api.api_key)
    save_json(job.output / "fit_summary.json", summary)
    out = copy.deepcopy(accepted)
    out["fit"] = copy.deepcopy(selected["fit"])
    out["fit_summary"] = summary
    job.final = copy.deepcopy(out)
    job._save()
    (job.output / "final.txt").write_text(out["text"], encoding="utf-8")
    save_json(job.output / "final.json", out)
    print("Fit summary:", json.dumps(summary, ensure_ascii=False), flush=True)
    return out
