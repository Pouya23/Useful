"""Resident llama.cpp engine with the original CUDA guard and native admission."""

from __future__ import annotations
import atexit
import os
import subprocess
import sys
import uuid
from pathlib import Path
from .model import load_spec, resolve_model, MODEL
from .requests import WritingError, WritingRequest
from .runtime import GB, LlamaServer, RuntimeConfig, RuntimeFailure
from .telemetry import MeasuredBackend, NvmlRecorder, error_record, parse_gpu_offload, save_json
from .pipeline import FastWritingJob
from .display import display_pass

PROFILE = "qwen35_9b"


class FastLlamaServer(LlamaServer):
    """Same native guard and admission; allow correct engine-managed prefix reuse."""

    def post(self, path, payload):
        if path == "/v1/chat/completions":
            payload = {**payload, "cache_prompt": True}
        return super().post(path, payload)

    def _iter_sse(self, path, payload, timeout=None):
        if path == "/v1/chat/completions":
            payload = {**payload, "cache_prompt": True}
        yield from super()._iter_sse(path, payload, timeout)

    def _build_command(self, flags):
        args = super()._build_command(flags)
        if self.config.device == "cuda" and self.config.kv_cache_device == "gpu":
            if "--op-offload" not in flags or "--flash-attn" not in flags:
                raise RuntimeFailure("GPU-cache speed mode requires --op-offload and --flash-attn")
            args[args.index("--no-op-offload")] = "--op-offload"
            args += ["--flash-attn", "auto"]
        return args


class FastQwenSession:
    """Resident best-model session; any number of jobs and feedback rounds."""

    def __init__(
        self,
        *,
        server: Path | str | None = None,
        model: Path | str | None = None,
        context_tokens: int = 32768,
        gpu_index: int = 0,
        kv_cache_device: str = "cpu",
        device: str = "cuda",
        output: Path | str | None = None,
        install_dependencies: bool = False,
        model_sha256: str | None = None,
        vram_limit_gb: float = 10.5,
        headroom_gb: float = 1.5,
        render=display_pass,
        show_progress: bool = False,
    ):
        if type(context_tokens) is not int or not 512 <= context_tokens <= 262144:
            raise WritingError("context_tokens must be 512..262144")
        if device not in {"cpu", "cuda"} or kv_cache_device not in {"cpu", "gpu"}:
            raise WritingError("Invalid device or kv_cache_device")
        if device != "cuda":
            raise WritingError(
                "FastQwenSession is the measured CUDA deployment; use FastWritingJob with a CPU backend for CPU tests"
            )
        if device == "cpu" and kv_cache_device != "cpu":
            raise WritingError("CPU inference requires the CPU KV cache")
        if type(show_progress) is not bool:
            raise WritingError("show_progress must be a boolean")
        self.server_path = Path(server) if server else None
        self.model_path = Path(model) if model else None
        self.context_tokens, self.gpu_index = context_tokens, gpu_index
        self.kv_cache_device, self.device = kv_cache_device, device
        if install_dependencies:
            raise WritingError("Run install_ubuntu.sh before generation; runtime installation is disabled")
        self.render = render
        self.model_sha256 = model_sha256
        self.vram_limit_gb, self.headroom_gb = vram_limit_gb, headroom_gb
        self.show_progress = show_progress
        self.output = Path(output) if output else Path("llm_results") / uuid.uuid4().hex[:12]
        self.native = self.recorder = self.backend = None
        self.closed = False
        self._entered = False

    def __enter__(self):
        if self.closed or self._entered:
            raise WritingError("A session cannot be re-entered")
        self._entered = True
        self.output.mkdir(parents=True, exist_ok=False)
        atexit.register(self.close)
        try:
            return self._start_session()
        except BaseException as exc:
            save_json(self.output / "startup_error.json", error_record(exc))
            self.close()
            raise

    def _start_session(self):
        if self.server_path is None:
            executable = os.environ.get("LLAMA_SERVER")
            if not executable:
                raise RuntimeFailure("Supply --server or set LLAMA_SERVER to your local llama-server")
            self.server_path = Path(executable)
        if self.model_path is None:
            raise RuntimeFailure("Supply --gguf-model; download models explicitly with download_model.py")
        model, provenance = resolve_model(
            load_spec(PROFILE), self.model_path, download=False,
            allow_custom=self.model_path.name != MODEL["filename"] or self.model_sha256 is not None,
            expected_sha256=self.model_sha256,
        )
        save_json(self.output / "model_provenance.json", provenance)
        threads = (
            min(4, len(os.sched_getaffinity(0)))
            if hasattr(os, "sched_getaffinity")
            else min(4, os.cpu_count() or 1)
        )
        config = RuntimeConfig(
            server=self.server_path,
            model=model,
            context_size=self.context_tokens,
            device=self.device,
            gpu_index=self.gpu_index,
            kv_cache_device=self.kv_cache_device,
            vram_limit_gb=self.vram_limit_gb,
            headroom_gb=self.headroom_gb,
            threads=threads,
            startup_timeout=900,
            request_timeout=1800,
            expected_architecture="qwen35" if provenance["matches_pinned_profile"] else None,
            log_path=self.output / "llama-server.log",
            unix_socket=self.output / "llama-server.sock",
        )
        self.native = FastLlamaServer(config)
        import pynvml

        pynvml.nvmlInit()
        try:
            handle = pynvml.nvmlDeviceGetHandleByIndex(self.gpu_index)
            raw_uuid = pynvml.nvmlDeviceGetUUID(handle)
            gpu_uuid = raw_uuid.decode("ascii") if isinstance(raw_uuid, bytes) else raw_uuid
            threshold = min(int(self.vram_limit_gb * GB), pynvml.nvmlDeviceGetMemoryInfo(handle).total) - int(self.headroom_gb * GB)
        finally:
            pynvml.nvmlShutdown()
        try:
            self.recorder = NvmlRecorder(
                self.output / "nvml_samples.csv",
                self.gpu_index,
                gpu_uuid,
                lambda: self.native._process.pid if self.native._process is not None else None,
                failure_callback=self.native._kill_process,
                abort_threshold_bytes=threshold,
            )
            print(
                f"Loading {model.name}; {self.context_tokens} context; KV={self.kv_cache_device}; "
                f"sampled guard={threshold / GB:.2f} GB",
                flush=True,
            )
            self.native.__enter__()
            if self.native.effective_context_size != self.context_tokens:
                raise RuntimeFailure(
                    "Native fitting changed the requested context; select CPU KV or set a smaller context explicitly"
                )
            self.backend = MeasuredBackend(self.native, self.recorder, self.output, model.name)
            self._ready()
            return self
        except BaseException as exc:
            save_json(self.output / "startup_error.json", error_record(exc))
            self.close()
            raise

    def _ready(self):
        if self.closed or self.backend is None:
            raise WritingError("Use the session inside its with block")
        self.recorder.check()
        self.native._check_failure()
        if self.backend.counter:
            evidence = parse_gpu_offload(
                self.native.config.log_path.read_text(encoding="utf-8", errors="replace")
            )
            if not evidence["valid_counts"] or not (evidence["offloaded_layers"] or 0) > 0:
                raise RuntimeFailure("Native log did not prove actual GPU tensor-layer offload")

    def new_job(self, request: WritingRequest, *, max_output_tokens=None, seed=42) -> FastWritingJob:
        self._ready()
        job = FastWritingJob(
            self.backend,
            request,
            self.output / "jobs" / uuid.uuid4().hex[:12],
            render=self.render,
            max_output_tokens=max_output_tokens,
            seed=seed,
            ready=self._ready,
            show_progress=self.show_progress,
        )
        return job

    def close(self):
        if self.closed:
            return
        if self.native is not None:
            self.native.close()  # Do not release the monitor before confirmed process termination.
        if self.backend is not None:
            self.backend.close()
        if self.recorder is not None:
            self.recorder.close()
        self.closed = True
        atexit.unregister(self.close)
        if self.output.is_dir():
            save_json(
                self.output / "lifecycle.json",
                {
                    "runtime": self.native.report() if self.native else None,
                    "memory": self.recorder.report() if self.recorder else None,
                    "server_terminated": self.native is None
                    or self.native._process is None
                    or self.native._process.poll() is not None,
                },
            )

    def __exit__(self, exc_type, exc, traceback):
        self.close()
