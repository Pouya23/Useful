"""Pinned model provenance, resumable download and checksum validation."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Callable

ROOT = Path(__file__).resolve().parent


MODEL = {
    "id": "qwen35_9b",
    "title": "Qwen3.5 9B (Q5_K_M)",
    "repository": "unsloth/Qwen3.5-9B-GGUF",
    "revision": "3885219b6810b007914f3a7950a8d1b469d598a5",
    "filename": "Qwen3.5-9B-Q5_K_M.gguf",
    "sha256": "dc2a39aef291f91a9116ad214058da0d86eb648743a124bd8c333787c4b9c91c",
    "bytes": 6577841376,
    "upstream": "Qwen/Qwen3.5-9B",
    "architecture": "qwen35",
}


def load_spec(model_id: str) -> dict:
    if model_id != MODEL["id"]:
        raise ValueError("This package supports only Qwen3.5 9B Q5_K_M")
    return MODEL.copy()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def resolve_model(
    spec: dict,
    path: Path | None = None,
    *,
    download: bool = False,
    allow_custom: bool = False,
    progress: Callable[[str], None] = print,
    expected_sha256: str | None = None,
) -> tuple[Path, dict]:
    path = (path or ROOT / "models" / spec["filename"]).resolve()
    if not path.exists():
        if not download:
            raise RuntimeError(
                f"Model file missing: {path}. Supply a valid model path; download explicitly with download_model.py."
            )
        raise RuntimeError("Download models explicitly with download_model.py")
    if not path.is_file():
        raise RuntimeError(f"Expected a GGUF file: {path}")
    progress(f"Verifying SHA256 of {path.name}")
    checksum = sha256_file(path)
    if expected_sha256 and checksum.lower() != expected_sha256.lower():
        raise RuntimeError("Custom GGUF SHA256 does not match --model-sha256")
    verified = checksum == spec["sha256"] and path.stat().st_size == spec["bytes"]
    if not verified and not allow_custom:
        raise RuntimeError(
            "Model size/checksum differs from the pinned profile. Use the documented Qwen3.5 9B Q5_K_M GGUF."
        )
    return path, {
        "profile": spec["id"],
        "path": str(path),
        "bytes": path.stat().st_size,
        "sha256": checksum,
        "matches_pinned_profile": verified,
        "repository": spec["repository"] if verified else None,
        "revision": spec["revision"] if verified else None,
        "upstream": spec["upstream"] if verified else None,
        "quant_filename": spec["filename"] if verified else path.name,
    }
