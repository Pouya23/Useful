"""One draft, then one completion per requested revision, indefinitely."""

from __future__ import annotations
import copy
import json
import re
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any, Callable
from .requests import (
    WritingError,
    WritingRequest,
    count_words,
    normalize_direction,
    sample_overlap,
)
from .telemetry import error_record, save_json
from .length import automatic_length_feedback
from .display import display_pass
from .prompts import build_messages, output_budget, original_context_prefix
from .progress import progress_word_limit

PROFILE = "qwen35_9b"
_UNSET = object()


class FastWritingJob:
    """One completion per feedback round, with no artificial revision limit.

    Every round sends the original context, latest accepted draft and latest
    feedback only. Earlier generation history is logged, not added to the prompt.
    """

    def __init__(
        self,
        backend: Any,
        request: WritingRequest,
        output: Path,
        *,
        render: Callable[[dict], None] = display_pass,
        max_output_tokens: int | None = None,
        seed: int = 42,
        ready: Callable[[], None] = lambda: None,
        show_progress: bool = False,
    ):
        request.validate()
        if max_output_tokens is not None and (type(max_output_tokens) is not int or max_output_tokens <= 0):
            raise WritingError("max_output_tokens must be a positive integer or None")
        if type(seed) is not int or seed < 0:
            raise WritingError("seed must be a nonnegative integer")
        if type(show_progress) is not bool:
            raise WritingError("show_progress must be a boolean")
        self.backend, self.request = backend, copy.deepcopy(request)
        self.output = Path(output)
        self.output.mkdir(parents=True, exist_ok=True)
        self.render, self.max_output_tokens, self.seed, self.ready = render, max_output_tokens, seed, ready
        self.show_progress = show_progress
        self.initial = None
        self.final = None
        self.calls: list[dict] = []
        self._context_prefix = original_context_prefix(self.request)
        self._sample_tokens = tuple(tuple(re.findall(r"\w+", s.casefold())) for s in self.request.samples)
        self._draft_attempted = False
        self._revision_attempts = 0
        self._accepted_revisions = 0
        self._direction_baseline_text = self.request.draft

    def _messages(self, request, **current_pass):
        return build_messages(self.request, request, context_prefix=self._context_prefix, **current_pass)

    def _budget(self, feedback, request, draft):
        return output_budget(feedback, request, draft, self.max_output_tokens)

    def _generate(self, stage, request, *, draft="", quality_feedback="", length_feedback):
        self.ready()
        messages = self._messages(
            request, draft=draft, quality_feedback=quality_feedback, length_feedback=length_feedback
        )
        tokens = self._budget(length_feedback, request, draft)
        if tokens + 16 >= self.backend.effective_context_size:
            raise WritingError(
                "Output budget leaves no usable prompt context; reduce max_output_tokens or increase context"
            )
        before = self.backend.counter
        response, failure = None, None
        event = None
        with self.backend.labelled(self.output.name, stage):
            try:
                # Native complete() performs exact token admission once. No duplicate tokenizer call here.
                response = self.backend.complete(
                    messages,
                    max_tokens=tokens,
                    temperature=0.7,
                    top_p=0.8,
                    top_k=20,
                    seed=self.seed + len(self.calls),
                    json_schema=None,
                    show_progress=self.show_progress,
                    progress_word_limit=progress_word_limit(length_feedback, draft),
                )
                self.ready()  # Reject a late guard/telemetry failure before accepting text.
                if response.get("finish_reason") != "stop":
                    raise WritingError(
                        "Generation was truncated or failed; partial text was saved, not accepted. "
                        "Increase max_output_tokens before another revision round. "
                        "An initial-draft failure requires a fresh job."
                    )
                script = response.get("text")
                if not isinstance(script, str) or not script.strip():
                    raise WritingError("The model returned no usable text")
                if re.search(r"</?think\b|<\|(?:channel|im_start|im_end|endoftext)[^>]*\|>", script, re.I):
                    raise WritingError("Model control/reasoning tokens are not accepted")
                self.backend.validation(self.backend.counter, "ok")
                return script.strip()
            except BaseException as exc:
                failure = error_record(exc)
                if self.backend.counter > before:
                    self.backend.validation(self.backend.counter, "failed", exc)
                raise
            finally:
                if self.backend.counter > before:
                    raw_path = self.backend.output / "round_outputs" / f"{self.backend.counter:04d}.json"
                    raw = response or (
                        json.loads(raw_path.read_text(encoding="utf-8")) if raw_path.is_file() else {}
                    )
                    raw_text = raw.get("text", "")
                    event = {
                        **self.backend.rounds[-1],
                        "stage": stage,
                        "text": raw_text if isinstance(raw_text, str) else "",
                        "status": "failed" if failure else "ok",
                        "error": failure,
                        "quality_feedback": quality_feedback,
                        "length_feedback": length_feedback,
                    }
                    self.calls.append(event)
                    save_json(self.output / "passes.json", self.calls)
                    (self.output / f"{len(self.calls):02d}_{stage}.txt").write_text(
                        event["text"], encoding="utf-8"
                    )
                    self._save()
                    self.render(event)

    def _result(self, text, request, *, direction=None, baseline=None, revised=False, quality_feedback=""):
        length = automatic_length_feedback(
            text, word_range=request.word_range(), direction=direction, baseline=baseline
        )
        warnings = []
        if length["needs_length_revision"]:
            warnings.append("Measured length request remains unmet; you can request another feedback round.")
        overlaps = sample_overlap(text, request.samples, sample_tokens=self._sample_tokens)
        if overlaps:
            warnings.append("Exact sample wording overlaps remain; inspect sample_overlap_flags.")
        if not request.sources:
            warnings.append("No reference sources supplied; technical claims have not been verified.")
        return {
            "text": text,
            "word_count": length["measured_words"],
            "length_feedback": length,
            "estimated_duration_seconds": length["measured_words"] * 60 / self.request.speaking_rate_wpm,
            "speaking_rate_wpm": self.request.speaking_rate_wpm,
            "revised": revised,
            "user_quality_feedback": quality_feedback,
            "sample_overlap_flags": overlaps,
            "warnings": warnings,
            "quality_assessment": "user_review_required; no model self-score",
            "word_count_policy": "whitespace tokens containing letters/numbers; hyphens count as one",
        }

    def _save(self):
        save_json(
            self.output / "job.json",
            {
                "model": getattr(self.backend, "profile", PROFILE),
                "request": asdict(self.request),
                "initial": self.initial,
                "final": self.final,
                "attempted_completions": len(self.calls),
                "revision_limit": None,
                "accepted_revisions": self._accepted_revisions,
                "one_completion_per_feedback_round": True,
            },
        )

    def draft(self) -> dict:
        if self._draft_attempted:
            raise WritingError(
                "This job already attempted its draft. Create a fresh job for a new brief or retry."
            )
        self._draft_attempted = True
        baseline = count_words(self.request.draft) if self.request.draft else None
        direction = normalize_direction(self.request.length_direction)
        feedback = automatic_length_feedback(
            self.request.draft, word_range=self.request.word_range(), direction=direction, baseline=baseline
        )
        text = self._generate("draft", self.request, draft=self.request.draft, length_feedback=feedback)
        self.initial = self._result(text, self.request, direction=direction, baseline=baseline)
        self._save()
        print(
            "Automatic length feedback:",
            json.dumps(self.initial["length_feedback"], ensure_ascii=False),
            flush=True,
        )
        return copy.deepcopy(self.initial)

    def revise(
        self,
        *,
        quality_feedback: str = "",
        length_direction=_UNSET,
        duration_seconds=_UNSET,
        word_range=_UNSET,
    ) -> dict:
        """Generate at most one revision this round; call again for unlimited rounds.

        No feedback and a satisfactory length accept the draft without another call.
        Direction-only feedback clears the old range; explicitly supplied bounds apply.
        Later rounds use the LATEST text and retain the latest length policy.
        An explicit new direction is measured against the immediately previous text.
        Omit direction to retain its existing baseline; None explicitly clears it.
        """
        if self.initial is None:
            raise WritingError("Call draft() successfully before revise()")
        if not isinstance(quality_feedback, str):
            raise WritingError("quality_feedback must be a string")
        latest = self.final or self.initial
        prior_policy = latest["length_feedback"]
        if duration_seconds is not _UNSET:
            if word_range is not _UNSET:
                raise WritingError("Use duration_seconds instead of word_range")
            if duration_seconds is None:
                word_range = None
            else:
                from .duration import DurationPolicy

                try:
                    word_range = DurationPolicy(
                        duration_seconds, self.request.speaking_rate_wpm, self.request.duration_tolerance
                    ).word_range()
                except ValueError as exc:
                    raise WritingError(str(exc)) from exc
            # A new duration replaces the prior relative policy unless the user
            # explicitly requests both and they are mutually compatible.
            if length_direction is _UNSET:
                length_direction = None
        explicit_direction = length_direction is not _UNSET
        direction = normalize_direction(
            length_direction if explicit_direction else prior_policy["length_direction"]
        )
        if word_range is _UNSET:
            band = None if explicit_direction and direction is not None else prior_policy["word_range"]
        else:
            band = word_range
        if band is not None and (not isinstance(band, (tuple, list)) or len(band) != 2):
            raise WritingError("word_range must be (minimum, maximum), None, or omitted")
        text = latest["text"]
        baseline = (
            count_words(text)
            if explicit_direction and direction
            else (prior_policy["baseline_words"] if direction else None)
        )
        validation_draft = self._direction_baseline_text if direction and not explicit_direction else text
        current = replace(
            self.request,
            draft=validation_draft,
            length_direction=direction,
            duration_seconds=None,
            min_words=band[0] if band is not None else None,
            max_words=band[1] if band is not None else None,
        )
        current.validate()
        feedback = automatic_length_feedback(
            text,
            word_range=current.word_range(),
            direction=direction,
            baseline=baseline if direction else None,
        )
        needs_revision = feedback["needs_length_revision"] or bool(quality_feedback.strip())
        if not needs_revision:
            self.final = self._result(
                text,
                current,
                direction=direction,
                baseline=baseline,
                quality_feedback=quality_feedback,
                revised=self._accepted_revisions > 0,
            )
            if direction and explicit_direction:
                self._direction_baseline_text = text
            self._save()
            return copy.deepcopy(self.final)
        self._revision_attempts += 1
        revised = self._generate(
            f"revision_{self._revision_attempts}",
            current,
            draft=text,
            quality_feedback=quality_feedback,
            length_feedback=feedback,
        )
        self._accepted_revisions += 1
        if direction and explicit_direction:
            self._direction_baseline_text = text
        self.final = self._result(
            revised,
            current,
            direction=direction,
            baseline=baseline if direction else None,
            revised=True,
            quality_feedback=quality_feedback,
        )
        self._save()
        print(
            "Final measured length:",
            json.dumps(self.final["length_feedback"], ensure_ascii=False),
            flush=True,
        )
        return copy.deepcopy(self.final)

    def finalize(self, **feedback) -> dict:
        """Backward-compatible alias; it does not close the job or limit later revisions."""
        return self.revise(**feedback)

    def accept(self) -> dict:
        """Accept the latest text without another generation, retaining honest length results."""
        if self.initial is None:
            raise WritingError("Call draft() successfully before accepting text")
        if self.final is None:
            self.final = copy.deepcopy(self.initial)
        self._save()
        return copy.deepcopy(self.final)


def review_interactively(job: FastWritingJob, *, initial_length_direction=None) -> dict:
    """Human loop: display one generation, collect feedback, repeat until accepted.

    Enter accepts if length is met; otherwise it requests ONE automatic length
    repair and asks again. /done accepts even when length is unmet. Other commands
    are /shorter, /longer and /keep. Programmatic callers can call job.revise().
    """
    first_round = True
    while True:
        quality = input(
            "\nFeedback (Enter: accept/repair length; /shorter, /longer, /keep, /duration SECONDS, /done): "
        ).strip()
        if quality.lower() == "/done":
            return job.accept()
        options = {"quality_feedback": quality}
        if first_round and initial_length_direction is not None:
            options["length_direction"] = initial_length_direction
        if quality.lower() in {"/shorter", "/longer", "/keep"}:
            options.update(quality_feedback="", length_direction=quality[1:].lower())
        if quality.lower().startswith("/duration"):
            try:
                command, seconds = quality.split()
                if command.lower() != "/duration":
                    raise ValueError()
                options.update(quality_feedback="", duration_seconds=float(seconds))
            except ValueError:
                print("Use /duration followed by positive seconds, for example /duration 150")
                continue
        before = len(job.calls)
        try:
            result = job.revise(**options)
        except WritingError as exc:
            print("Last accepted draft retained:", exc, flush=True)
            continue  # Retry requires another HUMAN feedback submission.
        first_round = False
        if not quality and len(job.calls) == before:
            return result
