"""A single owned engine worker, with bounded RPC and process-tree cleanup."""

import json
import os
import queue
import re
import signal
import subprocess
import sys
import threading
from dataclasses import asdict
from pathlib import Path
from .progress import PROGRESS_PREFIX, display_ipc_progress, finish_ipc_progress
from .runtime import RuntimeFailure


class WorkerClient:
    def __init__(self, settings, output, gpu_uuid):
        self.settings = settings
        self.output = Path(output)
        self.gpu_uuid = gpu_uuid
        self.effective_context_size = settings.context_tokens
        self.process = None
        self.replies = queue.Queue()
        self.failure = None
        self.log = None
        self.metadata = None
        self._shutdown_lock = threading.Lock()
        self._progress_active = False
        self.token_callback = None

    def start(self, memory_fraction):
        environment = os.environ.copy()
        environment["CUDA_VISIBLE_DEVICES"] = self.gpu_uuid
        environment["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
        # Isolate the worker from parent sitecustomize modules.
        environment.pop("PYTHONPATH", None)
        environment.pop("PYTHONHOME", None)
        environment["PYTHONUNBUFFERED"] = "1"
        if self.settings.local_files_only:
            environment["HF_HUB_OFFLINE"] = "1"
            environment["TRANSFORMERS_OFFLINE"] = "1"
        worker_python = self.settings.worker_python or sys.executable
        # Prefer the worker env's libstdc++ (conda) over the older system one so
        # packages like scipy/highspy find CXXABI symbols they were built against.
        # Drop other envs' site-packages lib dirs from LD_LIBRARY_PATH; they can
        # shadow Torch/audio extensions (e.g. another env's torchaudio).
        worker_root = Path(worker_python).resolve().parent.parent
        lib_dirs = []
        for prefix in (worker_root / "lib", Path(sys.prefix) / "lib"):
            if prefix.is_dir() and str(prefix) not in lib_dirs:
                lib_dirs.append(str(prefix))
        kept = []
        for part in environment.get("LD_LIBRARY_PATH", "").split(":"):
            if not part or part in lib_dirs or part in kept:
                continue
            # Other envs' packaged .so trees poison dlopen; CUDA/system libs stay.
            normalized = part.replace("\\", "/").lower()
            if "/site-packages/" in normalized or re.search(r"/cuda(?:-[\d.]+)?/(?:lib|lib64|targets)(?:/|$)", normalized):
                continue
            kept.append(part)
        environment["LD_LIBRARY_PATH"] = ":".join(lib_dirs + kept)
        package_root = Path(__file__).resolve().parent.parent
        self.log = (self.output / "engine.log").open("w", encoding="utf-8")
        options = (
            {"start_new_session": True} if os.name != "nt" else {"creationflags": subprocess.CREATE_NO_WINDOW}
        )
        self.process = subprocess.Popen(
            [worker_python, "-m", "pipeline_core.worker"],
            cwd=package_root,
            env=environment,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=self.log,
            text=True,
            encoding="utf-8",
            bufsize=1,
            **options,
        )
        threading.Thread(target=self._read_replies, daemon=True).start()
        self.metadata = self.rpc("load", settings=asdict(self.settings), memory_fraction=memory_fraction)
        if self.metadata["context_tokens"] != self.effective_context_size:
            raise RuntimeFailure("Engine changed the requested context")

    def _read_replies(self):
        try:
            for line in self.process.stdout:
                if line.startswith("LLM_TOKEN "):
                    if self.token_callback:
                        self.token_callback(json.loads(line[len("LLM_TOKEN "):]))
                    continue
                if line.startswith(PROGRESS_PREFIX):
                    try:
                        percent = int(line[len(PROGRESS_PREFIX) :].strip())
                    except ValueError:
                        continue
                    display_ipc_progress(percent)
                    self._progress_active = percent < 100
                    continue
                if line.startswith("QWEN_REPLY "):
                    if self._progress_active:
                        finish_ipc_progress()
                        self._progress_active = False
                    self.replies.put(json.loads(line[len("QWEN_REPLY ") :]))
                elif self.log and not self.log.closed:
                    self.log.write(line)
        except Exception as exc:
            self.replies.put({"ok": False, "error": str(exc)})
        finally:
            self.replies.put({"ok": False, "error": "Worker exited; inspect engine.log"})

    def rpc(self, operation, **payload):
        self.check()
        try:
            self.process.stdin.write(
                json.dumps({"operation": operation, **payload}, ensure_ascii=False) + "\n"
            )
            self.process.stdin.flush()
            response = self.replies.get(timeout=1800)
        except (OSError, queue.Empty) as exc:
            self.failure = RuntimeFailure(f"Worker communication failed: {exc}")
            self.kill()
            raise self.failure from exc
        if self._progress_active:
            finish_ipc_progress()
            self._progress_active = False
        if not response.get("ok"):
            raise RuntimeFailure(
                response.get("error", "Worker failure") + "\n" + response.get("traceback", "")
            )
        return response["result"]

    def check(self):
        if self.failure:
            raise self.failure
        if self.process is None or self.process.poll() is not None:
            raise RuntimeFailure("Engine worker is not running")

    def complete(self, messages, **sampling):
        return self.rpc("generate", messages=messages, sampling=sampling,
                        stream_tokens=self.token_callback is not None)

    def kill(self):
        """Kill only this worker and descendants; verify termination before reuse."""
        import psutil

        with self._shutdown_lock:
            if self.process is None:
                return
            try:
                parent = psutil.Process(self.process.pid)
                owned = parent.children(recursive=True) + [parent]
            except psutil.NoSuchProcess:
                owned = []
            if os.name != "nt":
                try:
                    os.killpg(self.process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            for child in reversed(owned):
                try:
                    child.kill()
                except psutil.NoSuchProcess:
                    pass
            _, alive = psutil.wait_procs(owned, timeout=15)
            alive = [
                child for child in alive if child.is_running() and child.status() != psutil.STATUS_ZOMBIE
            ]
            self.process.wait(timeout=15)
            if alive:
                raise RuntimeFailure("Engine descendants remain alive; do not start another engine")

    def close(self):
        self.kill()
        if self.process:
            for stream in (self.process.stdin, self.process.stdout):
                if stream:
                    stream.close()
        if self.log:
            self.log.close()
