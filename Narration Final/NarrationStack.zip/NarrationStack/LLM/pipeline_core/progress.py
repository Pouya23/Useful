"""Generation progress as a percentage of the requested word-range maximum."""

from __future__ import annotations

import sys

from .requests import count_words

PROGRESS_PREFIX = "QWEN_PROGRESS "


def progress_word_limit(length_feedback: dict, draft: str = "") -> int:
    """Upper end of the current word range, or a conservative fallback."""
    band = length_feedback.get("word_range") if isinstance(length_feedback, dict) else None
    if isinstance(band, (list, tuple)) and len(band) == 2 and type(band[1]) is int and band[1] > 0:
        return band[1]
    target = length_feedback.get("target_words") if isinstance(length_feedback, dict) else None
    if type(target) is int and target > 0:
        return target
    draft_words = count_words(draft) if draft else 0
    return max(draft_words, 650)


def percent_for_words(word_count: int, word_limit: int) -> int:
    if type(word_limit) is not int or word_limit <= 0:
        return 0
    if type(word_count) is not int or word_count <= 0:
        return 0
    return min(99, int(100 * word_count / word_limit))


class ProgressReporter:
    """Print `Progress: N%` from partial text using words / max_range."""

    def __init__(self, word_limit: int, *, ipc: bool = False, stream=None):
        if type(word_limit) is not int or word_limit <= 0:
            raise ValueError("progress word_limit must be a positive integer")
        self.word_limit = word_limit
        self.ipc = ipc
        self.stream = stream or sys.stderr
        self._last = -1
        self._text = ""
        self._words = 0
        self._token_has_word = False

    def update_text(self, text: str) -> None:
        if not isinstance(text, str):
            return
        self._words = count_words(text)
        tail = text.rsplit(None, 1)[-1] if text and not text[-1].isspace() else ""
        self._token_has_word = any(c.isalnum() for c in tail)
        self._emit(percent_for_words(self._words, self.word_limit))

    def append_text(self, piece: str) -> None:
        if not isinstance(piece, str) or not piece:
            return
        # Match count_words exactly without retaining/recounting the growing output.
        for char in piece:
            if char.isspace():
                self._token_has_word = False
            elif char.isalnum() and not self._token_has_word:
                self._words += 1
                self._token_has_word = True
        self._emit(percent_for_words(self._words, self.word_limit))

    def finish(self) -> None:
        self._emit(100, final=True)

    def _emit(self, percent: int, *, final: bool = False) -> None:
        percent = max(0, min(100, int(percent)))
        if percent == self._last and not final:
            return
        self._last = percent
        if self.ipc:
            # Prefer the process's real stdout: worker.complete() redirects sys.stdout to stderr.
            stream = sys.__stdout__ if sys.__stdout__ is not None else sys.stdout
            stream.write(PROGRESS_PREFIX + str(percent) + "\n")
            stream.flush()
            return
        end = "\n" if final else ""
        self.stream.write(f"\rProgress: {percent}%{end}")
        self.stream.flush()


def make_reporter(show_progress: bool, word_limit: int | None, *, ipc: bool = False) -> ProgressReporter | None:
    if not show_progress:
        return None
    if type(word_limit) is not int or word_limit <= 0:
        word_limit = 650
    return ProgressReporter(word_limit, ipc=ipc)


def display_ipc_progress(percent: int, stream=None) -> None:
    stream = stream or sys.stderr
    stream.write(f"\rProgress: {max(0, min(100, int(percent)))}%")
    stream.flush()


def finish_ipc_progress(stream=None) -> None:
    stream = stream or sys.stderr
    stream.write("\rProgress: 100%\n")
    stream.flush()
