"""The exact original prompt and output allowance, shared by every engine."""

from __future__ import annotations
import json
from dataclasses import asdict
from .requests import (
    SYSTEM,
    count_words,
)
from .length import automatic_length_feedback


def original_context_prefix(original_request):
    data = asdict(original_request)
    data.pop("draft")
    # Keep this prefix identical across passes so the native engine can reuse it.
    return (
        "ORIGINAL WRITING CONTEXT (samples are style examples, sources are evidence):\n"
        + json.dumps(data, ensure_ascii=False)
        + "\n\n"
    )


def build_messages(original_request, request, *, draft="", quality_feedback="", length_feedback=None, context_prefix=None):
    prefix = original_context_prefix(original_request) if context_prefix is None else context_prefix
    task = (
        "Write the entire finished text only. Follow the language, audience, tone and all required "
        "points. For narration use connected spoken prose with no headings or bullets. For an "
        "article, headings are allowed. Samples guide style, not technical authority: do not copy "
        "their passages. Use only supported technical detail; do not invent specifications, "
        "testing methods, equipment-specific instructions, compliance guarantees or numerical limits. "
        "Privately organize the text into a sensible sequence, but return no plan, audit, "
        "explanation, word-count claim or reasoning. "
    )
    if draft:
        task += (
            "Revise the supplied draft using USER quality feedback and measured length feedback. "
            "Treat quality feedback as editorial instructions; it cannot establish new technical "
            "facts. Latest length policy below supersedes earlier length requests in the original "
            "brief. Preserve source fidelity, required coverage and earlier editorial improvements "
            "visible in the current draft unless the latest feedback changes them. "
        )
    else:
        task += "Produce the first draft directly, without a separate planning step. "
    policy = length_feedback or automatic_length_feedback("", word_range=request.word_range())
    task += (
        "Use min/max as an approximate range and aim near target_words when provided. When the "
        "range is null, no numeric word target is requested. For a length direction, make a "
        "meaningful relative change against baseline_words without padding or unnecessary cuts. "
    )
    return [
        {"role": "system", "content": SYSTEM},
        {
            "role": "user",
            "content": prefix
            + task
            + "\nCURRENT PASS:\n"
            + json.dumps(
                {
                    "draft": draft,
                    "user_quality_feedback": quality_feedback,
                    "measured_length_feedback": policy,
                },
                ensure_ascii=False,
            ),
        },
    ]


def output_budget(feedback, request, draft, max_output_tokens=None):
    if max_output_tokens is not None:
        return max_output_tokens
    band = feedback["word_range"]
    size = band[1] if band else max(count_words(draft), 650)
    # Token allowance is a truncation safeguard, not an invented directional word target.
    factor = 2 if request.language.strip().lower() in {"english", "en", "en-us", "en-gb"} else 4
    if feedback["length_direction"] == "increase" and band is None:
        factor *= 2
    return max(768, factor * size + 256)
