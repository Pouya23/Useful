"""Continuous VRAM measurement and per-generation logs."""

from __future__ import annotations

import csv
import json
import re
import threading
import time
import traceback
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .runtime import GB, RuntimeFailure


def save_json(path: Path, value: Any) -> None:
    """Atomic replacement makes partial summaries detectable after interruption."""
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def error_record(exc: BaseException) -> dict:
    return {
        "type": type(exc).__name__,
        "message": str(exc),
        "traceback": "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
    }


def parse_gpu_offload(log: str) -> dict:
    """Read actual tensor-layer offload evidence from the pinned llama.cpp log."""
    matches = re.findall(r"offloaded\s+(\d+)\s*/\s*(\d+)\s+layers to GPU", log)
    if not matches:
        return {
            "offloaded_layers": None,
            "total_layers": None,
            "valid_counts": False,
            "evidence": "No offloaded N/M layers to GPU message found in the native server load log",
        }
    offloaded, total = map(int, matches[-1])
    return {
        "offloaded_layers": offloaded,
        "total_layers": total,
        "valid_counts": total > 0 and 0 <= offloaded <= total,
        "evidence": "Pinned llama.cpp native model-load log: offloaded N/M layers to GPU",
    }


class TelemetryFailure(RuntimeFailure):
    """A total-device VRAM measurement cannot be trusted; stop the worker."""


class NvmlRecorder:
    """Continuous device/process trace with round windows and fail-closed sampling.

    Process usage can be unavailable on a driver. That is recorded as null with
    an explicit reason. Total-device sampling is mandatory and any failure is
    fatal. A single lock orders boundary samples and periodic samples.
    """

    fields = (
        "utc",
        "monotonic_seconds",
        "gpu_index",
        "gpu_uuid",
        "case",
        "stage",
        "round_id",
        "pid",
        "total_used_bytes",
        "device_capacity_bytes",
        "process_used_bytes",
        "process_metric_status",
    )

    def __init__(
        self,
        output: Path,
        gpu_index: int,
        expected_uuid: str,
        pid_provider: Callable[[], int | None],
        *,
        interval: float = 0.01,
        nvml: Any = None,
        clock: Callable[[], float] = time.monotonic,
        failure_callback: Callable[[], None] | None = None,
        abort_threshold_bytes: int | None = None,
    ) -> None:
        if not 0.001 <= interval <= 0.1:
            raise ValueError("NVML interval must be between 1 and 100 milliseconds")
        if nvml is None:
            import pynvml as nvml
        self.nvml, self.clock, self.interval = nvml, clock, interval
        self.gpu_index, self.expected_uuid = gpu_index, expected_uuid
        self.pid_provider = pid_provider
        self.failure_callback = failure_callback
        if abort_threshold_bytes is not None and (
            type(abort_threshold_bytes) is not int or abort_threshold_bytes <= 0
        ):
            raise ValueError("abort_threshold_bytes must be a positive integer")
        self.abort_threshold_bytes = abort_threshold_bytes
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.thread: threading.Thread | None = None
        self.failure: TelemetryFailure | None = None
        self.case, self.stage, self.round_id = "lifecycle", "before_startup", None
        self.active_round: dict | None = None
        self.sample_count, self.peak_total, self.peak_process = 0, 0, None
        self.process_unavailable_reasons: set[str] = set()
        self.closed = False
        self.initialized = False
        self.stream = output.open("x", newline="", encoding="utf-8")
        self.writer = csv.DictWriter(self.stream, fieldnames=self.fields)
        self.writer.writeheader()
        try:
            nvml.nvmlInit()
            self.initialized = True
            self.handle = nvml.nvmlDeviceGetHandleByIndex(gpu_index)
            raw_uuid = nvml.nvmlDeviceGetUUID(self.handle)
            self.uuid = raw_uuid.decode("ascii") if isinstance(raw_uuid, bytes) else raw_uuid
            if not isinstance(self.uuid, str) or self.uuid != expected_uuid:
                raise TelemetryFailure(f"GPU identity mismatch: requested {expected_uuid}, found {self.uuid}")
            memory = nvml.nvmlDeviceGetMemoryInfo(self.handle)
            self.capacity = memory.total
            if type(self.capacity) is not int or self.capacity <= 0:
                raise TelemetryFailure("NVML returned invalid device capacity")
            self.sample()
            self.thread = threading.Thread(target=self._watch, daemon=True, name="llm-nvml-recorder")
            self.thread.start()
        except BaseException:
            self.close(sample_final=False)
            raise

    def _process_usage(self, pid: int | None) -> tuple[int | None, str]:
        if pid is None:
            return None, "server_pid_not_available"
        api = getattr(self.nvml, "nvmlDeviceGetComputeRunningProcesses", None)
        if api is None:
            return None, "compute_process_api_not_available"
        try:
            rows = api(self.handle)
        except Exception as exc:
            unsupported = getattr(self.nvml, "NVMLError_NotSupported", ())
            no_permission = getattr(self.nvml, "NVMLError_NoPermission", ())
            permitted = tuple(cls for cls in (unsupported, no_permission) if isinstance(cls, type))
            if permitted and isinstance(exc, permitted):
                return None, f"{type(exc).__name__}: {exc}"
            raise TelemetryFailure(f"NVML compute-process telemetry failed: {exc}") from exc
        matching = [row for row in rows if row.pid == pid]
        if not matching:
            return 0, "server_pid_absent_from_compute_list"
        amounts = [getattr(row, "usedGpuMemory", None) for row in matching]
        unavailable = getattr(self.nvml, "NVML_VALUE_NOT_AVAILABLE", (1 << 64) - 1)
        if any(type(value) is not int or value == unavailable for value in amounts):
            return None, "driver_does_not_report_process_memory"
        # A compute process should appear once. Duplicate records must not double count.
        value = max(amounts)
        if value < 0 or value > self.capacity:
            raise TelemetryFailure("NVML returned invalid per-process memory")
        return value, "available"

    def _sample_locked(self) -> dict:
        self.check()
        try:
            memory = self.nvml.nvmlDeviceGetMemoryInfo(self.handle)
            used = memory.used
            if type(used) is not int or not 0 <= used <= self.capacity or memory.total != self.capacity:
                raise TelemetryFailure("NVML total-device memory telemetry became invalid")
            pid = self.pid_provider()
            process, process_status = self._process_usage(pid)
            row = {
                "utc": datetime.now(timezone.utc).isoformat(),
                "monotonic_seconds": self.clock(),
                "gpu_index": self.gpu_index,
                "gpu_uuid": self.uuid,
                "case": self.case,
                "stage": self.stage,
                "round_id": self.round_id,
                "pid": pid,
                "total_used_bytes": used,
                "device_capacity_bytes": self.capacity,
                "process_used_bytes": process,
                "process_metric_status": process_status,
            }
            self.writer.writerow(row)
            self.stream.flush()
            self.sample_count += 1
            self.peak_total = max(self.peak_total, used)
            if process is not None:
                self.peak_process = max(self.peak_process or 0, process)
            else:
                self.process_unavailable_reasons.add(process_status)
            if self.active_round is not None:
                state = self.active_round
                state["memory_samples"] += 1
                state["total_device_peak_bytes"] = max(state["total_device_peak_bytes"], used)
                if process is not None:
                    state["process_memory_samples"] += 1
                    state["server_process_peak_bytes"] = max(state["server_process_peak_bytes"] or 0, process)
                else:
                    state["process_memory_unavailable_reasons"].add(process_status)
            if self.abort_threshold_bytes is not None and used >= self.abort_threshold_bytes:
                raise TelemetryFailure(
                    f"Total GPU VRAM {used / GB:.3f} GB reached the conservative "
                    f"{self.abort_threshold_bytes / GB:.3f} GB abort threshold"
                )
            return row
        except BaseException as exc:
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                raise
            failure = (
                exc if isinstance(exc, TelemetryFailure) else TelemetryFailure(f"NVML sampling failed: {exc}")
            )
            self.failure = failure
            raise failure from exc

    def sample(self) -> dict:
        with self.lock:
            return self._sample_locked()

    def check(self) -> None:
        if self.failure is not None:
            raise self.failure

    def _watch(self) -> None:
        while not self.stop.wait(self.interval):
            try:
                self.sample()
            except BaseException as exc:
                self.failure = exc if isinstance(exc, TelemetryFailure) else TelemetryFailure(str(exc))
                if self.failure_callback is not None:
                    try:
                        self.failure_callback()
                    except Exception:
                        # The telemetry error remains authoritative; lifecycle cleanup confirms exit.
                        pass
                return

    def label(self, case: str, stage: str) -> None:
        with self.lock:
            self.check()
            self.case, self.stage = case, stage

    def begin_round(self, round_id: int, case: str, stage: str) -> dict:
        with self.lock:
            if self.active_round is not None:
                raise TelemetryFailure("Overlapping generations on one GPU are forbidden")
            self.case, self.stage, self.round_id = case, stage, round_id
            state = {
                "memory_samples": 0,
                "process_memory_samples": 0,
                "total_device_peak_bytes": 0,
                "server_process_peak_bytes": None,
                "process_memory_unavailable_reasons": set(),
            }
            self.active_round = state
            try:
                baseline = self._sample_locked()
            except BaseException:
                self.active_round, self.round_id = None, None
                raise
            state["baseline_total_device_bytes"] = baseline["total_used_bytes"]
            state["baseline_server_process_bytes"] = baseline["process_used_bytes"]
            state["server_pid"] = baseline["pid"]
            state["started_monotonic_seconds"] = baseline["monotonic_seconds"]
            return state

    def end_round(self) -> dict:
        with self.lock:
            state = self.active_round
            if state is None:
                raise TelemetryFailure("No active generation round")
            try:
                self._sample_locked()
            finally:
                state["ended_monotonic_seconds"] = self.clock()
                state["process_memory_unavailable_reasons"] = sorted(
                    state["process_memory_unavailable_reasons"]
                )
                self.active_round, self.round_id = None, None
                self.stage = "between_rounds"
            return state

    def report(self) -> dict:
        with self.lock:
            return {
                "gpu_index": self.gpu_index,
                "gpu_uuid": self.expected_uuid,
                "sample_interval_seconds": self.interval,
                "memory_samples": self.sample_count,
                "sampled_peak_total_device_bytes": self.peak_total,
                "sampled_peak_server_process_bytes": self.peak_process,
                "process_metric_unavailable_reasons": sorted(self.process_unavailable_reasons),
                "telemetry_error": str(self.failure) if self.failure else None,
                "abort_threshold_bytes": self.abort_threshold_bytes,
                "hard_vram_cap_guaranteed": False,
                "caveat": "NVML polling includes other applications and can miss short transients.",
            }

    def close(self, *, sample_final: bool = True) -> None:
        if self.closed:
            return
        self.stop.set()
        if self.thread is not None:
            self.thread.join(timeout=2)
        try:
            if sample_final and self.failure is None and self.initialized:
                self.sample()
        finally:
            self.closed = True
            self.stream.close()
            if self.initialized:
                self.nvml.nvmlShutdown()


class MeasuredBackend:
    """Instrument the existing backend without changing its validation rules."""

    def __init__(self, server: Any, recorder: NvmlRecorder, output: Path, profile: str) -> None:
        self.server, self.recorder, self.output, self.profile = server, recorder, output, profile
        self.case, self.stage = "protocol", "unlabelled"
        self.rounds: list[dict] = []
        self.counter = 0
        self.events = (output / "rounds.jsonl").open("x", encoding="utf-8")
        self.validation_events = (output / "round_validation.jsonl").open("x", encoding="utf-8")
        (output / "round_outputs").mkdir()
        (output / "round_inputs").mkdir()

    @property
    def effective_context_size(self) -> int:
        return self.server.effective_context_size

    def prompt_tokens(self, messages: list[dict]) -> int:
        self.recorder.check()
        result = self.server.prompt_tokens(messages)
        self.recorder.check()
        return result

    @contextmanager
    def labelled(self, case: str, stage: str):
        old = self.case, self.stage
        self.case, self.stage = case, stage
        self.recorder.label(case, stage)
        try:
            yield
        finally:
            self.case, self.stage = old
            if self.recorder.failure is None:
                self.recorder.label(*old)

    def complete(self, messages: list[dict], **kwargs: Any) -> dict:
        if self.stage == "unlabelled":
            raise RuntimeFailure("Every generation must have an explicit stage label")
        self.counter += 1
        entry = {
            "round_id": self.counter,
            "profile": self.profile,
            "case": self.case,
            "stage": self.stage,
            "gpu_index": self.recorder.gpu_index,
            "gpu_uuid": self.recorder.expected_uuid,
            "max_output_tokens": kwargs.get("max_tokens"),
            "schema_requested": kwargs.get("json_schema") is not None,
            "temperature": kwargs.get("temperature"),
            "top_p": kwargs.get("top_p"),
            "top_k": kwargs.get("top_k"),
            "seed": kwargs.get("seed"),
            "backend_status": "failed",
            "pipeline_validation_status": "not_evaluated",
            "pipeline_validation_scope": "Finished text, stop reason, reasoning/control token checks",
            "finish_reason": None,
            "usage": {},
            "error": None,
            "telemetry_error": None,
            "measurement_scope": "complete() entry through exit: admission, transport, prefill and decoding",
            "hard_vram_cap_guaranteed": False,
        }
        state, result = None, None
        started = time.monotonic()
        primary_error: BaseException | None = None
        try:
            save_json(
                self.output / "round_inputs" / f"{self.counter:04d}.json",
                {"messages": messages, "generation": kwargs, "case": self.case, "stage": self.stage},
            )
            state = self.recorder.begin_round(self.counter, self.case, self.stage)
            result = self.server.complete(messages, **kwargs)
            self.recorder.check()
            entry.update(
                backend_status="ok", finish_reason=result.get("finish_reason"), usage=result.get("usage", {})
            )
            return result
        except BaseException as exc:
            primary_error = exc
            entry["error"] = error_record(exc)
            raise
        finally:
            telemetry_error: BaseException | None = None
            if state is not None:
                try:
                    self.recorder.end_round()
                except BaseException as exc:
                    telemetry_error = exc
                    entry["telemetry_error"] = error_record(exc)
                    entry["backend_status"] = "failed"
                finally:
                    # end_round() updates state even if its final sample failed.
                    state["process_memory_unavailable_reasons"] = sorted(
                        state["process_memory_unavailable_reasons"]
                    )
                    entry.update(state)
            else:
                entry.update(
                    memory_samples=0,
                    process_memory_samples=0,
                    total_device_peak_bytes=None,
                    server_process_peak_bytes=None,
                    baseline_total_device_bytes=None,
                    baseline_server_process_bytes=None,
                )
                if isinstance(primary_error, TelemetryFailure):
                    entry["telemetry_error"] = error_record(primary_error)
            entry["latency_seconds"] = time.monotonic() - started
            peak = entry["total_device_peak_bytes"]
            entry["total_device_peak_gb"] = peak / GB if peak is not None else None
            process_peak = entry["server_process_peak_bytes"]
            entry["server_process_peak_gb"] = process_peak / GB if process_peak is not None else None
            baseline = entry["baseline_total_device_bytes"]
            entry["peak_above_baseline_bytes"] = (
                max(0, peak - baseline) if peak is not None and baseline is not None else None
            )
            if result is not None:
                save_json(self.output / "round_outputs" / f"{self.counter:04d}.json", result)
            self.rounds.append(entry)
            self.events.write(json.dumps(entry, ensure_ascii=False, allow_nan=False) + "\n")
            self.events.flush()
            print(
                f"ROUND {self.profile}/{self.case}/{self.stage}: "
                f"peak={entry['total_device_peak_gb']} GB, status={entry['backend_status']}",
                flush=True,
            )
            if telemetry_error is not None:
                # Never mask a telemetry failure behind an HTTP/backend exception.
                raise TelemetryFailure(
                    f"Round telemetry failed: {telemetry_error}; primary error: {primary_error}"
                ) from telemetry_error

    def validation(self, round_id: int, status: str, exc: BaseException | None = None) -> None:
        entry = next((row for row in reversed(self.rounds) if row["round_id"] == round_id), None)
        if entry is None:
            return
        entry["pipeline_validation_status"] = status
        event = {"round_id": round_id, "status": status, "error": error_record(exc) if exc else None}
        self.validation_events.write(json.dumps(event, ensure_ascii=False) + "\n")
        self.validation_events.flush()

    def close(self) -> None:
        self.events.close()
        self.validation_events.close()
        fields = (
            "profile",
            "gpu_index",
            "gpu_uuid",
            "server_pid",
            "case",
            "stage",
            "round_id",
            "backend_status",
            "pipeline_validation_status",
            "max_output_tokens",
            "schema_requested",
            "finish_reason",
            "latency_seconds",
            "memory_samples",
            "process_memory_samples",
            "baseline_total_device_bytes",
            "total_device_peak_bytes",
            "total_device_peak_gb",
            "baseline_server_process_bytes",
            "server_process_peak_bytes",
            "server_process_peak_gb",
            "peak_above_baseline_bytes",
            "error",
            "telemetry_error",
            "usage",
        )
        with (self.output / "rounds.csv").open("x", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for row in self.rounds:
                serial = row.copy()
                for key in ("error", "telemetry_error", "usage"):
                    serial[key] = json.dumps(row.get(key), ensure_ascii=False)
                writer.writerow(serial)
