"""Run this file from the extracted package directory."""

from pipeline_core.cli import main
from pipeline_core.requests import WritingError
from pipeline_core.runtime import RuntimeFailure
import sys

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (WritingError, RuntimeFailure, ValueError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)
