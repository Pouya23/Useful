"""Adapter contracts with fake packages; no GPU or model downloads."""

import json
import sys
from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from pipeline_core.engines.base import EngineSettings
from pipeline_core.engines.vllm import VllmEngine
from pipeline_core.engines.transformers import TransformersEngine


class FakeTokenizer:
    def apply_chat_template(self, messages, **options):
        assert options == {"tokenize": False, "add_generation_prompt": True, "enable_thinking": False}
        return json.dumps(messages)

    def encode(self, text, **options):
        assert options == {"add_special_tokens": False}
        return [10, 11, 12]


def test_vllm_forwards_sampling_and_exact_token_prompt(monkeypatch):
    engine = VllmEngine.__new__(VllmEngine)
    engine.effective_context_size = 512
    engine.tokenizer = FakeTokenizer()
    output = SimpleNamespace(text="Maintenance text.", finish_reason="stop", token_ids=[2, 3])
    engine.model = Mock()
    engine.model.generate.return_value = [SimpleNamespace(outputs=[output])]
    params = Mock(side_effect=lambda **kwargs: kwargs)
    monkeypatch.setitem(sys.modules, "vllm", SimpleNamespace(SamplingParams=params))
    result = engine.complete(
        [{"role": "user", "content": "Brief"}], max_tokens=100, temperature=0.7, top_p=0.8, top_k=20, seed=42
    )
    arguments = engine.model.generate.call_args
    assert arguments.args[0] == [{"prompt_token_ids": [10, 11, 12]}]
    assert arguments.args[1] == dict(
        max_tokens=100,
        temperature=0.7,
        top_p=0.8,
        top_k=20,
        min_p=0.0,
        seed=42,
        repetition_penalty=1.0,
        skip_special_tokens=False,
    )
    assert arguments.kwargs.get("use_tqdm") is False
    assert result["finish_reason"] == "stop"
    assert result["usage"] == {"prompt_tokens": 3, "completion_tokens": 2}
    assert len(result["rendered_prompt_sha256"]) == 64


def test_vllm_overflow_does_not_call_model(monkeypatch):
    engine = VllmEngine.__new__(VllmEngine)
    engine.effective_context_size = 512
    engine.tokenizer = FakeTokenizer()
    engine.model = Mock()
    monkeypatch.setitem(sys.modules, "vllm", SimpleNamespace(SamplingParams=Mock()))
    with pytest.raises(ValueError, match="Context overflow"):
        engine.complete([], max_tokens=500, temperature=0.7, top_p=0.8, top_k=20, seed=42)
    engine.model.generate.assert_not_called()


def test_vllm_constructor_uses_one_gpu_and_bounded_pool(monkeypatch):
    monkeypatch.setattr(sys, "platform", "linux")
    tokenizer_loader = Mock(return_value=FakeTokenizer())
    model_loader = Mock()
    monkeypatch.setitem(
        sys.modules,
        "transformers",
        SimpleNamespace(AutoTokenizer=SimpleNamespace(from_pretrained=tokenizer_loader)),
    )
    monkeypatch.setitem(sys.modules, "vllm", SimpleNamespace(LLM=model_loader))
    VllmEngine(EngineSettings(name="vllm"), 0.46875)
    arguments = model_loader.call_args.kwargs
    assert arguments["tensor_parallel_size"] == 1
    assert arguments["gpu_memory_utilization"] == 0.46875
    assert arguments["enforce_eager"] is True
    assert arguments["dtype"] == "auto"
    assert arguments["max_model_len"] == 32768
    assert "attention_backend" not in arguments


def test_transformers_constructor_uses_nf4_and_no_sharding(monkeypatch):
    cuda = SimpleNamespace(
        is_bf16_supported=lambda: False,
        is_available=lambda: True,
        device_count=lambda: 1,
        set_per_process_memory_fraction=Mock(),
    )
    torch = SimpleNamespace(cuda=cuda, float16="float16")
    model = Mock()
    model.eval.return_value = model
    model.hf_device_map = {"": 0}
    model_loader = Mock(return_value=model)
    quant_loader = Mock(return_value="NF4")
    tokenizer_loader = Mock(return_value=FakeTokenizer())
    monkeypatch.setitem(sys.modules, "torch", torch)
    monkeypatch.setitem(
        sys.modules,
        "transformers",
        SimpleNamespace(
            AutoConfig=SimpleNamespace(from_pretrained=Mock(return_value=SimpleNamespace(model_type="qwen3_5"))),
            AutoModelForCausalLM=SimpleNamespace(from_pretrained=Mock()),
            AutoTokenizer=SimpleNamespace(from_pretrained=tokenizer_loader),
            BitsAndBytesConfig=quant_loader,
            Qwen3_5ForConditionalGeneration=SimpleNamespace(from_pretrained=model_loader),
        ),
    )
    TransformersEngine(EngineSettings(name="transformers"), 0.46875)
    assert model_loader.call_args.kwargs["device_map"] == {"": 0}
    assert "attn_implementation" not in model_loader.call_args.kwargs
    assert quant_loader.call_args.kwargs["bnb_4bit_quant_type"] == "nf4"
    cuda.set_per_process_memory_fraction.assert_called_once_with(0.46875, 0)
