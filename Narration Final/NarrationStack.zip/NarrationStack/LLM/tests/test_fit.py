"""Offline tests for estimate/accurate fit selection and max-retry best-of."""

from dataclasses import replace

import pytest
from pipeline_core.duration_api import DurationApiConfig
from pipeline_core.fit import FitSettings, measure_fit, revise_until_fit, select_best, speech_duration_range
from pipeline_core.requests import WritingError, WritingRequest
from tests.test_writer import MeasuredFake, job_for, text


@pytest.fixture
def timed_brief():
    return WritingRequest(
        title="Maintenance of pipe handling systems",
        instructions="Use calm spoken prose.",
        required_points=("Report defects.", "Use approved maintenance procedures."),
        samples=("A demonstration of maintenance writing style.",),
        duration_seconds=60,
        speaking_rate_wpm=130,
        duration_tolerance=0.10,
    )


def test_speech_duration_range():
    low, high = speech_duration_range(100, 0.1)
    assert low == 90.0 and high == pytest.approx(110.0)


def test_estimate_measure_within_and_distance(timed_brief):
    settings = FitSettings(estimate=True)
    # 60s @ 130 wpm → target 130, band 117-143
    ok = measure_fit(text(130), timed_brief, settings)
    assert ok["within_range"] and ok["distance"] == 0 and ok["mode"] == "estimate"
    short = measure_fit(text(50), timed_brief, settings)
    assert not short["within_range"] and short["automatic_action"] == "expand"
    long = measure_fit(text(200), timed_brief, settings)
    assert not long["within_range"] and long["automatic_action"] == "shorten"


def test_accurate_measure_uses_duration_api(timed_brief):
    settings = FitSettings(
        estimate=False,
        speech_duration_tolerance=0.10,
        duration_api=DurationApiConfig(host="127.0.0.1", port=8080),
    )

    def fake_plan(text, desired, config):
        assert desired == 60
        assert "word0" in text
        return {"estimated_natural_duration_s": 59.0, "success": True, "reason": None}

    fit = measure_fit(text(20), timed_brief, settings, plan=fake_plan)
    assert fit["within_range"] and fit["measured_duration_seconds"] == 59.0

    def too_long(text, desired, config):
        return {"estimated_natural_duration_s": 90.0, "success": False, "reason": "too_long"}

    bad = measure_fit(text(20), timed_brief, settings, plan=too_long)
    assert not bad["within_range"] and bad["automatic_action"] == "shorten"


def test_accurate_requires_api_config(timed_brief):
    with pytest.raises(WritingError, match="duration-api"):
        FitSettings(estimate=False).validate()


def test_select_best_prefers_closest_then_target():
    candidates = [
        {"round_index": 0, "fit": {"within_range": False, "distance": 20, "absolute_error_to_target": 30}},
        {"round_index": 1, "fit": {"within_range": False, "distance": 5, "absolute_error_to_target": 40}},
        {"round_index": 2, "fit": {"within_range": False, "distance": 5, "absolute_error_to_target": 10}},
    ]
    assert select_best(candidates)["round_index"] == 2


def test_revise_until_fit_stops_when_estimate_in_range(tmp_path, timed_brief):
    # draft short, first repair lands in band (~130 words)
    job, backend, _ = job_for(tmp_path, timed_brief, [text(40), text(130)])
    job.draft()
    final = revise_until_fit(job, FitSettings(max_retries=3, estimate=True), progress=lambda *_: None)
    assert backend.counter == 2
    assert final["fit"]["within_range"]
    assert final["fit_summary"]["stopped_in_range"]
    assert (job.output / "fit_summary.json").is_file()


def test_revise_until_fit_returns_best_after_max_retries(tmp_path, timed_brief):
    # Never lands in 117-143; closest is 110 (distance 7) over 40/200
    job, backend, _ = job_for(tmp_path, timed_brief, [text(40), text(200), text(110)])
    job.draft()
    final = revise_until_fit(job, FitSettings(max_retries=2, estimate=True), progress=lambda *_: None)
    assert backend.counter == 3
    assert not final["fit"]["within_range"]
    assert final["fit_summary"]["selected_round_index"] == 2
    assert final["word_count"] == 110


def test_revise_until_fit_accurate_forces_revision_when_words_ok(tmp_path, timed_brief):
    # Word count looks fine (~130) but duration API says too short until last call.
    job, backend, _ = job_for(tmp_path, timed_brief, [text(130), text(140), text(125)])
    job.draft()
    durations = iter([40.0, 45.0, 58.0])

    def fake_plan(text, desired, config):
        return {"estimated_natural_duration_s": next(durations), "success": False, "reason": "too_short"}

    settings = FitSettings(
        max_retries=3,
        estimate=False,
        speech_duration_tolerance=0.10,
        duration_api=DurationApiConfig(host="127.0.0.1", port=9),
    )
    final = revise_until_fit(job, settings, plan=fake_plan, progress=lambda *_: None)
    assert backend.counter == 3
    assert final["fit"]["within_range"]
    assert final["fit"]["measured_duration_seconds"] == 58.0


def test_cli_rejects_partial_duration_api(monkeypatch):
    from pipeline_core.cli import build_parser, _fit_settings

    args = build_parser().parse_args(
        ["--duration-seconds", "60", "--duration-api-host", "127.0.0.1", "--no-estimate"]
    )
    with pytest.raises(WritingError):
        _fit_settings(args)
