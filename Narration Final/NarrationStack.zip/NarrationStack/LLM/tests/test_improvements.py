import io
import json
import random
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from pipeline_core.cli import build_parser, _fit_settings
from pipeline_core.duration_api import DurationApiConfig, plan_duration, validate_duration_response
from pipeline_core.fit import FitSettings, revise_until_fit
from pipeline_core.fit import measure_fit, select_best
from pipeline_core.progress import ProgressReporter
from pipeline_core.requests import count_words, WritingError, WritingRequest
from tests.test_writer import job_for, text


def test_incremental_progress_matches_whole_text_word_policy():
    random.seed(42)
    content = "  ".join(["word", "-", "123", "کلمه", "a-b", "...", "a\tb", "中"] * 20)
    reporter = ProgressReporter(500, stream=io.StringIO())
    prefix = ""
    position = 0
    while position < len(content):
        piece = content[position:position + random.randint(1, 9)]
        position += len(piece)
        prefix += piece
        reporter.append_text(piece)
        assert reporter._words == count_words(prefix)
    reporter.update_text("...word ")
    reporter.append_text("x-y")
    assert reporter._words == 2


@pytest.mark.parametrize("duration", [True, float("nan"), float("inf"), 0, -1, "42"])
def test_reject_invalid_api_response(duration):
    with pytest.raises(WritingError):
        validate_duration_response({"estimated_natural_duration_s": duration})


def test_total_round_limit_and_default_model_selection():
    args = build_parser().parse_args(["--duration-seconds", "60", "--max-rounds", "1"])
    assert _fit_settings(args).max_retries == 0
    assert args.estimate is True
    assert args.model == "Qwen/Qwen3.5-9B"


def test_earlier_best_is_saved_and_zero_retries_works(tmp_path):
    request = WritingRequest("Test", duration_seconds=60)
    job, backend, _ = job_for(tmp_path, request, [text(110), text(300)])
    job.draft()
    result = revise_until_fit(job, FitSettings(max_retries=1), progress=lambda *_: None)
    assert result["fit_summary"]["selected_round_index"] == 0
    assert (job.output / "final.txt").read_text(encoding="utf-8") == text(110)
    assert json.loads((job.output / "job.json").read_text())["final"]["fit"] == result["fit"]
    assert len(list(job.output.glob("0*_*.txt"))) == 2


def test_real_http_duration_contract_and_success_false():
    received = []

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            received.append((self.path, self.headers.get("X-API-Key"), json.loads(self.rfile.read(int(self.headers["Content-Length"])))))
            data = json.dumps({"success": False, "reason": "too_long", "estimated_natural_duration_s": 90.0}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *_):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        payload = plan_duration(text(20), 60, DurationApiConfig("127.0.0.1", server.server_port, api_key="test-secret"))
        assert payload["success"] is False
        path, key, body = received[0]
        assert path == "/duration" and key == "test-secret"
        assert body["desired_duration"] == 60
        assert body["split_pattern"] == r"\n+"
        assert set(body) == {"text", "desired_duration", "voice", "lang_code", "speed", "atempo_min", "atempo_max", "seed", "sample_rate", "bitrate_kbps", "split_pattern"}
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


def test_ipv6_url_and_voice_validation():
    assert DurationApiConfig("::1", 80).base_url() == "http://[::1]:80"
    with pytest.raises(WritingError):
        DurationApiConfig("host", 80, voice="bm_george", lang_code="a").validate()


def test_native_profile_requires_no_python_ml_packages():
    # Installation locks are complete, exact pins; helpers import without Torch.
    lock = Path(__file__).resolve().parents[1] / "locks" / "native.txt"
    if lock.exists():
        assert "torch==" not in lock.read_text()


def test_accurate_unmeasurable_text_repairs_without_estimate_fallback(tmp_path):
    request = WritingRequest("Test", duration_seconds=60)
    job, backend, _ = job_for(tmp_path, request, [text(1001), text(130)])
    job.draft()
    calls = []

    def plan(script, duration, config):
        calls.append(script)
        return {"estimated_natural_duration_s": 60}

    result = revise_until_fit(job, FitSettings(max_retries=1, estimate=False,
        duration_api=DurationApiConfig("host", 80)), plan=plan, progress=lambda *_: None)
    assert len(calls) == 1 and backend.counter == 2
    assert result["fit"]["within_range"]
    assert result["fit_summary"]["selected_round_index"] == 1


def test_all_unmeasured_candidates_cannot_claim_accurate_best():
    fit = measure_fit(text(1001), WritingRequest("Test", duration_seconds=60),
        FitSettings(estimate=False, duration_api=DurationApiConfig("host", 80)))
    with pytest.raises(WritingError, match="No candidate"):
        select_best([{"fit": fit}])
