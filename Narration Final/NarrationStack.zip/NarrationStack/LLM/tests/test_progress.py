"""Offline progress percentage helpers."""

from pipeline_core.progress import percent_for_words, progress_word_limit


def test_progress_uses_word_range_maximum():
    assert progress_word_limit({"word_range": [351, 429], "target_words": 390}) == 429


def test_progress_falls_back_to_target_then_draft():
    assert progress_word_limit({"word_range": None, "target_words": 200}) == 200
    assert progress_word_limit({"word_range": None, "target_words": None}, "one two three") == 650


def test_percent_caps_before_completion():
    assert percent_for_words(0, 100) == 0
    assert percent_for_words(50, 100) == 50
    assert percent_for_words(100, 100) == 99
    assert percent_for_words(200, 100) == 99
