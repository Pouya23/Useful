"""A digest taken from the previous writer's exact prompt-building function."""

import hashlib
import json
from pipeline_core.requests import WritingRequest
from pipeline_core.length import automatic_length_feedback
from pipeline_core.prompts import build_messages


def test_original_prompt_path_is_preserved_with_duration_fields():
    request = WritingRequest(
        "Maintenance of pipe handling systems", instructions="Use approved references.", duration_seconds=180
    )
    feedback = automatic_length_feedback("", word_range=request.word_range())
    messages = build_messages(request, request, length_feedback=feedback)
    digest = hashlib.sha256(json.dumps(messages, ensure_ascii=False).encode()).hexdigest()
    assert digest == "cb35fd0d6d776eef80db29827b7dd4d0ff60fc43b18a6173ed879352bea7b34b"
