# NarrationStack

Two GPU containers for the completed LLM/TTS scripts, sharing one CUDA/Python/Flask base. Nothing is started automatically by this delivery.

For the failed conda install on your GTX 1080 Ti / driver 535.183.01, start with [`docs/RECOVERY_GTX1080TI.md`](docs/RECOVERY_GTX1080TI.md). This corrected delivery uses offline conda cloning with plugins disabled and compatible CUDA 12.2.2 / Torch cu121/cu118 builds.

1. Follow [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) from host prerequisites through downloads, build, GPU checks, startup and verification.
2. Give the backend team [`docs/LLM_API.md`](docs/LLM_API.md), [`docs/TTS_API.md`](docs/TTS_API.md) and [`docs/BACKEND_INTEGRATION.md`](docs/BACKEND_INTEGRATION.md).
3. Machine-readable schemas are `docs/llm-openapi.json` and `docs/tts-openapi.json`; each running container also serves Swagger at `/docs/` and its live schema at `/openapi.json`.

One shared GPU execution gate coordinates the containers. Models stay resident between jobs, and model loading/inference is serialized on the shared GPU. Models and durable data are mounted, not baked into images.

LLM: async job queue or live POST SSE, explicit round/retry events, original estimated/API acceptance and closest-round selection. TTS: waveform-free duration preview, sync MP3 or async jobs, time-based progress and ETA. Both include durable artifacts and explicit failures.

See `docs/VALIDATION.md` for tested behavior and the unexecuted container/GPU checks.
