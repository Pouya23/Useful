# Changes and validation

The supplied TTS folder was read without modification. The new `TTS` directory contains runnable server/client/provisioning scripts, helpers and tests. It does not require installing this project as a library. The active Kokoro API is the reconstruction target; the enclosing older Qwen writer, old release builders and historical outputs are reference material, not runtime dependencies.

## Preserved pipeline

Planning still performs only frontend/BERT/duration prediction. Integer duration rounding, minimum duration units, recursive chunk splitting, voice styles and the 600-sample contract remain unchanged. Generation reuses the exact saved tensors, seeds each chunk identically, and runs the same F0/noise predictor, acoustic encoder and decoder. Global peak protection, FFmpeg tempo-chain construction, output sample rate/bitrate, mono MP3 and ffprobe measurement remain.

HTTP payloads/status behavior, optional authentication, queue bound, FIFO processing, plan persistence, idempotency/conflicts, interrupted-job recovery, sync/async behavior and timing calibration are retained. `/duration` never synthesizes speech and still returns HTTP 200 with a usable natural duration when only tempo fitting fails. Truncation, invalid phonemes, failed fits, waveform/sample mismatches and failed jobs remain explicit errors.

## Improvements

- Added a main CLI for compatible checkpoint/config/repository/digest selection and operational settings. Removed machine-specific local paths and implicit startup downloads; serving is offline. English frontend data/library paths are explicit and provisioned beforehand.
- Corrected the input-validation message from 10–500 to the actual unchanged 10–1000 word limit.
- Cache voice digests using file identity, size and nanosecond modification/change timestamps; replacement/modification invalidates the digest. Reject changes during hashing. Avoid the previous repeated full file hashes for every plan request.
- Added an LRU tensor-payload byte budget alongside the original cache-entry limit. Eviction only changes recomputation cost, not the resulting plan. The byte budget is not a total-process RSS cap.
- Allocate one final float32 audio buffer and fill it by chunk. Avoid retaining all chunk arrays plus a concatenation copy. Do not multiply the whole waveform by 1 when peak protection needs no gain change. Sample order, values and global gain semantics are retained.
- Supply frozen expansion sizes to repeat_interleave, avoiding an otherwise necessary CUDA synchronization to discover their output sizes. The durations and expansion algorithm are unchanged.
- Replace synchronous 50 ms SQLite polling with a condition notification at job completion/failure, keeping durable state authoritative. Avoid persisting unchanged progress and the extra connection/read after claiming a job. Add a timing-history index and compute cumulative chunk samples once for O(1) progress ETA lookups.
- Stream client downloads to an atomic file instead of buffering the whole MP3. Stop the demo client cleanly on failed fits and strip transport-only async/generate fields before `/duration`.
- Retain the exact Kokoro source commit, freeze the full dependency closure, and provide curl/checksum-based download plus offline conda/pip setup. Provision static FFmpeg/ffprobe and bundled pronunciation resources explicitly.

## Evidence from this run

- **44 tests passed under Python 3.11.11.** Includes all 35 existing service tests plus cache invalidation/eviction, CLI/model settings, validation and deterministic waveform-buffer assembly. Service tests cover duration-without-generation, rejected fits/specs, queue persistence/capacity, idempotency, sync/async completion/failure, downloads, authentication, restart recovery, ETA/progress bounds and valid OpenAPI.
- The buffer test exercises the real assembly/control path with tensor/model fixtures and checks sample ordering, per-chunk seed sequence and natural sample count. It is not a neural acoustic-quality test.
- Python compilation and Bash installer syntax checks passed. OpenAPI was regenerated from the retained schemas/routes.
- Audited **127 exact application packages** against published dependency metadata, Python 3.11 markers/extras and Linux x86_64/glibc 2.31 artifacts. No missing/conflicting declared dependencies. 125 wheel artifacts and two explicitly frozen pure-Python source artifacts (Kokoro commit and docopt); `dependency_audit.json` and `requirements-artifacts.json` record the result. The English spaCy wheel's hash and dependency constraints were checked directly.
- Downloaded and SHA256-verified the exact Kokoro source archive, spaCy English wheel and FFmpeg 7.0.2 static archive. Verified FFmpeg archive layout and included its complete compiled-library inventory in `FFMPEG_BUILD.txt` (including libmp3lame 3.100).
- Verified the original HF model revision and published checkpoint digest against repository metadata. No large model weights were downloaded or inferred in this workspace.

## Hardware and installation limits

The workspace is Windows. Full Ubuntu installation, offline source builds on Linux, real CPU/GPU model inference, acoustic quality, end-to-end latency, GPU peak usage and real MP3 generation were not executed in this run. Existing historical CPU/audio reports in the source folder are not counted as new verification. Real CPU/HTTP smoke scripts are included for your server.

The Python/network/helper changes reduce identifiable overhead and allocations; no measured end-to-end GPU speedup is claimed. Different GPU kernels, CUDA builds, pronunciation-library versions or FFmpeg versions can affect audio. The original dependency setup left OS libraries/FFmpeg/Torch resolution partly unpinned; this delivery freezes them explicitly, but does not guarantee identical MP3 bytes across deployments.

The test card is now identified as GTX 1080 Ti (SM 6.1), driver 535.183.01. This delivery pins official Torch/torchaudio 2.5.1+cu121 and their complete CUDA 12.1 dependency closure; the same build supports the A6000 final target. GPU allocator accounting remains the original Torch-based measurement, not a whole-device instantaneous memory cap.

Model interchangeability is deliberately constrained to compatible Kokoro architectures. Accepting arbitrary TTS architectures while claiming the same waveform-free exact-duration plan would change the pipeline. Incompatible decoder configurations/checkpoints fail explicitly. Use a fresh data directory when changing models or implementation signatures; saved incompatible queued plans are rejected, not silently regenerated.
