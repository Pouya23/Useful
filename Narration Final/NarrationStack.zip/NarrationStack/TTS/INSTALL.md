# TTS: Ubuntu 20.04 installation and operation

Keep this **TTS** folder beside `containers/` in the extracted NarrationStack. These are executable scripts; do not install this project as a Python library. The installer creates a conda environment named **TTS** with **Python 3.11.11** before installing application packages.

## Complete Bash setup

```bash
cd /your/path/TTS
export DOWNLOAD_DIR="/your/chosen/path/TTS-downloads"
export CONDA_ROOT="$HOME/miniconda-TTS"
export DOWNLOAD_PROXY="socks5h://YOUR_PROXY_IP:YOUR_PROXY_PORT"

# Only basic OS download tools are needed beforehand; Python is not needed.
sudo apt-get update
sudo apt-get install -y curl ca-certificates

# Prefer your proxy's CA certificate if it uses a private certificate authority.
# export CURL_CA_BUNDLE="/path/to/proxy-ca.pem"

# If this proxy requires curl -k, explicitly enable that mode:
# export CURL_INSECURE=1

bash install_ubuntu.sh
source "$CONDA_ROOT/etc/profile.d/conda.sh"
conda activate "$CONDA_ROOT/envs/TTS"
source runtime/activate_tools.sh

python download_models.py \
  --model-dir "$DOWNLOAD_DIR/models/Kokoro-82M"

# Select your physical NVIDIA GPU; use 0 for the first GPU.
export CUDA_VISIBLE_DEVICES=0
export API_KEY=""  # Set a key here if clients should send X-API-Key.
python run_server.py \
  --model-dir "$DOWNLOAD_DIR/models/Kokoro-82M" \
  --data-dir "/your/chosen/path/TTS-data" \
  --device cuda:0 --host 0.0.0.0 --port 8080 \
  --max-vram-gb 5 --cuda-reserve-mb 768 \
  --threads 4 --max-pending-jobs 32 \
  --max-chunk-seconds 20 --plan-cache-size 16 --plan-cache-mb 128
```

Use `--device cpu` for explicit CPU operation. There is no silent GPU-to-CPU fallback. The original 5 GB allocator ceiling/reserve is preserved and is sufficient to begin testing on your old approximately 11 GB GPU or the A6000. Torch's CUDA build requires a working compatible NVIDIA driver; this lock uses the official **CUDA 12.1** wheel, requiring driver **530.30.02 or newer** for the full toolkit compatibility target. Your **GTX 1080 Ti (SM 6.1)** and installed **535.183.01** driver meet that target; the same wheel also supports A6000. No CUDA toolkit, Docker, NVIDIA Container Toolkit, GCC, system Python or pip network access is needed for these scripts.

If apt also cannot reach your network, supply the Ubuntu curl/CA `.deb` files through a working machine first. A machine with neither curl nor working apt cannot bootstrap its own downloads. All application downloads after curl exists go through curl, honor `DOWNLOAD_PROXY`, and stay under `DOWNLOAD_DIR`.

## What the installer does

1. Downloads the fixed `Miniconda3-py311_25.1.1-2-Linux-x86_64.sh` and verifies SHA256.
2. Installs it with its package cache retained, then clones its exact bundled packages **offline** into TTS. It refuses an unrelated preexisting conda prefix; choose a fresh `CONDA_ROOT`.

   The shared clone helper disables external plugins, selects the classic solver, forces the local bootstrap cache and uses an absolute environment prefix. Keep `../containers/` beside this folder. After a child installer exits, explicitly activate the printed prefix in your parent shell; otherwise your previous base Python remains active.
3. Downloads every frozen application artifact through curl. Compatible wheels, URLs and SHA256 digests are in `requirements-artifacts.json`.
4. Installs pinned offline build tools. Builds only **docopt 0.6.2** and the **exact Kokoro source commit** locally through pip with network/build isolation disabled. Every other application artifact is a wheel. No GCC is needed for either pure-Python build.
5. Installs the full closure with `--no-index --no-deps --no-build-isolation --require-hashes` and runs `pip check`.
6. Downloads pinned **FFmpeg/ffprobe 7.0.2** static Linux tools. Their runtime codec libraries are included in the frozen archive; no system FFmpeg installation is required. `espeakng-loader 0.2.4` supplies the pinned pronunciation library/data, and `soundfile 0.13.1` supplies its bundled native library.
7. Verifies the spaCy English model, runs regression tests, and saves complete installed-package/build inventories under `DOWNLOAD_DIR/manifests/`.

The SHA256-pinned installer determines every bootstrap library version/build, including Python's native libraries. `conda-explicit.txt` and `conda-packages.json` enumerate them after installation. `pip-all.txt` enumerates every installed Python distribution. These records include bootstrap packages as well as application requirements.

**Every application dependency is pinned in [`requirements.lock`](requirements.lock): 127 packages**, including Torch CUDA libraries, frontend dependencies, tests and build tools. Core versions retain the source service's choices: Flask 3.1.3, Waitress 3.0.2, flask-swagger-ui 5.33.0, Pydantic 2.13.4, NumPy 1.26.4, SciPy 1.14.1, soundfile 0.13.1, Transformers 5.3.0, huggingface-hub 1.6.0, Misaki 0.9.4, spaCy 3.8.16, Thinc 8.3.13 and en-core-web-sm 3.8.0. Torch/torchaudio are both **2.5.1+cu121**, with Linux CUDA 12.1 dependencies fully pinned, including nvJitLink 12.1.105. Kokoro is version 0.9.4 at commit `dfb907a02bba8152ca444717ca5d78747ccb4bec`, preserving the supplied implementation rather than substituting the PyPI wheel.

Downloads include package/source archives, the conda installer, tools and explicitly selected model files. Installed Python lives in `CONDA_ROOT`. Runtime requests/plans/audio/results live in your separately selected `--data-dir`. Reuse a separate directory from your LLM installation so manifests/wheel sets stay distinct.

## Model interchangeability

The server accepts **compatible Kokoro-family checkpoint/config/voice variants** through its main CLI:

```bash
python download_models.py --model-repo OWNER/COMPATIBLE-KOKORO \
  --revision COMMIT --checkpoint variant.pth --config variant.json \
  --model-dir "$DOWNLOAD_DIR/models/variant"

python run_server.py --model-dir "$DOWNLOAD_DIR/models/variant" \
  --model-repo OWNER/COMPATIBLE-KOKORO --checkpoint variant.pth --config variant.json \
  --model-sha256 EXPECTED_CHECKPOINT_SHA256 \
  --data-dir /your/path/variant-data --device cuda:0 --port 8080
```

Model downloads freeze branches to immutable commits, verify published LFS digests, and save `download_manifest.json`. The original model remains pinned to HF revision `f3ff3571791e39611d31c381e3a41a3af07b4987`. Downloads support public repositories; gated/private models can be downloaded with your authorized workflow and supplied as local files.

An unrelated architecture such as XTTS or Piper cannot preserve this pipeline's waveform-free, sample-exact Kokoro duration contract. The implementation therefore checks architecture/decoder compatibility and rejects incompatible weights. It does not mislabel a synthesized-waveform estimate as a waveform-free plan. A model/config swap changes engine signatures: use a fresh data directory, or expect queued plans from an incompatible signature to fail explicitly.

## HTTP use: existing contract preserved

```bash
curl --noproxy '*' http://127.0.0.1:8080/health
curl --noproxy '*' -H 'Content-Type: application/json' \
  --data-binary @examples/duration.json http://127.0.0.1:8080/duration
curl --noproxy '*' -H 'Content-Type: application/json' \
  --data-binary @examples/generate.json http://127.0.0.1:8080/generate
```

Add `-H "X-API-Key: $API_KEY"` when a key is configured. `/duration` returns JSON only and never synthesizes audio. HTTP 200 with `success:false` still includes natural duration and `too_short`/`too_long`; invalid specs/planning failures use 422. Requests still accept 10–1000 words and targets up to 1800 seconds, with the original voice/speed/tempo/seed/sample-rate/bitrate rules and no extra fields.

`POST /generate` requires `generate:true`. Default `async:true` returns a job ID; `async:false` waits and returns MP3 with `X-Job-Id`. Poll/download via `/progress`. Swagger is `/docs/`, schema is `/openapi.json`. Queue persistence, FIFO processing, idempotency, interrupted-job recovery, errors and timing calibration are retained.

```bash
python demo_client.py --base-url http://127.0.0.1:8080 \
  --spec examples/duration.json --output speech.mp3
python run_server.py --help
```

For the previously created LLM pipeline, point its `--duration-api-host`/`--duration-api-port` at this service. Its accurate acceptance check should compare `estimated_natural_duration_s`, not the stretched target. Final MP3 timing remains approximate and is measured independently by ffprobe.

## Verification on your server

```bash
python -m pytest -q tests
python export_openapi.py
# Real CPU/GPU checks, with downloaded weights and tools:
python verification/real_cpu_smoke.py \
  --model-dir "$DOWNLOAD_DIR/models/Kokoro-82M" \
  --cases-dir examples --output-dir /your/path/tts-cpu-check
python verification/http_smoke.py \
  --model-dir "$DOWNLOAD_DIR/models/Kokoro-82M" \
  --output-dir /your/path/tts-http-check
```

The supplied real smoke scripts intentionally use CPU for portability; run the server with `--device cuda:0` to check actual GPU deployment. No current-run GPU/audio quality claim is inferred from the older verification artifacts supplied with the original folder.

Compatibility sources: [Kokoro pinned source](https://github.com/hexgrad/kokoro/tree/dfb907a02bba8152ca444717ca5d78747ccb4bec), [PyTorch CUDA/version matrix](https://docs.pytorch.org/get-started/previous-versions/), [Miniconda checksums](https://repo.anaconda.com/miniconda/), [spaCy English model](https://github.com/explosion/spacy-models/releases/tag/en_core_web_sm-3.8.0), [espeakng-loader](https://github.com/thewh1teagle/espeakng-loader).
