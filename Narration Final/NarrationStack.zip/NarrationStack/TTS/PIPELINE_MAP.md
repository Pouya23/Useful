# Original TTS execution map

Read from contracts, engine, jobs, Flask app, server, deployment scripts, tests and verification artifacts before changing their execution path. The enclosing folder also contains an older Qwen writer, sample texts, past MP3s and a file pointing to another machine's models. Those are not TTS runtime dependencies.

1. Read environment settings: model/data directories, CPU/CUDA, memory reserve, threads, chunk/cache limits, queue capacity, initial ETA and API key.
2. Check FFmpeg/ffprobe. Optionally download pinned Kokoro weights/config/English voices. Acquire a data-directory OS lease and load one resident model.
3. Configure CUDA without CPU fallback and set the Torch allocator fraction. Validate the decoder's 600-samples-per-duration-unit contract at 24 kHz. Hash weights/config/source into an engine signature.
4. Construct model-free American/British frontends and discover voices. Open SQLite WAL storage, fail interrupted running jobs and retain queued plans. Start one generation worker.
5. Serve Flask through Waitress: `/duration`, `/generate`, `/progress`, `/health`, `/openapi.json`, Swagger `/docs/`. Enforce body limits and optional X-API-Key.
6. Strictly validate JSON: 10–1000 words, target >0 and ≤1800 seconds, voice/language agreement, speed/tempo bounds, sample-rate/bitrate compatibility, seed, split pattern and no extra fields.
7. Planning: hash text/voice/frontend settings and model signature; reuse a plan cache entry. Verify/load the voice tensor. Hold the engine lock and inference mode for frontend/duration inference.
8. Phonemize and tokenize. Reject unknown symbols/context overflow. Run BERT, duration text encoder, LSTM and duration projection. Round/clamp durations exactly as the original; sum integer units ×600.
9. Recursively split overlong chunks at their word midpoint. Cache CPU IDs, duration tensors, predictor embeddings and styles. Planning never runs F0/noise prediction, acoustic decoder or waveform synthesis.
10. Fit check: natural seconds / target seconds, compared with inclusive tempo bounds. Return natural sample count, fit reason, target/stretch estimates, chunk count and default/calibrated ETA. `/duration` returns HTTP 200 JSON on successful planning even when tempo fit fails.
11. Generation admission: replay matching idempotency keys, reject conflicts/failed fits, save the frozen plan and request, then enqueue with a bounded SQLite transaction. Clean files if admission fails.
12. Async requests return a job ID immediately. Sync requests wait for terminal status and return MP3 or JSON error. Both use the same durable worker.
13. Claim FIFO jobs; load and verify the frozen plan signature. Update stage/progress/ETA using observed chunk timings.
14. Synthesize chunks serially under the engine lock and inference mode. Seed each with seed + index ×1,000,003. Use repeat_interleave length expansion, F0/noise prediction, acoustic encoding and decoder. Reject nonfinite audio/sample mismatches.
15. Concatenate chunks; apply global peak protection (gain ≤1, peak ≤0.98); chain FFmpeg atempo stages within 0.5–2, resample and encode mono MP3. Probe actual container duration and publish atomically.
16. Persist actual durations/errors/timings/allocator peaks and calibration. Explicitly record failures. Progress stays below 100 until completed; downloads only serve completed audio.
17. Signal shutdown and retain the data lease until the worker exits. Keep durable requests, plans, audio, results and timing history.

# Improved counterpart

Steps 1–17 remain in order, with the same endpoint payloads and acoustic calculations. A main CLI exposes compatible model directory/repository/checkpoint/config/digest settings. Sample-exact planning remains restricted to compatible Kokoro decoder architectures.

Explicit curl provisioning replaces automatic server downloads. Local configurable paths replace host/container-specific defaults. Optimizations target repeated voice hashing, cache RAM, waveform copies, SQLite polling/writes and repeated chunk sums. Installation creates `TTS` with Python 3.11 first, then installs complete frozen dependencies offline. See `CHANGES_AND_VALIDATION.md` for evidence and limits.
