# TTS scripts

Start with [`PIPELINE_MAP.md`](PIPELINE_MAP.md), then [`INSTALL.md`](INSTALL.md) for complete Ubuntu 20.04 commands and [`requirements.lock`](requirements.lock) for all exact dependencies.

`run_server.py` is the main CLI. Configure compatible Kokoro models with `--model-dir`, `--model-repo`, `--checkpoint`, `--config` and `--model-sha256`. Configure local CPU/GPU, HTTP, queue and plan-cache settings there. The service runs offline after explicit curl provisioning.

The original `/duration`, `/generate` and `/progress` contracts are preserved, including sample-exact natural plans, sync/async generation, durable jobs, idempotency and MP3 downloads. The scripts require no project/library installation.

`CHANGES_AND_VALIDATION.md` describes optimizations, test evidence and hardware-testing limits. Original files were left untouched; unrelated Qwen code, past outputs and host-specific deployment scripts are not runtime dependencies.
