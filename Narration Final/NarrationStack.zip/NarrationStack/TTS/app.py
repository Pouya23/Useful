"""Three functional Flask endpoints plus Swagger and operational health routes."""

from __future__ import annotations

import hmac
import re
import os
import threading

from flask import Flask, jsonify, request, send_file, g
from flask_swagger_ui import get_swaggerui_blueprint
from pydantic import ValidationError
from werkzeug.exceptions import HTTPException

from contracts import FitPreview, GenerateRequest, GenerationAccepted, GenerationSpec, JobProgress, ProgressRequest
from jobs import IdempotencyConflict, QueueFull


class ApiError(Exception):
    def __init__(self, status, code, message, details=None):
        self.status, self.code, self.message, self.details = status, code, message, details


def openapi_document(service):
    sample = {"text": "The final decision required patience, clear evidence, and careful judgment.",
              "voice": "am_onyx", "lang_code": "a", "speed": 1.0,
              "desired_duration": 5.0, "atempo_min": .5, "atempo_max": 2.0,
              "seed": 42, "sample_rate": 48000, "bitrate_kbps": 320}
    schemas = {model.__name__: model.model_json_schema() for model in (
        GenerationSpec, GenerateRequest, ProgressRequest, FitPreview, GenerationAccepted, JobProgress)}
    response = {"description": "JSON result; success=false and error/reason describe rejected or failed operations.",
                "content": {"application/json": {"schema": {"type": "object"}}}}
    security = [{"ApiKeyAuth": []}] if service.settings.api_key else []

    def post(model, summary, example, response_model, code="200"):
        successful = {"description": summary, "content": {"application/json": {
            "schema": {"$ref": f"#/components/schemas/{response_model.__name__}"}}}}
        if response_model is JobProgress:
            successful["content"]["audio/mpeg"] = {"schema": {"type": "string", "format": "binary"}}
        responses = {code: successful, "400": response, "401": response, "409": response,
                     "422": response, "503": response}
        if code == "202":
            responses["200"] = {
                "description": (
                    "Async idempotent replay (JSON job), or synchronous generate "
                    "(async=false) returning audio/mpeg with X-Job-Id / X-Success headers."
                ),
                "content": {
                    "application/json": {"schema": {"$ref": f"#/components/schemas/{response_model.__name__}"}},
                    "audio/mpeg": {"schema": {"type": "string", "format": "binary"}},
                },
            }
        operation = {"summary": summary, "security": security,
                "requestBody": {"required": True, "content": {"application/json": {
                    "schema": {"$ref": f"#/components/schemas/{model.__name__}"}, "example": example}}},
                "responses": responses}
        if model is GenerateRequest:
            operation["parameters"] = [{"name": "Idempotency-Key", "in": "header", "required": False,
                                        "description": "Same key/specifications return the same job ID.",
                                        "schema": {"type": "string", "maxLength": 128}}]
        return operation

    return {"openapi": "3.1.0", "info": {"title": "Kokoro GPU Duration-Fit API", "version": "1.0.0",
            "description": "Natural length is planned without waveform synthesis. Final MP3 duration and job ETA are estimates, independently measured at completion. Uses one persistent model and one durable generation queue. POST /generate with async=true returns a job_id immediately; async=false blocks until the MP3 is ready."},
            "servers": [{"url": "/"}], "components": {"schemas": schemas, "securitySchemes": {
                "ApiKeyAuth": {"type": "apiKey", "in": "header", "name": "X-API-Key"}}},
            "paths": {
                "/duration": {"post": post(GenerationSpec, "Return sample-exact unatempoed natural duration and check FFmpeg atempo range; always returns natural duration JSON (success may be false); never synthesize speech", sample, FitPreview)},
                "/generate": {"post": post(GenerateRequest, "Validate fit and generate speech; async=true queues a job, async=false waits and returns the MP3", {**sample, "generate": True, "async": True}, GenerationAccepted, "202")},
                "/progress": {
                    "post": post(ProgressRequest, "Get status, time-based progress, remaining-time estimate, and result", {"job_id": "0" * 32}, JobProgress),
                    "get": {"summary": "Poll a job, or download its completed MP3 with download=true", "security": security,
                            "parameters": [{"name": "job_id", "in": "query", "required": True,
                                            "schema": {"type": "string", "pattern": "^[0-9a-f]{32}$"}},
                                           {"name": "download", "in": "query", "schema": {"type": "boolean", "default": False}}],
                            "responses": {"200": {"description": "Job JSON, or completed MP3 when download=true", "content": {
                                "application/json": {"schema": {"$ref": "#/components/schemas/JobProgress"}},
                                "audio/mpeg": {"schema": {"type": "string", "format": "binary"}}}},
                                "401": response, "404": response, "409": response, "422": response}},
                },
            },
            "x-installed-voices": service.engine.voices,
            "x-unknown-backend-contract": "Confirm payload/response names with the backend team before assuming port-only compatibility."}


def create_app(service):
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 256 * 1024
    app.config["JSON_SORT_KEYS"] = False
    app.extensions["speech_service"] = service
    admission_slots = threading.BoundedSemaphore(int(os.getenv("TTS_MAX_ACTIVE_REQUESTS", "4")))
    swagger = get_swaggerui_blueprint("/docs", "/openapi.json", config={"app_name": "Kokoro GPU API"})
    app.register_blueprint(swagger, url_prefix="/docs")

    @app.before_request
    def authentication():
        if request.path in {"/duration", "/generate", "/progress"} and service.settings.api_key:
            if not hmac.compare_digest(request.headers.get("X-API-Key", ""), service.settings.api_key):
                raise ApiError(401, "unauthorized", "A valid X-API-Key is required")
        if request.path in {"/duration", "/generate"}:
            if not admission_slots.acquire(blocking=False):
                raise ApiError(503, "request_capacity", "Too many active planning/generation requests; retry later")
            g.admission_slot = True

    @app.teardown_request
    def release_admission(_):
        if g.pop("admission_slot", False):
            admission_slots.release()

    @app.errorhandler(ApiError)
    def api_error(error):
        body = {"success": False, "error": {"code": error.code, "message": error.message}}
        if error.details:
            body["error"]["details"] = error.details
        return jsonify(body), error.status

    @app.errorhandler(HTTPException)
    def http_error(error):
        return jsonify(success=False, error={"code": error.name.lower().replace(" ", "_"), "message": error.description}), error.code

    @app.errorhandler(Exception)
    def unexpected(error):
        app.logger.exception("API request failed", exc_info=error)
        return jsonify(success=False, error={"code": "internal_error", "message": "Request failed; inspect the server logs."}), 500

    @app.errorhandler(QueueFull)
    def full(error):
        return jsonify(success=False, error={"code": "queue_full", "message": str(error)}), 503, {"Retry-After": "10"}

    @app.errorhandler(IdempotencyConflict)
    def conflict(error):
        return jsonify(success=False, error={"code": "idempotency_conflict", "message": str(error)}), 409

    def validate(model, value=None):
        if value is None:
            if not request.is_json:
                raise ApiError(415, "content_type", "Send Content-Type: application/json")
            value = request.get_json()
        try:
            return model.model_validate(value)
        except ValidationError as error:
            details = [{"field": ".".join(str(part) for part in item["loc"]), "message": item["msg"], "type": item["type"]}
                       for item in error.errors()]
            raise ApiError(422, "invalid_specifications", "Request failed validation", details) from error

    @app.post("/duration")
    def duration():
        """Always return the unatempoed natural duration when planning succeeds.

        Out-of-range atempo still includes estimated_natural_duration_s / natural_samples;
        success=false and reason=too_short|too_long mark the fit. HTTP 422 is reserved for
        invalid specs or planning failures, not "text does not fit the tempo window".
        """
        spec = validate(GenerationSpec)
        try:
            _, result = service.estimate(spec)
        except ValueError as error:
            raise ApiError(422, "planning_failed", str(error)) from error
        return jsonify(result), 200

    @app.post("/generate")
    def generate():
        incoming = validate(GenerateRequest)
        spec = GenerationSpec.model_validate(incoming.model_dump(exclude={"generate", "async_"}))
        key = request.headers.get("Idempotency-Key")
        if key is not None and not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", key):
            raise ApiError(422, "invalid_idempotency_key", "Idempotency-Key must contain 1–128 letters/digits/_.:- characters")
        try:
            result = service.submit(spec, key)
        except ValueError as error:
            raise ApiError(422, "planning_failed", str(error)) from error
        if "job_id" not in result:
            return jsonify(result), 422

        if incoming.async_ is True:
            return jsonify(result), 200 if result.get("idempotent_replay") else 202

        # Synchronous path: keep the HTTP request open until the worker finishes.
        job_id = result["job_id"]
        try:
            final = service.wait_until_terminal(job_id)
        except TimeoutError as error:
            raise ApiError(504, "generation_timeout", str(error)) from error
        if final["status"] != "completed":
            body = {
                "success": False,
                "job_id": job_id,
                "status": final["status"],
                "error": final.get("error"),
                "message": "Synchronous generation failed",
            }
            return jsonify(body), 500
        path = service.job_directory(job_id) / "speech.mp3"
        if not path.is_file():
            raise ApiError(410, "audio_missing", "Completed job's MP3 has been removed from storage")
        response = send_file(
            path,
            mimetype="audio/mpeg",
            as_attachment=True,
            download_name=path.name,
            conditional=True,
        )
        response.headers["X-Job-Id"] = job_id
        response.headers["X-Success"] = "true"
        response.headers["Access-Control-Expose-Headers"] = "X-Job-Id, X-Success"
        return response, 200

    @app.route("/progress", methods=["GET", "POST"])
    def progress():
        if request.method == "GET":
            download = request.args.get("download", "false").lower()
            if download not in {"true", "false", "1", "0"}:
                raise ApiError(422, "invalid_download", "download must be true or false")
            value = {"job_id": request.args.get("job_id") or request.args.get("uuid"), "download": download in {"true", "1"}}
            query = validate(ProgressRequest, value)
        else:
            query = validate(ProgressRequest)
        result = service.progress(query.job_id)
        if result is None:
            raise ApiError(404, "job_not_found", "No job exists for this job_id")
        if query.download:
            if result["status"] != "completed":
                raise ApiError(409, "audio_not_ready", "Download is available only after successful completion")
            path = service.job_directory(query.job_id) / "speech.mp3"
            if not path.is_file():
                raise ApiError(410, "audio_missing", "Completed job's MP3 has been removed from storage")
            return send_file(path, mimetype="audio/mpeg", as_attachment=True,
                             download_name=path.name, conditional=True)
        return jsonify(result)

    @app.get("/health")
    def health():
        ready = service.worker.is_alive()
        return jsonify(success=ready, ready=ready, device=service.settings.device,
                       generation_worker_alive=service.worker.is_alive(),
                       engine_signature=service.engine.signature,
                       installed_voices=service.engine.voices,
                       timing_profile=service.profile,
                       gpu_memory=service.engine.memory_snapshot()), 200 if ready else 503

    @app.get("/openapi.json")
    def specification():
        return jsonify(openapi_document(service))

    return app
