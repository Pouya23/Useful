"""Main server CLI: swap compatible Kokoro checkpoints without changing HTTP contracts."""
import argparse
from dataclasses import replace
import os
from pathlib import Path
from contracts import Settings


def parse_settings(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", type=Path)
    parser.add_argument("--model-repo")
    parser.add_argument("--checkpoint", dest="checkpoint_name")
    parser.add_argument("--config", dest="config_name")
    parser.add_argument("--model-sha256")
    parser.add_argument("--data-dir", "--output", type=Path, help="Persistent output base; generated jobs/files get UTC timestamp names")
    parser.add_argument("--device", choices=["cpu", "cuda:0"])
    parser.add_argument("--max-vram-gb", type=float)
    parser.add_argument("--cuda-reserve-mb", type=int)
    parser.add_argument("--threads", type=int)
    parser.add_argument("--max-pending-jobs", type=int)
    parser.add_argument("--max-chunk-seconds", type=float)
    parser.add_argument("--plan-cache-size", type=int)
    parser.add_argument("--plan-cache-mb", type=float)
    parser.add_argument("--api-key", help="Alternatively set API_KEY in the environment")
    parser.add_argument("--host", default=os.getenv("HTTP_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("HTTP_PORT", "8000")))
    parser.add_argument("--http-threads", type=int, default=8)
    args = parser.parse_args(argv)
    names = set(Settings.__dataclass_fields__)
    overrides = {k: v for k, v in vars(args).items() if k in names and v is not None}
    settings = replace(Settings.from_env(), **overrides)
    settings.validate()
    if not 1 <= args.port <= 65535 or not 1 <= args.http_threads <= 128:
        parser.error("Use port 1..65535 and http-threads 1..128")
    return args, settings
