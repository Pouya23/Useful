"""Validated HTTP inputs and environment settings for the standalone service."""

from __future__ import annotations

import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, StrictBool, model_validator
from uuid import UUID


class GenerationSpec(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)

    text: str = Field(min_length=1, max_length=100000, description="Complete English passage, 10-1000 whitespace-delimited words.")
    voice: str = Field(default="am_onyx", pattern=r"^[ab][fm]_[a-z]+$", description="Installed American/British Kokoro preset ID, not a WAV or filesystem path.")
    lang_code: Literal["a", "b"] = "a"
    speed: float = Field(default=1.0, ge=0.25, le=4.0, strict=True, description="Native Kokoro speed; separate from the later FFmpeg tempo factor.")
    desired_duration: float = Field(gt=0, le=1800, strict=True, description="Target seconds after FFmpeg tempo fitting. MP3/atempo export duration is approximate.")
    atempo_min: float = Field(default=0.93, ge=0.125, le=8, strict=True)
    atempo_max: float = Field(default=1.15, ge=0.125, le=8, strict=True)
    split_pattern: Literal[r"\n+"] | None = Field(default=r"\n+", description="Newline splitting or null. Arbitrary regular expressions are not accepted over HTTP.")
    seed: int = Field(default=42, ge=0, lt=2**32, strict=True)
    sample_rate: int = Field(default=48000, ge=8000, le=192000, strict=True, description="MP3 export rate; libmp3lame supported rates are validated below.")
    bitrate_kbps: Literal[64, 96, 128, 160, 192, 224, 256, 320] = 320

    @model_validator(mode="after")
    def check_combination(self):
        self.text = self.text.strip()
        count = len(self.text.split())
        if not 10 <= count <= 1000:
            raise ValueError(f"text must contain 10–1000 whitespace-delimited words; received {count}")
        if self.atempo_min > self.atempo_max:
            raise ValueError("atempo_min must not exceed atempo_max")
        if self.voice[0] != self.lang_code:
            raise ValueError("voice prefix and lang_code must agree: a=American, b=British English")
        if self.sample_rate not in {8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000}:
            raise ValueError("sample_rate must be supported by libmp3lame: 8000/11025/12000/16000/22050/24000/32000/44100/48000")
        if isinstance(self.bitrate_kbps, bool):
            raise ValueError("bitrate_kbps must be an integer")
        if self.sample_rate < 32000 and self.bitrate_kbps > 160:
            raise ValueError("MP3 rates below 32000 Hz require bitrate_kbps <=160")
        return self


class GenerateRequest(GenerationSpec):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False, populate_by_name=True)

    generate: StrictBool = Field(default=True, description="Optional compatibility field; if supplied it must be true.", json_schema_extra={"const": True})
    async_: StrictBool = Field(
        default=True,
        alias="async",
        description="If true (default), accept the job and return job_id immediately. "
        "If false, keep the HTTP request open until generation finishes, then return the MP3 "
        "with the successful job_id in the X-Job-Id response header.",
    )

    @model_validator(mode="after")
    def require_generation(self):
        if self.generate is not True:
            raise ValueError("generate must be true; use /duration for natural length and fit check only")
        return self


class ProgressRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    job_id: str = Field(pattern=r"^[0-9a-f]{32}$")
    download: StrictBool = False

    @model_validator(mode="before")
    @classmethod
    def normalize_uuid(cls, data):
        if not isinstance(data, dict):
            return data
        data = dict(data)
        if "uuid" in data:
            if "job_id" in data:
                raise ValueError("Use job_id or uuid, not both")
            data["job_id"] = data.pop("uuid")
        try:
            data["job_id"] = UUID(data["job_id"]).hex
        except (ValueError, TypeError, AttributeError, KeyError) as exc:
            raise ValueError("job_id must be a UUID string") from exc
        return data


class FitPreview(BaseModel):
    success: bool
    duration_s: float | None = Field(default=None, description="Fitted target on success; natural unatempoed duration on failed fit")
    duration_kind: Literal["fitted_target", "natural_unatempoed"] | None = None
    reason: Literal["too_short", "too_long"] | None
    estimated_natural_duration_s: float
    natural_samples: int
    natural_sample_rate: int
    desired_duration_s: float
    estimated_final_duration_s: float
    atempo_factor: float
    atempo_min: float
    atempo_max: float
    chunk_count: int
    natural_duration_is_sample_exact: bool
    final_duration_is_sample_exact: bool
    duration_estimate_kind: str
    estimated_generation_time_s: float
    estimated_encoding_time_s: float
    eta_source: str
    calibration_samples: int
    eta_is_guaranteed: bool
    planning_time_s: float
    waveform_generated: bool = Field(description="Whether the admission/planning step generated a waveform; false.")


class GenerationAccepted(FitPreview):
    job_id: str
    status: Literal["queued", "running", "completed", "failed"]
    idempotent_replay: bool
    progress_url: str


class JobProgress(BaseModel):
    success: bool
    job_id: str
    status: Literal["queued", "running", "completed", "failed"]
    stage: str
    progress_percent: float
    elapsed_generation_time_s: float
    time_remaining_s: float = Field(description="Approximate remaining runtime including queue wait; zero during overrun is not completion.")
    estimated_queue_wait_s: float
    queue_position: int
    estimated_generation_time_s: float
    eta_source: str
    eta_is_guaranteed: bool
    eta_overrun: bool
    completed_chunks: int
    total_chunks: int
    estimated_final_duration_s: float
    result: dict | None = Field(description="Present after completion; includes audio_url, actual_natural_duration_s, actual_final_duration_s, duration_error_percent, timing and GPU allocator measurements.")
    error: dict | None


@dataclass(frozen=True)
class Settings:
    model_dir: Path
    data_dir: Path
    device: str = "cuda:0"
    max_vram_gb: float = 5.0
    cuda_reserve_mb: int = 768
    threads: int = 4
    max_pending_jobs: int = 32
    max_chunk_seconds: float = 20.0
    plan_cache_size: int = 16
    gpu_rtf: float = 0.024
    cpu_rtf: float = 0.5
    encode_overhead_s: float = 1.5
    ffmpeg_timeout_s: float = 300.0
    api_key: str = ""
    model_repo: str = "hexgrad/Kokoro-82M"
    checkpoint_name: str = "kokoro-v1_0.pth"
    config_name: str = "config.json"
    model_sha256: str | None = None
    plan_cache_mb: float = 128.0

    @classmethod
    def from_env(cls):
        settings = cls(
            model_dir=Path(os.getenv("MODEL_DIR", "models")),
            data_dir=Path(os.getenv("DATA_DIR", "data")),
            device=os.getenv("TTS_DEVICE", "cuda:0"),
            max_vram_gb=float(os.getenv("MAX_VRAM_GB", "5")),
            cuda_reserve_mb=int(os.getenv("CUDA_RESERVE_MB", "768")),
            threads=int(os.getenv("CPU_THREADS", "4")),
            max_pending_jobs=int(os.getenv("MAX_PENDING_JOBS", "32")),
            max_chunk_seconds=float(os.getenv("MAX_CHUNK_SECONDS", "20")),
            plan_cache_size=int(os.getenv("PLAN_CACHE_SIZE", "16")),
            gpu_rtf=float(os.getenv("INITIAL_GPU_RTF", "0.024")),
            cpu_rtf=float(os.getenv("INITIAL_CPU_RTF", "0.5")),
            encode_overhead_s=float(os.getenv("INITIAL_ENCODE_SECONDS", "1.5")),
            ffmpeg_timeout_s=float(os.getenv("FFMPEG_TIMEOUT_SECONDS", "300")),
            api_key=os.getenv("API_KEY", ""),
            model_repo=os.getenv("TTS_MODEL_REPO", "hexgrad/Kokoro-82M"),
            checkpoint_name=os.getenv("TTS_CHECKPOINT", "kokoro-v1_0.pth"),
            config_name=os.getenv("TTS_CONFIG", "config.json"),
            model_sha256=os.getenv("TTS_MODEL_SHA256") or None,
            plan_cache_mb=float(os.getenv("PLAN_CACHE_MB", "128")),
        )
        settings.validate()
        return settings

    def validate(self):
        settings = self
        if settings.device != "cpu" and settings.device != "cuda:0":
            raise ValueError("TTS_DEVICE must be cpu or cuda:0; select the GPU with CUDA_VISIBLE_DEVICES")
        if not math.isfinite(settings.max_vram_gb) or not 0 < settings.max_vram_gb <= 5 or settings.cuda_reserve_mb < 0:
            raise ValueError("Require 0<MAX_VRAM_GB<=5 and CUDA_RESERVE_MB>=0")
        if not math.isfinite(settings.plan_cache_mb) or settings.plan_cache_mb < 0:
            raise ValueError("PLAN_CACHE_MB must be finite and nonnegative")
        for name in (settings.checkpoint_name, settings.config_name):
            if Path(name).name != name or name in {".", ".."}:
                raise ValueError("Checkpoint/config names must be filenames inside model-dir")
        if settings.model_sha256:
            import re
            if not re.fullmatch(r"[0-9a-fA-F]{64}", settings.model_sha256):
                raise ValueError("Model SHA256 must be 64 hexadecimal characters")
        if not 1 <= settings.threads <= 64 or not 1 <= settings.max_pending_jobs <= 128:
            raise ValueError("CPU_THREADS must be 1..64; MAX_PENDING_JOBS must be 1..128")
        if not 1 <= settings.max_chunk_seconds <= 30 or not 1 <= settings.plan_cache_size <= 64:
            raise ValueError("MAX_CHUNK_SECONDS must be 1..30; PLAN_CACHE_SIZE must be 1..64")
        times = (settings.gpu_rtf, settings.cpu_rtf, settings.encode_overhead_s, settings.ffmpeg_timeout_s)
        if not all(math.isfinite(value) and value > 0 for value in times):
            raise ValueError("Timing defaults/timeouts must be positive")
