"""Beginner client: duration/fit check, submit, show time-based progress, download MP3."""

import argparse
import json
import time
from pathlib import Path

import requests


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True, help="e.g. http://GPU_SERVER_ADDRESS:8080")
    parser.add_argument("--spec", type=Path, default=Path(__file__).parent / "examples" / "duration.json")
    parser.add_argument("--output", type=Path, default=Path("my_speech.mp3"))
    parser.add_argument("--api-key", default="")
    args = parser.parse_args()
    base = args.base_url.rstrip("/")
    headers = {"X-API-Key": args.api_key} if args.api_key else {}
    spec = json.loads(args.spec.read_text(encoding="utf-8"))
    spec.pop("generate", None)
    spec.pop("async", None)
    planned = requests.post(base + "/duration", json=spec, headers=headers, timeout=120)
    print("Duration:", json.dumps(planned.json(), indent=2))
    planned.raise_for_status()
    if not planned.json().get("success"):
        raise RuntimeError(f"Text does not fit the requested tempo range: {planned.json().get('reason')}")
    submitted = requests.post(base + "/generate", json={**spec, "generate": True}, headers=headers, timeout=120)
    submitted.raise_for_status()
    job_id = submitted.json()["job_id"]
    print("Job:", job_id)
    deadline = time.monotonic() + 3600
    while time.monotonic() < deadline:
        response = requests.get(base + "/progress", params={"job_id": job_id}, headers=headers, timeout=30)
        response.raise_for_status()
        state = response.json()
        percent = state["progress_percent"]
        filled = int(percent / 5)
        print(f"\r[{'#' * filled}{'-' * (20-filled)}] {percent:6.2f}% {state['status']}/{state['stage']} remaining~{state['time_remaining_s']:.1f}s", end="", flush=True)
        if state["status"] == "failed":
            raise RuntimeError("\n" + json.dumps(state["error"]))
        if state["status"] == "completed":
            args.output.parent.mkdir(parents=True, exist_ok=True)
            temporary = args.output.with_name(args.output.name + ".part")
            with requests.get(base + state["result"]["audio_url"], headers=headers, timeout=120, stream=True) as audio:
                audio.raise_for_status()
                with temporary.open("wb") as output:
                    for chunk in audio.iter_content(chunk_size=1024 * 1024):
                        output.write(chunk)
            temporary.replace(args.output)
            print("\nSaved:", args.output.resolve())
            print("Actual final seconds:", state["result"]["actual_final_duration_s"])
            return
        time.sleep(.5)
    raise TimeoutError("Client polling deadline exceeded; inspect /progress using the saved job_id")


if __name__ == "__main__":
    main()
