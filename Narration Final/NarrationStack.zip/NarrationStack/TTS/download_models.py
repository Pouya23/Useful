"""Explicit curl download of a frozen Kokoro-compatible checkpoint and English voices."""
import argparse
import json
from pathlib import Path, PurePosixPath
from urllib.parse import quote
from download_packages import curl_json, download, sha256

REVISION = "f3ff3571791e39611d31c381e3a41a3af07b4987"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-repo", default="hexgrad/Kokoro-82M")
    parser.add_argument("--revision")
    parser.add_argument("--checkpoint", default="kokoro-v1_0.pth")
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--model-dir", type=Path, required=True)
    args = parser.parse_args()
    revision = args.revision or (REVISION if args.model_repo == "hexgrad/Kokoro-82M" else "main")
    info = curl_json(f"https://huggingface.co/api/models/{args.model_repo}/revision/{quote(revision,safe='')}?blobs=true")
    commit = info["sha"]
    records = {}
    for item in info["siblings"]:
        filename = item["rfilename"]
        relative = PurePosixPath(filename)
        if relative.is_absolute() or ".." in relative.parts or "\\" in filename:
            raise ValueError("Unsafe repository path")
        if filename not in {args.checkpoint, args.config, "LICENSE"} and not (filename.startswith("voices/") and relative.name.endswith(".pt") and relative.name[:2] in {"am", "af", "bm", "bf"}):
            continue
        target = args.model_dir / filename
        download(f"https://huggingface.co/{args.model_repo}/resolve/{commit}/{quote(filename)}", target, item.get("lfs",{}).get("sha256"))
        records[filename] = {"sha256": sha256(target), "bytes": target.stat().st_size}
    if args.checkpoint not in records or args.config not in records or not any(p.startswith("voices/") for p in records):
        raise ValueError("Repository lacks the selected checkpoint/config or English voice packs")
    (args.model_dir / "download_manifest.json").write_text(json.dumps(
        {"repository": args.model_repo, "revision": commit, "files": records},indent=2),encoding="utf-8")
    print(f"Model ready: {args.model_dir.resolve()}\nCheckpoint SHA256: {records[args.checkpoint]['sha256']}")


if __name__ == "__main__":
    main()
