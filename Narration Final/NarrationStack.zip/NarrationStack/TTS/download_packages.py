#!/usr/bin/env python3
"""Curl-only wheel downloads, exact pins, SHA256 and native platform tags.

Run after creating the Python 3.11 environment. Pip never contacts an index.
Only the frozen Kokoro commit and docopt use explicitly pinned pure-Python sources.
All other installation artifacts must be compatible wheels.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

# Miniconda's bundled pip provides packaging before we install our pinned packaging.
try:
    from packaging.tags import sys_tags
    from packaging.utils import parse_wheel_filename
except ImportError:
    from pip._vendor.packaging.tags import sys_tags
    from pip._vendor.packaging.utils import parse_wheel_filename


def curl_options() -> list[str]:
    args = ["curl", "--fail", "--location", "--retry", "5", "--retry-delay", "2",
            "--connect-timeout", "60"]
    if os.environ.get("DOWNLOAD_PROXY"):
        args += ["--proxy", os.environ["DOWNLOAD_PROXY"]]
    if os.environ.get("CURL_CA_BUNDLE"):
        args += ["--cacert", os.environ["CURL_CA_BUNDLE"]]
    if os.environ.get("CURL_INSECURE") == "1":
        args += ["--insecure"]
    return args


def curl_json(url: str) -> dict:
    return json.loads(subprocess.check_output(curl_options() + ["--silent", "--show-error", url]))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def download(url: str, destination: Path, checksum: str | None = None) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file() and checksum and sha256(destination) == checksum:
        return
    part = destination.with_name(destination.name + ".part")
    subprocess.run(curl_options() + ["--silent", "--show-error", "--continue-at", "-",
                                    "--output", str(part), url], check=True)
    if checksum and sha256(part) != checksum:
        raise RuntimeError(f"SHA256 mismatch: {part}; inspect the retained partial file")
    part.replace(destination)


def pins(path: Path) -> list[tuple[str, str]]:
    result = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        match = re.fullmatch(r"([A-Za-z0-9_.-]+)==([^\s;]+)", line)
        if not match:
            raise ValueError(f"Expected an exact pin, got {line!r}")
        result.append(match.groups())
    return result


def select_wheel(metadata: dict, ranks: dict) -> dict:
    eligible = []
    for artifact in metadata.get("urls", []):
        if artifact.get("packagetype") != "bdist_wheel" or artifact.get("yanked"):
            continue
        _, _, _, tags = parse_wheel_filename(artifact["filename"])
        positions = [ranks[t] for t in tags if t in ranks]
        if positions:
            eligible.append((min(positions), artifact["filename"], artifact))
    if not eligible:
        raise RuntimeError(f"No compatible wheel for {metadata['info']['name']}=={metadata['info']['version']} on this Python/glibc/CPU")
    return min(eligible, key=lambda item: item[:2])[2]


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("lock", type=Path)
    parser.add_argument("download_dir", type=Path)
    parser.add_argument("--jobs", type=int, default=4)
    args = parser.parse_args(argv)
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    args.download_dir.mkdir(parents=True, exist_ok=True)
    ranks = {tag: i for i, tag in enumerate(sys_tags())}
    packages = pins(args.lock)
    frozen_path = args.lock.with_name(args.lock.stem + "-artifacts.json")
    frozen = {(p["name"], p["version"]): p for p in json.loads(frozen_path.read_text(encoding="utf-8"))} if frozen_path.exists() else {}

    def fetch(item):
        name, version = item
        if (name, version) in frozen:
            artifact = frozen[(name, version)]
            if artifact.get("kind") != "source":
                _, _, _, tags = parse_wheel_filename(artifact["filename"])
                if not any(t in ranks for t in tags):
                    raise RuntimeError(f"Frozen wheel is incompatible with this interpreter/platform: {artifact['filename']}")
            digest = artifact["sha256"]
        else:
            metadata = curl_json(f"https://pypi.org/pypi/{name}/{version}/json")
            artifact = select_wheel(metadata, ranks)
            digest = artifact["digests"]["sha256"]
        destination = args.download_dir / artifact["filename"]
        print(f"Downloading {name}=={version}", flush=True)
        download(artifact["url"], destination, digest)
        return {"name": name, "version": version, "filename": destination.name,
                "sha256": digest, "url": artifact["url"]}

    with ThreadPoolExecutor(max_workers=args.jobs) as executor:
        manifest = list(executor.map(fetch, packages))
    (args.download_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    # Each selected wheel is named explicitly; no ambiguity from a shared download directory.
    (args.download_dir / "install-wheels.txt").write_text(
        "".join(f"{(args.download_dir / p['filename']).resolve().as_uri()} --hash=sha256:{p['sha256']}\n" for p in manifest),
        encoding="utf-8")
    print(f"Verified {len(manifest)} wheels; install-wheels.txt is ready for offline pip.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
