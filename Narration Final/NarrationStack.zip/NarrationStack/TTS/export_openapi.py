"""Export the backend contract without loading Kokoro or starting a server."""

import json
from pathlib import Path
from types import SimpleNamespace

from app import openapi_document


def main():
    stub = SimpleNamespace(settings=SimpleNamespace(api_key=""), engine=SimpleNamespace(voices=[]))
    document = openapi_document(stub)
    document.pop("x-installed-voices", None)
    document["x-catalog-note"] = "The live /openapi.json and /health list installed voices after startup."
    destination = Path(__file__).parent / "openapi.json"
    destination.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")
    print(destination)


if __name__ == "__main__":
    main()
