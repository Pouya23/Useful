#!/usr/bin/env bash
# No preinstalled Python required. All application downloads use curl.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
: "${DOWNLOAD_DIR:?Set DOWNLOAD_DIR to your chosen absolute download directory}"
CONDA_ROOT="${CONDA_ROOT:-$HOME/miniconda-TTS}"
[[ "$(uname -m)" == x86_64 ]] || { echo 'Requires Ubuntu x86_64' >&2; exit 2; }
command -v curl >/dev/null || { echo 'Install curl and ca-certificates first (see INSTALL.md)' >&2; exit 2; }
mkdir -p "$DOWNLOAD_DIR"
DOWNLOAD_DIR="$(cd -- "$DOWNLOAD_DIR" && pwd)"
export DOWNLOAD_DIR
CURL=(bash "$ROOT/../containers/curl_retry.sh" --fail --location --retry 5 --retry-delay 2 --connect-timeout 60)
[[ -z "${DOWNLOAD_PROXY:-}" ]] || CURL+=(--proxy "$DOWNLOAD_PROXY")
[[ -z "${CURL_CA_BUNDLE:-}" ]] || CURL+=(--cacert "$CURL_CA_BUNDLE")
[[ "${CURL_INSECURE:-0}" != 1 ]] || CURL+=(--insecure)
INSTALLER=Miniconda3-py311_25.1.1-2-Linux-x86_64.sh
SHA=d8c1645776c0758214e4191c605abe5878002051316bd423f2b14b22d6cb4251
if [[ ! -x "$CONDA_ROOT/bin/conda" ]]; then
  if [[ ! -f "$DOWNLOAD_DIR/$INSTALLER" ]]; then
    CURL_EXPECTED_SHA256="$SHA" "${CURL[@]}" --continue-at - -o "$DOWNLOAD_DIR/$INSTALLER.part" "https://repo.anaconda.com/miniconda/$INSTALLER"
    printf '%s  %s\n' "$SHA" "$DOWNLOAD_DIR/$INSTALLER.part" | sha256sum -c -
    mv -- "$DOWNLOAD_DIR/$INSTALLER.part" "$DOWNLOAD_DIR/$INSTALLER"
  fi
  printf '%s  %s\n' "$SHA" "$DOWNLOAD_DIR/$INSTALLER" | sha256sum -c -
  bash "$DOWNLOAD_DIR/$INSTALLER" -b -k -p "$CONDA_ROOT"
  printf '%s\n' "$SHA" > "$CONDA_ROOT/.tts-bootstrap"
fi
[[ -f "$CONDA_ROOT/.tts-bootstrap" && "$(cat "$CONDA_ROOT/.tts-bootstrap")" == "$SHA" ]] || { echo 'Choose a fresh CONDA_ROOT for the pinned TTS bootstrap' >&2; exit 2; }
source "$ROOT/../containers/conda_offline.sh"
clone_offline_env "$CONDA_ROOT" TTS
source "$CONDA_ROOT/etc/profile.d/conda.sh"
conda activate "$CONDA_ROOT/envs/TTS"
python -c 'import sys; assert sys.version_info[:3] == (3,11,11), sys.version'
if [[ "${CHECK_GPU:-1}" == 1 ]]; then
  python "$ROOT/../containers/check_gpu.py" --profile tts
fi
mkdir -p "$DOWNLOAD_DIR/manifests"
conda list --explicit > "$DOWNLOAD_DIR/manifests/conda-explicit.txt"
conda list --json > "$DOWNLOAD_DIR/manifests/conda-packages.json"
python "$ROOT/download_packages.py" "$ROOT/requirements.lock" "$DOWNLOAD_DIR/wheels" --jobs "${DOWNLOAD_JOBS:-1}"
python "$ROOT/prepare_install.py" "$DOWNLOAD_DIR"
export PIP_NO_INDEX=1 PIP_DISABLE_PIP_VERSION_CHECK=1
python "$ROOT/../containers/install_offline.py" "$DOWNLOAD_DIR/wheels" \
  --names pip,setuptools,wheel,hatchling,packaging,pathspec,trove-classifiers --no-check
# Only docopt and the exact Kokoro commit need source builds; their build backends are already pinned/installed.
python "$ROOT/../containers/install_offline.py" "$DOWNLOAD_DIR/wheels"
python -m pip check
python "$ROOT/../containers/write_runtime_env.py" --environment "$CONDA_PREFIX" \
  --tools "$DOWNLOAD_DIR/tools/ffmpeg-7.0.2-amd64-static" --output "$ROOT/runtime/activate_tools.sh"
source "$ROOT/runtime/activate_tools.sh"
if [[ "${CHECK_GPU:-1}" == 1 ]]; then
  python "$ROOT/../containers/check_gpu.py" --profile tts --torch
fi
python -m pip freeze --all > "$DOWNLOAD_DIR/manifests/pip-all.txt"
ffmpeg -version > "$DOWNLOAD_DIR/manifests/ffmpeg-build.txt"
python -c 'import spacy,espeakng_loader; assert spacy.util.is_package("en_core_web_sm"); print("English frontend installed")'
cd "$ROOT"
python -m pytest -q tests
echo 'Ready: conda environment TTS. Download models explicitly before running run_server.py.'
printf 'Activate from your own shell: source %q; conda activate %q\n' "$CONDA_ROOT/etc/profile.d/conda.sh" "$CONDA_ROOT/envs/TTS"
