"""SQLite-backed admission, a single generation worker, and calibrated ETA."""

from __future__ import annotations

import contextlib
import hashlib
import json
import logging
import math
import sqlite3
import sys
import statistics
import threading
import time
import uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'containers'))
from output_paths import artifact_path, new_artifact_dir

from contracts import GenerationSpec, Settings
from kokoro_fit_core import evaluate_fit

LOGGER = logging.getLogger(__name__)


class QueueFull(Exception):
    pass


class IdempotencyConflict(Exception):
    pass


class RuntimeLease:
    """Prevent two service processes from loading models against one data volume."""

    def __init__(self, path: Path):
        self.file = path.open("a+b")
        try:
            if __import__("os").name == "nt":
                import msvcrt
                self.file.seek(0)
                if not self.file.read(1):
                    self.file.write(b"0")
                    self.file.flush()
                self.file.seek(0)
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except Exception:
            self.file.close()
            raise RuntimeError("Another service owns this DATA_DIR; use one server process per GPU/data volume") from None

    def close(self):
        self.file.close()


class JobStore:
    def __init__(self, directory: Path):
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / "jobs.sqlite3"
        with self.connection() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS jobs (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, job_id TEXT UNIQUE NOT NULL,
                    spec_json TEXT NOT NULL, fit_json TEXT NOT NULL, request_hash TEXT NOT NULL,
                    idempotency_key TEXT UNIQUE, status TEXT NOT NULL,
                    created_at REAL NOT NULL, started_at REAL, finished_at REAL,
                    estimated_runtime_s REAL NOT NULL, eta_source TEXT NOT NULL,
                    calibration_samples INTEGER NOT NULL, stage TEXT NOT NULL,
                    completed_chunks INTEGER NOT NULL DEFAULT 0,
                    last_progress_percent REAL NOT NULL DEFAULT 0,
                    result_json TEXT, error_json TEXT
                );
                CREATE TABLE IF NOT EXISTS timings (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, profile TEXT NOT NULL,
                    natural_seconds REAL NOT NULL, synthesis_seconds REAL NOT NULL,
                    encoding_seconds REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS jobs_status_order ON jobs(status,seq);
                CREATE INDEX IF NOT EXISTS timings_profile_order ON timings(profile,seq);
            """)
            if 'artifact_dir' not in {row[1] for row in db.execute('PRAGMA table_info(jobs)')}:
                db.execute('ALTER TABLE jobs ADD COLUMN artifact_dir TEXT')

    @contextlib.contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=15, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout=15000")
        try:
            yield db
        finally:
            db.close()

    def recover(self):
        with self.connection() as db:
            db.execute("UPDATE jobs SET status='failed', stage='interrupted', finished_at=?, error_json=? WHERE status='running'",
                       (time.time(), json.dumps({"code": "service_restarted", "message": "The server restarted during this job; resubmit with a new idempotency key."})))

    def get(self, job_id):
        with self.connection() as db:
            row = db.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        return dict(row) if row else None

    def idempotent(self, key):
        if not key:
            return None
        with self.connection() as db:
            row = db.execute("SELECT * FROM jobs WHERE idempotency_key=?", (key,)).fetchone()
        return dict(row) if row else None

    def enqueue(self, job_id, spec, fit, request_hash, key, estimate, maximum, artifact_dir=None):
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                if db.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0] >= maximum:
                    raise QueueFull("Generation queue is full; retry later")
                db.execute("""INSERT INTO jobs(job_id,spec_json,fit_json,request_hash,idempotency_key,status,
                           created_at,estimated_runtime_s,eta_source,calibration_samples,stage)
                           VALUES(?,?,?,?,?,'queued',?,?,?,?,'queued')""",
                           (job_id, json.dumps(spec), json.dumps(fit), request_hash, key, time.time(),
                            estimate["estimated_generation_time_s"], estimate["eta_source"], estimate["calibration_samples"]))
                db.execute('UPDATE jobs SET artifact_dir=? WHERE job_id=?',(artifact_dir,job_id))
                db.execute("COMMIT")
            except Exception:
                db.execute("ROLLBACK")
                raise

    def claim(self):
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY seq LIMIT 1").fetchone()
            if row:
                started_at = time.time()
                db.execute("UPDATE jobs SET status='running', stage='synthesizing', started_at=? WHERE job_id=?",
                           (started_at, row["job_id"]))
            db.execute("COMMIT")
        return {**dict(row), "status": "running", "stage": "synthesizing", "started_at": started_at} if row else None

    def update_stage(self, job_id, stage, chunks, eta=None):
        with self.connection() as db:
            if eta is None:
                db.execute("UPDATE jobs SET stage=?,completed_chunks=? WHERE job_id=?", (stage, chunks, job_id))
            else:
                db.execute("UPDATE jobs SET stage=?,completed_chunks=?,estimated_runtime_s=?,eta_source='current_job_chunk_timing' WHERE job_id=?",
                           (stage, chunks, eta, job_id))

    def finish(self, job_id, result=None, error=None):
        with self.connection() as db:
            status = "completed" if result is not None else "failed"
            db.execute("UPDATE jobs SET status=?,stage=?,finished_at=?,result_json=?,error_json=?,last_progress_percent=CASE WHEN ?='completed' THEN 100 ELSE last_progress_percent END WHERE job_id=?",
                       (status, status, time.time(), json.dumps(result) if result is not None else None,
                        json.dumps(error) if error else None, status, job_id))

    def history(self, profile):
        with self.connection() as db:
            return [dict(row) for row in db.execute("SELECT * FROM timings WHERE profile=? ORDER BY seq DESC LIMIT 64", (profile,))]

    def record_timing(self, profile, result):
        with self.connection() as db:
            db.execute("INSERT INTO timings(profile,natural_seconds,synthesis_seconds,encoding_seconds) VALUES(?,?,?,?)",
                       (profile, result["actual_natural_duration_s"], result["synthesis_seconds"], result["encoding_seconds"]))

    def outstanding(self):
        with self.connection() as db:
            return [dict(row) for row in db.execute("SELECT * FROM jobs WHERE status IN ('queued','running') ORDER BY seq")]

    def remember_progress(self, job_id, percent):
        with self.connection() as db:
            db.execute("UPDATE jobs SET last_progress_percent=MAX(last_progress_percent,?) WHERE job_id=?", (percent, job_id))


class SpeechService:
    def __init__(self, settings: Settings, engine_factory, *, start_worker=True):
        self.settings = settings
        settings.validate()
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.lease = RuntimeLease(settings.data_dir / "runtime.lock")
        try:
            self.engine = engine_factory(settings)
            self.store = JobStore(settings.data_dir)
            self.store.recover()
            self.job_root = settings.data_dir / "jobs"
            self.job_root.mkdir(exist_ok=True)
            self.stop_event, self.wake_event = threading.Event(), threading.Event()
            self.admission_lock = threading.RLock()
            self.job_changed = threading.Condition()
            device_profile = getattr(self.engine, "runtime_profile", settings.device)
            self.profile = f"{self.engine.signature}:{device_profile}:{settings.threads}"
            self.worker = threading.Thread(target=self._work, name="kokoro-generation-worker", daemon=True)
            if start_worker:
                self.worker.start()
        except Exception:
            self.lease.close()
            raise

    def timing_estimate(self, natural_seconds):
        history = self.store.history(self.profile)
        baseline = self.settings.cpu_rtf if self.settings.device == "cpu" else self.settings.gpu_rtf
        if history:
            rtf = statistics.median(row["synthesis_seconds"] / row["natural_seconds"] for row in history if row["natural_seconds"] > 0)
            encode = statistics.median(row["encoding_seconds"] for row in history)
            source = "calibrated_median_rtf"
        else:
            rtf, encode, source = baseline, self.settings.encode_overhead_s, "uncalibrated_default"
        return {"estimated_generation_time_s": max(.1, natural_seconds * rtf + encode),
                "estimated_encoding_time_s": max(.05, encode), "eta_source": source,
                "calibration_samples": len(history), "eta_is_guaranteed": False}

    def estimate(self, spec):
        started = time.perf_counter()
        plan = self.engine.plan(spec)
        fit = evaluate_fit(plan, spec)
        return plan, {**fit, **self.timing_estimate(plan.seconds),
                      "planning_time_s": time.perf_counter() - started,
                      "waveform_generated": False}

    def submit(self, spec: GenerationSpec, idempotency_key=None):
        serialized = spec.model_dump()
        request_hash = hashlib.sha256(json.dumps(serialized, sort_keys=True).encode()).hexdigest()
        with self.admission_lock:
            existing = self.store.idempotent(idempotency_key)
            if existing:
                if existing["request_hash"] != request_hash:
                    raise IdempotencyConflict("Idempotency-Key was already used with different specifications")
                return {**json.loads(existing["fit_json"]), "success": True,
                        "job_id": existing["job_id"], "idempotent_replay": True,
                        "progress_url": f"/progress?job_id={existing['job_id']}",
                        **self.progress(existing["job_id"])}
            plan, estimate = self.estimate(spec)
            if not estimate["success"]:
                return estimate
            job_id = uuid.uuid4().hex
            directory = new_artifact_dir(self.job_root, job_id)
            try:
                self.engine.save_plan(plan, directory / "plan.pt")
                (directory / "request.json").write_text(json.dumps(serialized, indent=2) + "\n", encoding="utf-8")
                self.store.enqueue(job_id, serialized, estimate, request_hash, idempotency_key,
                                   estimate, self.settings.max_pending_jobs, artifact_dir=str(directory))
            except Exception:
                for name in ("plan.pt", "plan.partial.pt", "request.json"):
                    (directory / name).unlink(missing_ok=True)
                directory.rmdir()
                raise
            self.wake_event.set()
            return {**estimate, "success": True, "job_id": job_id, "status": "queued",
                    "waveform_generated": False, "idempotent_replay": False,
                    "progress_url": f"/progress?job_id={job_id}"}

    def wait_until_terminal(self, job_id, *, timeout_s=1800.0, poll_s=0.05):
        """Block until the job reaches completed/failed, or raise TimeoutError."""
        deadline = time.monotonic() + timeout_s
        with self.job_changed:
            while time.monotonic() < deadline:
                job = self.store.get(job_id)
                if job is None:
                    raise RuntimeError(f"Job disappeared while waiting: {job_id}")
                if job["status"] in {"completed", "failed"}:
                    return self.progress(job_id)
                self.wake_event.set()
                self.job_changed.wait(timeout=min(30.0, max(0.0, deadline - time.monotonic())))
        raise TimeoutError(f"Timed out after {timeout_s:.0f}s waiting for job {job_id}")

    def progress(self, job_id):
        job = self.store.get(job_id)
        if job is None:
            return None
        now = time.time()
        status = job["status"]
        elapsed = max(0.0, (job["finished_at"] or now) - job["started_at"]) if job["started_at"] else 0.0
        estimated = job["estimated_runtime_s"]
        queue_wait, position = 0.0, 0
        if status == "queued":
            for other in self.store.outstanding():
                if other["job_id"] == job_id:
                    break
                position += 1
                spent = max(0.0, now - other["started_at"]) if other["started_at"] else 0
                queue_wait += max(0.0, other["estimated_runtime_s"] - spent)
        if status == "completed":
            percent, remaining = 100.0, 0.0
        elif status == "failed":
            percent, remaining = job["last_progress_percent"], 0.0
        elif status == "queued":
            percent, remaining = 0.0, queue_wait + estimated
        else:
            percent = max(job["last_progress_percent"], min(99.0, 100 * elapsed / estimated))
            remaining = max(0.0, estimated - elapsed)
            if percent > job["last_progress_percent"]:
                self.store.remember_progress(job_id, percent)
        fit = json.loads(job["fit_json"])
        result = json.loads(job["result_json"]) if job["result_json"] else None
        if result:
            result["audio_url"] = f"/progress?job_id={job_id}&download=true"
        return {"success": status != "failed", "job_id": job_id, "status": status, "stage": job["stage"],
                "progress_percent": round(percent, 3), "elapsed_generation_time_s": round(elapsed, 4),
                "time_remaining_s": round(remaining, 4), "estimated_queue_wait_s": round(queue_wait, 4),
                "queue_position": position, "estimated_generation_time_s": estimated,
                "eta_source": job["eta_source"], "eta_is_guaranteed": False,
                "eta_overrun": status == "running" and elapsed > estimated,
                "completed_chunks": job["completed_chunks"], "total_chunks": fit["chunk_count"],
                "estimated_final_duration_s": fit["estimated_final_duration_s"],
                "result": result, "error": json.loads(job["error_json"]) if job["error_json"] else None}

    def job_directory(self, job_id):
        row=self.store.get(job_id)
        return artifact_path(row['artifact_dir']) if row and row.get('artifact_dir') else self.job_root / job_id

    def _work(self):
        while not self.stop_event.is_set():
            job = self.store.claim()
            if not job:
                self.wake_event.wait(.5)
                self.wake_event.clear()
                continue
            job_id = job["job_id"]
            directory = self.job_directory(job_id)
            try:
                spec = GenerationSpec.model_validate_json(job["spec_json"])
                plan = self.engine.load_plan(directory / "plan.pt")
                encode_eta = self.timing_estimate(plan.seconds)["estimated_encoding_time_s"]
                started = time.perf_counter()
                completed_samples = [0]
                for chunk in plan.chunks:
                    completed_samples.append(completed_samples[-1] + chunk["native_samples"])

                def changed(stage, done, total):
                    if self.stop_event.is_set():
                        raise RuntimeError("Service is shutting down")
                    elapsed = time.perf_counter() - started
                    eta = None
                    if done:
                        completed_seconds = completed_samples[done] / 24000
                        ratio = elapsed / completed_seconds
                        eta = elapsed + max(0, plan.seconds - completed_seconds) * ratio + encode_eta
                        if not math.isfinite(eta) or eta <= 0:
                            raise RuntimeError("Invalid runtime estimate")
                    self.store.update_stage(job_id, stage, done, eta)

                result = self.engine.generate(plan, spec, directory / "speech.mp3", changed)
                result["generation_wall_time_s"] = time.perf_counter() - started
                self.store.record_timing(self.profile, result)
                (directory / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
                with self.job_changed:
                    self.store.finish(job_id, result=result)
                    self.job_changed.notify_all()
                LOGGER.info("Job %s completed in %.3fs", job_id, result["generation_wall_time_s"])
            except Exception as error:
                LOGGER.exception("Job %s failed", job_id)
                with self.job_changed:
                    self.store.finish(job_id, error={"code": "generation_failed", "message": str(error)})
                    self.job_changed.notify_all()

    def close(self):
        self.stop_event.set()
        self.wake_event.set()
        if self.worker.is_alive():
            self.worker.join(timeout=30)
        if not self.worker.is_alive():
            self.lease.close()
