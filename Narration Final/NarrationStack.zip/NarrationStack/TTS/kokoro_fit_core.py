"""Duration-fit engine derived from the supplied Kokoro CLI and helpers.

Planning never calls F0/noise prediction, the acoustic decoder, or FFmpeg.
Generation reuses the actual cached integer durations and duration embeddings.
FFmpeg atempo/MP3 length remains a target estimate, not a sample-exact guarantee.
"""

from __future__ import annotations

import hashlib
import inspect
import json
import math
import subprocess
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from contracts import GenerationSpec, Settings

NATIVE_RATE = 24000
SAMPLES_PER_DURATION_UNIT = 600
SOURCE_REVISION = "dfb907a02bba8152ca444717ca5d78747ccb4bec"
MODEL_REVISION = "f3ff3571791e39611d31c381e3a41a3af07b4987"


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_atempo_filter(factor: float) -> str:
    if not math.isfinite(factor) or factor <= 0:
        raise ValueError("atempo factor must be positive and finite")
    parts = []
    while factor > 2:
        parts.append("atempo=2")
        factor /= 2
    while factor < .5:
        parts.append("atempo=0.5")
        factor /= .5
    parts.append(f"atempo={factor:.12g}")
    return ",".join(parts)


@dataclass
class SpeechPlan:
    engine_signature: str
    natural_samples: int
    chunks: list[dict[str, Any]]

    @property
    def seconds(self):
        return self.natural_samples / NATIVE_RATE


def evaluate_fit(plan: SpeechPlan, spec: GenerationSpec) -> dict:
    factor = plan.seconds / spec.desired_duration
    reason = "too_short" if factor < spec.atempo_min else "too_long" if factor > spec.atempo_max else None
    return {
        "success": reason is None, "reason": reason,
        "duration_s": spec.desired_duration if reason is None else plan.seconds,
        "duration_kind": "fitted_target" if reason is None else "natural_unatempoed",
        "estimated_natural_duration_s": plan.seconds,
        "natural_samples": plan.natural_samples, "natural_sample_rate": NATIVE_RATE,
        "desired_duration_s": spec.desired_duration,
        "estimated_final_duration_s": plan.seconds / factor,
        "atempo_factor": factor, "atempo_min": spec.atempo_min, "atempo_max": spec.atempo_max,
        "chunk_count": len(plan.chunks),
        "natural_duration_is_sample_exact": True,
        "final_duration_is_sample_exact": False,
        "duration_estimate_kind": "Kokoro frozen natural duration; FFmpeg tempo-ratio target for final MP3",
    }


def encode_mp3(audio, spec: GenerationSpec, factor: float, destination: Path, timeout: float) -> dict:
    import numpy as np

    wave = np.asarray(audio, dtype=np.float32).reshape(-1)
    if not wave.size or not np.isfinite(wave).all():
        raise RuntimeError("Cannot encode empty/nonfinite audio")
    peak = float(np.max(np.abs(wave)))
    gain = min(1.0, .98 / peak) if peak else 1.0
    # Preserve the caller's waveform; allocate a scale copy only if protection is needed.
    if gain != 1.0:
        wave = wave * gain
    temporary = destination.with_name(destination.stem + ".partial.mp3")
    command = ["ffmpeg", "-nostdin", "-y", "-hide_banner", "-loglevel", "error",
               "-f", "f32le", "-ar", str(NATIVE_RATE), "-ac", "1", "-i", "pipe:0",
               "-af", build_atempo_filter(factor), "-ar", str(spec.sample_rate), "-ac", "1",
               "-c:a", "libmp3lame", "-b:a", f"{spec.bitrate_kbps}k", str(temporary)]
    try:
        completed = subprocess.run(command, input=wave.tobytes(), capture_output=True, timeout=timeout)
        if completed.returncode:
            raise RuntimeError("FFmpeg failed: " + completed.stderr.decode("utf-8", "replace")[-2000:])
        probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                "-of", "default=nw=1:nk=1", str(temporary)],
                               capture_output=True, text=True, check=True, timeout=30)
        duration = float(probe.stdout.strip())
        if not math.isfinite(duration) or duration <= 0:
            raise RuntimeError("ffprobe returned an invalid MP3 duration")
        temporary.replace(destination)
        return {"actual_final_duration_s": duration,
                "duration_error_percent": 100 * abs(duration - spec.desired_duration) / spec.desired_duration,
                "duration_measurement": "ffprobe format duration; includes MP3 container/encoder timing",
                "peak_before_protection": peak, "amplitude_gain": gain,
                "atempo_filter": build_atempo_filter(factor), "file_size_bytes": destination.stat().st_size}
    finally:
        temporary.unlink(missing_ok=True)


class KokoroEngine:
    def __init__(self, settings: Settings):
        import numpy as np
        import torch
        from kokoro import KModel, KPipeline
        import spacy
        import espeakng_loader
        from phonemizer.backend.espeak.wrapper import EspeakWrapper

        if not spacy.util.is_package("en_core_web_sm"):
            raise RuntimeError("English spaCy model missing; run install_ubuntu.sh before serving")
        EspeakWrapper.set_library(espeakng_loader.get_library_path())
        EspeakWrapper.set_data_path(espeakng_loader.get_data_path())

        self.settings, self.torch, self.np = settings, torch, np
        self.lock = threading.RLock()
        self.cache: OrderedDict[str, SpeechPlan] = OrderedDict()
        self.pack_cache = {}
        self.file_digests = {}
        self.cache_bytes = 0
        self.device = torch.device(settings.device)
        torch.set_num_threads(settings.threads)
        if self.device.type == "cuda":
            if not torch.cuda.is_available():
                raise RuntimeError("CUDA unavailable: use an NVIDIA GPU host with GPU-enabled Docker. No CPU fallback.")
            torch.cuda.set_device(self.device)
            total = torch.cuda.get_device_properties(self.device).total_memory
            allocator = min(total, int(settings.max_vram_gb * 1e9)) - settings.cuda_reserve_mb * 1_000_000
            if allocator <= 0:
                raise RuntimeError("CUDA reserve leaves no allocator budget")
            torch.cuda.set_per_process_memory_fraction(allocator / total, self.device)
            torch.cuda.reset_peak_memory_stats(self.device)
        config_path = settings.model_dir / "config.json"
        checkpoint = settings.model_dir / settings.checkpoint_name
        config_path = settings.model_dir / settings.config_name
        config = json.loads(config_path.read_text(encoding="utf-8"))
        decoder = config.get("istftnet", {})
        if (decoder.get("upsample_rates"), decoder.get("upsample_kernel_sizes"),
            decoder.get("gen_istft_hop_size"), decoder.get("gen_istft_n_fft")) != ([10, 6], [20, 12], 5, 20):
            raise RuntimeError("Model configuration does not satisfy the 600-sample duration contract")
        source_hash = file_hash(Path(inspect.getfile(KModel)))
        checkpoint_hash = file_hash(checkpoint)
        if settings.model_sha256 and checkpoint_hash != settings.model_sha256.lower():
            raise RuntimeError("Checkpoint SHA256 does not match --model-sha256")
        self.signature = hashlib.sha256((SOURCE_REVISION + source_hash + checkpoint_hash
                                        + file_hash(config_path) + file_hash(Path(__file__))
                                        + str(settings.max_chunk_seconds)).encode()).hexdigest()
        hardware = torch.cuda.get_device_name(self.device) if self.device.type == "cuda" else "cpu"
        self.runtime_profile = f"{hardware}:{torch.__version__}:{self.device}"
        self.model = KModel(repo_id=settings.model_repo, config=config, model=str(checkpoint)).to(self.device).eval()
        self.pipelines = {code: KPipeline(lang_code=code, repo_id=settings.model_repo, model=False) for code in ("a", "b")}
        self.voices = sorted(path.stem for path in (settings.model_dir / "voices").glob("[ab][fm]_*.pt"))
        if not self.voices:
            raise RuntimeError("No installed English voice packs found")
        self.memory_snapshot()

    def voice_hash(self, path: Path) -> str:
        """Avoid rehashing unchanged packs; file replacement/modification invalidates the cache."""
        def fingerprint():
            st = path.stat()
            return st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns
        with self.lock:
            before = fingerprint()
            cached = self.file_digests.get(path)
            if cached is not None and cached[0] == before:
                return cached[1]
            digest = file_hash(path)
            if fingerprint() != before:
                raise RuntimeError("Voice file changed during hashing; retry after publishing it atomically")
            self.file_digests[path] = before, digest
            return digest

    def memory_snapshot(self) -> dict:
        if self.device.type == "cpu":
            return {"device": "cpu", "gpu_vram_bytes": 0}
        allocated = self.torch.cuda.max_memory_allocated(self.device)
        reserved = self.torch.cuda.max_memory_reserved(self.device)
        if max(allocated, reserved) > self.settings.max_vram_gb * 1e9:
            raise RuntimeError("PyTorch measured allocator peak exceeded configured VRAM target")
        return {"device": str(self.device), "peak_torch_allocated_bytes_since_start": allocated,
                "peak_torch_reserved_bytes_since_start": reserved,
                "max_vram_gb": self.settings.max_vram_gb,
                "instantaneous_whole_process_peak_certified": False}

    @staticmethod
    def plan_bytes(plan: SpeechPlan) -> int:
        return sum(t.numel() * t.element_size() for c in plan.chunks
                   for t in (c["ids"], c["durations"], c["embedding"], c["style"]))

    def remember_plan(self, key: str, plan: SpeechPlan):
        old = self.cache.pop(key, None)
        if old is not None:
            self.cache_bytes -= self.plan_bytes(old)
        self.cache[key] = plan
        self.cache_bytes += self.plan_bytes(plan)
        while len(self.cache) > self.settings.plan_cache_size or self.cache_bytes > self.settings.plan_cache_mb * 1024**2:
            _, evicted = self.cache.popitem(last=False)
            self.cache_bytes -= self.plan_bytes(evicted)

    def plan(self, spec: GenerationSpec) -> SpeechPlan:
        torch = self.torch
        if spec.voice not in self.voices:
            raise ValueError(f"Unknown installed voice {spec.voice!r}; available: {', '.join(self.voices)}")
        voice_path = self.settings.model_dir / "voices" / f"{spec.voice}.pt"
        key = hashlib.sha256(json.dumps({"text": spec.text, "voice": spec.voice, "voice_sha": self.voice_hash(voice_path),
                                        "speed": spec.speed, "lang": spec.lang_code,
                                        "split": spec.split_pattern, "engine": self.signature}, sort_keys=True).encode()).hexdigest()
        # Hold the cache lock during phonemization/planning. Generation yields
        # this same lock between chunks; no two model forwards overlap on the GPU.
        with self.lock, torch.inference_mode():
            if key in self.cache:
                self.cache.move_to_end(key)
                return self.cache[key]
            voice_hash = self.voice_hash(voice_path)
            if spec.voice not in self.pack_cache or self.pack_cache[spec.voice][0] != voice_hash:
                pack = torch.load(voice_path, map_location="cpu", weights_only=True)
                if not isinstance(pack, torch.Tensor) or pack.ndim != 3 or pack.shape[1:] != (1, 256) or not torch.isfinite(pack).all():
                    raise ValueError("Invalid Kokoro voice embedding")
                self.pack_cache[spec.voice] = (voice_hash, pack)
            pack = self.pack_cache[spec.voice][1]
            quiet = self.pipelines[spec.lang_code]
            chunks = []

            def plan_text(text: str):
                for result in quiet(text, voice=None, split_pattern=spec.split_pattern):
                    ps = result.phonemes
                    if not ps:
                        if any(character.isalnum() for character in result.graphemes):
                            raise ValueError("Frontend produced no phonemes for spoken text")
                        continue
                    unknown = {p for p in ps if p not in self.model.vocab and not p.isspace()}
                    if unknown:
                        raise ValueError(f"Unsupported pronunciation symbols: {sorted(unknown)}")
                    ids = [self.model.vocab[p] for p in ps if p in self.model.vocab]
                    if len(ids) + 2 > self.model.context_length or len(ps) > len(pack):
                        raise ValueError("Phoneme/voice context exceeded; refusing silent truncation")
                    tokens = torch.tensor([[0, *ids, 0]], device=self.device, dtype=torch.long)
                    lengths = torch.tensor([tokens.shape[1]], device=self.device)
                    mask = torch.zeros_like(tokens, dtype=torch.bool)
                    ref = pack[len(ps) - 1].to(self.device)
                    bert = self.model.bert(tokens, attention_mask=(~mask).int())
                    encoded = self.model.bert_encoder(bert).transpose(-1, -2)
                    d = self.model.predictor.text_encoder(encoded, ref[:, 128:], lengths, mask)
                    logits, _ = self.model.predictor.lstm(d)
                    durations = torch.round(torch.sigmoid(self.model.predictor.duration_proj(logits)).sum(-1) / spec.speed).clamp_min(1).long().reshape(-1)
                    count = int(durations.sum().item()) * SAMPLES_PER_DURATION_UNIT
                    if count / NATIVE_RATE > self.settings.max_chunk_seconds:
                        words = result.graphemes.split()
                        if len(words) < 2:
                            raise ValueError("One token exceeds the chunk duration limit; adjust speed/text")
                        middle = len(words) // 2
                        plan_text(" ".join(words[:middle]))
                        plan_text(" ".join(words[middle:]))
                        continue
                    chunks.append({"text": result.graphemes, "phonemes": ps, "ids": tokens.cpu(),
                                   "durations": durations.cpu(), "embedding": d.cpu(), "style": ref.cpu(),
                                   "native_samples": count})

            plan_text(spec.text)
            if not chunks:
                raise ValueError("No phoneme content was found")
            self.memory_snapshot()
            plan = SpeechPlan(self.signature, sum(chunk["native_samples"] for chunk in chunks), chunks)
            self.remember_plan(key, plan)
            return plan

    def save_plan(self, plan: SpeechPlan, path: Path):
        temporary = path.with_suffix(".partial.pt")
        self.torch.save({"engine_signature": plan.engine_signature, "natural_samples": plan.natural_samples,
                         "chunks": plan.chunks}, temporary)
        temporary.replace(path)

    def load_plan(self, path: Path) -> SpeechPlan:
        value = self.torch.load(path, map_location="cpu", weights_only=True)
        if value["engine_signature"] != self.signature:
            raise RuntimeError("Queued plan belongs to different model/source weights")
        return SpeechPlan(**value)

    def generate(self, plan: SpeechPlan, spec: GenerationSpec, destination: Path,
                 progress: Callable[[str, int, int], None]) -> dict:
        if plan.engine_signature != self.signature:
            raise RuntimeError("Model signature changed since planning")
        torch, np = self.torch, self.np
        start = time.perf_counter()
        # One final CPU buffer rather than all chunks plus a concatenate copy.
        audio = np.empty(plan.natural_samples, dtype=np.float32)
        offset = 0
        for index, chunk in enumerate(plan.chunks):
            progress("synthesizing", index, len(plan.chunks))
            with self.lock, torch.inference_mode():
                torch.manual_seed((spec.seed + index * 1000003) % 2**32)
                tokens, durations = chunk["ids"].to(self.device), chunk["durations"].to(self.device)
                d, ref = chunk["embedding"].to(self.device), chunk["style"].to(self.device)
                # repeat_interleave is the exact length-regulator alignment;
                # it avoids allocating a quadratic one-hot matrix.
                duration_units = chunk["native_samples"] // SAMPLES_PER_DURATION_UNIT
                expanded = torch.repeat_interleave(d.transpose(-1, -2), durations, dim=2,
                                                  output_size=duration_units)
                f0, noise = self.model.predictor.F0Ntrain(expanded, ref[:, 128:])
                lengths = torch.tensor([tokens.shape[1]], device=self.device)
                mask = torch.zeros_like(tokens, dtype=torch.bool)
                acoustic = torch.repeat_interleave(self.model.text_encoder(tokens, lengths, mask), durations, dim=2,
                                                  output_size=duration_units)
                wave = self.model.decoder(acoustic, f0, noise, ref[:, :128]).reshape(-1).cpu().numpy()
                if len(wave) != chunk["native_samples"] or not np.isfinite(wave).all():
                    raise RuntimeError("Kokoro waveform violated its frozen duration plan")
                self.memory_snapshot()
            audio[offset:offset + len(wave)] = wave
            offset += len(wave)
            del wave, expanded, f0, noise, acoustic, tokens, durations, d, ref
            progress("synthesizing", index + 1, len(plan.chunks))
        if offset != plan.natural_samples:
            raise RuntimeError("Natural waveform length differs from the admission preview")
        synthesis_seconds = time.perf_counter() - start
        fit = evaluate_fit(plan, spec)
        if not fit["success"]:
            raise RuntimeError("Saved plan no longer satisfies the atempo range")
        progress("encoding", len(plan.chunks), len(plan.chunks))
        encode_start = time.perf_counter()
        encoded = encode_mp3(audio, spec, fit["atempo_factor"], destination, self.settings.ffmpeg_timeout_s)
        return {**fit, **encoded, "actual_natural_duration_s": len(audio) / NATIVE_RATE,
                "natural_duration_error_percent": 0.0, "synthesis_seconds": synthesis_seconds,
                "encoding_seconds": time.perf_counter() - encode_start,
                "memory": self.memory_snapshot()}
