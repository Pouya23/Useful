"""Write the offline build-tool subset and install pinned static FFmpeg tools."""
import argparse
import json
import tarfile
from pathlib import Path
from download_packages import download


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("download_dir",type=Path)
    args=parser.parse_args()
    root=args.download_dir.resolve()
    wheels=root/'wheels'
    manifest=json.loads((wheels/'manifest.json').read_text(encoding='utf-8'))
    build={'pip','setuptools','wheel','hatchling','packaging','pathspec','trove-classifiers'}
    (wheels/'build-tools.txt').write_text(''.join(
        f"{(wheels/p['filename']).as_uri()} --hash=sha256:{p['sha256']}\n" for p in manifest if p['name'] in build),encoding='utf-8')
    frozen=json.loads((Path(__file__).parent/'native-artifacts.json').read_text())
    artifact=root/frozen['filename']
    download(frozen['url'],artifact,frozen['sha256'])
    destination=root/'tools'
    destination.mkdir(exist_ok=True)
    tools=destination/'ffmpeg-7.0.2-amd64-static'
    stamp=tools/'.verified-archive-sha256'
    valid=stamp.is_file() and stamp.read_text().strip()==frozen['sha256'] and (tools/'ffmpeg').is_file() and (tools/'ffprobe').is_file()
    if not valid:
        with tarfile.open(artifact,'r:xz') as archive:
            archive.extractall(destination,filter='data')
        stamp.write_text(frozen['sha256']+'\n')
    if not (tools/'ffmpeg').is_file() or not (tools/'ffprobe').is_file():
        raise RuntimeError('Unexpected FFmpeg archive layout')
    print(tools)


if __name__=='__main__':
    main()
