"""Production entry point: one Flask/Waitress process and one GPU worker."""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path
import sys
import signal

from waitress import serve

from app import create_app
from jobs import SpeechService
from kokoro_fit_core import KokoroEngine
from cli import parse_settings


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    args, settings = parse_settings()
    for tool in ("ffmpeg", "ffprobe"):
        if not shutil.which(tool):
            raise RuntimeError(f"{tool} is required on PATH")
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "containers"))
    from gpu_gate import GpuGate, CombinedLock
    gate = GpuGate(enabled=settings.device != "cpu")
    def guarded_factory(config):
        with gate:
            engine = KokoroEngine(config)
        engine.lock = CombinedLock(engine.lock, gate)
        return engine
    service = SpeechService(settings, guarded_factory)
    def shutdown(*_):
        service.stop_event.set()
        service.wake_event.set()
        raise SystemExit(0)
    signal.signal(signal.SIGTERM, shutdown)
    try:
        app = create_app(service)
        host, port = args.host, args.port
        logging.info("Ready on %s:%s; device=%s; Swagger=/docs/", host, port, settings.device)
        serve(app, host=host, port=port, threads=args.http_threads, channel_timeout=600,
              max_request_body_size=256 * 1024)
    finally:
        service.close()


if __name__ == "__main__":
    main()
