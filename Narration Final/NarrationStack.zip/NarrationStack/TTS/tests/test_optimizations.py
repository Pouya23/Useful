import threading
import time
from pathlib import Path
from collections import OrderedDict
from types import SimpleNamespace
from kokoro_fit_core import SpeechPlan

import pytest

from contracts import GenerationSpec, Settings
from kokoro_fit_core import KokoroEngine, file_hash
from cli import parse_settings


def test_voice_hash_reuses_digest_and_invalidates_on_change(tmp_path, monkeypatch):
    path=tmp_path/'voice.pt'; path.write_bytes(b'original')
    engine=KokoroEngine.__new__(KokoroEngine)
    engine.lock=threading.RLock(); engine.file_digests={}
    calls=[]
    def count(path):
        calls.append(path)
        return file_hash(path)
    monkeypatch.setattr('kokoro_fit_core.file_hash',count)
    first=engine.voice_hash(path)
    assert engine.voice_hash(path)==first and len(calls)==1
    path.write_bytes(b'changed longer')
    assert engine.voice_hash(path)!=first and len(calls)==2


def test_main_cli_model_selection(tmp_path):
    _, settings=parse_settings(['--model-dir',str(tmp_path),'--checkpoint','custom.pth',
        '--model-repo','someone/compatible-kokoro','--config','variant.json','--device','cpu',
        '--plan-cache-mb','32'])
    assert settings.checkpoint_name=='custom.pth'
    assert settings.config_name=='variant.json'
    assert settings.model_repo=='someone/compatible-kokoro'
    assert settings.plan_cache_mb==32


def test_validation_message_matches_real_word_limit():
    with pytest.raises(ValueError,match='10–1000'):
        GenerationSpec(text='one two',desired_duration=10.0)
    assert len(GenerationSpec(text='word '*1000,desired_duration=10.0).text.split())==1000


@pytest.mark.parametrize('limit',[float('nan'),float('inf'),-1])
def test_bad_cache_budget_rejected(tmp_path,limit):
    with pytest.raises(ValueError):
        Settings(tmp_path,tmp_path,plan_cache_mb=limit).validate()


def test_plan_cache_disabled_is_valid(tmp_path):
    Settings(tmp_path,tmp_path,plan_cache_mb=0).validate()


def test_byte_budget_evicts_lru_without_changing_plan():
    tensor=SimpleNamespace(numel=lambda: 100,element_size=lambda:4)
    plan=SpeechPlan('test',1200,[dict(ids=tensor,durations=tensor,embedding=tensor,style=tensor)])
    engine=KokoroEngine.__new__(KokoroEngine)
    engine.cache=OrderedDict(); engine.cache_bytes=0
    engine.settings=SimpleNamespace(plan_cache_size=16,plan_cache_mb=2000/1024**2)
    engine.remember_plan('first',plan)
    engine.remember_plan('second',plan)
    assert list(engine.cache)==['second'] and engine.cache_bytes==1600
    assert engine.cache['second'] is plan
    engine.settings.plan_cache_mb=0
    engine.remember_plan('third',plan)
    assert not engine.cache and engine.cache_bytes==0
