"""Exercise the real generation assembly/control path with deterministic tiny tensor fixtures."""
from contextlib import nullcontext
from types import SimpleNamespace
import threading

from contracts import GenerationSpec
from kokoro_fit_core import KokoroEngine, SpeechPlan


class Tensor:
    shape=(1,2)
    def __init__(self, values=None): self.values=values
    def to(self,*_): return self
    def transpose(self,*_): return self
    def reshape(self,*_): return self
    def cpu(self): return self
    def numpy(self): return self.values
    def __getitem__(self,_): return self


def test_preallocated_audio_preserves_samples_seed_and_fit(monkeypatch,tmp_path):
    seeds=[]; audio_outputs=iter([[.1]*600,[.2]*1200])
    torch=SimpleNamespace(inference_mode=nullcontext,manual_seed=seeds.append,
        repeat_interleave=lambda *a,**k:Tensor(),tensor=lambda *a,**k:Tensor(),
        zeros_like=lambda *a,**k:Tensor(),bool=bool)
    np=SimpleNamespace(float32='float32',empty=lambda size,**k:[0.0]*size,
        isfinite=lambda _:SimpleNamespace(all=lambda:True))
    model=SimpleNamespace(predictor=SimpleNamespace(F0Ntrain=lambda *a:(Tensor(),Tensor())),
        text_encoder=lambda *a:Tensor(),decoder=lambda *a:Tensor(next(audio_outputs)))
    engine=KokoroEngine.__new__(KokoroEngine)
    engine.torch=torch; engine.np=np; engine.device='cpu'; engine.model=model
    engine.lock=threading.RLock(); engine.signature='fixture'
    engine.settings=SimpleNamespace(ffmpeg_timeout_s=30)
    engine.memory_snapshot=lambda: {}
    chunks=[dict(ids=Tensor(),durations=Tensor(),embedding=Tensor(),style=Tensor(),native_samples=n) for n in (600,1200)]
    plan=SpeechPlan('fixture',1800,chunks)
    spec=GenerationSpec(text='word '*10,desired_duration=1800/24000,atempo_min=1.0,atempo_max=1.0)
    encoded=[]
    def encode(audio,*args):
        encoded.append(list(audio)); return {'actual_final_duration_s':1800/24000}
    monkeypatch.setattr('kokoro_fit_core.encode_mp3',encode)
    progress=[]
    result=engine.generate(plan,spec,tmp_path/'speech.mp3',lambda *a:progress.append(a))
    assert encoded==[[.1]*600+[.2]*1200]
    assert seeds==[42,1000045]
    assert result['actual_natural_duration_s']==1800/24000
    assert result['natural_duration_error_percent']==0
    assert progress[-1]==('encoding',2,2)
