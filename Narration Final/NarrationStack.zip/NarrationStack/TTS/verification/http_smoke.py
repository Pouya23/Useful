"""Exercise the actual Waitress startup and HTTP API on loopback, then stop it."""

import argparse
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import requests


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    env = os.environ.copy()
    env.update(MODEL_DIR=str(args.model_dir.resolve()), DATA_DIR=str((args.output_dir / "data").resolve()),
               DOWNLOAD_MODELS="0", TTS_DEVICE="cpu", HTTP_HOST="127.0.0.1", HTTP_PORT=str(port), API_KEY="")
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    session = requests.Session()
    session.trust_env = False
    with (args.output_dir / "waitress.log").open("w", encoding="utf-8") as log:
        process = subprocess.Popen([sys.executable, str(root / "run_server.py")], cwd=root, env=env,
                                   stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
        try:
            base = f"http://127.0.0.1:{port}"
            deadline = time.monotonic() + 120
            while True:
                if process.poll() is not None:
                    raise RuntimeError("Server failed to start; inspect waitress.log")
                try:
                    ready = session.get(base + "/health", timeout=2)
                    if ready.status_code == 200:
                        break
                except requests.RequestException:
                    pass
                if time.monotonic() >= deadline:
                    raise TimeoutError("Waitress startup timed out")
                time.sleep(.25)
            assert ready.json()["device"] == "cpu"
            assert session.get(base + "/docs/", timeout=5).status_code == 200
            schema = session.get(base + "/openapi.json", timeout=5)
            assert schema.status_code == 200 and len(schema.json()["paths"]) == 3
            body = json.loads((root / "examples" / "estimate.json").read_text())
            estimate = session.post(base + "/duration", json=body, timeout=30)
            assert estimate.status_code == 200, estimate.text
            generation = session.post(base + "/generate", json={**body, "generate": True}, timeout=30)
            assert generation.status_code == 202, generation.text
            job_id = generation.json()["job_id"]
            deadline = time.monotonic() + 120
            while True:
                response = session.get(base + "/progress", params={"job_id": job_id}, timeout=10)
                assert response.status_code == 200
                result = response.json()
                if result["status"] in {"completed", "failed"}:
                    break
                if time.monotonic() >= deadline:
                    raise TimeoutError("HTTP generation timed out")
                time.sleep(.2)
            assert result["status"] == "completed", result
            audio = session.get(base + result["result"]["audio_url"], timeout=10)
            assert audio.status_code == 200 and audio.headers["Content-Type"].startswith("audio/mpeg")
            (args.output_dir / "http_am_onyx_sample.mp3").write_bytes(audio.content)
            report = {"http_server": "Waitress", "device": "cpu", "container_started": False,
                      "health": ready.json(), "swagger_http_status": 200, "openapi_http_status": 200,
                      "estimate": estimate.json(), "generation_admission": generation.json(),
                      "completed_progress": result, "download_bytes": len(audio.content)}
            (args.output_dir / "http_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
            print(json.dumps({"result": "passed", "device": "cpu", "host": "loopback", "port_was_temporary": True}))
        finally:
            process.terminate()
            try:
                process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
            session.close()


if __name__ == "__main__":
    main()
