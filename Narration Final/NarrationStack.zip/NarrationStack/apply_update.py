"""Copy only changed delivery files, backing up originals and preserving runtime data."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda:stream.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()


def apply(source,destination,backup=None,dry_run=False):
    source,destination=Path(source).resolve(),Path(destination).resolve()
    if source==destination:raise ValueError('Extract the new bundle into a separate staging directory first')
    manifest=json.loads((source/'DELIVERY_SHA256.json').read_text(encoding='utf-8'))
    backup=Path(backup).resolve() if backup else destination/'_update-backups'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    actions=[]
    # Validate the entire input before making changes.
    for name,expected in manifest.items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts or relative.parts[0] in {'state','data','downloads','models','_update-backups'} or name=='.env':
            raise ValueError(f'Unsafe/protected delivery path: {name}')
        src=(source/relative).resolve();target=(destination/relative).resolve()
        if not src.is_relative_to(source) or not target.is_relative_to(destination):raise ValueError(f'Path escapes bundle: {name}')
        if digest(src)!=expected:raise ValueError(f'Delivery checksum mismatch: {name}')
        if target.exists() and not target.is_file():raise ValueError(f'File conflicts with directory: {name}')
        if not target.exists() or digest(target)!=expected:actions.append((relative,src,target,target.exists()))
    for relative,src,target,existed in actions:
        print(('REPLACE ' if existed else 'ADD ')+relative.as_posix())
        if dry_run:continue
        if existed:
            saved=backup/relative;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,saved)
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
    if not dry_run:
        destination.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source/'DELIVERY_SHA256.json',destination/'DELIVERY_SHA256.json')
    print(f'{len(actions)} files require changes; other source files and runtime data are retained.')
    if any(a[3] for a in actions):print(f'Original-file backup: {backup}')
    return actions


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=Path(__file__).parent)
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--backup-dir',type=Path)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    apply(args.source,args.destination,args.backup_dir,args.dry_run)
