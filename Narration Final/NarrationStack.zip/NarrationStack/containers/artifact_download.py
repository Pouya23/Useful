"""Curl 7.68-compatible retries, verified cache reuse and safe partial recovery."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import uuid
import shutil

TRANSIENT = {5, 6, 7, 18, 28, 35, 52, 55, 56}


def curl_options():
    args = ["curl", "--fail", "--location", "--connect-timeout", "60"]
    if os.getenv("DOWNLOAD_PROXY"):
        args += ["--proxy", os.environ["DOWNLOAD_PROXY"]]
    if os.getenv("CURL_CA_BUNDLE"):
        args += ["--cacert", os.environ["CURL_CA_BUNDLE"]]
    if os.getenv("CURL_INSECURE") == "1":
        args += ["--insecure"]
    return args


def sha256(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def quarantine(path):
    if path.exists():
        path.replace(path.with_name(path.name + ".invalid-" + uuid.uuid4().hex[:8]))


def attempts():
    count = int(os.getenv("DOWNLOAD_RETRIES", "10"))
    delay = float(os.getenv("DOWNLOAD_RETRY_DELAY", "3"))
    if count < 1 or delay < 0:
        raise ValueError("Use DOWNLOAD_RETRIES>=1 and DOWNLOAD_RETRY_DELAY>=0")
    return count, delay


def curl_json(url):
    count, delay = attempts()
    for index in range(count):
        result = subprocess.run(curl_options() + ["--silent", "--show-error", url],
                                stdout=subprocess.PIPE, text=True)
        if result.returncode == 0:
            return json.loads(result.stdout)
        if result.returncode not in TRANSIENT or index + 1 == count:
            raise RuntimeError(f"Metadata curl failed with exit {result.returncode}: {url}")
        time.sleep(delay)


def download(url, destination, checksum=None):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    part = destination.with_name(destination.name + ".part")
    if destination.is_file():
        if checksum is None or sha256(destination) == checksum:
            print(f"Reuse verified/cache file: {destination.name}", flush=True)
            return
        quarantine(destination)
    if part.is_file() and checksum and sha256(part) == checksum:
        part.replace(destination)
        print(f"Recovered complete .part: {destination.name}", flush=True)
        return
    if checksum:
        for directory in os.getenv("NARRATION_DOWNLOAD_CACHE_DIRS", "").split(os.pathsep):
            if not directory:
                continue
            cache = Path(directory) / destination.name
            cached_part = cache.with_name(cache.name + ".part")
            for candidate in (cache, cached_part):
                if candidate.resolve() not in {destination.resolve(), part.resolve()} and candidate.is_file() and sha256(candidate) == checksum:
                    try:
                        os.link(candidate, destination)
                    except OSError:
                        shutil.copy2(candidate, destination)
                    print(f"Reuse cached artifact: {destination.name}", flush=True)
                    return
            if not part.exists() and cached_part.is_file() and cached_part.resolve() != part.resolve():
                shutil.copy2(cached_part, part)
                print(f"Reuse cached partial: {destination.name}", flush=True)
                break
    count, delay = attempts()
    for index in range(count):
        result = subprocess.run(curl_options() + ["--silent", "--show-error", "--continue-at", "-",
            "--output", str(part), "--write-out", "%{http_code}", url], stdout=subprocess.PIPE, text=True)
        status = (result.stdout or "").strip()[-3:]
        # A transfer can finish just before an interrupted connection is reported.
        if part.is_file() and checksum and sha256(part) == checksum:
            part.replace(destination)
            return
        if result.returncode == 0:
            if checksum is None:
                part.replace(destination)
                return
            quarantine(part)
            recoverable = True
        elif result.returncode == 33 or status == "416":
            # Range unsupported/out of bounds: keep the failed file for inspection,
            # then restart only this artifact. Never reset a partial on arbitrary 4xx.
            quarantine(part)
            recoverable = True
        else:
            recoverable = result.returncode in TRANSIENT or status in {"408", "429", "500", "502", "503", "504"}
        if not recoverable or index + 1 == count:
            raise RuntimeError(f"Download not complete: {destination.name}; curl={result.returncode}, HTTP={status}. "
                               "Verified files and resumable .part data were retained; rerun setup.")
        print(f"Retry {index + 2}/{count}: {destination.name} (curl={result.returncode}, HTTP={status})", flush=True)
        time.sleep(delay)
