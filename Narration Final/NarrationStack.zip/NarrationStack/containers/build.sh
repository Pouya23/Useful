#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
[[ -f .env ]] || { echo 'Copy .env.example to .env and configure it first.' >&2; exit 2; }
set -a
source .env
set +a
mkdir -p "$STATE_DIR/llm" "$STATE_DIR/tts" "$STATE_DIR/inputs" "$STATE_DIR/gpu-locks" "$DOWNLOAD_DIR/provenance"
sudo chown -R 10001:10001 "$STATE_DIR/llm" "$STATE_DIR/tts" "$STATE_DIR/gpu-locks"
chmod 755 "$STATE_DIR/inputs"
docker compose config --quiet
docker compose build
docker image inspect narration-llm:1.0.0 narration-tts:1.0.0 > "$DOWNLOAD_DIR/provenance/images.json"
echo 'Images built. Nothing was started. Follow DEPLOYMENT.md to start them when ready.'
