"""Check the selected GPU/driver and optionally execute small Torch CUDA probes.

No model is downloaded, no server is started, and no configuration is changed.
"""
import argparse
import json
import os
import shutil
import subprocess


MINIMUM_DRIVERS = {"native": (535, 104, 5), "tts": (530, 30, 2),
                   "transformers": (520, 61, 5), "vllm": (580, 65, 6)}


def version_tuple(value):
    parts = tuple(int(p) for p in value.split("."))
    return (parts + (0, 0, 0))[:3]


def validate_device(profile, capability, driver):
    required_capability = (7, 5) if profile == "vllm" else (6, 1) if profile == "native" else (6, 0)
    if capability < required_capability:
        raise RuntimeError(f"{profile} requires compute capability >= {required_capability}; got {capability}. "
                           "Use the native profile on the GTX 1080 Ti.")
    if version_tuple(driver) < MINIMUM_DRIVERS[profile]:
        raise RuntimeError(f"{profile} requires driver >= {'.'.join(map(str, MINIMUM_DRIVERS[profile]))}; got {driver}.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=list(MINIMUM_DRIVERS), required=True)
    parser.add_argument("--torch", action="store_true", help="Run real CUDA matrix/Conv1d/LSTM probes")
    parser.add_argument("--required", action="store_true", help="Fail instead of skipping a machine without nvidia-smi")
    parser.add_argument("--gpu", default=os.getenv("GPU_DEVICE_ID", "0"))
    args = parser.parse_args()
    if not shutil.which("nvidia-smi"):
        if args.required:
            raise RuntimeError("nvidia-smi is unavailable: install/enable the NVIDIA driver first")
        print("GPU checks skipped: nvidia-smi unavailable. Run check_gpu.py --required on the GPU server.")
        return
    row = subprocess.check_output(["nvidia-smi", "-i", args.gpu,
        "--query-gpu=name,driver_version,compute_cap,memory.total", "--format=csv,noheader,nounits"], text=True).strip()
    name, driver, capability, memory = [p.strip() for p in row.split(",")]
    validate_device(args.profile, tuple(int(p) for p in capability.split(".")), driver)
    result = dict(profile=args.profile, gpu=name, driver=driver, compute_capability=capability, memory_mb=int(memory))
    if args.torch:
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError("Pinned Torch cannot initialize CUDA on this device")
        # Honor CUDA_VISIBLE_DEVICES; a service always sees its selected GPU as cuda:0.
        with torch.inference_mode():
            matrix = torch.ones((32, 32), device="cuda:0")
            assert torch.isfinite(matrix @ matrix).all().item()
            conv = torch.nn.Conv1d(2, 4, 3).to("cuda:0")
            assert torch.isfinite(conv(torch.ones((1, 2, 16), device="cuda:0"))).all().item()
            lstm = torch.nn.LSTM(4, 4, batch_first=True).to("cuda:0")
            assert torch.isfinite(lstm(torch.ones((1, 8, 4), device="cuda:0"))[0]).all().item()
            torch.cuda.synchronize()
        result.update(torch=torch.__version__, torch_cuda=torch.version.cuda,
                      torch_architectures=torch.cuda.get_arch_list(), cuda_probes="passed")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
