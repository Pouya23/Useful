#!/usr/bin/env bash
# Source this helper. Clone only the checksum-pinned bootstrap's local cache.
# Keep the environment settings for later conda list/activate operations.
clone_offline_env() {
  local bootstrap="$1" name="$2" prefix
  bootstrap="$(cd -- "$bootstrap" && pwd)"
  prefix="$bootstrap/envs/$name"
  export CONDA_NO_PLUGINS=true CONDA_SOLVER=classic CONDA_OFFLINE=true
  export CONDA_AUTO_UPDATE_CONDA=false CONDA_REPORT_ERRORS=false
  export CONDA_PKGS_DIRS="$bootstrap/pkgs" CONDA_ENVS_PATH="$bootstrap/envs"
  export PYTHONNOUSERSITE=1
  if [[ ! -f "$prefix/conda-meta/history" || ! -x "$prefix/bin/python" ]]; then
    if [[ -e "$prefix" ]]; then
      echo "Incomplete environment at $prefix. Move that directory aside or choose a fresh CONDA_ROOT, then rerun." >&2
      return 2
    fi
    "$bootstrap/bin/conda" --no-plugins create --offline --yes --solver classic \
      --no-default-packages --prefix "$prefix" --clone "$bootstrap"
  fi
  "$prefix/bin/python" -I -c 'import sys; assert sys.version_info[:3] == (3,11,11), sys.version'
}
