#!/usr/bin/env bash
# Bootstrap retry wrapper for Ubuntu 20.04 curl; no --retry-all-errors needed.
set -u
tries="${DOWNLOAD_RETRIES:-10}"
delay="${DOWNLOAD_RETRY_DELAY:-3}"
output=""
args=("$@")
for ((i=0;i<${#args[@]};i++)); do
  [[ "${args[i]}" != --output && "${args[i]}" != -o ]] || output="${args[i+1]}"
done
if [[ -n "$output" && -n "${CURL_EXPECTED_SHA256:-}" ]]; then
  if [[ -f "$output" ]] && printf '%s  %s\n' "$CURL_EXPECTED_SHA256" "$output" | sha256sum -c - >/dev/null 2>&1; then
    echo 'Recovered checksum-complete bootstrap partial.' >&2; exit 0
  fi
  IFS=: read -r -a caches <<< "${NARRATION_DOWNLOAD_CACHE_DIRS:-}"
  filename="$(basename -- "$output")"; filename="${filename%.part}"
  for cache in "${caches[@]}"; do
    [[ -n "$cache" && -f "$cache/$filename" ]] || continue
    if printf '%s  %s\n' "$CURL_EXPECTED_SHA256" "$cache/$filename" | sha256sum -c - >/dev/null 2>&1; then
      cp -- "$cache/$filename" "$output"; echo 'Reused cached bootstrap artifact.' >&2; exit 0
    fi
  done
fi
for ((attempt=1;attempt<=tries;attempt++)); do
  curl "$@"
  result=$?
  [[ "$result" != 0 ]] || exit 0
  case "$result" in 5|6|7|18|28|35|52|55|56) ;; *) exit "$result";; esac
  [[ "$attempt" -lt "$tries" ]] || exit "$result"
  printf 'Retrying interrupted curl transfer (%s/%s, exit=%s).\n' "$attempt" "$tries" "$result" >&2
  sleep "$delay"
done
exit 1
