"""Download all application/model/build artifacts with curl before Docker builds."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "TTS"))
from download_packages import download


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--download-dir", type=Path, required=True)
    parser.add_argument("--llm-profile", choices=["native", "transformers", "vllm"], default="native")
    parser.add_argument("--models", action="store_true", help="Also obtain the pinned LLM GGUF and Kokoro model")
    args = parser.parse_args()
    destination = args.download_dir.resolve()
    for lock, subdir in ((ROOT / "containers/common.lock", "common"),
                         (ROOT / f"LLM/locks/{args.llm_profile}.txt", f"llm-{args.llm_profile}"),
                         (ROOT / "TTS/requirements.lock", "tts")):
        subprocess.run([sys.executable, str(ROOT / "TTS/download_packages.py"), str(lock), str(destination/subdir)], check=True)
    if args.llm_profile != "native":
        subprocess.run([sys.executable, str(ROOT / "TTS/download_packages.py"), str(ROOT / "LLM/locks/native.txt"),
                        str(destination / "llm-native")], check=True)
    source = destination / "llama-source.tar.gz"
    download("https://codeload.github.com/ggml-org/llama.cpp/legacy.tar.gz/0faee5004297c3bcfa40b7bf11750127b8c1fd7d",
             source, "67c10b895e534bac0cf6ce107e08570f13a3e66d5550eef927cc74e03b2bebf7")
    native = json.loads((ROOT / "TTS/native-artifacts.json").read_text())
    download(native["url"], destination/native["filename"], native["sha256"])
    for item in json.loads((ROOT / "containers/host-artifacts.json").read_text()):
        download(item["url"], destination / "host-debs" / item["filename"], item["sha256"])
    if args.models:
        subprocess.run([sys.executable, str(ROOT / "LLM/download_model.py"), "--kind", "gguf",
                        "--download-dir", str(destination / "models/llm")], check=True)
        subprocess.run([sys.executable, str(ROOT / "TTS/download_models.py"),
                        "--model-dir", str(destination / "models/tts")], check=True)
        if args.llm_profile != "native":
            subprocess.run([sys.executable, str(ROOT / "LLM/download_model.py"), "--kind", "hf",
                            "--download-dir", str(destination / "models/hf")], check=True)


if __name__ == "__main__":
    main()
