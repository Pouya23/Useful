#!/usr/bin/env bash
# Does not install/start Docker. Downloads versioned Docker/NVIDIA .deb files via curl.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${DOWNLOAD_DIR:?Set DOWNLOAD_DIR}"
PY="$DOWNLOAD_DIR/bootstrap-conda/bin/python"
[[ -x "$PY" ]] || { echo 'Run containers/prepare.sh first to create the download interpreter.' >&2; exit 2; }
"$PY" - "$ROOT" "$DOWNLOAD_DIR" <<'PY'
import json,sys
from pathlib import Path
root, destination = map(Path,sys.argv[1:])
sys.path.insert(0,str(root/'TTS'))
from download_packages import download
for p in json.loads((root/'containers/host-artifacts.json').read_text()):
    download(p['url'],destination/'host-debs'/p['filename'],p['sha256'])
PY
