#!/usr/bin/env bash
set -euo pipefail
source /app/runtime-env.sh
exec "$@"
