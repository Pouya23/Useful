"""Export both API contracts without loading models or starting services.

Run with an interpreter containing the pinned common HTTP dependencies.
Separate processes keep the pipelines' flat module names isolated.
"""
import subprocess
import sys
from pathlib import Path


root = Path(__file__).resolve().parents[1]
for service in ("LLM", "TTS"):
    source = """
import json
import sys
from pathlib import Path
from types import SimpleNamespace
root = Path(sys.argv[1])
service = sys.argv[2]
sys.path.insert(0, str(root / service))
if service == 'LLM':
    from api_app import openapi_document
    document = openapi_document()
else:
    from app import openapi_document
    document = openapi_document(SimpleNamespace(
        settings=SimpleNamespace(api_key=''), engine=SimpleNamespace(voices=[])))
destination = root / 'docs' / (service.lower() + '-openapi.json')
destination.write_text(json.dumps(document, indent=2) + '\\n', encoding='utf-8')
print(destination)
"""
    subprocess.run([sys.executable, "-c", source, str(root), service], check=True)
