"""Reentrant process/thread gate shared by both containers on the same GPU.

The gate covers model forwards/loading, never an LLM job's remote /duration call.
Resident weights remain allocated, so memory budgets must still allow both models.
"""
import hashlib
import os
from pathlib import Path
import threading


class GpuGate:
    def __init__(self, directory=None, identity=None, enabled=True):
        self.enabled = enabled and os.getenv("GPU_SERIALIZE", "1") != "0"
        self.mutex = threading.RLock()
        self.local = threading.local()
        identity = identity or os.getenv("GPU_SCHEDULER_ID", "0")
        directory = Path(directory or os.getenv("GPU_LOCK_DIR", "/gpu-locks"))
        if self.enabled:
            directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / (hashlib.sha256(identity.encode()).hexdigest()[:24] + ".lock")

    def __enter__(self):
        if not self.enabled:
            return self
        self.mutex.acquire()
        try:
            depth = getattr(self.local, "depth", 0)
            if depth == 0:
                import fcntl
                stream = self.path.open("a+b")
                try:
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
                except BaseException:
                    stream.close()
                    raise
                self.local.stream = stream
            self.local.depth = depth + 1
            return self
        except BaseException:
            self.mutex.release()
            raise

    def __exit__(self, *_):
        if not self.enabled:
            return
        try:
            self.local.depth -= 1
            if self.local.depth == 0:
                import fcntl
                stream = self.local.stream
                try:
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
                finally:
                    stream.close()
                    del self.local.stream
        finally:
            self.mutex.release()


class CombinedLock:
    def __init__(self, local_lock, gpu_gate):
        self.local_lock, self.gpu_gate = local_lock, gpu_gate

    def __enter__(self):
        self.local_lock.acquire()
        try:
            self.gpu_gate.__enter__()
            return self
        except BaseException:
            self.local_lock.release()
            raise

    def __exit__(self, *args):
        try:
            self.gpu_gate.__exit__(*args)
        finally:
            self.local_lock.release()
