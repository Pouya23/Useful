"""Install isolated, curl-staged LLM workers and record their interpreter allowlist."""
import argparse
import json
import os
from pathlib import Path
import subprocess


def profiles_for(profile):
    return {"native": ["native"], "transformers": ["transformers"], "vllm": ["vllm"],
            "compatible": ["native", "transformers"], "all": ["native", "transformers", "vllm"]}[profile]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=["native", "transformers", "vllm", "compatible", "all"], required=True)
    parser.add_argument("--bootstrap", type=Path, required=True)
    parser.add_argument("--download-dir", type=Path, required=True)
    parser.add_argument("--layout", choices=["host", "container"], default="host")
    args = parser.parse_args()
    bootstrap = args.bootstrap.resolve()
    helpers = Path(__file__).resolve().parent
    primary = bootstrap / "envs/LLM"
    multiple = args.profile in {"compatible", "all"}
    workers = {"llama_cpp": str(primary / "bin/python")}
    manifests = Path("/app/provenance/workers") if args.layout == "container" else args.download_dir / "manifests"
    manifests.mkdir(parents=True, exist_ok=True)
    for profile in profiles_for(args.profile):
        prefix = primary
        if multiple and profile != "native":
            name = "LLM-" + profile
            subprocess.run(["bash", "-c", 'source "$1"; clone_offline_env "$2" "$3"', "bash",
                            str(helpers / "conda_offline.sh"), str(bootstrap), name], check=True)
            prefix = bootstrap / "envs" / name
        python = prefix / "bin/python"
        if prefix == primary:
            common = args.download_dir / ("wheels-common" if args.layout == "host" else "common")
            subprocess.run([str(python), str(helpers / "install_offline.py"), str(common), "--no-check"], check=True)
        directory = args.download_dir / (("wheels-" if args.layout == "host" else "llm-") + profile)
        subprocess.run([str(python), str(helpers / "install_offline.py"), str(directory)], check=True)
        if profile != "native":
            workers[profile] = str(python)
        (prefix / ".llm-profile").write_text(profile + "\n", encoding="utf-8")
        with (manifests / f"pip-worker-{profile}.txt").open("w", encoding="utf-8") as out:
            subprocess.run([str(python), "-m", "pip", "freeze", "--all"], stdout=out, check=True)
    (primary / ".llm-profile").write_text(args.profile + "\n", encoding="utf-8")
    registry = primary / ".llm-engines.json"
    registry.write_text(json.dumps({"schema_version": 1, "workers": workers}, indent=2) + "\n", encoding="utf-8")
    print(f"Engine selection registry: {registry}")


if __name__ == "__main__":
    main()
