"""Install a curl-staged manifest in the image; never contact an index."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import importlib.metadata


def installed_version(name):
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--names", help="Comma-separated subset, used for source build tools")
    parser.add_argument("--no-check", action="store_true", help="Defer pip check until the final profile layer")
    args = parser.parse_args()
    records = json.loads((args.directory / "manifest.json").read_text(encoding="utf-8"))
    if args.names:
        names = set(args.names.split(","))
        records = [p for p in records if p["name"] in names]
    stamps = Path(sys.prefix) / ".narration-artifacts"
    stamps.mkdir(exist_ok=True)
    lines = []
    for record in records:
        # A version is sufficient for immutable wheels; source builds additionally
        # need our artifact stamp to distinguish same-version Kokoro commits.
        source = not record["filename"].endswith(".whl")
        stamp = stamps / record["sha256"]
        if installed_version(record["name"]) == record["version"] and (not source or stamp.exists()):
            continue
        path = args.directory / record["filename"]
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(8*1024*1024), b""):
                digest.update(block)
        if digest.hexdigest() != record["sha256"]:
            raise RuntimeError(f"Staged artifact checksum mismatch: {path.name}")
        lines.append(f"{path.resolve().as_uri()} --hash=sha256:{record['sha256']}\n")
    if not lines:
        print(f"Already installed: {args.directory.name}; skipped package installation")
        if not args.no_check:
            subprocess.run([sys.executable, "-m", "pip", "check"], check=True)
        return
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as output:
        output.writelines(lines)
        requirements = Path(output.name)
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "--no-index", "--no-deps", "--no-build-isolation",
                        "--require-hashes", "--disable-pip-version-check", "-r", str(requirements)], check=True)
        if not args.no_check:
            subprocess.run([sys.executable, "-m", "pip", "check"], check=True)
        for record in records:
            if installed_version(record["name"]) == record["version"]:
                (stamps / record["sha256"]).touch()
    finally:
        requirements.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
