"""Install a curl-staged manifest in the image; never contact an index."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    records = json.loads((args.directory / "manifest.json").read_text(encoding="utf-8"))
    lines = []
    for record in records:
        path = args.directory / record["filename"]
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(8*1024*1024), b""):
                digest.update(block)
        if digest.hexdigest() != record["sha256"]:
            raise RuntimeError(f"Staged artifact checksum mismatch: {path.name}")
        lines.append(f"{path.resolve().as_uri()} --hash=sha256:{record['sha256']}\n")
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as output:
        output.writelines(lines)
        requirements = Path(output.name)
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "--no-index", "--no-deps", "--no-build-isolation",
                        "--require-hashes", "--disable-pip-version-check", "-r", str(requirements)], check=True)
        subprocess.run([sys.executable, "-m", "pip", "check"], check=True)
    finally:
        requirements.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
