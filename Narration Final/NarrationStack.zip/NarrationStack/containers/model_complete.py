"""Validate saved default model provenance offline; return 1 when repair is needed."""
import argparse
import hashlib
import json
from pathlib import Path


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def complete(kind, directory):
    directory = Path(directory).resolve()
    try:
        if kind == 'gguf':
            return digest(directory / 'Qwen3.5-9B-Q5_K_M.gguf') == 'dc2a39aef291f91a9116ad214058da0d86eb648743a124bd8c333787c4b9c91c'
        path = directory / ('download-provenance.json' if kind == 'hf' else 'download_manifest.json')
        record = json.loads(path.read_text(encoding='utf-8'))
        expected = ('Qwen/Qwen3.5-9B', 'c202236235762e1c871ad0ccb60c8ee5ba337b9a') if kind == 'hf' else (
            'hexgrad/Kokoro-82M', 'f3ff3571791e39611d31c381e3a41a3af07b4987')
        if (record['repository'], record['revision']) != expected:
            return False
        files = record['files']
        files = {p['filename']:p for p in files} if isinstance(files, list) else files
        if not files or 'config.json' not in files:
            return False
        if kind == 'hf' and not any(p.endswith('.safetensors') for p in files):
            return False
        if kind == 'tts' and ('kokoro-v1_0.pth' not in files or not any(p.startswith('voices/') for p in files)):
            return False
        for name, metadata in files.items():
            target = (directory / name).resolve()
            if not target.is_relative_to(directory) or digest(target) != metadata['sha256']:
                return False
        return True
    except (OSError, ValueError, KeyError, TypeError):
        return False


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kind', choices=['gguf','hf','tts'], required=True)
    parser.add_argument('--directory', type=Path, required=True)
    args = parser.parse_args()
    ok = complete(args.kind, args.directory)
    print(('Verified, reuse: ' if ok else 'Missing/changed, prepare: ') + str(args.directory))
    raise SystemExit(0 if ok else 1)
