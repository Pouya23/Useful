"""Timestamped generated artifacts; persistent databases/locks keep their state names."""
from datetime import datetime, timezone
from pathlib import Path
import re
import uuid

STAMP = re.compile(r"\d{8}T\d{12}Z_[0-9a-f]{8}")


def new_stamp():
    return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'_'+uuid.uuid4().hex[:8]


class ArtifactPath(type(Path())):
    @property
    def stamp(self):
        for part in reversed(self.parts):
            found=STAMP.search(part)
            if found:return found.group()
        raise ValueError('Artifact path has no timestamped run/job ancestor')

    def __truediv__(self,other):
        other=Path(other)
        if other.is_absolute():return ArtifactPath(other)
        result=Path(self)
        for part in other.parts:
            if part in {'.','..'}:raise ValueError('Artifact paths cannot traverse directories')
            name=Path(part)
            if not STAMP.search(part):
                part=f'{name.stem}_{self.stamp}{name.suffix}' if name.suffix else f'{part}_{self.stamp}'
            result=result/part
        return ArtifactPath(result)


def artifact_path(path):
    path=Path(path)
    return ArtifactPath(path) if any(STAMP.search(p) for p in path.parts) else path


def new_artifact_dir(base,label='run'):
    base=Path(base)
    base.mkdir(parents=True,exist_ok=True)
    directory=ArtifactPath(base/f'{label}_{new_stamp()}')
    directory.mkdir(exist_ok=False)
    return directory
