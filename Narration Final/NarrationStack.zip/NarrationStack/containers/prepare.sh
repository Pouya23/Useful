#!/usr/bin/env bash
# Host preparation needs only curl/Bash; pip/conda never downloads application packages.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${DOWNLOAD_DIR:?Set an absolute DOWNLOAD_DIR}"
mkdir -p "$DOWNLOAD_DIR"
DOWNLOAD_DIR="$(cd -- "$DOWNLOAD_DIR" && pwd)"
export DOWNLOAD_DIR
CURL=(bash "$ROOT/containers/curl_retry.sh" --fail --location --retry 5 --retry-delay 2 --connect-timeout 60)
[[ -z "${DOWNLOAD_PROXY:-}" ]] || CURL+=(--proxy "$DOWNLOAD_PROXY")
[[ -z "${CURL_CA_BUNDLE:-}" ]] || CURL+=(--cacert "$CURL_CA_BUNDLE")
[[ "${CURL_INSECURE:-0}" != 1 ]] || CURL+=(--insecure)
INSTALLER=Miniconda3-py311_25.1.1-2-Linux-x86_64.sh
SHA=d8c1645776c0758214e4191c605abe5878002051316bd423f2b14b22d6cb4251
if [[ ! -f "$DOWNLOAD_DIR/$INSTALLER" ]]; then
  CURL_EXPECTED_SHA256="$SHA" "${CURL[@]}" --continue-at - -o "$DOWNLOAD_DIR/$INSTALLER.part" "https://repo.anaconda.com/miniconda/$INSTALLER"
  printf '%s  %s\n' "$SHA" "$DOWNLOAD_DIR/$INSTALLER.part" | sha256sum -c -
  mv "$DOWNLOAD_DIR/$INSTALLER.part" "$DOWNLOAD_DIR/$INSTALLER"
fi
printf '%s  %s\n' "$SHA" "$DOWNLOAD_DIR/$INSTALLER" | sha256sum -c -
BOOTSTRAP="$DOWNLOAD_DIR/bootstrap-conda"
[[ -x "$BOOTSTRAP/bin/python" ]] || bash "$DOWNLOAD_DIR/$INSTALLER" -b -k -p "$BOOTSTRAP"
"$BOOTSTRAP/bin/python" -c 'import sys; assert sys.version_info[:3]==(3,11,11),sys.version'
EXTRA=()
[[ "${DOWNLOAD_MODELS:-1}" != 1 ]] || EXTRA+=(--models)
"$BOOTSTRAP/bin/python" "$ROOT/containers/download_assets.py" --download-dir "$DOWNLOAD_DIR" \
  --llm-profile "${LLM_PROFILE:-native}" "${EXTRA[@]}"
