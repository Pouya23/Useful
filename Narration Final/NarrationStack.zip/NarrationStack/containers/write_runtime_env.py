"""Create a shell fragment that prefers this environment's pinned native libraries."""
import argparse
from pathlib import Path
import shlex


def activation_text(prefix, tools=None):
    prefix = Path(prefix).resolve()
    site = prefix / "lib/python3.11/site-packages"
    libraries = [site / "torch/lib", *sorted((site / "nvidia").glob("*/lib")), prefix / "lib"]
    libraries = [str(p) for p in libraries if p.is_dir()]
    paths = [str(Path(tools).resolve())] if tools else []
    paths.append(str(prefix / "bin"))
    return (f'export PATH={shlex.quote(":".join(paths))}:"$PATH"\n'
            f'export LD_LIBRARY_PATH={shlex.quote(":".join(libraries))}${{LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}}\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--environment", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--tools", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(activation_text(args.environment, args.tools), encoding="utf-8")


if __name__ == "__main__":
    main()
