# Backend integration flow

Default external ports are 8081/8082; internal container-to-container TTS traffic uses `tts:8000`.

## Recommended full workflow

1. Collect the narration brief, required points, style samples, approved sources, target seconds and chosen voice/speed/tolerances.
2. POST the LLM `/generate` body. Use async=true for a job/polling workflow or async=false for live SSE.
3. If consuming SSE, store the job ID from the header/accepted event. Keep a separate provisional buffer per round. Handle `retry` and reset that display on the next `round_start`.
4. Wait for a completed LLM result, via SSE or `/progress`. Use **the selected final `result.text`**, not the last streamed round. Inspect `fit.within_range`: a best-at-limit result can be successful generation with an unmet tolerance.
5. For exact plausibility, use LLM `estimate:false` with the same target, voice, lang_code and speed that will be used for TTS. Its duration calls do not synthesize audio. Estimated LLM fitting is faster but uses WPM assumptions.
6. POST TTS `/duration` with the selected text and speech specifications to ensure its requested FFmpeg tempo window fits. A LLM natural-duration tolerance and a TTS tempo window are separate constraints: one can pass while the other fails.
7. If tempo fit fails, decide in your product whether to request another LLM generation or change target/allowed tempo. Do not call generation blindly, truncate text or infer success from estimated_final_duration_s alone.
8. POST TTS `/generate` with async=true and an Idempotency-Key, then poll status/ETA and download when completed. Or use async=false with a long request timeout and receive MP3 directly.
9. Save both UUIDs, the accepted narration, selected LLM round, actual speech duration and final MP3 asset location in your backend record.

LLM `speech_duration_tolerance` controls a band on **natural** speech seconds; TTS `atempo_min/atempo_max` controls whether the speech can be stretched to the desired final length. Natural planning is sample-exact for the compatible frozen Kokoro plan; MP3/atempo and runtime ETAs are approximate.

## SSE implementation essentials

- POST JSON with a fetch/HTTP client supporting streamed response bodies. Standard browser EventSource only issues GET, so it cannot start this request.
- Parse SSE frames separated by blank lines. Network chunks can split one frame or contain many; use a streaming UTF-8 decoder and retain incomplete frames between reads.
- Preserve all `data:` content as JSON. Ignore comment heartbeats. Do not treat EOF without a completed/error event as success.
- Append token text to the current round, except when `replace_from` explicitly replaces a suffix. Token IDs may arrive with empty text while the tokenizer waits for a decodable boundary.
- Treat every stream round as provisional. On `completed`, replace the visible narration with the authoritative selected result, which can be an earlier saved round.
- Once HTTP 200 SSE starts, later failures are error events. Before streaming starts, normal 4xx/5xx JSON applies.
- A disconnect does not cancel inference. Poll the existing UUID and recover result.text rather than resubmitting automatically. LLM POST generation does not implement an idempotency key; an untracked POST retry creates a new job.
- Swagger documents the transport but is not a dedicated streaming UI. Use curl --no-buffer or the backend's SSE client for live testing.

For browser integrations, place these services behind same-origin backend/proxy routes or implement the appropriate CORS policy in that proxy; the API does not enable permissive cross-origin access automatically.

## Progress and failure handling

Poll about every 0.5–1 second rather than spinning. LLM percentage measures the maximum generation-round budget and token/word progress; early acceptance can jump to 100. TTS percentage uses elapsed/estimated runtime; it adapts to calibrated/current chunk timing. Neither percentage is a quality score.

Only `status:completed` means finished. TTS zero remaining time during an ETA overrun is not completion. Failed jobs retain error details and never pretend to be 100% complete.

Handle HTTP 503 with bounded retry/backoff; capacity can be queue capacity or active-stream/request capacity. Handle 422 as invalid input/planning/fit information rather than retrying the same body endlessly. Handle 401 as wrong/missing service key. A 404 UUID is unknown, not a pending job.

The two services share one GPU execution lock. LLM decode releases it before remote duration checks; TTS planning acquires it independently. Keep the common mount/identity and avoid running another copy against the same state directories. Serialized execution still consumes resident memory from both models.

## Restart semantics

Completed results and MP3s remain in the host state directories. Interrupted running jobs fail explicitly; queued jobs survive. TTS queued plans tied to a different model/source signature fail rather than being regenerated under different weights. Backend users should receive a retry option with a new job/key when a job has failed.

Stored request data can include source text and per-request duration credentials. Treat state directories as private application data; the job SQLite file is owner-only and API progress does not expose raw saved request payloads.
