# Complete deployment guide: two containers, one NVIDIA GPU

Nothing is started by the delivered source or preparation/build scripts. The explicit `docker compose up` step below is where **you** start the services.

## 1. Select the GPU machine and storage

Use a Linux x86_64 server with an NVIDIA GPU and working driver. Your test card is a **GTX 1080 Ti, 11264 MiB, SM 6.1**, with **driver 535.183.01**; the deployment card is an RTX A6000. Default images use CUDA **12.2.2** and the TTS wheels use CUDA **12.1**. The native toolkit requires driver **535.104.05 or newer**, so your existing driver is suitable and does not need replacement. The native compiler defaults include SM 6.1/7.5/8.6; A6000 is SM 8.6. Only one physical GPU is exposed to each container, and both use that same GPU.

```bash
nvidia-smi
nvidia-smi --query-gpu=index,name,uuid,driver_version,memory.total --format=csv
uname -m
df -h
```

Choose absolute paths with enough room for models, wheel/source downloads, CUDA build cache and image layers; start with about 50 GB free for the default stack. Optional Transformers/vLLM LLM profiles need additional space. Downloads and runtime data can be on different disks; Docker's image storage is separate unless your administrator has configured its `data-root`.

Extract `NarrationStack.zip` on this machine. Do not overwrite your previous individual pipeline folders.

## 2. Install basic download tools

```bash
sudo apt-get update
sudo apt-get install -y curl ca-certificates
cd /your/path/NarrationStack
export DOWNLOAD_DIR="/your/chosen/path/narration-downloads"
export DOWNLOAD_PROXY="socks5h://PROXY_IP:PROXY_PORT"
# Prefer the proxy CA if needed:
# export CURL_CA_BUNDLE="/path/to/proxy-ca.pem"
# Explicit curl -k opt-in only if your proxy requires it:
# export CURL_INSECURE=1
```

No preinstalled Python is required. The prepare script bootstraps fixed Python 3.11.11 through a checksum-verified Miniconda installer. Application packages, model assets and host package artifacts are fetched with curl; pip/conda install application dependencies offline.

## 3. Download application artifacts and models

```bash
export LLM_PROFILE=native
export DOWNLOAD_MODELS=1
bash containers/prepare.sh
```

This downloads common packages, the selected LLM packages, all TTS packages, the exact native llama.cpp source, fixed static FFmpeg tools, versioned host `.deb` files, the original Qwen Q5_K_M GGUF and Kokoro checkpoint/English voices. They remain under `DOWNLOAD_DIR`. Checksums are verified. Downloads resume through curl and validated files are reused.

Model layout:

```text
DOWNLOAD_DIR/models/llm/Qwen3.5-9B-Q5_K_M.gguf
DOWNLOAD_DIR/models/tts/config.json
DOWNLOAD_DIR/models/tts/kokoro-v1_0.pth
DOWNLOAD_DIR/models/tts/voices/*.pt
```

Set `DOWNLOAD_MODELS=0` to use already downloaded compatible files and place them in this layout yourself. HF profiles additionally use `models/hf/`. There are no model downloads on service startup or during generation.

## 4. Install Docker and its NVIDIA runtime

Skip package installation if your server already has suitable Docker Engine/Buildx/Compose and NVIDIA Container Toolkit. Requirements: Compose ≥2.20 with BuildKit additional build contexts, and Docker GPU device support. Keep your existing compatible installation rather than replacing it unnecessarily.

For your requested **Ubuntu 20.04**, the prepared `host-debs` contain a verified legacy Focal-compatible set: Docker Engine/CLI 27.5.1, containerd 1.7.25, Compose 2.32.4, Buildx 0.20.0, NVIDIA Container Toolkit/libnvidia-container 1.18.2. Their exact Debian versions/URLs/SHA256 are in `containers/host-artifacts.json`.

```bash
sudo dpkg -i "$DOWNLOAD_DIR"/host-debs/*.deb
# If dpkg reports missing OS dependencies, install the listed Ubuntu packages:
sudo apt-get -f install
sudo systemctl enable --now docker
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker

# Permit your login to issue Docker commands, then log out/in once:
sudo usermod -aG docker "$USER"
```

After logging back in:

```bash
docker version
docker compose version
docker buildx version
docker info --format '{{json .Runtimes}}'
```

Docker's current supported Ubuntu-host list no longer includes 20.04; this guide provides the pinned existing Focal package route, not a claim of current vendor support. Newer hosts can use the current official installation path while still running these Ubuntu 20.04-based images. See [Docker's Ubuntu installation guide](https://docs.docker.com/engine/install/ubuntu/) and [NVIDIA's runtime configuration guide](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html).

## 5. Configure image pulls/build networking

Pip never needs network access. Docker itself must obtain the two versioned NVIDIA CUDA base images, and the native compiler build stage uses apt for Ubuntu build tools. Those transports are independent of pip and curl.

If your server can access registries/Ubuntu repositories normally:

```bash
docker pull nvidia/cuda:12.2.2-runtime-ubuntu20.04
docker pull nvidia/cuda:12.2.2-devel-ubuntu20.04
```

If Docker needs a proxy, configure an **HTTP CONNECT proxy** for the daemon; the SOCKS URL used by curl is not automatically a Docker daemon proxy. Follow [Docker daemon proxy configuration](https://docs.docker.com/engine/daemon/proxy/). A private CA must also be trusted by Docker for registry pulls. Native-build apt may need a reachable HTTP proxy; Docker build proxy arguments can be supplied without putting credentials into application layers.

If the target server cannot pull/build images through its network, build them on another Linux x86_64 machine with repository access; no GPU is needed to compile the native image. Use the same staged artifacts and CUDA architecture values, then export/transfer the final images:

```bash
# On the build machine after step 7:
docker save -o "$DOWNLOAD_DIR/narration-images.tar" \
  narration-llm:1.0.0 narration-tts:1.0.0
# Transfer the tar, source/config folder and models to the GPU server.
# On the GPU server:
docker load -i "$DOWNLOAD_DIR/narration-images.tar"
```

This is the fully offline runtime route. There is no need to run pip on the GPU host.

## 6. Set every deployment value

```bash
cp .env.example .env
```

Edit `.env`. Use absolute Linux paths. Quote values containing spaces, punctuation interpreted by a shell or semicolons; `containers/build.sh` reads this shell-compatible file.

| Setting | Meaning / initial value |
|---|---|
| `DOWNLOAD_DIR` | The exact artifact/model directory from step 3 |
| `STATE_DIR` | Durable jobs, input files and shared GPU lock directory |
| `GPU_DEVICE_ID` | Physical GPU index or NVIDIA UUID; use the same value for both services |
| `BIND_ADDRESS` | `127.0.0.1` for local/reverse-proxy access; `0.0.0.0` for direct remote access |
| `LLM_PORT`, `TTS_PORT` | Host ports, defaults 8081/8082; both container ports are 8000 |
| `LLM_API_KEY`, `TTS_API_KEY` | Set your own keys; backend sends the matching `X-API-Key` |
| `LLM_PROFILE` | `native` default; optional `transformers` or `vllm` build profile |
| `LLM_ENGINE` | `llama_cpp` default; optional matching HF engine |
| `LLM_CONTEXT_TOKENS` | 8192 for initial small-GPU test; increase explicitly if inputs require it |
| `LLM_KV_CACHE_DEVICE` | `cpu` for initial test; optional `gpu` on the A6000 |
| `LLM_VRAM_LIMIT_GB`, `LLM_HEADROOM_GB` | 10.5 / 1.5 for initial test; sampled total-device guard, decimal GB |
| `TTS_MAX_VRAM_GB`, `TTS_CUDA_RESERVE_MB` | 2 / 512 initial small-GPU allocator settings |
| `TTS_MAX_CHUNK_SECONDS` | 10 initially; smaller chunks reduce decoder activation memory |
| `TTS_PLAN_CACHE_MB` | CPU tensor-payload cache budget, default 128 |
| `CUDA_ARCHS` | `"61;75;86"`; set `"86"` if building only for the A6000 |
| `BUILD_JOBS` | 4; lower if host RAM is limited while compiling |

For the A6000, start with these optional overrides after validating the small configuration:

```dotenv
LLM_CONTEXT_TOKENS=32768
LLM_KV_CACHE_DEVICE=gpu
LLM_VRAM_LIMIT_GB=40
LLM_HEADROOM_GB=2
TTS_MAX_VRAM_GB=5
TTS_CUDA_RESERVE_MB=768
TTS_MAX_CHUNK_SECONDS=20
CUDA_ARCHS="86"
```

The single GPU gate serializes model loading/LLM decoding/TTS model forwards. It does **not** hold a lock while the LLM calls `/duration`, and CPU MP3 encoding can proceed outside the GPU gate. Resident weights and CUDA contexts remain allocated in both containers: serialization does not make two models fit automatically. The old card's exact capacity and inference peaks must be tested. If its guard trips, decrease context/chunk sizes, keep CPU KV, or use a smaller compatible GGUF. No CPU fallback masks a GPU failure.

Inside the Compose network, LLM duration checks use **`http://tts:8000/duration`**, regardless of the external TTS port. The LLM receives `TTS_API_KEY` as its duration API key automatically. Both services share the same GPU lock bind mount and identity; do not remove either.

## 7. Build the images; this does not start them

```bash
bash containers/build.sh
docker image ls narration-llm narration-tts
```

The build script creates owned state directories (UID/GID 10001) and records image metadata under `DOWNLOAD_DIR/provenance/images.json`. Shared stages contain CUDA runtime, fixed Miniconda/Python and the frozen 46-package HTTP/build-tool set. Native llama.cpp is compiled in a disposable CUDA development stage. TTS and optional HF LLM dependencies remain separate because their Torch/Transformers pins differ.

Model files are read-only mounts, not multi-GB image layers. Application-code changes are copied after dependency installation, preserving cached initialization layers. The LLM keeps one session resident for identical engine settings and reloads only when those settings change; TTS loads its resident model on startup.

## 8. Test GPU passthrough, then explicitly start

```bash
# Short diagnostic container; no narration services started yet:
docker run --rm --gpus "device=0" nvidia/cuda:12.2.2-runtime-ubuntu20.04 nvidia-smi
# Replace device=0 above if GPU_DEVICE_ID differs.

# Probe the pinned libraries before starting the actual services:
docker compose run --rm --no-deps tts python ../containers/check_gpu.py --profile tts --torch --required
docker compose run --rm --no-deps llm python ../containers/check_gpu.py --profile native --required
# For an optional HF profile, replace --profile native above with that profile
# and add --torch. Use native on the GTX 1080 Ti for the first deployment.
# Now start the actual services:
docker compose up -d --no-build
docker compose ps
docker compose logs -f tts llm
```

TTS starts first and must become healthy before LLM starts. LLM validates NVML at startup and loads its selected model lazily on the first generation request. `/health` distinguishes worker readiness from `model_loaded`; later identical jobs reuse the resident session. There is no hidden LLM warm-up generation.

## 9. Check the APIs

```bash
curl --noproxy '*' http://127.0.0.1:8082/health
curl --noproxy '*' http://127.0.0.1:8081/health
```

Swagger: `http://SERVER:8081/docs/` for LLM and `http://SERVER:8082/docs/` for TTS. Schemas: `/openapi.json` on each. Authorize Swagger with the appropriate key if configured.

Use the curl examples in `LLM_API.md` and `TTS_API.md` to verify async completion, synchronous SSE/MP3 and accurate duration fitting. The source includes real TTS smoke scripts and API contract tests; fake-engine tests are not evidence of real GPU quality/latency.

## 10. Backend access and proxy settings

For remote backend access, set the appropriate `BIND_ADDRESS`, host firewall/routing and keys, then recreate services:

```bash
docker compose up -d --no-build
```

If exposing through Nginx, use `containers/nginx-example.conf`: disable SSE buffering/compression and allow long read/send timeouts. Streaming clients should use POST fetch with an SSE parser, not the browser `EventSource` GET-only constructor. TTS synchronous responses may take minutes; set backend request/proxy timeouts accordingly. See the separate API documents.

## 11. Inspect, stop, restart and preserve work

```bash
docker compose logs --tail=100 llm
docker compose logs --tail=100 tts
docker compose stop
docker compose up -d --no-build
docker compose down
```

State and models are host bind mounts and remain after `down`. Interrupted running jobs become explicitly failed on restart; queued LLM requests and queued TTS plans survive. Incompatible queued TTS model signatures fail rather than silently regenerating a different plan. Switching a TTS model should use a fresh state directory.

LLM `/progress` returns selected final text/fit even if the SSE connection was lost. A stream disconnect does not cancel its job. TTS completed audio is downloadable through `/progress?job_id=...&download=true`.

Inspect actual installed versions inside the images:

```bash
docker compose exec llm cat /app/provenance/python-packages.txt
docker compose exec tts cat /app/provenance/python-packages.txt
docker compose exec tts ffmpeg -version
docker compose exec llm llama-server --version
```

## 12. Optional engines and model changes

To build a Transformers LLM image, set `LLM_PROFILE=transformers` during preparation and in `.env`, set `LLM_ENGINE=transformers`, and use `/models/hf`. Its worker is in the image's LLM environment; arbitrary interpreter execution is not exposed through HTTP. The native engine remains included. vLLM similarly uses `LLM_PROFILE=vllm`/`LLM_ENGINE=vllm`; that dependency stack requires the newer CUDA 13-compatible driver/card described in `LLM/INSTALL.md` and is intended for the A6000. Native is the simplest initial one-GPU deployment.

LLM requests can select compatible mounted GGUF/HF models. TTS model/config/repository/digest settings are deployment values; only compatible Kokoro checkpoint architectures preserve the waveform-free duration contract. Mount all selected model files before startup.

No containers were started or GPU inference executed while preparing this delivery, following your instruction.
