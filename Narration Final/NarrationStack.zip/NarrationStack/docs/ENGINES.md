# LLM engines and isolated workers

Both the main CLI and HTTP `engine` field select `llama_cpp`, `transformers` or `vllm`. Installing only the native profile cannot supply missing Torch packages. The new combined profiles solve that by preparing separate worker environments and recording their interpreter paths in the main LLM environment's `.llm-engines.json`.

| Setup profile | Prepared engines | Target |
| --- | --- | --- |
| native | llama_cpp | Minimal default native image |
| transformers | llama_cpp and Transformers in the primary environment | Single HF profile |
| vllm | llama_cpp and vLLM in the primary environment | Supported A6000 and driver |
| compatible | llama_cpp plus isolated Transformers worker | GTX 1080 Ti and A6000 |
| all | llama_cpp plus isolated Transformers and vLLM workers | A6000 with driver 580.65.06 or newer |

The user-facing conda environment remains **LLM**. Combined profiles additionally create internal `LLM-transformers` and `LLM-vllm` worker prefixes. Their incompatible Torch/Transformers stacks are never merged. Only one chosen LLM session is resident; an engine/model change closes the old session before loading the next. The CLI resolves workers automatically. An explicit CLI `--worker-python` remains available for trusted external environments; the HTTP field can only select the deployment-registered interpreter for that engine.

Native uses the existing GGUF. HF engines require the full safetensors model directory and tokenizer/config files; a GGUF file is not interchangeable with that directory. The combined host setup obtains the pinned HF model under the chosen LLM download directory's `models/hf`; containers use `/models/hf`.

```bash
# After compatible/all setup and activation:
python run_pipeline.py --engine transformers --model /path/to/models/hf \
  --duration-seconds 60 --context-tokens 8192 --dtype auto

# Supported A6000 only, after all setup:
python run_pipeline.py --engine vllm --model /path/to/models/hf \
  --duration-seconds 60 --context-tokens 8192 --vram-limit-gb 40 --headroom-gb 2
```

```json
{"engine":"transformers","model":"/models/hf","duration_seconds":60,"async":true}
```

The same HTTP body can use `"engine":"vllm"` in an all-profile deployment on supported hardware. `/health` reports `installed_engines`; this describes installed interpreters, not a guarantee that an unsupported GPU can execute them. The pipeline still saves each round, stops on the first in-range result, and otherwise selects the closest saved candidate.

Transformers keeps NF4 double quantization and hardware-selected float16/bfloat16. Qwen chunked prefill and real streamer callbacks remain in place. Worker library paths now prefer that worker's own Torch/NVIDIA/conda libraries and remove inherited foreign environment/CUDA library directories. vLLM CLI progress and HTTP tokens both use live scheduler steps; the obsolete per-request logits processor path has been removed.

The GTX 1080 Ti is SM 6.1. It cannot execute the supplied vLLM/CUDA 13 stack, even if all packages are downloaded. No configuration flag or driver update adds the missing GPU architecture. Native and the cu118 Transformers profile are its supported targets. A6000 is SM 8.6; the vLLM package stack requires the newer driver. No GPU engine/model execution was performed during local delivery validation.

Package versions remain frozen in the existing per-engine lock and artifact files. New combined profiles compose those exact isolated stacks. Sources: [Transformers Qwen3.5 documentation](https://huggingface.co/docs/transformers/v5.13.0/model_doc/qwen3_5), [vLLM supported models](https://docs.vllm.ai/en/v0.31.0/models/supported_models/), [bitsandbytes hardware support](https://huggingface.co/docs/bitsandbytes/installation).
