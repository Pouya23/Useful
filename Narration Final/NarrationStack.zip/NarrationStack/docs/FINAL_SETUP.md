# Final resumable setup

Run `setup.sh` from the complete NarrationStack folder. It prepares the host environments or container artifacts and images. It does not start narration servers or containers. Keep the existing downloaded packages, `.part` files, model files, conda roots, `LLM/runtime`, `.env`, and job data.

## Resume your current test device

The supplied logs show LLM downloads under `LLM Packages`, TTS downloads under `TTS Downloads`, and bootstrap roots `/home/ali/miniconda-LLM` and `/home/ali/miniconda-TTS`. TTS environment creation succeeded; the last failure was downloading Typer after intermittent SSL resets, not a demonstrated speech-generation failure. The commands below reuse those paths. Replace the proxy value if it has changed.

```bash
cd /mnt/hard/home/toroghi/NarrationStack
export DOWNLOAD_PROXY="socks5h://192.168.20.20:1088"
export DOWNLOAD_JOBS=1
export DOWNLOAD_RETRIES=10
export DOWNLOAD_RETRY_DELAY=3
bash setup.sh --mode host \
  --download-dir "/mnt/hard/home/toroghi/Narration Downloads" \
  --llm-download-dir "/mnt/hard/home/toroghi/NarrationStack/LLM Packages" \
  --tts-download-dir "/mnt/hard/home/toroghi/NarrationStack/TTS Downloads" \
  --llm-conda-root "/home/ali/miniconda-LLM" \
  --tts-conda-root "/home/ali/miniconda-TTS" \
  --llm-profile compatible --gpu 0
```

Run this same command again after a network interruption. Serial downloading is the default for the unstable proxy. A checking/preparing message is not evidence of a network download: valid files print reuse messages. A completed `.part` is promoted after SHA256 verification, so the manually downloaded NumPy file is retained. Incomplete downloads resume. SSL/reset failures are retried in Python/Bash and do not depend on the unsupported curl 7.68 `--retry-all-errors` flag. Only HTTP 416/range errors or a completed wrong-checksum artifact trigger a restart of that individual artifact; HTTP 403/404 does not delete partial data. Invalid files are quarantined for inspection.

## Fresh Ubuntu 20.04 device

Install a working NVIDIA driver before GPU execution. The current GTX 1080 Ti driver 535.183.01 satisfies the native/Transformers/TTS profiles. The same profiles support A6000; vLLM additionally requires driver 580.65.06 or newer. The setup preserves the installed driver. If there is no driver yet, install an appropriate NVIDIA driver using your Ubuntu/NVIDIA administration procedure and reboot before GPU checks.

```bash
cd /your/path/NarrationStack
nvidia-smi
export DOWNLOAD_PROXY="socks5h://PROXY_IP:PROXY_PORT"
# Prefer a proxy CA if needed; curl insecure mode is an explicit choice:
# export CURL_CA_BUNDLE="/path/to/proxy-ca.pem"
# export CURL_INSECURE=1
bash setup.sh --mode host \
  --download-dir "/srv/narration-downloads" \
  --llm-profile auto --gpu 0
```

No preinstalled Python or Python packages are needed. The script installs missing curl/CA/compiler OS prerequisites via apt, bootstraps checksum-pinned Python 3.11.11, and installs all application packages offline after curl downloads. If apt is inaccessible, transfer/install its matching OS `.deb` prerequisites first using the deployment guide. `auto` chooses native plus Transformers unless both the GPU and driver meet the vLLM requirement, in which case it prepares all three. Explicit `compatible` is recommended for the GTX 1080 Ti; explicit `all` targets a suitably configured A6000.

## What rerunning skips

- Existing checksum-pinned bootstrap roots and valid Python 3.11.11 environment prefixes are reused.
- Installed wheel distributions with the exact pinned versions are skipped; only missing/different versions are installed. Pinned source builds additionally require a provenance stamp, so an older unverified same-version Kokoro may be rebuilt once.
- Complete verified downloads and complete `.part` files are reused. Partial files resume. CUDA/model/package downloads remain at the selected locations.
- Verified FFmpeg extraction is reused. Native compilation is skipped when the build configuration and executable checksum match. A compiler/toolkit/configuration change gets an incremental or separate build directory without deleting prior builds.
- Complete pinned HF/TTS model manifests and their checksums are verified offline before any model download is requested. This verification reads files and can take time on a slow disk; it does not retransmit them.
- Docker reuses its matching layers. Changing application source or build inputs can rebuild the affected image layers.

Package checks and small GPU probes still run to detect an inconsistent environment. Setup never deletes a conda environment, downloaded model or job directory. An incomplete conda prefix is reported with its exact path so it can be preserved/moved aside or a new root can be chosen.

## Activate and run LLM

For your current device:

```bash
cd /mnt/hard/home/toroghi/NarrationStack/LLM
source /home/ali/miniconda-LLM/etc/profile.d/conda.sh
conda activate /home/ali/miniconda-LLM/envs/LLM
source runtime/activate_python.sh
source runtime/activate_native.sh
python --version

# Native GGUF engine:
python run_pipeline.py --engine llama_cpp \
  --server "$LLAMA_SERVER" \
  --gguf-model "/mnt/hard/home/toroghi/NarrationStack/LLM Packages/models/llm/Qwen3.5-9B-Q5_K_M.gguf" \
  --duration-seconds 60 --context-tokens 8192

# Transformers worker is selected automatically from the engine registry:
python run_pipeline.py --engine transformers \
  --model "/mnt/hard/home/toroghi/NarrationStack/LLM Packages/models/hf" \
  --duration-seconds 60 --context-tokens 8192 --dtype auto
```

Keep the original prompt, source, sample, seed, round and fitting options as described in the LLM guide. The two engines can generate different text from the same seed; sampling behavior and acceptance policies are preserved, not an assertion of identical neural output.

## Activate and run TTS

```bash
cd /mnt/hard/home/toroghi/NarrationStack/TTS
source /home/ali/miniconda-TTS/etc/profile.d/conda.sh
conda activate /home/ali/miniconda-TTS/envs/TTS
source runtime/activate_tools.sh
export CUDA_VISIBLE_DEVICES=0
python ../containers/check_gpu.py --profile tts --torch --required
python run_server.py \
  --model-dir "/mnt/hard/home/toroghi/NarrationStack/TTS Downloads/models/Kokoro-82M" \
  --data-dir "/mnt/hard/home/toroghi/narration-state/tts" \
  --device cuda:0 --host 127.0.0.1 --port 8082 \
  --max-vram-gb 2 --cuda-reserve-mb 512 --max-chunk-seconds 10
```

This explicit run command starts TTS only when you execute it. Existing API specifications and Kokoro sample-exact natural planning remain intact. Installed runtime versions and timing profiles can change ETAs; neither download success nor the small CUDA probe verifies speech quality.

## Container preparation and existing download reuse

```bash
cd /mnt/hard/home/toroghi/NarrationStack
export DOWNLOAD_PROXY="socks5h://192.168.20.20:1088"
bash setup.sh --mode containers \
  --download-dir "/mnt/hard/home/toroghi/container-downloads" \
  --llm-download-dir "/mnt/hard/home/toroghi/NarrationStack/LLM Packages" \
  --tts-download-dir "/mnt/hard/home/toroghi/NarrationStack/TTS Downloads" \
  --llm-profile compatible --no-build-images
```

Compatible wheel filenames/digests are copied or hard-linked from the supplied existing caches rather than downloaded again. Model directory layouts differ between host and containers; compatible large checkpoint files are reused when their frozen SHA256 is known. Already complete container model manifests skip their downloads entirely. Missing metadata/voice/model files are fetched as needed.

Use `.env.example` as the template for `.env`, preserve your existing keys and paths, and set `DOWNLOAD_DIR` to the container artifact directory, `STATE_DIR` to the desired persistent state directory, `LLM_PROFILE=compatible`, and `LLM_ENGINE=llama_cpp`. On a supported A6000 use `LLM_PROFILE=all` to permit all three request engines. Then build:

```bash
bash containers/build.sh
```

Install Docker/NVIDIA host prerequisites, perform GPU checks, and start services using the complete deployment guide. Preparation and build scripts never run `docker compose up`. Existing `.env` is never overwritten. If it is missing, container setup copies the template and asks you to configure it before building; this is required because artifact/state paths and credentials are deployment-specific.

## Setup switches

`--no-models` skips model preparation; `--no-build-native` skips the host CUDA build; `--no-build-images` stages container artifacts only; `--skip-gpu-check` is for intentional CPU-only staging. `--llm-download-dir`, `--tts-download-dir`, `--llm-conda-root`, `--tts-conda-root`, `--state-dir`, `--proxy`, and `--gpu` select deployment paths/connectivity. The profile choices are `native`, `transformers`, `vllm`, `compatible`, `all`, or hardware-aware `auto`.

## Timestamped output bases

LLM `run_pipeline.py --output /path/base` treats the value as a reusable base. Each invocation creates a `run_YYYYMMDDTHHMMSSffffffZ_RANDOM` subdirectory; generated job subdirectories, narration rounds, final text/JSON and telemetry filenames contain the UTC timestamp. Repeating the same output argument does not overwrite a previous run or fail because its directory exists. Read the exact selected path printed by the CLI.

TTS `run_server.py --output /path/base` is an alias for `--data-dir`. Every newly generated job and its request, frozen plan, result and MP3 artifacts get timestamped names. The LLM API launcher also accepts `api_server.py --output /path/base`; generated job/event artifacts use timestamped names. API UUIDs, progress URLs and MP3 download routes remain stable; persistent state records the actual artifact directory, and existing jobs with legacy paths remain readable.

State databases, GPU/process locks and service root directories retain their operational names so restarting with the same base preserves queue recovery, idempotency and calibration. They are not generated narration/audio artifacts. Run one service process per state directory as before; timestamps do not bypass the pipeline's GPU/process admission controls.
