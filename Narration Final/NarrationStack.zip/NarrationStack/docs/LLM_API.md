# LLM API contract — backend handoff

Base URL: `http://LLM_SERVER:8081` by default. Content type: `application/json`. If configured, send `X-API-Key: LLM_API_KEY`. Functional endpoints are `/generate` and `/progress`; `/docs/`, `/openapi.json` and `/health` are operational documentation/readiness routes.

The static schema is `llm-openapi.json`. The live schema reflects the deployed authentication setting. JSON uses **snake_case**, not the CLI's hyphenated flags. Unknown fields are rejected. Boolean values must be JSON booleans, not strings.

## POST /generate

Required field: `duration_seconds`. All fields with defaults may be omitted. `async` defaults to true.

```json
{
  "duration_seconds": 180,
  "title": "Maintenance of pipe handling systems",
  "instructions": "Write clear spoken training from the supplied references.",
  "point": ["Report defects and follow approved procedures."],
  "sources": [{"id":"site","text":"Paste the approved source here.","description":"Site reference"}],
  "samples": ["An optional example of the desired writing style."],
  "max_retries": 5,
  "estimate": true,
  "async": true
}
```

Async accepted response: **HTTP 202**.

```json
{"success":true,"job_id":"32_lowercase_hex_characters","status":"queued","progress_url":"/progress?job_id=..."}
```

`success:true` means the generation job was accepted, not that it is complete or already within tolerance. Queue capacity failures use HTTP 503; invalid input uses 422. One worker processes jobs sequentially and keeps its model resident while engine settings remain identical.

### Configuration fields

| Fields | Default / constraints |
|---|---|
| `duration_seconds` | Required positive number; accurate mode ≤1800 seconds |
| `title`, `instructions` | Same original CLI defaults |
| `point` | Array of required coverage strings, default `[]` |
| `samples` | Array of inline style texts, default `[]` |
| `sources` | Array of `{id,text,description}` references; IDs unique |
| `sample`, `source` | Arrays of mounted UTF-8 filenames under `/inputs`; optional alternative/addition to inline fields |
| `speaking_rate_wpm` | 130, range 40–300 |
| `duration_tolerance` | 0.10, range 0–0.5; estimated word-band tolerance |
| `speech_duration_tolerance` | 0.10, range 0–0.5; natural-duration tolerance for accurate mode |
| `estimate` | true; false invokes the configured TTS `/duration` API |
| `max_retries` | 5; nonnegative number of revisions **after** the initial draft |
| `max_rounds` | Optional positive total-generation limit **including** the draft; overrides max_retries |
| `seed` | 42; each attempted generation increments the seed |
| `engine` | Deployed `LLM_ENGINE`, normally llama_cpp; transformers/vllm require their image profile |
| `model`, `model_revision` | Mounted/cached HF model and optional commit, for HF engines |
| `gguf_model` | Deployed GGUF path under `/models`, for native engine |
| `model_sha256` | Optional 64-hex required GGUF digest |
| `server` | Deployed native binary under `/opt/llama/bin` |
| `worker_python` | Optional; must equal the image's interpreter. Change image profile to change environments |
| `gpu_index` | 0 only, because exactly one GPU is visible to the container |
| `context_tokens` | Deployment default (8192 in initial Compose setup), 512–262144 |
| `max_output_tokens` | Automatic original allowance unless explicitly supplied; no silent truncation |
| `dtype` | auto; alternatives float16/bfloat16 |
| `kv_cache_device` | Deployment default (cpu initially), alternative gpu |
| `prefill_chunk_tokens` | 512, positive integer |
| `vram_limit_gb`, `headroom_gb` | Deployment defaults; finite positive decimal GB, reserve below ceiling |
| `show_progress` | false; console display option; SSE works independently |
| `output` | Optional relative artifact subdirectory under the job; no arbitrary filesystem output paths |
| `async` | true returns JSON; false returns SSE |

Accurate-mode settings:

| Field | Default |
|---|---|
| `duration_api_host` | Compose service `tts` |
| `duration_api_port` | 8000 **inside Compose**, not external port 8082 |
| `duration_api_key` | Configured TTS key from deployment; optional per-request override |
| `duration_api_scheme` | http; https supported |
| `duration_api_timeout` | 120 seconds |
| `duration_api_use_proxy` | false |
| `voice`, `lang_code` | am_onyx / a; matching American or British voice |
| `speech_speed` | 1.0, range 0.25–4 |
| `atempo_min`, `atempo_max` | 0.93 / 1.15, range 0.125–8 and min ≤ max |

Acceptance compares word count to the original duration/WPM tolerance band when `estimate:true`. When false, it compares **`estimated_natural_duration_s`** from TTS to target × (1 ± speech tolerance). It never uses the stretched final target as its plausibility measurement.

It stops at the first in-range generation. At retry exhaustion it returns the saved candidate closest to the acceptable band, breaking ties by target error and earlier round. Completed jobs may therefore have `fit.within_range:false`; that is a valid best-at-limit result. If an API candidate cannot be measured within TTS's input limits, it cannot win an accurate-mode selection. Transport failures or no measurable candidate produce a failed job with saved artifacts.

## Synchronous SSE: async=false

Use the same POST endpoint/payload with `"async":false`. Response: **HTTP 200**, `Content-Type: text/event-stream`, header `X-Job-Id`. It is one continuous SSE connection across all rounds; a retry does not require opening another HTTP request.

```text
id: 1
event: accepted
data: {"job_id":"...","success":true,"status":"queued"}

id: 2
event: round_start
data: {"job_id":"...","round_index":0,"maximum_rounds":6,"reset_text":true}

id: 3
event: token
data: {"job_id":"...","round_index":0,"text":"Reliable ","token_ids":null,"unit":"backend_delta"}

event: round_end
data: {"job_id":"...","round_index":0,"stage":"draft","fit":{"within_range":false,"distance":12,"automatic_action":"expand"}}

event: retry
data: {"job_id":"...","round_index":0,"next_round_index":1,"reason":"outside_tolerance","remaining_retries":5,"fit":{...}}

event: round_start
data: {"job_id":"...","round_index":1,"maximum_rounds":6,"reset_text":true}

event: completed
data: {"job_id":"...","success":true,"result":{"text":"Selected final narration...","fit":{...},"fit_summary":{...}}}
```

| Event | Backend handling |
|---|---|
| `accepted` | Store job_id immediately |
| `round_start` | Begin a new provisional round buffer; round_index is zero-based |
| `token` | Apply live text delta/token IDs to that round |
| `round_end` | Record validated round fit metrics |
| `retry` | Notify UI/logic that this round missed tolerance; next round follows |
| `completed` | Replace provisional output with `result.text`; this may come from an earlier round |
| `error` | Terminal failure: `{success:false,error:{code,message}}`; retain job_id for artifacts/progress |

The native engine forwards real server content deltas immediately; an SSE delta is not necessarily exactly one tokenizer token and it does not expose token IDs. It is **not** a replay of a finished response. Transformers sends each generated token ID immediately; text can be empty until its official decoder has a complete word/Unicode boundary. vLLM sends newly generated IDs/text from live engine scheduler steps. `unit` identifies `backend_delta`, `model_token` or `decoder_flush`. Do not equate delta/event count with token count. If a vLLM decoder revises a suffix, optional `replace_from` is a character offset: replace the current round's suffix at that offset with `text`; otherwise append `text`.

SSE output is provisional until final round validation/fit selection. Incomplete/truncated or control-token output can fail after partial deltas were observed. Only `completed.result.text` is authoritative accepted text.

Events have monotonically increasing IDs within the job. Heartbeats are SSE comments `: heartbeat` and should be ignored by the event parser. Once SSE headers are sent, failures arrive as `error` events rather than a changed HTTP status. A disconnected client does not cancel inference. There is no SSE reconnect endpoint in this two-endpoint contract; recover final state/text via `/progress`.

Use `fetch`/a POST-capable SSE client; browser `EventSource` cannot POST a JSON request. Disable intermediary response buffering/compression and use sufficiently long timeouts. Swagger shows the operation/schema but is not a dedicated live-token UI.

## GET or POST /progress

```json
{"job_id":"UUID"}
```

`{"uuid":"UUID"}` is also accepted. UUIDs may be 32-hex or standard hyphenated strings; returned IDs use lowercase 32-hex. GET uses `?job_id=UUID` or `?uuid=UUID`.

Response: HTTP 200 for any existing queued/running/completed/failed job.

```json
{
  "success":true,
  "job_id":"...",
  "status":"running",
  "stage":"generating",
  "round_index":1,
  "progress_percent":24.5,
  "queue_position":0,
  "elapsed_seconds":12.3,
  "progress_is_estimate":true,
  "progress_basis":"fraction of maximum round budget, using word progress within each round",
  "result":null,
  "error":null
}
```

Progress is monotonic, stays below 100 while running, and becomes 100 only on completion. It uses the maximum round budget because actual retry count is unknowable in advance; early acceptance legitimately jumps to 100. It is not an exact fraction of elapsed GPU work or a quality probability. Queued jobs start at 0; failed jobs keep their last percentage with `success:false` and an error. Unknown UUID: 404; invalid UUID: 422.

On completion, `result` includes final `text`, `word_count`, `estimated_duration_seconds`, `fit`, `fit_summary`, source/overlap warnings and artifact location. `fit_summary.selected_round_index` identifies the winning saved round; `stopped_in_range` is the acceptance flag.

## Curl examples

```bash
# Async:
curl --noproxy '*' -H "X-API-Key: $LLM_API_KEY" -H 'Content-Type: application/json' \
  -d '{"duration_seconds":180,"async":true,"max_retries":5}' \
  http://127.0.0.1:8081/generate

# Live SSE:
curl --noproxy '*' --no-buffer -H "X-API-Key: $LLM_API_KEY" -H 'Content-Type: application/json' \
  -d '{"duration_seconds":180,"async":false,"estimate":false,"speech_duration_tolerance":0.05}' \
  http://127.0.0.1:8081/generate

# Final state/result:
curl --noproxy '*' -H "X-API-Key: $LLM_API_KEY" \
  'http://127.0.0.1:8081/progress?job_id=YOUR_JOB_ID'
```
