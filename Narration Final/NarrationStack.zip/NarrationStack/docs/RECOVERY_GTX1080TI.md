# Resume the failed installation on your test server

Your log identifies Ubuntu 20.04.6, a GTX 1080 Ti (11264 MiB, SM 6.1), and driver 535.183.01. The failing command never created LLM: an external Anaconda Terms-of-Service plugin attempted to fetch `tos.json` despite `--offline`. Afterwards, the parent shell still used your existing Miniconda base and Python 3.9.17.

The corrected installers disable external conda plugins, select the built-in classic solver, use the pinned bootstrap's own retained package cache, create environments by absolute prefix, and activate that exact prefix. They do not modify your existing `/home/ali/miniconda3` or its `.condarc`. This is an offline clone of already downloaded packages; disabling that network hook does not constitute acceptance of any channel terms.

## 1. Extract this corrected archive into a fresh source directory

For example, place it under `/mnt/hard/home/toroghi/corrected/NarrationStack`. Keep existing downloaded packages and the successfully installed `/home/ali/miniconda-LLM`; neither needs deletion. Keep the entire archive directory structure because both installers use the shared `containers/` helpers.

## 2. Rerun LLM setup, reusing your completed bootstrap/downloads

```bash
cd /mnt/hard/home/toroghi/corrected/NarrationStack/LLM
export DOWNLOAD_DIR="/mnt/hard/home/toroghi/NarrationStack/LLM Packages"
export CONDA_ROOT="/home/ali/miniconda-LLM"
export PROFILE=native
export CUDA_VISIBLE_DEVICES=0
export DOWNLOAD_PROXY="socks5h://YOUR_PROXY_IP:YOUR_PROXY_PORT"
# If necessary, choose ONE of these according to your proxy:
# export CURL_CA_BUNDLE="/path/to/proxy-ca.pem"
# export CURL_INSECURE=1
bash install_ubuntu.sh

# A child Bash script cannot activate your parent interactive shell.
# Run these commands yourself AFTER installation succeeds:
source "$CONDA_ROOT/etc/profile.d/conda.sh"
conda activate "$CONDA_ROOT/envs/LLM"
source runtime/activate_python.sh
python --version                 # must print Python 3.11.11
python -m pip check
```

If the installer reports an incomplete environment directory, preserve/move aside only the printed `.../envs/LLM` directory, then rerun. Your pasted failure occurred before environment creation, so this normally is unnecessary. Do not remove the bootstrap, package cache, or your old Python environment.

## 3. Build native CUDA support and download the LLM

```bash
sudo apt-get update
sudo apt-get install -y build-essential curl ca-certificates
export CUDA_ARCHS="61;86"   # test GTX 1080 Ti plus final A6000
export BUILD_JOBS=4
bash build_native.sh
source runtime/activate_native.sh
"$LLAMA_SERVER" --version
python download_model.py --kind gguf --download-dir "$DOWNLOAD_DIR/models/llm"
```

The installer now downloads **CUDA Toolkit 12.2.2** into `DOWNLOAD_DIR/cuda-12.2.2`, installs **the toolkit only**, and preserves driver 535.183.01. Native CUDA build outputs from the previous CUDA 12.4 setup should be rebuilt with the corrected script. If choosing an existing toolkit, set `CUDA_ROOT` explicitly to that compatible toolkit; avoid pointing at a 12.4/13.x installation on this test driver.

For the CLI invocation and all model/input/fit options, follow `LLM/INSTALL.md`. For the combined HTTP services, use `docs/DEPLOYMENT.md`; the container route creates its own environments and does not need these host environment installations.

## 4. Install TTS in its own pinned environment

```bash
cd /mnt/hard/home/toroghi/corrected/NarrationStack/TTS
export DOWNLOAD_DIR="/mnt/hard/home/toroghi/TTS Packages"
export CONDA_ROOT="/home/ali/miniconda-TTS"
bash install_ubuntu.sh
source "$CONDA_ROOT/etc/profile.d/conda.sh"
conda activate "$CONDA_ROOT/envs/TTS"
source runtime/activate_tools.sh
python --version
python -m pip check
python ../containers/check_gpu.py --profile tts --torch --required
python download_models.py --model-dir "$DOWNLOAD_DIR/models/Kokoro-82M"
```

The installer executes a small real CUDA matrix/Conv1d/LSTM probe when `nvidia-smi` is available. This catches missing CUDA kernels, driver initialization and cuDNN linkage errors before service startup. It does not synthesize speech. Use `CHECK_GPU=0` only for intentional CPU-only artifact preparation and repeat the required probe on your GPU server.

For standalone TTS server settings, follow `TTS/INSTALL.md`. Its GPU lock defaults to a writable directory under its selected data directory. The Docker stack explicitly binds both services to `/gpu-locks` for shared-GPU coordination.

## Versions selected for the identified hardware

| Component/profile | Pinned build | GTX 1080 Ti / driver 535.183.01 | A6000 |
| --- | --- | --- | --- |
| Python in both environments | 3.11.11 | Yes | Yes |
| Native LLM toolkit/base image | CUDA 12.2.2, SM 61/75/86 | Selected default | Supported |
| TTS Torch + torchaudio | 2.5.1+cu121, CUDA 12.1 | Selected default | Supported |
| Optional Transformers LLM Torch | 2.6.0+cu118, CUDA 11.8 | Compatible package target; use auto/float16 | Supported |
| Optional vLLM | 0.31.0 / Torch 2.13.0 / CUDA 13.0 | Unsupported; preflight rejects it | Requires driver 580.65.06 or newer |

The CUDA version shown by `nvidia-smi` is the driver's maximum advertised CUDA compatibility; it does not identify an installed toolkit or the CUDA version bundled inside Torch. Keep the **native** profile for your initial one-GPU test. Pascal has no native bfloat16 or tensor cores; the optional Transformers path uses float16 under `dtype=auto`. Explicit unsupported bfloat16 requests now produce a clear error.

Your log also contains a global `/usr/local/cuda/lib64` library path. The generated activation fragments and container entrypoint prefer the selected environment's pinned Torch/NVIDIA libraries before inherited library paths. Source the indicated fragment after activating an environment to avoid mixing it with another installed CUDA toolkit.

All transitive application versions and frozen wheel URLs/SHA256 are in `LLM/locks/*` and `TTS/requirements*`. The corrected nvJitLink dependency is pinned to 12.1.105. A separate shared-HTTP/vLLM `referencing` version conflict was also corrected. `containers/dependency-audit.json` reports each standalone and merged container closure.

Sources: [NVIDIA CUDA 12.2.2 release notes](https://docs.nvidia.com/cuda/archive/12.2.2/cuda-toolkit-release-notes/index.html), [official PyTorch build versions](https://pytorch.org/get-started/previous-versions/), [bitsandbytes hardware support](https://huggingface.co/docs/bitsandbytes/installation). GPU execution on your server remains the final verification; no remote execution or container startup was performed while preparing this archive.
