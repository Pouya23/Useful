# Exact file replacement checklist

This compares the new source delivery with the previously delivered NarrationStack ZIP. Files edited independently on your device may differ; the update tool compares their actual SHA256 and backs up every replaced file. No downloaded packages, partial downloads, model weights, environments, compiled runtime directories, job state or existing `.env` should be removed.

## Apply safely on the current device

Stop the existing narration service processes before updating their source. Extract this ZIP into a separate staging directory, yielding `/mnt/hard/home/toroghi/staging/NarrationStack`; do not extract inside the live NarrationStack directory, which creates an unwanted nested copy. If unzip is missing, install it with `sudo apt-get install -y unzip`. For example:

```bash
mkdir -p /mnt/hard/home/toroghi/staging
unzip /path/to/new/NarrationStack.zip -d /mnt/hard/home/toroghi/staging
PYTHON=/home/ali/miniconda-TTS/envs/TTS/bin/python
"$PYTHON" /mnt/hard/home/toroghi/staging/NarrationStack/apply_update.py \
  --destination /mnt/hard/home/toroghi/NarrationStack --dry-run
"$PYTHON" /mnt/hard/home/toroghi/staging/NarrationStack/apply_update.py \
  --destination /mnt/hard/home/toroghi/NarrationStack
```

This preserves unchanged files and saves replaced originals under `_update-backups/TIMESTAMP/`. It validates the entire source manifest before copying. Use a fresh staging directory for each delivery. On a fresh device, extract directly into the chosen project parent and run `setup.sh` as described in [FINAL_SETUP.md](FINAL_SETUP.md); the update tool is only needed for an existing installation with Python 3.11 available.

Then run the current-device command in [FINAL_SETUP.md](FINAL_SETUP.md). It reuses existing package/model downloads and environment prefixes and performs only missing or changed installation/build work. Review `.env.example` against your existing `.env` manually; the update tool never replaces `.env`.

## Which documents to give the backend team

Give them only **NarrationStack_Backend_Handoff.docx** from this `docs/` directory: two A4 pages covering both APIs, with full schemas embedded. It supersedes the earlier external `NarrationStack_Backend_Handoff.html` and the combined backend handoff drafts. Those obsolete handoff copies can be archived or removed; they are not runtime inputs. Keep the setup/deployment/recovery documents for operations. Existing API Markdown files remain reference material, with the Word file serving as the final backend handoff.

An accidental nested `NarrationStack/NarrationStack` source copy was excluded from the delivery; it is not an active dependency. Do not delete unknown files in it without checking whether you stored anything there. The update tool leaves it untouched.

## Exact source inventory

Paths below are relative to the project root. `docs/replacements.json` contains the same classification for tooling. The delivery checksum manifest is regenerated with the final archive.

### Replace these files (38)

- `.dockerignore`
- `LLM/INSTALL.md`
- `LLM/api_app.py`
- `LLM/api_contracts.py`
- `LLM/api_server.py`
- `LLM/api_service.py`
- `LLM/api_store.py`
- `LLM/build_native.sh`
- `LLM/compare_engines.py`
- `LLM/download_packages.py`
- `LLM/install_ubuntu.sh`
- `LLM/pipeline_core/cli.py`
- `LLM/pipeline_core/engines/vllm.py`
- `LLM/pipeline_core/llama_session.py`
- `LLM/pipeline_core/pipeline.py`
- `LLM/pipeline_core/process.py`
- `LLM/pipeline_core/session.py`
- `LLM/tests/test_adapters.py`
- `README.md`
- `TTS/INSTALL.md`
- `TTS/app.py`
- `TTS/cli.py`
- `TTS/download_packages.py`
- `TTS/install_ubuntu.sh`
- `TTS/jobs.py`
- `TTS/prepare_install.py`
- `TTS/tests/test_service.py`
- `containers/Dockerfile`
- `containers/download_assets.py`
- `containers/install_offline.py`
- `containers/prepare.sh`
- `docs/BACKEND_INTEGRATION.md`
- `docs/DEPLOYMENT.md`
- `docs/LLM_API.md`
- `docs/RECOVERY_GTX1080TI.md`
- `docs/VALIDATION.md`
- `docs/llm-openapi.json`
- `DELIVERY_SHA256.json`

### Add these files (18)

- `LLM/pipeline_core/artifacts.py`
- `LLM/pipeline_core/engines/registry.py`
- `apply_update.py`
- `containers/artifact_download.py`
- `containers/curl_retry.sh`
- `containers/install_llm_profiles.py`
- `containers/model_complete.py`
- `containers/output_paths.py`
- `docs/ENGINES.md`
- `docs/FINAL_SETUP.md`
- `docs/NarrationStack_Backend_Handoff.docx`
- `docs/REPLACEMENTS.md`
- `docs/replacements.json`
- `setup.sh`
- `tests/test_apply_update.py`
- `tests/test_engine_setup.py`
- `tests/test_output_paths.py`
- `tests/test_resumable_downloads.py`

### These files need no replacement (92)

- `.env.example`
- `LLM/CHANGES_AND_VALIDATION.md`
- `LLM/PIPELINE_MAP.md`
- `LLM/README.md`
- `LLM/cpu_benchmark.json`
- `LLM/download_model.py`
- `LLM/locks/audit.json`
- `LLM/locks/native-artifacts.json`
- `LLM/locks/native.txt`
- `LLM/locks/transformers-artifacts.json`
- `LLM/locks/transformers.txt`
- `LLM/locks/vllm-artifacts.json`
- `LLM/locks/vllm.txt`
- `LLM/maintenance_example.py`
- `LLM/pipeline_core/__init__.py`
- `LLM/pipeline_core/display.py`
- `LLM/pipeline_core/duration.py`
- `LLM/pipeline_core/duration_api.py`
- `LLM/pipeline_core/engines/__init__.py`
- `LLM/pipeline_core/engines/base.py`
- `LLM/pipeline_core/engines/llama_cpp.py`
- `LLM/pipeline_core/engines/transformers.py`
- `LLM/pipeline_core/fit.py`
- `LLM/pipeline_core/length.py`
- `LLM/pipeline_core/model.py`
- `LLM/pipeline_core/progress.py`
- `LLM/pipeline_core/prompts.py`
- `LLM/pipeline_core/requests.py`
- `LLM/pipeline_core/runtime.py`
- `LLM/pipeline_core/telemetry.py`
- `LLM/pipeline_core/worker.py`
- `LLM/pipeline_core/writer.py`
- `LLM/requirements-native.in`
- `LLM/requirements-transformers.in`
- `LLM/requirements-vllm.in`
- `LLM/run_pipeline.py`
- `LLM/tests/__init__.py`
- `LLM/tests/conftest.py`
- `LLM/tests/requirements.txt`
- `LLM/tests/test_duration_engines.py`
- `LLM/tests/test_fit.py`
- `LLM/tests/test_improvements.py`
- `LLM/tests/test_progress.py`
- `LLM/tests/test_prompt_parity.py`
- `LLM/tests/test_writer.py`
- `TTS/CHANGES_AND_VALIDATION.md`
- `TTS/FFMPEG_BUILD.txt`
- `TTS/PIPELINE_MAP.md`
- `TTS/README.md`
- `TTS/contracts.py`
- `TTS/demo_client.py`
- `TTS/dependency_audit.json`
- `TTS/download_models.py`
- `TTS/examples/duration.json`
- `TTS/examples/generate.json`
- `TTS/examples/generate_sync.json`
- `TTS/examples/sample_text_10.txt`
- `TTS/examples/sample_text_100.txt`
- `TTS/examples/sample_text_500.txt`
- `TTS/export_openapi.py`
- `TTS/kokoro_fit_core.py`
- `TTS/native-artifacts.json`
- `TTS/openapi.json`
- `TTS/requirements-artifacts.json`
- `TTS/requirements.in`
- `TTS/requirements.lock`
- `TTS/run_server.py`
- `TTS/tests/conftest.py`
- `TTS/tests/test_optimizations.py`
- `TTS/tests/test_waveform_buffer.py`
- `TTS/verification/http_smoke.py`
- `TTS/verification/real_cpu_smoke.py`
- `compose.yaml`
- `containers/build.sh`
- `containers/check_gpu.py`
- `containers/common-artifacts.json`
- `containers/common.in`
- `containers/common.lock`
- `containers/conda_offline.sh`
- `containers/dependency-audit.json`
- `containers/download_host.sh`
- `containers/entrypoint.sh`
- `containers/export_openapi.py`
- `containers/gpu_gate.py`
- `containers/host-artifacts.json`
- `containers/nginx-example.conf`
- `containers/write_runtime_env.py`
- `docs/TTS_API.md`
- `docs/tts-openapi.json`
- `tests/test_conda_offline.sh`
- `tests/test_environment_setup.py`
- `tests/test_llm_api.py`

### Old source paths absent from this delivery (0)

None.
