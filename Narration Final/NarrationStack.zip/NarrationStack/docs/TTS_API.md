# TTS API contract — backend handoff

Base URL: `http://TTS_SERVER:8082` by default. JSON requests use `Content-Type: application/json`. If configured, send `X-API-Key: TTS_API_KEY`. Functional endpoints: `/duration`, `/generate`, `/progress`. Swagger `/docs/`, schema `/openapi.json`, operational `/health`. Static schema: `tts-openapi.json`.

One resident compatible Kokoro model serves a durable FIFO queue. Duration planning and synthesis share the GPU execution gate with the LLM; final MP3 encoding is CPU work.

## Common generation specification

```json
{
  "text":"The final decision required patience, clear evidence, and careful judgment.",
  "desired_duration":5,
  "voice":"am_onyx",
  "lang_code":"a",
  "speed":1.0,
  "atempo_min":0.93,
  "atempo_max":1.15,
  "split_pattern":"\\n+",
  "seed":42,
  "sample_rate":48000,
  "bitrate_kbps":320
}
```

Only `text` and `desired_duration` are required. All other fields above may be omitted to use these defaults. The literal split pattern string is backslash+n+ (JSON `"\\n+"`), not a string containing an actual newline.

| Field | Validation |
|---|---|
| `text` | 10–1000 whitespace-delimited words; ≤100,000 characters |
| `desired_duration` | Numeric seconds >0 and ≤1800 |
| `voice` | Installed English Kokoro preset; pattern `[ab][fm]_[a-z]+` |
| `lang_code` | a=American, b=British; must match voice prefix |
| `speed` | Native Kokoro speed 0.25–4, separate from FFmpeg tempo |
| `atempo_min`, `atempo_max` | Each 0.125–8; min ≤ max |
| `split_pattern` | Only literal `\n+` or null |
| `seed` | Integer 0–2³²−1 |
| `sample_rate` | 8000,11025,12000,16000,22050,24000,32000,44100,48000 |
| `bitrate_kbps` | 64,96,128,160,192,224,256,320; ≤160 when sample rate <32000 |

Extra fields, string booleans/numbers in strict fields and invalid combinations are rejected with HTTP 422. `voice` selects a preset of the deployment's model; switching architecture/model is an administrator/deployment operation, not an arbitrary per-request file load.

## POST /duration — JSON only, never audio

Send the common specification, without `async` or `generate`. The endpoint runs phonemization and integer-duration prediction only; it does not run the speech decoder or FFmpeg and creates no generation job.

Natural duration is the frozen Kokoro sample plan at 24 kHz. Required multiplier = natural duration / target duration. Allowed tempo bounds are inclusive.

Planning success always uses **HTTP 200**, even when tempo fit is impossible:

```json
{
  "success":true,
  "reason":null,
  "duration_s":5.0,
  "duration_kind":"fitted_target",
  "estimated_natural_duration_s":5.25,
  "natural_samples":126000,
  "natural_sample_rate":24000,
  "desired_duration_s":5.0,
  "estimated_final_duration_s":5.0,
  "atempo_factor":1.05,
  "atempo_min":0.93,
  "atempo_max":1.15,
  "chunk_count":1,
  "natural_duration_is_sample_exact":true,
  "final_duration_is_sample_exact":false,
  "waveform_generated":false,
  "estimated_generation_time_s":1.63,
  "estimated_encoding_time_s":1.5,
  "eta_source":"uncalibrated_default",
  "calibration_samples":0,
  "eta_is_guaranteed":false,
  "planning_time_s":0.08,
  "duration_estimate_kind":"Kokoro frozen natural duration; FFmpeg tempo-ratio target for final MP3"
}
```

If the multiplier is out of range, `success:false`, `reason:"too_short"` or `"too_long"`, and **`duration_s` is the natural unatempoed speech duration**, with `duration_kind:"natural_unatempoed"`. `estimated_natural_duration_s` is always included. `estimated_final_duration_s` remains the mathematical stretch target and is not evidence that a permitted fit exists. Invalid specs/planning failures return HTTP 422 with `{success:false,error:{code,message,details?}}`.

The LLM's accurate length check uses the natural-duration field, not the stretched target. Natural planning precision does not make encoded MP3 duration sample-exact.

## POST /generate — async job or synchronous MP3

Send the common specification plus `async` (default true). The former `generate:true` field is optional for compatibility; if supplied it must be true.

### async=true

If fit succeeds, **HTTP 202**:

```json
{"success":true,"job_id":"32_hex_uuid","status":"queued","progress_url":"/progress?job_id=...","idempotent_replay":false,"estimated_final_duration_s":5.0,"estimated_generation_time_s":1.63,"waveform_generated":false}
```

The actual response also contains the preview fields. Accepted means planned/queued; waveform generation is done by the background worker afterward. Persist the UUID, then poll `/progress`.

If fit fails, HTTP **422** with `success:false`, reason and natural duration; no job is created. Queue/request capacity failure is 503 (`Retry-After` may be provided). Invalid input: 422.

Optional `Idempotency-Key` header, 1–128 letters/digits/`_.:-`: the same key/spec returns the same job ID and HTTP 200 JSON with `idempotent_replay:true`; a changed specification under that key returns 409. Failed jobs remain associated with their key; use a new key to explicitly retry a failed job.

### async=false

The server validates/plans fit, then holds the request until its durable worker completes the job. Success: **HTTP 200**, `Content-Type: audio/mpeg`, attachment MP3, headers **`X-Job-Id`** and `X-Success:true`. No initial JSON acceptance body is sent on this path.

Fit failure still returns 422 JSON without generation. A generation failure returns HTTP 500 JSON with job_id/status/error. A wait timeout returns HTTP 504 JSON; retrieve existing job state where a UUID was already obtained, or use idempotency to avoid unintentionally duplicating work. Set backend/proxy timeouts long enough for queued synthesis (the server's synchronous wait deadline is 1800 seconds). If using sync mode, `Idempotency-Key` is recommended.

## GET or POST /progress

POST body: `{"job_id":"UUID"}` or `{"uuid":"UUID"}`. GET query: `?job_id=UUID` or `?uuid=UUID`. Standard hyphenated/32-hex UUIDs are accepted; canonical responses use 32-hex.

```json
{
  "success":true,
  "job_id":"...",
  "status":"running",
  "stage":"synthesizing",
  "progress_percent":45.2,
  "elapsed_generation_time_s":3.1,
  "time_remaining_s":3.76,
  "estimated_queue_wait_s":0,
  "queue_position":0,
  "estimated_generation_time_s":6.86,
  "eta_source":"current_job_chunk_timing",
  "eta_is_guaranteed":false,
  "eta_overrun":false,
  "completed_chunks":2,
  "total_chunks":5,
  "estimated_final_duration_s":180,
  "result":null,
  "error":null
}
```

Running progress is based on **elapsed generation time / estimated total runtime**, capped below 100 and monotonic. ETA starts from configured/calibrated real-time factor and encoding overhead, then adapts to observed chunk timings. Queued jobs have 0% progress and remaining time including estimated wait for preceding jobs. Remaining time is approximate; `time_remaining_s:0` during an overrun does **not** mean completion—check `status` and `eta_overrun`.

On completion: status completed, 100%, zero remaining time. `result` includes `audio_url`, actual natural/final durations, final target error percentage, synthesis/encoding timing and Torch allocator peaks. On failure: `success:false`, status failed, error details, last recorded percentage. Unknown UUID: 404; malformed UUID: 422.

To download the completed MP3:

```text
GET /progress?job_id=UUID&download=true
POST /progress {"job_id":"UUID","download":true}
```

Response: HTTP 200 audio/mpeg after completion; 409 before completion/after failure; 410 if the stored MP3 was removed. Final duration comes from ffprobe container timing and is approximate, even though natural waveform sample count exactly matches its frozen plan.

## Curl examples

```bash
curl --noproxy '*' -H "X-API-Key: $TTS_API_KEY" -H 'Content-Type: application/json' \
  --data-binary @TTS/examples/duration.json http://127.0.0.1:8082/duration

# Async; add/remove the async field explicitly as desired:
curl --noproxy '*' -H "X-API-Key: $TTS_API_KEY" -H 'Content-Type: application/json' \
  --data-binary @TTS/examples/generate.json http://127.0.0.1:8082/generate

# Sync JSON file contains async:false; save audio only if HTTP succeeds:
curl --noproxy '*' --fail --max-time 1800 -H "X-API-Key: $TTS_API_KEY" \
  -H 'Content-Type: application/json' -H 'Idempotency-Key: speech-001' \
  --data-binary @TTS/examples/generate_sync.json \
  -D response-headers.txt -o speech.mp3 http://127.0.0.1:8082/generate

curl --noproxy '*' -H "X-API-Key: $TTS_API_KEY" \
  'http://127.0.0.1:8082/progress?job_id=YOUR_JOB_ID'
```
