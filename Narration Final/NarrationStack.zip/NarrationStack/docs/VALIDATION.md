# Delivery validation

Validated with Python **3.11.11** on the development Windows machine:

| Suite | Result |
| --- | --- |
| LLM pipeline regression suite | 73 passed |
| TTS pipeline regression suite | 44 passed |
| Container/API/environment integration suite | 43 passed |
| Offline conda command-wrapper regression | Passed |
| Eight standalone/merged dependency closures | Passed |
| Both exported OpenAPI schemas | Specification validation passed |
| Python source compilation | Passed |
| Bash preparation/build/download scripts | Syntax checks passed |
| Docker Compose configuration | Configuration validation passed |

The new integration tests cover persisted rounds, closest-round selection, asynchronous jobs, UUID aliases, restart recovery, authentication, validation, bounded queues, live native SSE deltas, native prompt-cache preservation, vLLM scheduler deltas, and accurate-mode HTTP interoperability with the TTS request contract. The accurate-mode test also verifies that the GPU gate is released before the LLM calls the duration service.

The corrected installation adds hardware/driver admission tests for the reported GTX 1080 Ti / 535.183.01 and A6000, exact artifact/pin consistency checks, CUDA family/nvJitLink regressions and a no-failure audit of the Python 3.11 dependency closure for all profiles and their shared HTTP overlays. Official Torch wheel METADATA was read to determine the actual cu121/cu118 dependencies. Full neural wheels were not installed/executed on this Windows machine.

Update-tool tests verify backups, unchanged-file skipping, dry runs, protected runtime paths and all-before-write checksum validation. Update-tool tests verify backups, unchanged-file skipping, dry runs, protected runtime paths and all-before-write checksum validation. Update-tool tests verify backups, unchanged-file skipping, dry runs, protected runtime paths and all-before-write checksum validation. Additional checks exercise combined-profile worker selection and HTTP interpreter allowlists, completed-package installation skipping, model provenance/corruption detection, completed-partial promotion, SSL/reset retry without curl's unsupported retry-all-errors option, HTTP 404 preservation, HTTP 416 recovery and timestamped output reuse/reloading. The LLM and TTS store schemas add an artifact-directory column while preserving legacy job paths. The two-page API-only Word handoff was opened and rendered by Microsoft Word, rasterized with the packaged document renderer's PNG stage, and visually inspected on both A4 pages. The Word file embeds both full OpenAPI schemas, whose extracted bytes match the standalone exports.

The Bash wrapper regression uses a command spy with an already-active unrelated base, a wrong shared package cache and paths containing spaces. It verifies absolute cloning, disabled plugins, classic solver, local cache, environment reuse and protection of incomplete prefixes. This is **not** an executed Linux Miniconda clone. Actual server installation remains to be verified by rerunning the corrected installer; the included GPU probe then executes small real CUDA matrix/Conv1d/LSTM operations on that machine.

Neural engines are substituted in these tests; they do not measure model quality, GPU throughput, real acoustic output, or GPU peak memory. The existing TTS planning tests validate sample accounting and fit behavior without claiming a deployed checkpoint run.

**No containers were started.** Docker image builds, the Linux process-shared `flock` gate, NVIDIA device access, compiled CUDA kernels, actual token streaming under GPU inference, and end-to-end MP3 generation remain server-side verification steps in `DEPLOYMENT.md`. The local Linux Docker daemon was stopped and this machine did not provide an NVIDIA GPU. There are no measured GPU speedup claims.

The one-GPU execution gate serializes neural work; it does not free resident model weights or enforce a physical VRAM partition. Both models and their caches must fit concurrently. The provided small-card settings are conservative starting values, not a guarantee for the GTX 1080 Ti with desktop/display processes.

Pinned Python packages and downloaded artifacts have exact versions and SHA256 manifests. Versioned CUDA base tags and Ubuntu build-tool repositories are external inputs; for image-level reproducibility, record/pin the resolved base image digests and archive the built images. Build output records each active conda environment and installed Python packages in `/app/provenance`.

The static OpenAPI exports describe the default unauthenticated configuration and omit installed voice discovery. Live `/openapi.json` reflects configured authentication and available voices. The human API guides define the SSE event payloads and authoritative final-round behavior in more detail.

Tests can be repeated with the supplied pinned test dependencies in separate processes:

```bash
docker compose run --rm --no-deps llm python -m pytest tests -q
docker compose run --rm --no-deps tts python -m pytest tests -q
```

These two commands start temporary containers only when **you** execute them. The cross-service integration tests in the top-level `tests/` directory can be run in a development Python 3.11 environment containing `containers/common.lock`; they use fake models and a loopback HTTP server.
