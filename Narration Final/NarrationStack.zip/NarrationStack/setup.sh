#!/usr/bin/env bash
# Resumable preparation only. Never starts narration servers or containers.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE=host
DOWNLOAD_DIR="${DOWNLOAD_DIR:-}"
LLM_DOWNLOAD_DIR="${LLM_DOWNLOAD_DIR:-}"
TTS_DOWNLOAD_DIR="${TTS_DOWNLOAD_DIR:-}"
LLM_CONDA_ROOT="${LLM_CONDA_ROOT:-$HOME/miniconda-LLM}"
TTS_CONDA_ROOT="${TTS_CONDA_ROOT:-$HOME/miniconda-TTS}"
LLM_PROFILE="${LLM_PROFILE:-auto}"
STATE_DIR="${STATE_DIR:-$ROOT/state}"
BUILD_NATIVE=1
BUILD_IMAGES=1
DOWNLOAD_MODELS="${DOWNLOAD_MODELS:-1}"
while (($#)); do
  case "$1" in
    --mode) MODE="$2"; shift 2;;
    --download-dir) DOWNLOAD_DIR="$2"; shift 2;;
    --llm-download-dir) LLM_DOWNLOAD_DIR="$2"; shift 2;;
    --tts-download-dir) TTS_DOWNLOAD_DIR="$2"; shift 2;;
    --llm-conda-root) LLM_CONDA_ROOT="$2"; shift 2;;
    --tts-conda-root) TTS_CONDA_ROOT="$2"; shift 2;;
    --llm-profile) LLM_PROFILE="$2"; shift 2;;
    --state-dir) STATE_DIR="$2"; shift 2;;
    --proxy) export DOWNLOAD_PROXY="$2"; shift 2;;
    --gpu) export GPU_DEVICE_ID="$2" CUDA_VISIBLE_DEVICES="$2"; shift 2;;
    --skip-gpu-check) export CHECK_GPU=0; shift;;
    --no-models) DOWNLOAD_MODELS=0; shift;;
    --no-build-native) BUILD_NATIVE=0; shift;;
    --no-build-images) BUILD_IMAGES=0; shift;;
    --help) echo 'See docs/FINAL_SETUP.md. Required: --download-dir PATH. Modes: host, containers. Profiles: auto, native, compatible, transformers, vllm, all.'; exit 0;;
    *) echo "Unknown option: $1" >&2; exit 2;;
  esac
done
[[ "$MODE" == host || "$MODE" == containers ]] || { echo 'Mode must be host or containers' >&2; exit 2; }
: "${DOWNLOAD_DIR:?Pass --download-dir PATH or export DOWNLOAD_DIR}"
[[ "$(uname -m)" == x86_64 ]] || { echo 'This bundle targets Linux x86_64' >&2; exit 2; }
mkdir -p "$DOWNLOAD_DIR"
DOWNLOAD_DIR="$(cd -- "$DOWNLOAD_DIR" && pwd)"
export DOWNLOAD_DIR DOWNLOAD_MODELS STATE_DIR
if [[ "$LLM_PROFILE" == auto ]]; then
  LLM_PROFILE=compatible
  if command -v nvidia-smi >/dev/null; then
    if nvidia-smi -i "${GPU_DEVICE_ID:-0}" --query-gpu=driver_version,compute_cap --format=csv,noheader,nounits \
      | awk -F, '{split($1,d,"."); if(d[1]>=580 && $2+0>=7.5)exit 0; exit 1}'; then LLM_PROFILE=all; fi
  fi
fi
case "$LLM_PROFILE" in native|transformers|vllm|compatible|all) ;; *) echo 'Invalid LLM profile' >&2; exit 2;; esac
export LLM_PROFILE
echo "Setup mode=$MODE, LLM profile=$LLM_PROFILE; completed artifacts and stages will be reused."
missing=()
command -v curl >/dev/null || missing+=(curl)
[[ -f /etc/ssl/certs/ca-certificates.crt ]] || missing+=(ca-certificates)
if [[ "$MODE" == host && "$BUILD_NATIVE" == 1 ]]; then
  for tool in gcc g++ make; do command -v "$tool" >/dev/null || missing+=(build-essential); done
fi
if ((${#missing[@]})); then
  sudo apt-get update
  sudo apt-get install -y "${missing[@]}"
fi
cd "$ROOT"
if [[ "$MODE" == containers ]]; then
  cache_llm="${LLM_DOWNLOAD_DIR:-$DOWNLOAD_DIR/LLM}"
  cache_tts="${TTS_DOWNLOAD_DIR:-$DOWNLOAD_DIR/TTS}"
  export NARRATION_DOWNLOAD_CACHE_DIRS="$cache_llm/wheels-common:$cache_llm/wheels-native:$cache_llm/wheels-transformers:$cache_llm/wheels-vllm:$cache_tts/wheels:$cache_llm/models/llm:$cache_tts/models/Kokoro-82M"
  bash containers/prepare.sh
  if [[ "$BUILD_IMAGES" == 1 ]]; then
    if [[ ! -f .env ]]; then
      cp .env.example .env
      echo 'Created .env; set its paths, keys and LLM_PROFILE to the value printed above, then run containers/build.sh. Nothing started.'
      exit 0
    fi
    command -v docker >/dev/null || { echo 'Artifacts ready. Install the staged Docker/NVIDIA packages using DEPLOYMENT.md, then rerun.'; exit 0; }
    env_profile="$(bash -c 'source "$1"; printf "%s" "${LLM_PROFILE:-native}"' bash "$ROOT/.env")"
    env_download="$(bash -c 'source "$1"; printf "%s" "${DOWNLOAD_DIR:-}"' bash "$ROOT/.env")"
    if [[ "$env_profile" != "$LLM_PROFILE" || "$env_download" != "$DOWNLOAD_DIR" ]]; then
      echo "Artifacts ready. Preserve your keys/state settings, but set .env LLM_PROFILE=$LLM_PROFILE and DOWNLOAD_DIR=$DOWNLOAD_DIR before building." >&2
      exit 2
    fi
    docker info >/dev/null 2>&1 || { echo 'Artifacts ready; Linux Docker daemon is unavailable. Follow DEPLOYMENT.md and rerun when it is available.'; exit 0; }
    bash containers/build.sh
  fi
  exit 0
fi
LLM_DOWNLOAD_DIR="${LLM_DOWNLOAD_DIR:-$DOWNLOAD_DIR/LLM}"
TTS_DOWNLOAD_DIR="${TTS_DOWNLOAD_DIR:-$DOWNLOAD_DIR/TTS}"
export NARRATION_DOWNLOAD_CACHE_DIRS="$LLM_DOWNLOAD_DIR:$TTS_DOWNLOAD_DIR:$LLM_DOWNLOAD_DIR/wheels-common:$LLM_DOWNLOAD_DIR/wheels-native:$LLM_DOWNLOAD_DIR/wheels-transformers:$LLM_DOWNLOAD_DIR/wheels-vllm:$TTS_DOWNLOAD_DIR/wheels:$LLM_DOWNLOAD_DIR/models:$LLM_DOWNLOAD_DIR/models/llm:$TTS_DOWNLOAD_DIR/models/Kokoro-82M"
(export DOWNLOAD_DIR="$LLM_DOWNLOAD_DIR" CONDA_ROOT="$LLM_CONDA_ROOT" PROFILE="$LLM_PROFILE"; bash LLM/install_ubuntu.sh)
LLM_PYTHON="$LLM_CONDA_ROOT/envs/LLM/bin/python"
if [[ "$BUILD_NATIVE" == 1 ]]; then
  (export DOWNLOAD_DIR="$LLM_DOWNLOAD_DIR"; source "$LLM_CONDA_ROOT/etc/profile.d/conda.sh"; conda activate "$LLM_CONDA_ROOT/envs/LLM"; source LLM/runtime/activate_python.sh; bash LLM/build_native.sh)
fi
(export DOWNLOAD_DIR="$TTS_DOWNLOAD_DIR" CONDA_ROOT="$TTS_CONDA_ROOT"; bash TTS/install_ubuntu.sh)
if [[ "$DOWNLOAD_MODELS" == 1 ]]; then
  if ! "$LLM_PYTHON" containers/model_complete.py --kind gguf --directory "$LLM_DOWNLOAD_DIR/models/llm"; then
    "$LLM_PYTHON" LLM/download_model.py --kind gguf --download-dir "$LLM_DOWNLOAD_DIR/models/llm"
  fi
  if [[ "$LLM_PROFILE" != native ]] && ! "$LLM_PYTHON" containers/model_complete.py --kind hf --directory "$LLM_DOWNLOAD_DIR/models/hf"; then
    "$LLM_PYTHON" LLM/download_model.py --kind hf --download-dir "$LLM_DOWNLOAD_DIR/models/hf"
  fi
  TTS_PYTHON="$TTS_CONDA_ROOT/envs/TTS/bin/python"
  if ! "$TTS_PYTHON" containers/model_complete.py --kind tts --directory "$TTS_DOWNLOAD_DIR/models/Kokoro-82M"; then
    "$TTS_PYTHON" TTS/download_models.py --model-dir "$TTS_DOWNLOAD_DIR/models/Kokoro-82M"
  fi
fi
echo 'Preparation complete. No servers or containers started. Follow docs/FINAL_SETUP.md to activate and use them.'
