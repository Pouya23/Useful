import hashlib
import importlib.util
import json
from pathlib import Path

import pytest

spec = importlib.util.spec_from_file_location(
    'delivery_update', Path(__file__).resolve().parents[1] / 'apply_update.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def bundle(source, files):
    source.mkdir()
    manifest = {}
    for name, content in files.items():
        path = source / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        manifest[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    (source / 'DELIVERY_SHA256.json').write_text(json.dumps(manifest))


def test_update_backs_up_changed_files_and_preserves_runtime_data(tmp_path):
    source, target, backup = [tmp_path / n for n in ('source', 'target', 'backup')]
    bundle(source, {'code.py': 'new', 'same.py': 'same', 'docs/new.md': 'added'})
    target.mkdir()
    (target / 'code.py').write_text('old')
    (target / 'same.py').write_text('same')
    (target / '.env').write_text('private config')
    (target / 'state').mkdir()
    (target / 'state/job').write_text('result')
    original_time = (target / 'same.py').stat().st_mtime_ns
    assert len(module.apply(source, target, backup)) == 2
    assert (backup / 'code.py').read_text() == 'old'
    assert (target / 'code.py').read_text() == 'new'
    assert (target / 'same.py').stat().st_mtime_ns == original_time
    assert (target / '.env').read_text() == 'private config'
    assert (target / 'state/job').read_text() == 'result'
    assert not module.apply(source, target, backup)


def test_dry_run_writes_nothing(tmp_path):
    source, target = tmp_path / 'source', tmp_path / 'target'
    bundle(source, {'main.py': 'new'})
    assert len(module.apply(source, target, dry_run=True)) == 1
    assert not target.exists()


@pytest.mark.parametrize('name', ['.env', 'state/job', '../escape'])
def test_protected_or_escaping_path_is_rejected_before_writing(tmp_path, name):
    source, target = tmp_path / 'source', tmp_path / 'target'
    source.mkdir()
    (source / 'DELIVERY_SHA256.json').write_text(json.dumps({name: 'invalid'}))
    with pytest.raises(ValueError, match='Unsafe/protected'):
        module.apply(source, target)
    assert not target.exists()


def test_checksum_failure_does_not_partially_apply(tmp_path):
    source, target = tmp_path / 'source', tmp_path / 'target'
    bundle(source, {'first.py': 'valid', 'last.py': 'valid'})
    (source / 'last.py').write_text('corrupt')
    with pytest.raises(ValueError, match='checksum mismatch'):
        module.apply(source, target)
    assert not target.exists()
