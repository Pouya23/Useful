#!/usr/bin/env bash
# Exercise the offline wrapper against a command spy, including the reported
# preexisting base/user cache conditions. Does not run conda or contact a server.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${TEST_TMP_DIR:?Choose a writable test fixture directory}"
mkdir -p "$TEST_TMP_DIR"
FIXTURE="$(mktemp -d "$TEST_TMP_DIR/conda-wrapper.XXXXXX")"
BOOTSTRAP="$FIXTURE/bootstrap with spaces"
mkdir -p "$BOOTSTRAP/bin" "$BOOTSTRAP/pkgs"
BOOTSTRAP="$(cd -- "$BOOTSTRAP" && pwd)"
cat > "$BOOTSTRAP/bin/conda" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
[[ "$CONDA_NO_PLUGINS" == true && "$CONDA_SOLVER" == classic && "$CONDA_OFFLINE" == true ]]
[[ "$CONDA_PKGS_DIRS" == "$SPY_BOOTSTRAP/pkgs" && "$CONDA_ENVS_PATH" == "$SPY_BOOTSTRAP/envs" ]]
[[ "$*" == *'--no-plugins create --offline --yes --solver classic --no-default-packages --prefix'* ]]
prefix=""
while (($#)); do
  if [[ "$1" == --prefix ]]; then prefix="$2"; shift; fi
  if [[ "$1" == --clone ]]; then [[ "$2" == "$SPY_BOOTSTRAP" ]]; fi
  shift
done
[[ "$prefix" == "$SPY_BOOTSTRAP/envs/LLM" ]]
printf 'clone\n' >> "$SPY_BOOTSTRAP/calls"
mkdir -p "$prefix/conda-meta" "$prefix/bin"
touch "$prefix/conda-meta/history"
cat > "$prefix/bin/python" <<'PY'
#!/usr/bin/env bash
[[ "$1" == -I && "$2" == -c && "$3" == *'(3,11,11)'* ]]
PY
chmod +x "$prefix/bin/python"
SH
chmod +x "$BOOTSTRAP/bin/conda"
export SPY_BOOTSTRAP="$BOOTSTRAP"
export CONDA_PREFIX="$FIXTURE/old-base" CONDA_EXE=/wrong/conda
export CONDA_PKGS_DIRS="$FIXTURE/wrong-shared-cache"
source "$ROOT/containers/conda_offline.sh"
clone_offline_env "$BOOTSTRAP" LLM
clone_offline_env "$BOOTSTRAP" LLM
[[ "$(wc -l < "$BOOTSTRAP/calls")" == 1 ]]
mkdir -p "$BOOTSTRAP/envs/TTS"
if clone_offline_env "$BOOTSTRAP" TTS; then
  echo 'An incomplete environment must fail explicitly.' >&2
  exit 1
fi
[[ -d "$BOOTSTRAP/envs/TTS" ]]
echo 'Offline conda wrapper regression passed: absolute prefix, local cache, no plugins, classic solver, reuse, partial-prefix protection.'
