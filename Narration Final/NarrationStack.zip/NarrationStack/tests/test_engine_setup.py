import importlib.util
import json
from pathlib import Path
import sys

import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'LLM'),str(ROOT/'containers')]
from pipeline_core.engines.registry import engine_workers, resolve_worker
from api_contracts import GenerateRequest
from api_service import engine_settings
from install_llm_profiles import profiles_for
import install_offline
from model_complete import complete


def registry(tmp_path,monkeypatch,workers):
    path=tmp_path/'engines.json'
    path.write_text(json.dumps({'schema_version':1,'workers':workers}))
    monkeypatch.setenv('LLM_ENGINE_REGISTRY',str(path))
    return path


def test_cli_auto_worker_and_http_allowlist(tmp_path,monkeypatch):
    worker=tmp_path/'isolated python'
    worker.touch()
    registry(tmp_path,monkeypatch,{'llama_cpp':sys.executable,'transformers':str(worker)})
    monkeypatch.setenv('LLM_PROFILE','compatible')
    assert resolve_worker('transformers')==str(worker)
    spec=GenerateRequest(duration_seconds=60,engine='transformers')
    assert engine_settings(spec,check_paths=False).worker_python==str(worker)
    with pytest.raises(ValueError,match='registered'):
        engine_settings(GenerateRequest(duration_seconds=60,engine='transformers',worker_python=sys.executable),check_paths=False)


def test_absent_engine_has_actionable_error(tmp_path,monkeypatch):
    registry(tmp_path,monkeypatch,{'llama_cpp':sys.executable})
    with pytest.raises(ValueError,match='profile=compatible'):
        resolve_worker('transformers')


def test_registry_rejects_relative_or_unknown_interpreters(tmp_path,monkeypatch):
    registry(tmp_path,monkeypatch,{'evil':'python'})
    with pytest.raises(ValueError,match='absolute'):
        engine_workers()


@pytest.mark.parametrize('profile,expected', [('native',['native']),('compatible',['native','transformers']),('all',['native','transformers','vllm'])])
def test_profile_closure(profile,expected):
    assert profiles_for(profile)==expected


def test_completed_package_layer_skips_pip_install(tmp_path,monkeypatch,capsys):
    wheels=tmp_path/'wheels'; wheels.mkdir()
    (wheels/'manifest.json').write_text(json.dumps([{'name':'example','version':'1.0','filename':'example.whl','sha256':'a'*64}]))
    monkeypatch.setattr(install_offline.sys,'prefix',str(tmp_path))
    monkeypatch.setattr(install_offline,'installed_version',lambda _: '1.0')
    calls=[]
    monkeypatch.setattr(install_offline.subprocess,'run',lambda args,**kw: calls.append(args))
    monkeypatch.setattr(sys,'argv',['install_offline',str(wheels)])
    install_offline.main()
    assert len(calls)==1 and calls[0][-2:]==['pip','check']
    assert 'skipped package installation' in capsys.readouterr().out


def test_hf_provenance_reuse_and_corruption(tmp_path):
    import hashlib
    files={'config.json':b'{}','weights.safetensors':b'weights'}
    for name,data in files.items(): (tmp_path/name).write_bytes(data)
    (tmp_path/'download-provenance.json').write_text(json.dumps({'repository':'Qwen/Qwen3.5-9B',
        'revision':'c202236235762e1c871ad0ccb60c8ee5ba337b9a','files':[{'filename':n,'sha256':hashlib.sha256(b).hexdigest()} for n,b in files.items()]}))
    assert complete('hf',tmp_path)
    (tmp_path/'weights.safetensors').write_bytes(b'corrupted')
    assert not complete('hf',tmp_path)
