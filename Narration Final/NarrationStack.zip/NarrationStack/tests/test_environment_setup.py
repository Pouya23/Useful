import importlib.util
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
loader = importlib.util.spec_from_file_location("gpu_preflight", ROOT / "containers/check_gpu.py")
preflight = importlib.util.module_from_spec(loader)
loader.loader.exec_module(preflight)


@pytest.mark.parametrize("profile", ["native", "tts", "transformers"])
def test_reported_test_device_is_accepted(profile):
    preflight.validate_device(profile, (6, 1), "535.183.01")


def test_pascal_rejects_vllm_even_with_new_driver():
    with pytest.raises(RuntimeError, match="compute capability"):
        preflight.validate_device("vllm", (6, 1), "580.105.01")


def test_a6000_vllm_driver_requirement():
    with pytest.raises(RuntimeError, match="driver"):
        preflight.validate_device("vllm", (8, 6), "535.183.01")
    preflight.validate_device("vllm", (8, 6), "580.65.06")


@pytest.mark.parametrize("relative", ["containers/common.lock", "TTS/requirements.lock",
                                    "LLM/locks/native.txt", "LLM/locks/transformers.txt", "LLM/locks/vllm.txt"])
def test_frozen_artifacts_match_exact_pins(relative):
    lock = ROOT / relative
    pins = dict(line.split("==", 1) for line in lock.read_text().splitlines() if line.strip())
    manifest = json.loads(lock.with_name(lock.stem + "-artifacts.json").read_text())
    assert len(manifest) == len(pins)
    assert {a["name"]: a["version"] for a in manifest} == pins
    assert all(len(a["sha256"]) == 64 and a["url"].startswith("https://") for a in manifest)


def test_cuda_pins_include_transitive_nvjitlink_and_only_one_toolkit():
    tts = (ROOT / "TTS/requirements.lock").read_text()
    transformers = (ROOT / "LLM/locks/transformers.txt").read_text()
    assert "torch==2.5.1+cu121\n" in tts
    assert "torchaudio==2.5.1+cu121\n" in tts
    assert "nvidia-nvjitlink-cu12==12.1.105\n" in tts
    assert "12.4.127" not in tts
    assert "torch==2.6.0+cu118\n" in transformers
    assert "nvidia-cuda-runtime-cu11==11.8.89\n" in transformers
    assert "nvidia-cuda-runtime-cu12" not in transformers


def test_every_dependency_audit_passes():
    audit = json.loads((ROOT / "containers/dependency-audit.json").read_text())
    assert len(audit["profiles"]) == 8
    assert not any(p["failures"] for p in audit["profiles"].values())
