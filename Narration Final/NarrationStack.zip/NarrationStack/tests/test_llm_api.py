import importlib.util
import json
from pathlib import Path
import re
import sys
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "LLM"), str(ROOT / "containers")]
import pytest
from api_contracts import GenerateRequest
from api_app import create_app, openapi_document
from api_service import LlmService
from pipeline_core.pipeline import FastWritingJob

loader = importlib.util.spec_from_file_location("llm_fixtures", ROOT / "LLM/tests/test_writer.py")
fixtures = importlib.util.module_from_spec(loader)
loader.loader.exec_module(fixtures)


class FakeSession:
    def __init__(self, settings, *, output, render, outputs):
        self.output, self.render = Path(output), render
        self.outputs = outputs
        self.closed = False
    def __enter__(self):
        self.output.mkdir(parents=True)
        self.backend = fixtures.MeasuredFake(self.output, self.outputs)
        self.backend.server = SimpleNamespace(token_callback=None)
        original = self.backend.complete
        def complete(*a, **k):
            result = original(*a, **k)
            for piece in re.findall(r"\S+\s*", result["text"]):
                callback = self.backend.server.token_callback
                if callback:
                    callback({"text": piece, "token_ids": None, "unit": "fixture"})
            return result
        self.backend.complete = complete
        return self
    def new_job(self, request, **kwargs):
        import uuid
        return FastWritingJob(self.backend, request, self.output / "jobs" / uuid.uuid4().hex, render=self.render, **kwargs)
    def close(self):
        self.closed = True


def service_for(tmp_path, outputs, start=True):
    return LlmService(tmp_path, session_factory=lambda *a,**k:FakeSession(*a,**k,outputs=outputs),
                      validate_paths=False, start_worker=start)


def wait(service, job_id):
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        state = service.store.get(job_id)
        if state["status"] in {"completed", "failed"}:
            return state
        time.sleep(.01)
    raise AssertionError(service.store.get(job_id))


def test_sse_retry_best_round_and_persistence(tmp_path):
    service = service_for(tmp_path, [fixtures.text(110), fixtures.text(40)])
    try:
        response = create_app(service).test_client().post("/generate",json={
            "duration_seconds":60, "async":False, "max_retries":1})
        assert response.status_code == 200 and response.mimetype == "text/event-stream"
        events = [json.loads(line[6:]) for line in response.get_data(as_text=True).splitlines() if line.startswith("data: ")]
        job_id = events[0]["job_id"]
        journal = [json.loads(line) for line in (service.store.directory(job_id)/"events.jsonl").read_text().splitlines()]
        names = [e["event"] for e in journal]
        assert names[0] == "accepted" and names[-1] == "completed"
        assert names.count("retry") == 1 and names.count("round_start") == 2
        assert names.index("token") < names.index("round_end") < names.index("retry")
        final = wait(service,job_id)
        assert final["progress_percent"] == 100
        assert final["result"]["fit_summary"]["selected_round_index"] == 0
        assert final["result"]["text"] == fixtures.text(110)
        assert Path(final["result"]["artifact_directory"],"final.txt").is_file()
        assert response.headers["X-Job-Id"] == job_id
    finally:
        service.close()


def test_async_and_uuid_alias(tmp_path):
    service = service_for(tmp_path,[fixtures.text(130)])
    try:
        client=create_app(service).test_client()
        response=client.post("/generate",json={"duration_seconds":60})
        assert response.status_code==202 and response.json["success"]
        job_id=response.json["job_id"]
        assert len(job_id)==32
        assert wait(service,job_id)["result"]["fit"]["within_range"]
        assert client.post("/progress",json={"uuid":job_id}).json["status"]=="completed"
        assert client.get("/progress?uuid="+job_id).status_code==200
        assert client.get("/progress?job_id="+'0'*32).status_code==404
        assert client.post("/progress",json={"job_id":"../private"}).status_code==422
    finally:
        service.close()


def test_invalid_request_and_queue_limit(tmp_path,monkeypatch):
    monkeypatch.setenv('LLM_MAX_PENDING_JOBS','1')
    service=service_for(tmp_path,[fixtures.text(130)],start=False)
    try:
        client=create_app(service).test_client()
        assert client.post('/generate',json={'duration_seconds':60,'async':'false'}).status_code==422
        assert client.post('/generate',json={'duration_seconds':0}).status_code==422
        assert client.post('/generate',json={'duration_seconds':60,'bogus':1}).status_code==422
        assert client.post('/generate',json={'duration_seconds':60}).status_code==202
        assert client.post('/generate',json={'duration_seconds':60}).status_code==503
    finally: service.close()


def test_authentication_and_schema(tmp_path,monkeypatch):
    monkeypatch.setenv('LLM_API_KEY','private-test-key')
    service=service_for(tmp_path,[fixtures.text(130)],start=False)
    try:
        client=create_app(service).test_client()
        assert client.post('/generate',json={'duration_seconds':60}).status_code==401
        assert client.post('/generate',json={'duration_seconds':60},headers={'X-API-Key':'private-test-key'}).status_code==202
        assert client.get('/docs/').status_code==200
        from openapi_spec_validator import validate
        validate(openapi_document())
    finally: service.close()


def test_restart_fails_running_but_keeps_queued(tmp_path):
    service=service_for(tmp_path,[],start=False)
    first=service.submit(GenerateRequest(duration_seconds=60))
    service.store.claim()
    second=service.submit(GenerateRequest(duration_seconds=60))
    service.close()
    replacement=service_for(tmp_path,[],start=False)
    try:
        assert replacement.store.get(first)['error']['code']=='service_restarted'
        assert replacement.store.get(second)['status']=='queued'
    finally: replacement.close()


def test_native_stream_is_live_and_does_not_invent_stop(tmp_path):
    from pipeline_core.runtime import RuntimeConfig, LlamaServer
    server=LlamaServer(RuntimeConfig(server=tmp_path/'server',model=tmp_path/'model',device='cpu'))
    received=[]
    server.token_callback=received.append
    def chunks(*_):
        yield {'choices':[{'delta':{'content':'hello '}}]}
        assert received[0]['text']=='hello '
        yield {'choices':[{'delta':{'content':'world'}}]}
    server._iter_sse=chunks
    text,reason,usage=server._complete_stream({},100,5)
    assert text=='hello world' and reason=='length'
    assert len(received)==2


def test_gate_is_reentrant():
    from gpu_gate import GpuGate,CombinedLock
    import threading
    gate=GpuGate(enabled=False)
    lock=CombinedLock(threading.RLock(),gate)
    with lock:
        with lock:
            pass


def test_accurate_mode_calls_real_tts_http_contract_without_gpu_lock(tmp_path,monkeypatch):
    from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
    import threading
    # Load the TTS contract under a separate module name to avoid test-path collisions.
    spec=importlib.util.spec_from_file_location('tts_contract',ROOT/'TTS/contracts.py')
    contracts=importlib.util.module_from_spec(spec)
    sys.modules['tts_contract']=contracts
    spec.loader.exec_module(contracts)
    durations=iter([40.0,58.0])
    received=[]
    class Gate:
        active=False
        def __enter__(self): self.active=True
        def __exit__(self,*_): self.active=False
    gate=Gate()
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            assert not gate.active, 'LLM must release GPU gate before asking TTS for duration'
            body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            contracts.GenerationSpec.model_validate(body)
            received.append(body)
            payload=json.dumps({'estimated_natural_duration_s':next(durations),'success':False,'reason':'too_short'}).encode()
            self.send_response(200); self.send_header('Content-Length',str(len(payload))); self.end_headers(); self.wfile.write(payload)
        def log_message(self,*_): pass
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    service=LlmService(tmp_path,session_factory=lambda *a,**k:FakeSession(*a,**k,outputs=[fixtures.text(130),fixtures.text(140)]),
                       gate=gate,validate_paths=False)
    try:
        response=create_app(service).test_client().post('/generate',json={'duration_seconds':60,'estimate':False,
            'duration_api_host':'127.0.0.1','duration_api_port':server.server_port,'max_retries':2})
        result=wait(service,response.json['job_id'])
        assert result['status']=='completed',result
        assert result['result']['fit']['measured_duration_seconds']==58.0
        assert len(received)==2
        assert received[0]['split_pattern']==r'\n+'
    finally:
        service.close(); server.shutdown(); server.server_close(); thread.join()


def test_native_stream_retains_prefix_cache(tmp_path,monkeypatch):
    from pipeline_core.llama_session import FastLlamaServer
    from pipeline_core.runtime import RuntimeConfig,LlamaServer
    captured=[]
    def iterator(self,path,payload,timeout=None):
        captured.append(payload); yield {'choices':[]}
    monkeypatch.setattr(LlamaServer,'_iter_sse',iterator)
    server=FastLlamaServer(RuntimeConfig(server=tmp_path/'server',model=tmp_path/'model',device='cpu'))
    list(server._iter_sse('/v1/chat/completions',{'cache_prompt':False}))
    assert captured==[{'cache_prompt':True}]


def test_vllm_live_steps_forward_new_tokens(monkeypatch):
    from pipeline_core.engines.vllm import VllmEngine
    events=[]
    class Scheduler:
        index=0
        def add_request(self,request_id,*_): self.request_id=request_id
        def has_unfinished_requests(self): return self.index<2
        def step(self):
            if self.index==1:
                assert events and events[0]['text']=='one '
            self.index+=1
            output=SimpleNamespace(text='one ' if self.index==1 else 'one two',token_ids=[10] if self.index==1 else [10,11],finish_reason='stop')
            return [SimpleNamespace(request_id=self.request_id,outputs=[output],finished=self.index==2)]
        def abort_request(self,request_ids): pass
    engine=VllmEngine.__new__(VllmEngine)
    engine.token_callback=events.append
    engine.effective_context_size=512
    engine.tokenizer=SimpleNamespace(apply_chat_template=lambda *a,**k:'prompt',encode=lambda *a,**k:[1,2])
    engine.model=SimpleNamespace(llm_engine=Scheduler())
    monkeypatch.setitem(sys.modules,'vllm',SimpleNamespace(SamplingParams=lambda **k:k))
    result=engine.complete([],max_tokens=20,temperature=.7,top_p=.8,top_k=20,seed=42)
    assert [e['text'] for e in events]==['one ','two']
    assert [e['token_ids'] for e in events]==[[10],[11]]
    assert result['text']=='one two'
