from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'containers'))
from output_paths import artifact_path, new_artifact_dir, STAMP


def test_same_output_base_creates_distinct_timestamped_artifacts(tmp_path):
    first=new_artifact_dir(tmp_path/'output')
    second=new_artifact_dir(tmp_path/'output')
    assert first!=second
    for directory in (first,second):
        target=directory/'final.txt'
        target.write_text('generation')
        assert STAMP.search(directory.name) and STAMP.search(target.name)
        assert artifact_path(str(directory))/'final.txt'==target
    assert len(list((tmp_path/'output').glob('run_*')))==2


def test_nested_artifact_mapping_is_stable_after_reload(tmp_path):
    root=new_artifact_dir(tmp_path)
    directory=root/'jobs'/'aabbcc'
    directory.mkdir(parents=True)
    path=directory/'request.json'
    path.write_text('{}')
    assert (artifact_path(str(directory))/'request.json').read_text()=='{}'
    assert all(STAMP.search(p) for p in directory.relative_to(tmp_path).parts)
