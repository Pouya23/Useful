import hashlib
from pathlib import Path
import sys
from types import SimpleNamespace
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'containers'))
import artifact_download as downloader


def checksum(data): return hashlib.sha256(data).hexdigest()


def test_completed_partial_is_promoted_without_curl(tmp_path,monkeypatch):
    target=tmp_path/'numpy.whl'
    target.with_suffix('.whl.part').write_bytes(b'complete')
    monkeypatch.setattr(downloader.subprocess,'run',lambda *a,**k:pytest.fail('must not resume a complete partial'))
    downloader.download('https://example.test/wheel',target,checksum(b'complete'))
    assert target.read_bytes()==b'complete'


def test_verified_destination_is_reused(tmp_path,monkeypatch):
    target=tmp_path/'wheel'; target.write_bytes(b'complete')
    monkeypatch.setattr(downloader.subprocess,'run',lambda *a,**k:pytest.fail('must not redownload'))
    downloader.download('https://example.test/wheel',target,checksum(b'complete'))


def test_ssl_reset_retries_and_preserves_partial(tmp_path,monkeypatch):
    target=tmp_path/'wheel'; part=target.with_name('wheel.part')
    calls=[]
    def run(command,**_):
        calls.append(command)
        assert '--retry-all-errors' not in command
        if len(calls)==1:
            part.write_bytes(b'part')
            return SimpleNamespace(returncode=35,stdout='000')
        assert part.read_bytes()==b'part'
        part.write_bytes(b'complete')
        return SimpleNamespace(returncode=0,stdout='206')
    monkeypatch.setattr(downloader.subprocess,'run',run)
    monkeypatch.setattr(downloader.time,'sleep',lambda _:None)
    downloader.download('https://example.test/wheel',target,checksum(b'complete'))
    assert len(calls)==2 and target.read_bytes()==b'complete'


def test_http_404_keeps_partial_and_does_not_reset(tmp_path,monkeypatch):
    target=tmp_path/'wheel'; part=target.with_name('wheel.part'); part.write_bytes(b'part')
    monkeypatch.setattr(downloader.subprocess,'run',lambda *a,**k:SimpleNamespace(returncode=22,stdout='404'))
    with pytest.raises(RuntimeError,match='HTTP=404'):
        downloader.download('https://example.test/wheel',target,checksum(b'complete'))
    assert part.read_bytes()==b'part'


def test_range_failure_restarts_only_that_artifact(tmp_path,monkeypatch):
    target=tmp_path/'wheel'; part=target.with_name('wheel.part'); part.write_bytes(b'bad')
    calls=[]
    def run(*_,**__):
        calls.append(1)
        if len(calls)==1: return SimpleNamespace(returncode=22,stdout='416')
        assert not part.exists()
        part.write_bytes(b'complete')
        return SimpleNamespace(returncode=0,stdout='200')
    monkeypatch.setattr(downloader.subprocess,'run',run)
    monkeypatch.setattr(downloader.time,'sleep',lambda _:None)
    downloader.download('https://example.test/wheel',target,checksum(b'complete'))
    assert len(list(tmp_path.glob('wheel.part.invalid-*')))==1
