#!/usr/bin/env bash
# Package working host files. No network, pip, conda, apt or compiler invocation.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
LLM_ENV="${LLM_ENV:-/home/ali/miniconda-LLM/envs/LLM}"
TTS_ENV="${TTS_ENV:-/home/ali/miniconda-TTS/envs/TTS}"
CONTEXT="${CONTEXT:-$ROOT/existing-image-context}"
FFMPEG_DIR="$ROOT/TTS-downloads/tools/ffmpeg-7.0.2-amd64-static"
NATIVE_DIR="$ROOT/LLM/runtime/llama-0faee5004297c3bcfa40b7bf11750127b8c1fd7d/build/bin"
CUDA_DIR="$ROOT/LLM-downloads/cuda-12.2.2/lib64"
command -v docker >/dev/null || { echo 'Docker is missing; stopping without installation.' >&2; exit 2; }
docker info >/dev/null
docker compose version >/dev/null
docker info --format '{{json .Runtimes}}' | grep -q nvidia || { echo 'NVIDIA Docker runtime is missing; stopping without installation.' >&2; exit 2; }
for item in "$LLM_ENV/bin/python" "$TTS_ENV/bin/python" "$FFMPEG_DIR/ffmpeg" "$NATIVE_DIR/llama-server"; do
  [[ -x "$item" ]] || { echo "Missing existing runtime: $item" >&2; exit 2; }
done
mkdir -p "$CONTEXT/app/LLM" "$CONTEXT/app/TTS" "$CONTEXT/app/containers" "$CONTEXT/config"
CONTEXT="$(cd -- "$CONTEXT" && pwd)"
# Existing system runtime directories contain all installed native dependencies.
# Never capture /etc wholesale: omit credentials, host home directories and model files.
runtime=()
for item in bin sbin lib lib64 usr/bin usr/sbin usr/lib usr/lib64 usr/share \
            etc/ld.so.cache etc/ld.so.conf etc/ld.so.conf.d etc/nsswitch.conf etc/os-release etc/localtime; do
  [[ ! -e "/$item" ]] || runtime+=("$item")
done
stage() {
  local destination="$1"; shift
  if [[ -s "$destination" && "${REFRESH_SNAPSHOT:-0}" != 1 ]]; then
    echo "Reusing snapshot: $destination (set REFRESH_SNAPSHOT=1 after changing installed environments/runtime)"
  else
    tar -C / -cf "$destination.partial" "$@"
    mv -- "$destination.partial" "$destination"
  fi
}
stage "$CONTEXT/host-runtime.tar" "${runtime[@]}"
if ! tar -tf "$CONTEXT/host-runtime.tar" | grep -x 'tmp/' >/dev/null; then
  mkdir -p "$CONTEXT/runtime-dirs/"{tmp,run,dev,proc,sys}
  chmod 1777 "$CONTEXT/runtime-dirs/tmp"
  tar -C "$CONTEXT/runtime-dirs" -rf "$CONTEXT/host-runtime.tar" tmp run dev proc sys
fi
# Preserve original prefixes, including conda root lib/bin files and embedded script paths.
LLM_ROOT="${LLM_ENV%/envs/LLM}"
TTS_ROOT="${TTS_ENV%/envs/TTS}"
stage "$CONTEXT/environments.tar" "${LLM_ROOT#/}" "${TTS_ROOT#/}"
stage "$CONTEXT/native-runtime.tar" "${NATIVE_DIR#/}" "${ROOT#/}/LLM/runtime/activate_python.sh" \
  "${ROOT#/}/LLM/runtime/activate_native.sh" "${ROOT#/}/TTS/runtime/activate_tools.sh"
if [[ ! -s "$CONTEXT/cuda-libraries.tar" || "${REFRESH_SNAPSHOT:-0}" == 1 ]]; then
  tar --dereference -C / -cf "$CONTEXT/cuda-libraries.tar.partial" "${CUDA_DIR#/}"
  mv -- "$CONTEXT/cuda-libraries.tar.partial" "$CONTEXT/cuda-libraries.tar"
fi
stage "$CONTEXT/ffmpeg.tar" "${FFMPEG_DIR#/}"
# Application source only; downloaded models/state stay mounted from the host.
tar -C "$ROOT/LLM" --exclude=runtime --exclude=llm_results --exclude=__pycache__ --exclude=.pytest_cache -cf - . | tar -C "$CONTEXT/app/LLM" -xf -
tar -C "$ROOT/TTS" --exclude=runtime --exclude=data --exclude=__pycache__ --exclude=.pytest_cache -cf - . | tar -C "$CONTEXT/app/TTS" -xf -
cp "$ROOT/containers/"{gpu_gate.py,output_paths.py,existing_entrypoint.sh} "$CONTEXT/app/containers/"
printf 'export ORIGINAL_ROOT=%q\nexport LLM_ENV=%q\nexport TTS_ENV=%q\nexport FFMPEG_DIR=%q\n' \
  "$ROOT" "$LLM_ENV" "$TTS_ENV" "$FFMPEG_DIR" > "$CONTEXT/config/paths.sh"
cp "$ROOT/containers/existing.Dockerfile" "$CONTEXT/Dockerfile"
# Legacy builder needs no downloadable BuildKit frontend. FROM scratch pulls nothing.
DOCKER_BUILDKIT=0 docker build --network=none --pull=false --target llm -t narration-llm:existing "$CONTEXT"
DOCKER_BUILDKIT=0 docker build --network=none --pull=false --target tts -t narration-tts:existing "$CONTEXT"
echo 'Images created using installed host files. No containers started. See docs/DEPLOYMENT.md.'
