# Container deployment from the already working installation — zero new installations

Use this patch in `/mnt/hard/home/toroghi/NarrationStack`. It creates two GPU images by snapshotting your existing installed Ubuntu runtime, conda prefixes, built llama-server, CUDA libraries and FFmpeg. It does not invoke pip, conda installation, apt, curl, compilation, model downloads, registry pulls or an external base image. Both final images share the same runtime/environment layers. Working host environments are copied, not modified. Model weights remain read-only host mounts.

## 1. Extract the patch into your existing project root

The ZIP contains `containers/…`, `compose.existing.yaml` and `docs/DEPLOYMENT.md` directly; it does not contain an additional NarrationStack folder. Place these files at those paths under your existing project. No Python source, package locks, environment files, models or activation scripts need replacement. Keep your installed versions, including the TTS Transformers 5.3.0 wheel visible in your listing; the builder never applies a new requirements file.

## 2. Build the two images using only local installed files

```bash
cd /mnt/hard/home/toroghi/NarrationStack
bash containers/build_existing.sh
```

Default existing environment paths are `/home/ali/miniconda-LLM/envs/LLM` and `/home/ali/miniconda-TTS/envs/TTS`, as in your earlier installation logs. If they differ, set `LLM_ENV`/`TTS_ENV` to your actual prefixes before building. The script preserves original conda root/prefix paths because installed scripts and runtime fragments may contain those absolute paths.

The following existing files are reused exactly from your listing:

- `LLM/runtime/activate_python.sh` and `activate_native.sh`.
- `LLM/runtime/llama-0faee5004297c3bcfa40b7bf11750127b8c1fd7d/build/bin/` including the compiled CUDA/native libraries.
- `LLM-downloads/cuda-12.2.2/lib64/` (symlinks are dereferenced when packaging these runtime libraries).
- `TTS/runtime/activate_tools.sh` and `TTS-downloads/tools/ffmpeg-7.0.2-amd64-static/`.
- The installed LLM/TTS environments and existing system runtime libraries.

No wheel cache or model copy is needed for the image build. No model is embedded in the images. `narration-downloads/models` is empty in your listing and is not used. Only the already available `llama_cpp` LLM engine is selected; there is no HF/vLLM installation step.

Snapshots/build context are stored in `existing-image-context/`. Expect significant disk use: it copies the installed conda roots and host runtime and then Docker stores image layers. The first copy/build can take time; that is local disk work, not a download. Subsequent builds reuse existing nonempty snapshot archives and Docker layers. After changing installed environments, native libraries or any source prefix path, refresh intentionally:

```bash
REFRESH_SNAPSHOT=1 bash containers/build_existing.sh
```

Do not snapshot while pip/conda or another process is modifying an environment. If an existing OS runtime file is unreadable, the script stops; it does not install a replacement. If you use sudo solely to read files, supply the same `LLM_ENV`, `TTS_ENV` and project location explicitly, and remember that snapshots then belong to root. Do not delete live environments or models.

The resulting images are `narration-llm:existing` and `narration-tts:existing`. `FROM scratch` means no base-image pull. Builds use `--network=none --pull=false` and the local legacy builder so a Dockerfile frontend is not fetched. Docker Engine/Compose and the NVIDIA container runtime must already be installed; the script checks them and stops if missing. Some Docker distributions omit the legacy builder; in that case this exact offline build requires an already installed usable builder, not a package download. It never starts services automatically.

## 3. Start containers when ready

Stop the host LLM/TTS API or CLI inference processes first; they compete for the same GPU and ports. The following command is the explicit service-start step:

```bash
cd /mnt/hard/home/toroghi/NarrationStack
export EXISTING_STATE_DIR="$PWD/state-existing"
export BIND_ADDRESS=0.0.0.0
export LLM_PORT=8083 TTS_PORT=8084
mkdir -p "$EXISTING_STATE_DIR/llm" "$EXISTING_STATE_DIR/tts" "$EXISTING_STATE_DIR/gpu-locks"
# Optional, set before startup; preserve any existing credentials:
# export LLM_API_KEY='your-llm-key'
# export TTS_API_KEY='your-tts-key'
docker compose -f compose.existing.yaml config --quiet
docker compose -f compose.existing.yaml up -d --no-build --pull never
docker compose -f compose.existing.yaml logs -f
```

The new images run as root inside the container to retain access to the existing owner-restricted model file and preserve the copied environment layout. Only the new state directory is writable; model/reference mounts are read-only. This is a packaging of your current runtime rather than a newly installed minimal base; review your existing runtime inventory before treating the image as a separately hardened release. No host environment or existing job state is overwritten.

Paths are already configured in `compose.existing.yaml`:

| Host path | Container path |
| --- | --- |
| `LLM-downloads/models/Qwen3.5-9B` | `/models/llm` (read-only) |
| `TTS-downloads/models/Kokoro-82M` | `/models/tts` (read-only) |
| `Texts` | LLM `/inputs` (read-only) |
| New `state-existing/llm` and `tts` | Each service's `/data` |
| New `state-existing/gpu-locks` | Both services' `/gpu-locks` |

These mount sources use the exact absolute project path from your listing. If moving the whole stack to another device/path, update the model/input bind sources and rebuild the snapshots for that device's working runtime. Do not point the containers at the empty `narration-downloads/models` directory.

Both services listen internally on port 8083. Host mappings are **LLM 0.0.0.0:8083** and **TTS 0.0.0.0:8084**. The LLM's duration client calls `http://tts:8083/duration` over the Compose network. It does not call host port 8084 or its own loopback interface.

The shared GPU gate uses the same directory and GPU identity for both containers and exposes GPU 0. It serializes model loading/inference but keeps resident weights allocated. Both models still must fit on your 11 GB test GPU. Existing Python package versions are unchanged; the Compose LLM context defaults to the previously recommended 8192 tokens with CPU KV cache. If you used different working inference/memory flags, preserve them through the corresponding environment entries in Compose. TTS retains its existing CLI/environment defaults unless you explicitly override them.

## 4. Verify endpoints

```bash
curl -fsS http://127.0.0.1:8084/health
curl -fsS http://127.0.0.1:8083/health
curl -sS http://127.0.0.1:8083/generate \
  -H 'Content-Type: application/json' \
  -d '{"duration_seconds":60,"async":true,"estimate":false,"max_retries":2}'
```

For a remote backend, use `http://DEVICE_IP:8083` for LLM and `http://DEVICE_IP:8084` for TTS. `0.0.0.0` is the bind address, not the recommended client URL. Swagger is `/docs/` on both ports. Send `X-API-Key` if configured. After receiving the LLM job ID, poll its `/progress`; send the final text to TTS `/duration`, then `/generate` and its progress/download route. Use the existing Word handoff for payload details.

LLM loads its model lazily when the first job starts, so LLM health alone does not verify a completed GPU generation. Wait for TTS health before submitting an accurate-mode LLM job. If a model or installed dependency is missing, offline startup fails rather than downloading it.

Generated artifacts remain timestamped inside the persistent state bases. Existing `Texts` TTS job state and `LLM/llm_results` CLI results are untouched. To stop these containers without deleting volumes/files:

```bash
docker compose -f compose.existing.yaml down
```

Do not run the original `setup.sh`, `containers/prepare.sh`, `containers/build.sh`, pipeline installers or download scripts for this procedure. This patch's only build script is `containers/build_existing.sh`.

## Validation scope

The new Bash files passed syntax checks, and the Compose file passed configuration validation. These host snapshots/images cannot be built or GPU-tested from the Windows development machine; no containers were started here. The build/start commands above run on your existing working Ubuntu device. No packages or models were downloaded or installed while creating this patch.
