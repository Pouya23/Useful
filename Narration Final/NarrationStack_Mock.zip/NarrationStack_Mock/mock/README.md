# Backend integration mock

Run both APIs without GPU drivers, CUDA, model weights, Torch, Transformers, vLLM or Kokoro. The production Flask routes, strict request models, queues, SQLite persistence, SSE events, retry selection, UUID progress/download URLs and TTS idempotency logic are reused. The engines are mock implementations. Every HTTP response carries `X-Mock: true`.

The TTS output is a **valid MP3 containing newly generated quiet random pink noise** for the requested duration; it is not speech. MP3 frame padding makes the measured length approximate, as in production. The completed result includes its measured `actual_final_duration_s`. Audio generation streams directly through FFmpeg without holding the whole recording in Python RAM. These endpoints use the same request/response structure documented in `../docs/NarrationStack_Backend_Handoff.docx`.

## Quick start with an existing environment

If a current LLM/TTS environment already has Flask, Pydantic, requests, flask-swagger-ui and Waitress installed, activate it and ensure `ffmpeg` and `ffprobe` are on PATH, then run from the extracted NarrationStack_Mock directory:

```bash
python mock/run_mock.py --host 0.0.0.0 --output /your/path/mock-state
```

Use a separate mock output base; do not point it at production service data. It creates timestamped artifact folders/files and retains UUIDs and state across restarts. The mock launcher supports Python 3.11 on Linux and Windows when the listed dependencies and FFmpeg are installed.

## Fresh Ubuntu 20.04: resumable installation, no preinstalled Python needed

```bash
cd /your/path/NarrationStack_Mock
export DOWNLOAD_DIR="/your/chosen/mock-downloads"
export CONDA_ROOT="$HOME/miniconda-MOCK"
# Optional proxy/CA settings; omit when not needed:
export DOWNLOAD_PROXY="socks5h://PROXY_IP:PROXY_PORT"
# export CURL_CA_BUNDLE="/path/to/proxy-ca.pem"
# export CURL_INSECURE=1
bash mock/install_ubuntu.sh
source mock/runtime/activate.sh
python mock/run_mock.py --host 0.0.0.0 --output /your/path/mock-state
```

The installer clones a Python **3.11.11** conda environment named `MOCK`, downloads the exact non-neural package closure in `containers/common.lock` plus FFmpeg/ffprobe **7.0.2** via curl, and installs Python wheels offline. It skips verified cached artifacts and already-installed exact packages, promotes verified complete `.part` files, resumes incomplete transfers, and retries transient proxy SSL/reset errors. It does not install GPU engines or run the production setup. Setup finishes without starting services; the final Python command above starts them.

To reuse an existing pinned LLM/TTS bootstrap, set `CONDA_ROOT=/home/ali/miniconda-TTS` (or the LLM root) instead of creating another bootstrap. `MOCK` remains a separate environment. To reuse existing wheels/bootstrap archives before downloading:

```bash
export NARRATION_DOWNLOAD_CACHE_DIRS="/path/to/LLM Packages:/path/to/LLM Packages/wheels-common:/path/to/TTS Downloads:/path/to/TTS Downloads/wheels"
```

## Addresses to configure in the backend

| Service | Base URL | Swagger |
| --- | --- | --- |
| LLM | `http://MOCK_HOST:8081` | `/docs/` |
| TTS | `http://MOCK_HOST:8082` | `/docs/` |

Expose these ports to the backend machine when running on another host. Default binding is localhost unless `--host 0.0.0.0` is supplied. For authenticated tests, set `LLM_API_KEY` and `API_KEY` before launching; send the matching `X-API-Key` to each service. The LLM calls its colocated mock TTS automatically for `estimate=false`. Explicit `duration_api_host`, `duration_api_port` and `duration_api_key` override this. If ports are changed, use `--llm-port` and `--tts-port`; a preexisting `DURATION_API_*` environment setting also overrides the automatic defaults.

## Test the whole flow

Request 60 seconds, which implies 130 words at the default rate:

```bash
# Async LLM: store the returned job_id and poll progress.
curl -sS http://localhost:8081/generate -H 'Content-Type: application/json' \
  -d '{"duration_seconds":60,"async":true,"estimate":false}'
curl -sS 'http://localhost:8081/progress?job_id=LLM_JOB_ID'

# SSE: each token is a simulated word-sized delta; completed.result is authoritative.
curl -N http://localhost:8081/generate -H 'Content-Type: application/json' \
  -d '{"duration_seconds":60,"async":false,"max_retries":2}'
```

Pass `result.text` from LLM progress/completed SSE to TTS as `text`, with `desired_duration:60`. First POST `/duration` using that JSON; it never creates audio. Then POST `/generate` adding `async:true`; poll its UUID and download `result.audio_url` after status is `completed`. With `async:false`, TTS `/generate` returns MP3 bytes directly.

A short standalone TTS example with a broad permitted tempo range:

```bash
curl -sS http://localhost:8082/generate -H 'Content-Type: application/json' \
  -d '{"text":"The backend can test this complete audio generation workflow without any model loading.","desired_duration":6,"atempo_min":0.5,"atempo_max":2.0,"async":false}' \
  --output sample.mp3
```

The LLM accepts all three engine names in mock mode; they select the same fake engine, and model configuration does not load model files. Inline `sources` and `samples` work normally; file-based inputs still use production `INPUT_ROOT` restrictions. Default LLM constraints remain, including at least 20 target words (about 9.24 seconds at 130 WPM). Invalid specifications return 422.

## Repeatable test scenarios

Stop the mock process and relaunch with the chosen flags; no extra request-body fields are added.

| Launcher option | Behavior |
| --- | --- |
| `--llm-scenario fit` | Default: generate the pipeline's target word count. |
| `--llm-scenario retry` | Initial draft too long; next round aims at target. Send `max_retries:1` or more. |
| `--llm-scenario exhaust` | All rounds too long; real best-round selection runs at the limit. |
| `--llm-scenario fail` | Accepted LLM job ends failed; SSE emits error. |
| `--tts-mode auto` | Default natural-duration simulation = word count × 60 / 130 / speed. |
| `--tts-mode fit` | Simulate natural duration at midpoint of the requested tempo window. |
| `--tts-mode too_short` / `too_long` | `/duration` returns 200 with failed fit; `/generate` rejects with 422 and creates no job. |
| `--tts-fail` | Accepted TTS job fails during generation; synchronous generation returns 500. |
| `--token-delay 0.02` | Default simulated delay per word delta; zero makes LLM instant. |
| `--job-delay 2` | Default TTS generation delay, enabling running/progress tests. |
| `--words-per-minute 130` | Simulated TTS natural speech rate; set another value to exercise accurate fitting. |

TTS `/duration` is deterministic for a specification and the selected mode; audio noise is random for each new job. Natural duration is explicitly marked simulated, not sample-exact Kokoro. Retry feedback in the LLM uses the unchanged production control loop: a changed mock WPM can cause further retries or exhausted selection. This mock does not simulate GPU memory, model quality, actual tokenizer tokens or real inference performance.

## Optional CPU-only Docker container

After `mock/install_ubuntu.sh` has prepared its download directory:

```bash
export MOCK_DOWNLOAD_DIR="/your/chosen/mock-downloads"
export MOCK_STATE_DIR="/your/path/mock-state"
# For backend access from another host:
export MOCK_BIND_ADDRESS=0.0.0.0
docker compose -f mock/compose.yaml build
docker compose -f mock/compose.yaml up -d
docker compose -f mock/compose.yaml logs -f
# Later:
docker compose -f mock/compose.yaml down
```

The image uses Python 3.11.11 and prepared wheels/FFmpeg; pip does not download anything. Docker may need to pull the base image through its separately configured registry/proxy. No NVIDIA runtime or GPU is required. Docker ports can coexist with production only when the host mappings differ; do not bind both services to the same ports.

Tests: `python -m pytest mock/tests -q` (FFmpeg tests need FFmpeg/ffprobe on PATH).

This standalone archive contains only the mock launcher, its HTTP/queue/fit support modules, exact dependency manifests, installer, optional mock container, tests and API handoff. The `LLM/` and `TTS/` folders contain support code, not model engines or production installers. No main project checkout is required; no model files or GPU packages are downloaded.
