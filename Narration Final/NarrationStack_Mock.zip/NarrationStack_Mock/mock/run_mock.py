"""Run both real HTTP contracts with mock engines; requires no GPU or models."""
import argparse
from dataclasses import replace
import json
import logging
import math
import os
from pathlib import Path
import shutil
import sys
import threading

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'LLM'), str(ROOT/'TTS'), str(ROOT/'containers')]
from api_app import create_app as llm_app
from api_service import LlmService
from app import create_app as tts_app
from contracts import Settings
from jobs import SpeechService
from engines import MockSession, MockSpeechEngine
from waitress import create_server


class MockSpeechService(SpeechService):
    def estimate(self, spec):
        plan, result = super().estimate(spec)
        result.update(mock=True, natural_duration_is_sample_exact=False,
                      duration_estimate_kind='Mock word-rate plan; no Kokoro prediction',
                      eta_source='mock_configured_delay', calibration_samples=0,
                      estimated_generation_time_s=max(.1, self.engine.delay + .5),
                      estimated_encoding_time_s=.5)
        return plan, result

    def timing_estimate(self, natural_seconds):
        return {'estimated_generation_time_s': max(.1, self.engine.delay + .5),
                'estimated_encoding_time_s': .5, 'eta_source': 'mock_configured_delay',
                'calibration_samples': 0, 'eta_is_guaranteed': False}


def mark_mock(app):
    @app.after_request
    def marker(response):
        response.headers['X-Mock'] = 'true'
        if response.is_json and response.status_code == 200:
            from flask import request
            body = response.get_json()
            if request.path == '/health':
                body.update(mock=True, device='cpu', model_loaded=False)
                response.set_data(app.json.dumps(body))
            elif request.path == '/openapi.json':
                body['info']['title'] += ' — MOCK'
                body['info']['description'] = 'Mock engines with real validation, jobs and fit control. Audio is random noise; natural duration is simulated.'
                response.set_data(app.json.dumps(body))
        return response
    return app


def build_services(output, *, llm_scenario='fit', token_delay=.02, tts_mode='auto',
                   wpm=130, job_delay=2, tts_fail=False):
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    registry = output/'mock-engines.json'
    registry.write_text(json.dumps({'schema_version': 1, 'workers':
                        {name: sys.executable for name in ('llama_cpp', 'transformers', 'vllm')}}))
    os.environ['LLM_ENGINE_REGISTRY'] = str(registry)
    llm = LlmService(output/'llm', validate_paths=False,
                     session_factory=lambda *a, **k: MockSession(*a, **k,
                         scenario=llm_scenario, token_delay=token_delay))
    try:
        settings = replace(Settings.from_env(), device='cpu', data_dir=output/'tts')
        tts = MockSpeechService(settings, lambda settings: MockSpeechEngine(settings,
                                mode=tts_mode, wpm=wpm, delay=job_delay, fail=tts_fail))
    except BaseException:
        llm.close()
        raise
    return llm, tts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--llm-port', type=int, default=8081)
    parser.add_argument('--tts-port', type=int, default=8082)
    parser.add_argument('--output', type=Path, default=ROOT/'mock-state')
    parser.add_argument('--llm-scenario', choices=['fit', 'retry', 'exhaust', 'fail'], default='fit')
    parser.add_argument('--tts-mode', choices=['auto', 'fit', 'too_short', 'too_long'], default='auto')
    parser.add_argument('--tts-fail', action='store_true')
    parser.add_argument('--token-delay', type=float, default=.02)
    parser.add_argument('--job-delay', type=float, default=2)
    parser.add_argument('--words-per-minute', type=float, default=130)
    args = parser.parse_args()
    if args.llm_port == args.tts_port or not all(1 <= p <= 65535 for p in (args.llm_port, args.tts_port)):
        parser.error('Use distinct ports from 1 to 65535')
    if not all(math.isfinite(v) for v in (args.token_delay, args.job_delay, args.words_per_minute)) or args.token_delay < 0 or args.job_delay < 0 or args.words_per_minute <= 0:
        parser.error('Delays must be finite and nonnegative; words-per-minute must be positive')
    for tool in ('ffmpeg', 'ffprobe'):
        if not shutil.which(tool):
            parser.error(f'{tool} is required; run mock/install_ubuntu.sh or add it to PATH')
    # The accurate LLM loop calls this live mock TTS endpoint by default.
    os.environ.setdefault('DURATION_API_HOST', '127.0.0.1')
    os.environ.setdefault('DURATION_API_PORT', str(args.tts_port))
    os.environ.setdefault('DURATION_API_KEY', os.getenv('API_KEY', ''))
    logging.basicConfig(level=logging.INFO)
    llm, tts = build_services(args.output, llm_scenario=args.llm_scenario,
                             token_delay=args.token_delay, tts_mode=args.tts_mode,
                             wpm=args.words_per_minute, job_delay=args.job_delay, tts_fail=args.tts_fail)
    servers = []
    try:
        servers.append(create_server(mark_mock(tts_app(tts)), host=args.host, port=args.tts_port, threads=8))
        servers.append(create_server(mark_mock(llm_app(llm)), host=args.host, port=args.llm_port, threads=12))
        print(f'MOCK ONLY: LLM http://{args.host}:{args.llm_port}/docs/; TTS http://{args.host}:{args.tts_port}/docs/', flush=True)
        thread = threading.Thread(target=servers[0].run, daemon=True)
        thread.start()
        servers[1].run()
    except KeyboardInterrupt:
        pass
    finally:
        for server in servers:
            server.close()
        llm.close()
        tts.close()


if __name__ == '__main__':
    main()
