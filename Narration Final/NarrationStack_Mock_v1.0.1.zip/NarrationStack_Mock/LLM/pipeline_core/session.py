"""Prevent accidental real-engine construction in the standalone mock."""
class WritingSession:
    def __init__(self, *args, **kwargs):
        raise RuntimeError('This bundle contains only mock engines; start mock/run_mock.py')
