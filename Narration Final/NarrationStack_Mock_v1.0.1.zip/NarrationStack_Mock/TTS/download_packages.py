"""Shared curl-only downloader import for the standalone mock FFmpeg installer."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'containers'))
from artifact_download import download
