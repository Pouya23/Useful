from dataclasses import dataclass
from typing import Any
from contracts import GenerationSpec
NATIVE_RATE = 24000

@dataclass
class SpeechPlan:
    engine_signature: str
    natural_samples: int
    chunks: list[dict[str, Any]]

    @property
    def seconds(self):
        return self.natural_samples / NATIVE_RATE

def evaluate_fit(plan: SpeechPlan, spec: GenerationSpec) -> dict:
    factor = plan.seconds / spec.desired_duration
    reason = "too_short" if factor < spec.atempo_min else "too_long" if factor > spec.atempo_max else None
    return {
        "success": reason is None, "reason": reason,
        "duration_s": spec.desired_duration if reason is None else plan.seconds,
        "duration_kind": "fitted_target" if reason is None else "natural_unatempoed",
        "estimated_natural_duration_s": plan.seconds,
        "natural_samples": plan.natural_samples, "natural_sample_rate": NATIVE_RATE,
        "desired_duration_s": spec.desired_duration,
        "estimated_final_duration_s": plan.seconds / factor,
        "atempo_factor": factor, "atempo_min": spec.atempo_min, "atempo_max": spec.atempo_max,
        "chunk_count": len(plan.chunks),
        "natural_duration_is_sample_exact": True,
        "final_duration_is_sample_exact": False,
        "duration_estimate_kind": "Kokoro frozen natural duration; FFmpeg tempo-ratio target for final MP3",
    }
