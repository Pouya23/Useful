"""CPU-only stand-ins used with the unchanged production HTTP/job/fit code."""
from contextlib import contextmanager
import json
import math
from pathlib import Path
import secrets
import subprocess
import time
from types import SimpleNamespace
import uuid

from output_paths import new_artifact_dir
from pipeline_core.pipeline import FastWritingJob
from kokoro_fit_core import SpeechPlan


class MockBackend:
    def __init__(self, settings, output, scenario, token_delay):
        self.output = output
        (output / 'round_outputs').mkdir()
        self.effective_context_size = settings.context_tokens
        self.scenario, self.token_delay = scenario, token_delay
        self.counter, self.rounds, self.stage = 0, [], 'draft'
        self.server = SimpleNamespace(token_callback=None)

    @contextmanager
    def labelled(self, case, stage):
        self.stage = stage
        yield

    def complete(self, messages, **sampling):
        if self.scenario == 'fail':
            raise RuntimeError('Intentional mock LLM failure')
        prompt = messages[-1]['content']
        policy = json.loads(prompt.split('\nCURRENT PASS:\n')[-1])['measured_length_feedback']
        target = policy.get('target_words') or 130
        if self.scenario == 'exhaust' or (self.scenario == 'retry' and self.stage == 'draft'):
            target = max(target + 10, math.ceil(target * 1.6))
        vocabulary = ('This mock narration lets the backend test generation streaming '
                      'progress retries and audio delivery without loading a real model').split()
        words = [vocabulary[i % len(vocabulary)] for i in range(max(1, int(target)))]
        started = time.perf_counter()
        for i, word in enumerate(words):
            if self.token_delay:
                time.sleep(self.token_delay)
            callback = self.server.token_callback
            if callback:
                callback({'text': word + (' ' if i < len(words)-1 else ''),
                          'token_ids': None, 'unit': 'mock_word'})
        text = ' '.join(words)
        self.counter += 1
        usage = {'prompt_tokens': sum(len(m['content'].split()) for m in messages),
                 'completion_tokens': len(words)}
        self.rounds.append({'profile': 'mock_cpu', 'round_id': self.counter,
                            'stage': self.stage, 'latency_seconds': time.perf_counter()-started,
                            'total_device_peak_gb': 0, 'total_device_peak_bytes': 0,
                            'error': None, 'usage': usage, 'finish_reason': 'stop',
                            'pipeline_validation_status': 'pending'})
        result = {'text': text, 'finish_reason': 'stop', 'usage': usage}
        (self.output / 'round_outputs' / f'{self.counter:04d}.json').write_text(
            json.dumps(result), encoding='utf-8')
        return result

    def validation(self, index, status, exc=None):
        self.rounds[-1]['pipeline_validation_status'] = status


class MockSession:
    def __init__(self, settings, *, output, render, scenario='fit', token_delay=.02):
        self.settings, self.output, self.render = settings, output, render
        self.scenario, self.token_delay = scenario, token_delay

    def __enter__(self):
        self.output = new_artifact_dir(self.output)
        self.backend = MockBackend(self.settings, self.output, self.scenario, self.token_delay)
        return self

    def new_job(self, request, **kwargs):
        return FastWritingJob(self.backend, request, self.output / 'jobs' / uuid.uuid4().hex,
                              render=self.render, **kwargs)

    def close(self):
        pass


class MockSpeechEngine:
    signature = 'mock-random-audio-v1'
    runtime_profile = 'cpu_mock'
    voices = ['af_heart', 'af_bella', 'af_nicole', 'af_sarah', 'af_sky',
              'am_adam', 'am_michael', 'am_onyx', 'am_echo', 'am_fenrir',
              'bf_emma', 'bf_isabella', 'bm_george', 'bm_lewis']

    def __init__(self, settings, *, mode='auto', wpm=130, delay=2, fail=False):
        self.settings, self.mode, self.wpm = settings, mode, wpm
        self.delay, self.fail = delay, fail

    def plan(self, spec):
        seconds = len(spec.text.split()) * 60 / self.wpm / spec.speed
        if self.mode == 'fit':
            seconds = spec.desired_duration * (spec.atempo_min + spec.atempo_max) / 2
        elif self.mode == 'too_short':
            seconds = spec.desired_duration * spec.atempo_min / 2
        elif self.mode == 'too_long':
            seconds = spec.desired_duration * spec.atempo_max * 2
        samples = max(1, round(seconds * 24000))
        return SpeechPlan(self.signature, samples, [{'native_samples': samples}])

    def save_plan(self, plan, path):
        Path(path).write_text(json.dumps({'natural_samples': plan.natural_samples,
                                        'chunks': plan.chunks}), encoding='utf-8')

    def load_plan(self, path):
        return SpeechPlan(self.signature, **json.loads(Path(path).read_text(encoding='utf-8')))

    def generate(self, plan, spec, destination, changed):
        if self.fail:
            raise RuntimeError('Intentional mock TTS generation failure')
        started = time.perf_counter()
        changed('synthesizing', 0, 1)
        time.sleep(self.delay)
        synthesis = time.perf_counter() - started
        changed('encoding', 1, 1)
        encode_start = time.perf_counter()
        # FFmpeg produces quiet random pink noise directly: no full-duration RAM buffer.
        seed = secrets.randbelow(2147483646) + 1
        temporary = destination.with_name(destination.stem + '.partial.mp3')
        command = ['ffmpeg', '-nostdin', '-y', '-hide_banner', '-loglevel', 'error',
                   '-f', 'lavfi', '-i',
                   f'anoisesrc=color=pink:amplitude=0.025:sample_rate={spec.sample_rate}:seed={seed}',
                   '-t', str(spec.desired_duration), '-ac', '1', '-ar', str(spec.sample_rate),
                   '-c:a', 'libmp3lame', '-b:a', f'{spec.bitrate_kbps}k', str(temporary)]
        try:
            subprocess.run(command, check=True, capture_output=True,
                           timeout=self.settings.ffmpeg_timeout_s)
            measured = subprocess.run(['ffprobe', '-v', 'error', '-show_entries',
                                       'format=duration', '-of', 'default=nw=1:nk=1', str(temporary)],
                                      check=True, capture_output=True, text=True, timeout=30)
            duration = float(measured.stdout.strip())
            if not math.isfinite(duration) or duration <= 0:
                raise RuntimeError('Invalid generated MP3 duration')
            temporary.replace(destination)
        finally:
            temporary.unlink(missing_ok=True)
        return {'mock': True, 'audio_kind': 'random_pink_noise',
                'actual_natural_duration_s': plan.seconds, 'actual_final_duration_s': duration,
                'duration_error_percent': 100*abs(duration-spec.desired_duration)/spec.desired_duration,
                'synthesis_seconds': synthesis, 'encoding_seconds': time.perf_counter()-encode_start,
                'gpu_memory': self.memory_snapshot()}

    def memory_snapshot(self):
        return {'mock': True, 'device': 'cpu', 'allocated_bytes': 0, 'reserved_bytes': 0}
