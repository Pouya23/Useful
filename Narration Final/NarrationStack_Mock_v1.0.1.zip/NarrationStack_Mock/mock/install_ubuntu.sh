#!/usr/bin/env bash
# Fast CPU-only mock setup. All Python package downloads use curl, never pip.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${DOWNLOAD_DIR:?Set DOWNLOAD_DIR to your chosen download/cache directory}"
CONDA_ROOT="${CONDA_ROOT:-$HOME/miniconda-MOCK}"
[[ "$(uname -m)" == x86_64 ]] || { echo 'Requires Linux x86_64' >&2; exit 2; }
if ! command -v curl >/dev/null || [[ ! -f /etc/ssl/certs/ca-certificates.crt ]]; then
  sudo apt-get update
  sudo apt-get install -y curl ca-certificates
fi
mkdir -p "$DOWNLOAD_DIR"
DOWNLOAD_DIR="$(cd -- "$DOWNLOAD_DIR" && pwd)"
export DOWNLOAD_DIR
INSTALLER=Miniconda3-py311_25.1.1-2-Linux-x86_64.sh
SHA=d8c1645776c0758214e4191c605abe5878002051316bd423f2b14b22d6cb4251
CURL=(bash "$ROOT/containers/curl_retry.sh" --fail --location --connect-timeout 60)
[[ -z "${DOWNLOAD_PROXY:-}" ]] || CURL+=(--proxy "$DOWNLOAD_PROXY")
[[ -z "${CURL_CA_BUNDLE:-}" ]] || CURL+=(--cacert "$CURL_CA_BUNDLE")
[[ "${CURL_INSECURE:-0}" != 1 ]] || CURL+=(--insecure)
if [[ ! -x "$CONDA_ROOT/bin/conda" ]]; then
  if [[ ! -f "$DOWNLOAD_DIR/$INSTALLER" ]]; then
    CURL_EXPECTED_SHA256="$SHA" "${CURL[@]}" --continue-at - -o "$DOWNLOAD_DIR/$INSTALLER.part" "https://repo.anaconda.com/miniconda/$INSTALLER"
    printf '%s  %s\n' "$SHA" "$DOWNLOAD_DIR/$INSTALLER.part" | sha256sum -c -
    mv -- "$DOWNLOAD_DIR/$INSTALLER.part" "$DOWNLOAD_DIR/$INSTALLER"
  fi
  printf '%s  %s\n' "$SHA" "$DOWNLOAD_DIR/$INSTALLER" | sha256sum -c -
  bash "$DOWNLOAD_DIR/$INSTALLER" -b -k -p "$CONDA_ROOT"
fi
# Use a pristine pinned bootstrap, including one already created by LLM/TTS setup.
"$CONDA_ROOT/bin/python" -I -c 'import sys; assert sys.version_info[:3] == (3,11,11), sys.version'
source "$ROOT/containers/conda_offline.sh"
clone_offline_env "$CONDA_ROOT" MOCK
PYTHON="$CONDA_ROOT/envs/MOCK/bin/python"
"$PYTHON" "$ROOT/LLM/download_packages.py" "$ROOT/containers/common.lock" "$DOWNLOAD_DIR/wheels" --jobs "${DOWNLOAD_JOBS:-1}"
"$PYTHON" "$ROOT/containers/install_offline.py" "$DOWNLOAD_DIR/wheels"
"$PYTHON" "$ROOT/TTS/prepare_install.py" "$DOWNLOAD_DIR"
"$PYTHON" "$ROOT/containers/write_runtime_env.py" --environment "$CONDA_ROOT/envs/MOCK" \
  --tools "$DOWNLOAD_DIR/tools/ffmpeg-7.0.2-amd64-static" --output "$ROOT/mock/runtime/activate.sh"
echo "Mock setup complete. No servers started. Run:"
printf 'source %q; python %q --output %q\n' "$ROOT/mock/runtime/activate.sh" "$ROOT/mock/run_mock.py" "$ROOT/mock-state"
