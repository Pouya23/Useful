import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from run_mock import build_services, llm_app, mark_mock, tts_app, seed_demo_jobs


TEXT = 'The backend can test this complete audio generation workflow without any model loading.'


@pytest.fixture
def services(tmp_path, monkeypatch):
    monkeypatch.setenv('LLM_ENGINE_REGISTRY', '')
    monkeypatch.delenv('LLM_API_KEY', raising=False)
    monkeypatch.delenv('API_KEY', raising=False)
    result = build_services(tmp_path, token_delay=0, job_delay=0, tts_mode='fit')
    yield result
    for service in result:
        service.close()


def terminal(service, job_id):
    deadline = time.monotonic()+10
    while time.monotonic() < deadline:
        row = service.progress(job_id) if hasattr(service, 'progress') else service.store.get(job_id)
        if row['status'] in {'completed', 'failed'}:
            return row
        time.sleep(.01)
    raise AssertionError('Mock job did not finish')


def test_llm_all_engine_names_and_mock_health(services):
    llm, _ = services
    client = mark_mock(llm_app(llm)).test_client()
    for engine in ('llama_cpp', 'transformers', 'vllm'):
        response = client.post('/generate', json={'duration_seconds': 12, 'engine': engine})
        assert response.status_code == 202
        row = terminal(llm, response.json['job_id'])
        assert row['status'] == 'completed', row
        assert row['progress_percent'] == 100
    health = client.get('/health')
    assert health.json['device'] == 'cpu' and health.json['mock']
    assert health.headers['X-Mock'] == 'true'


@pytest.mark.parametrize('scenario,retries,expected', [('retry', 1, 2), ('exhaust', 1, 2)])
def test_sse_retry_and_authoritative_completion(tmp_path, monkeypatch, scenario, retries, expected):
    monkeypatch.setenv('LLM_ENGINE_REGISTRY', '')
    monkeypatch.delenv('LLM_API_KEY', raising=False)
    pair = build_services(tmp_path, token_delay=0, job_delay=0, llm_scenario=scenario)
    try:
        response = llm_app(pair[0]).test_client().post('/generate', json={
            'duration_seconds': 12, 'async': False, 'max_retries': retries})
        assert response.status_code == 200
        body = response.get_data(as_text=True)
        assert body.count('event: round_start') == expected
        assert 'event: retry' in body and 'event: token' in body and 'event: completed' in body
    finally:
        for service in pair:
            service.close()


def test_duration_has_no_audio_and_rejections(services):
    _, tts = services
    client = mark_mock(tts_app(tts)).test_client()
    payload = {'text': TEXT, 'desired_duration': 2.0}
    good = client.post('/duration', json=payload)
    assert good.status_code == 200 and good.json['success']
    assert good.json['waveform_generated'] is False
    assert good.json['natural_duration_is_sample_exact'] is False
    assert not list(tts.job_root.iterdir())
    for mode in ('too_short', 'too_long'):
        tts.engine.mode = mode
        response = client.post('/duration', json=payload)
        assert response.status_code == 200 and response.json['reason'] == mode
        assert client.post('/generate', json=payload).status_code == 422
    assert client.post('/duration', json={**payload, 'extra': 1}).status_code == 422


@pytest.mark.skipif(not shutil.which('ffmpeg') or not shutil.which('ffprobe'), reason='FFmpeg required')
@pytest.mark.parametrize('async_', [False, True])
def test_real_mp3_duration_download_and_idempotency(services, async_):
    _, tts = services
    client = mark_mock(tts_app(tts)).test_client()
    payload = {'text': TEXT, 'desired_duration': 2.0, 'async': async_}
    response = client.post('/generate', json=payload, headers={'Idempotency-Key': 'mock-test'})
    assert response.status_code == (202 if async_ else 200)
    job_id = response.json['job_id'] if async_ else response.headers['X-Job-Id']
    row = terminal(tts, job_id)
    assert row['status'] == 'completed', row
    assert row['progress_percent'] == 100 and row['result']['mock']
    downloaded = client.get('/progress', query_string={'job_id': job_id, 'download': 'true'})
    assert downloaded.mimetype == 'audio/mpeg' and len(downloaded.data) > 1000
    path = tts.job_directory(job_id)/'speech.mp3'
    measured = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                               '-of', 'default=nw=1:nk=1', str(path)],
                              capture_output=True, text=True, check=True)
    assert abs(float(measured.stdout)-2.0) < .2
    replay = client.post('/generate', json={**payload, 'async': True}, headers={'Idempotency-Key': 'mock-test'})
    assert replay.status_code == 200 and replay.json['job_id'] == job_id
    conflict = client.post('/generate', json={**payload, 'desired_duration': 3.0}, headers={'Idempotency-Key': 'mock-test'})
    assert conflict.status_code == 409


def test_failure_jobs_and_authentication(services, monkeypatch):
    llm, tts = services
    monkeypatch.setenv('LLM_API_KEY', 'test-key')
    client = llm_app(llm).test_client()
    assert client.post('/generate', json={'duration_seconds': 12}).status_code == 401
    llm.factory = lambda *a, **k: __import__('engines').MockSession(*a, **k, scenario='fail', token_delay=0)
    response = client.post('/generate', json={'duration_seconds': 12}, headers={'X-API-Key': 'test-key'})
    assert terminal(llm, response.json['job_id'])['status'] == 'failed'
    tts.engine.fail = True
    response = tts_app(tts).test_client().post('/generate', json={'text': TEXT, 'desired_duration': 2.0})
    row = terminal(tts, response.json['job_id'])
    assert row['status'] == 'failed' and row['error']['code'] == 'generation_failed'


def test_accurate_llm_calls_live_mock_duration_api(services):
    import threading
    from werkzeug.serving import make_server
    llm, tts = services
    tts.engine.mode = 'auto'
    server = make_server('127.0.0.1', 0, tts_app(tts), threaded=True)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        response = llm_app(llm).test_client().post('/generate', json={
            'duration_seconds': 12, 'estimate': False, 'duration_api_host': '127.0.0.1',
            'duration_api_port': server.server_port, 'max_retries': 1})
        assert response.status_code == 202
        row = terminal(llm, response.json['job_id'])
        assert row['status'] == 'completed', row
        assert row['result']['fit']['within_range']
        assert not list(tts.job_root.iterdir())  # Accurate fit plans but never generates audio.
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()


def test_invalid_llm_word_target_is_422(services):
    response = llm_app(services[0]).test_client().post('/generate', json={'duration_seconds': 1})
    assert response.status_code == 422


def test_all_swagger_post_examples_and_progress_queries_are_valid(services):
    llm, tts = services
    tts.engine.mode = 'auto'
    seed_demo_jobs(llm, tts)
    for service, factory in ((llm, llm_app), (tts, tts_app)):
        client = mark_mock(factory(service), service).test_client()
        schema = client.get('/openapi.json').json
        for path, definition in schema['paths'].items():
            if 'post' in definition:
                example = definition['post']['requestBody']['content']['application/json']['example']
                response = client.post(path, json=example)
                assert response.status_code in {200, 202}, (path, response.json)
                if path == '/generate':
                    assert 'string' not in example.get('sample', [])
                    assert 'string' not in example.get('source', [])
        params = schema['paths']['/progress']['get']['parameters']
        job_id = next(p['example'] for p in params if p['name'] == 'job_id')
        assert client.get('/progress', query_string={'job_id': job_id}).status_code == 200


def test_tts_running_progress_is_below_complete(services):
    _, tts = services
    tts.engine.delay = .3
    client = tts_app(tts).test_client()
    response = client.post('/generate', json={'text': TEXT, 'desired_duration': 2.0})
    job_id = response.json['job_id']
    deadline = time.monotonic()+2
    while time.monotonic() < deadline:
        row = client.get('/progress', query_string={'job_id': job_id}).json
        if row['status'] == 'running':
            assert 0 <= row['progress_percent'] < 100
            assert row['time_remaining_s'] >= 0
            break
        time.sleep(.01)
    else:
        raise AssertionError('Never observed running state')
    assert terminal(tts, job_id)['status'] == 'completed'


def test_dual_http_launcher_end_to_end(tmp_path, monkeypatch):
    import os
    import socket
    import requests
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        pytest.skip('FFmpeg required')
    sockets = [socket.socket(), socket.socket()]
    for sock in sockets:
        sock.bind(('127.0.0.1', 0))
    ports = [sock.getsockname()[1] for sock in sockets]
    for sock in sockets:
        sock.close()
    env = os.environ.copy()
    for name in ('LLM_API_KEY', 'API_KEY', 'DURATION_API_HOST', 'DURATION_API_PORT', 'DURATION_API_KEY'):
        env.pop(name, None)
    process = subprocess.Popen([
        sys.executable, str(Path(__file__).resolve().parents[1]/'run_mock.py'),
        '--llm-port', str(ports[0]), '--tts-port', str(ports[1]),
        '--output', str(tmp_path), '--token-delay', '0', '--job-delay', '0'],
        env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    session = requests.Session()
    session.trust_env = False
    try:
        deadline = time.monotonic()+15
        while time.monotonic() < deadline:
            try:
                if all(session.get(f'http://127.0.0.1:{port}/health', timeout=1).status_code == 200 for port in ports):
                    break
            except requests.RequestException:
                if process.poll() is not None:
                    raise AssertionError(process.stderr.read().decode())
            time.sleep(.05)
        else:
            raise AssertionError('Mock launcher did not start both HTTP APIs')
        response = session.post(f'http://127.0.0.1:{ports[0]}/generate',
                                json={'duration_seconds': 12, 'estimate': False, 'async': False}, timeout=15)
        assert response.status_code == 200 and response.headers['X-Mock'] == 'true'
        data = [json.loads(line[6:]) for line in response.text.splitlines() if line.startswith('data: ')]
        result = next(item['result'] for item in data if 'result' in item)
        audio = session.post(f'http://127.0.0.1:{ports[1]}/generate',
                             json={'text': result['text'], 'desired_duration': 12, 'async': False}, timeout=15)
        assert audio.status_code == 200 and audio.headers['Content-Type'].startswith('audio/mpeg')
        assert len(audio.content) > 1000
    finally:
        session.close()
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        process.stderr.close()

