#!/usr/bin/env bash
# Small offline images: existing environments, tools and models remain read-only mounts.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
LLM_ENV="${LLM_ENV:-/home/ali/miniconda-LLM/envs/LLM}"
TTS_ENV="${TTS_ENV:-/home/ali/miniconda-TTS/envs/TTS}"
CONTEXT="${CONTEXT:-$ROOT/existing-image-context-small}"
command -v docker >/dev/null
docker info >/dev/null
docker compose version >/dev/null
docker info --format '{{json .Runtimes}}' | grep -q nvidia || { echo 'NVIDIA runtime missing; no installation will be attempted.' >&2; exit 2; }
NATIVE="$ROOT/LLM/runtime/llama-0faee5004297c3bcfa40b7bf11750127b8c1fd7d/build/bin"
FFMPEG_DIR="$ROOT/TTS-downloads/tools/ffmpeg-7.0.2-amd64-static"
CUDA_DIR="$ROOT/LLM-downloads/cuda-12.2.2"
for binary in "$LLM_ENV/bin/python" "$TTS_ENV/bin/python" "$NATIVE/llama-server" "$FFMPEG_DIR/ffmpeg"; do
  [[ -x "$binary" ]] || { echo "Missing existing binary: $binary" >&2; exit 2; }
done
mkdir -p "$CONTEXT/app/LLM" "$CONTEXT/app/TTS" "$CONTEXT/app/containers" "$CONTEXT/config"
"$LLM_ENV/bin/python" "$ROOT/containers/collect_existing_runtime.py" \
  --environment "$LLM_ENV" --environment "$TTS_ENV" --native "$NATIVE" --cuda "$CUDA_DIR" --output "$CONTEXT"
tar -C "$ROOT/LLM" --exclude=runtime --exclude=llm_results --exclude=__pycache__ --exclude=.pytest_cache -cf - . | tar -C "$CONTEXT/app/LLM" -xf -
tar -C "$ROOT/TTS" --exclude=runtime --exclude=data --exclude=__pycache__ --exclude=.pytest_cache -cf - . | tar -C "$CONTEXT/app/TTS" -xf -
cp "$ROOT/containers/"{gpu_gate.py,output_paths.py,existing_entrypoint.sh} "$CONTEXT/app/containers/"
printf 'export ORIGINAL_ROOT=%q\nexport LLM_ENV=%q\nexport TTS_ENV=%q\nexport FFMPEG_DIR=%q\n' \
  "$ROOT" "$LLM_ENV" "$TTS_ENV" "$FFMPEG_DIR" > "$CONTEXT/config/paths.sh"
cp "$ROOT/containers/existing.Dockerfile" "$CONTEXT/Dockerfile"
"$LLM_ENV/bin/python" - "$ROOT" "${LLM_ENV%/envs/LLM}" "${TTS_ENV%/envs/TTS}" <<'PY'
import json,sys
from pathlib import Path
Path(sys.argv[1], 'existing-paths.env').write_text(''.join(k+'='+json.dumps(v)+'\n' for k,v in
    [('PROJECT_ROOT',sys.argv[1]),('LLM_CONDA_ROOT',sys.argv[2]),('TTS_CONDA_ROOT',sys.argv[3])]))
PY
du -sh "$CONTEXT"
docker info --format 'Docker data root: {{.DockerRootDir}}'
DOCKER_BUILDKIT=0 docker build --network=none --pull=false --target llm -t narration-llm:existing "$CONTEXT"
DOCKER_BUILDKIT=0 docker build --network=none --pull=false --target tts -t narration-tts:existing "$CONTEXT"
docker image inspect narration-llm:existing narration-tts:existing --format '{{.RepoTags}} logical image bytes={{.Size}}'
docker system df
echo 'Small images built. No services started. Use --env-file existing-paths.env with compose.existing.yaml.'
