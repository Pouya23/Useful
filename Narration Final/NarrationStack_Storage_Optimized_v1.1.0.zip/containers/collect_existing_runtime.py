"""Collect only ELF system dependencies; installed environments remain host mounts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--environment', action='append', required=True, type=Path)
    parser.add_argument('--native', required=True, type=Path)
    parser.add_argument('--cuda', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if sys.platform != 'linux':
        parser.error('Run this collector on the working Linux server')
    args.output.mkdir(parents=True, exist_ok=True)
    roots = [p.resolve() for p in args.environment] + [args.native.resolve(), args.cuda.resolve()]
    def mounted(path):
        real = path.resolve()
        return any(real.is_relative_to(root) for root in roots)
    binaries = {Path(shutil.which(n)) for n in ('bash', 'sh', 'env', 'dirname') if shutil.which(n)}
    for p in ('/sbin/ldconfig', '/sbin/ldconfig.real', '/usr/sbin/ldconfig', '/usr/sbin/ldconfig.real'):
        if Path(p).is_file():
            binaries.add(Path(p))
    seeds = set(binaries)
    # Never scan the CUDA GUI/profiler installation: only its runtime libraries.
    scans = [p.resolve() for p in args.environment] + [args.native, args.cuda/'lib64']
    for root in scans:
        seeds.update(p for p in root.rglob('*.so*') if p.is_file()
                     and not p.name.startswith(('libtk', 'libtcl', '_tkinter')))
    seeds.update(p/'bin/python' for p in args.environment)
    seeds.add(args.native/'llama-server')
    copied = set(binaries)
    missing = set()
    inspected = set()
    pending = list(seeds)
    libraries = []
    for root in args.environment:
        libraries += [root/'lib', root/'lib/python3.11/site-packages/torch/lib']
        libraries += list((root/'lib/python3.11/site-packages/nvidia').glob('*/lib'))
    libraries += [args.cuda/'lib64', args.native]
    env = os.environ.copy()
    env['LD_LIBRARY_PATH'] = ':'.join(str(p) for p in libraries if p.is_dir()) + ':' + env.get('LD_LIBRARY_PATH', '')
    # Never embed host driver binaries: the existing NVIDIA container runtime injects them.
    driver = re.compile(r'^lib(?:cuda\.|nvidia-|nvcuvid\.|nvidia-ml\.)')
    while pending:
        item = pending.pop()
        if item.resolve() in inspected:
            continue
        inspected.add(item.resolve())
        result = subprocess.run(['ldd', str(item)], env=env, capture_output=True, text=True, timeout=30)
        for line in result.stdout.splitlines():
            if '=> not found' in line:
                name = line.split()[0]
                if not driver.match(name):
                    missing.add(name)
                continue
            match = re.search(r'(?:=>\s+)?(/\S+)\s+\(', line)
            if not match:
                continue
            dep = Path(match.group(1))
            if not mounted(dep) and not driver.match(dep.name):
                if not dep.is_file() or not os.access(dep, os.R_OK):
                    raise RuntimeError(f'Required system library is unreadable: {dep}')
                copied.add(dep)
                pending.append(dep)
    # Optional modules may have unresolved libraries not used by these APIs. Keep
    # diagnostics, and test actual imports inside the finished mounted containers.
    for name in ('/etc/nsswitch.conf', '/etc/ld.so.cache', '/etc/ssl/certs/ca-certificates.crt'):
        if Path(name).is_file():
            copied.add(Path(name))
    archive = args.output/'runtime-minimal.tar'
    temporary = archive.with_suffix('.partial.tar')
    with tarfile.open(temporary, 'w', dereference=True) as tar:
        for path in sorted(copied):
            tar.add(path, arcname=str(path).lstrip('/'), recursive=False)
        for name in ('tmp', 'run', 'dev', 'proc', 'sys'):
            node = tarfile.TarInfo(name)
            node.type = tarfile.DIRTYPE
            node.mode = 0o1777 if name == 'tmp' else 0o755
            tar.addfile(node)
    temporary.replace(archive)
    report = {'system_file_count': len(copied), 'archive_bytes': archive.stat().st_size,
              'inspected_elf_count': len(inspected), 'optional_unresolved_libraries': sorted(missing),
              'files': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(copied)}}
    (args.output/'runtime-inventory.json').write_text(json.dumps(report, indent=2)+'\n')
    print(f'System runtime: {len(copied)} files, {archive.stat().st_size/1024**2:.1f} MiB; no environments/models copied.')


if __name__ == '__main__':
    main()
