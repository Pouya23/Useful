# No external base image, downloads, package installation or CUDA compilation.
FROM scratch AS common
ADD runtime-minimal.tar /
COPY app /app
COPY config /bundle-config
ENV NVIDIA_VISIBLE_DEVICES=all NVIDIA_DRIVER_CAPABILITIES=compute,utility \
    HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1 \
    PYTHONNOUSERSITE=1 HOME=/tmp TMPDIR=/tmp
ENTRYPOINT ["/bin/bash", "/app/containers/existing_entrypoint.sh"]

FROM common AS llm
WORKDIR /app/LLM
ENV SERVICE_KIND=llm LLM_PROFILE=native LLM_ENGINE=llama_cpp HTTP_PORT=8083 \
    LLM_DATA_DIR=/data MODELS_ROOT=/models INPUT_ROOT=/inputs
EXPOSE 8083
CMD ["api_server.py"]

FROM common AS tts
WORKDIR /app/TTS
ENV SERVICE_KIND=tts MODEL_DIR=/models/tts DATA_DIR=/data TTS_DEVICE=cuda:0 HTTP_PORT=8083
EXPOSE 8083
CMD ["run_server.py"]
