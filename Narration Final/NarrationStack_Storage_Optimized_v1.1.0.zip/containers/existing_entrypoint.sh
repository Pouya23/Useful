#!/usr/bin/env bash
set -euo pipefail
source /bundle-config/paths.sh
if [[ "$SERVICE_KIND" == llm ]]; then
  source "$ORIGINAL_ROOT/LLM/runtime/activate_python.sh"
  source "$ORIGINAL_ROOT/LLM/runtime/activate_native.sh"
  export SERVER_ROOT="$(dirname -- "$LLAMA_SERVER")"
  export PATH="$LLM_ENV/bin:$PATH"
  exec "$LLM_ENV/bin/python" "$@"
else
  source "$ORIGINAL_ROOT/TTS/runtime/activate_tools.sh"
  export PATH="$TTS_ENV/bin:$FFMPEG_DIR:$PATH"
  exec "$TTS_ENV/bin/python" "$@"
fi
