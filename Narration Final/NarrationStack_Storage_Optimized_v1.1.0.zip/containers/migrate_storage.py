"""Move the complete stack to the local POSIX filesystem with most free space."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys

LOCAL_FILESYSTEMS = {'ext2', 'ext3', 'ext4', 'xfs', 'btrfs', 'zfs', 'f2fs'}


def run(args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8*1024*1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def verify_tree(source, destination):
    """Check all entries, content, ownership, mode and links before any deletion."""
    source, destination = Path(source), Path(destination)
    seen = set()
    hardlinks = {}
    stack = [Path('.')]
    while stack:
        relative = stack.pop()
        src, dst = source/relative, destination/relative
        a, b = src.lstat(), dst.lstat()
        if stat.S_IFMT(a.st_mode) != stat.S_IFMT(b.st_mode):
            raise RuntimeError(f'Entry type mismatch: {relative}')
        if (stat.S_IMODE(a.st_mode), a.st_uid, a.st_gid) != (stat.S_IMODE(b.st_mode), b.st_uid, b.st_gid):
            raise RuntimeError(f'Permissions/ownership mismatch: {relative}')
        seen.add(relative.as_posix())
        if stat.S_ISLNK(a.st_mode):
            if os.readlink(src) != os.readlink(dst):
                raise RuntimeError(f'Symlink mismatch: {relative}')
        elif stat.S_ISREG(a.st_mode):
            if a.st_size != b.st_size or sha(src) != sha(dst):
                raise RuntimeError(f'File checksum mismatch: {relative}')
            identity = (a.st_dev, a.st_ino)
            if a.st_nlink > 1:
                previous = hardlinks.setdefault(identity, (b.st_dev, b.st_ino))
                if previous != (b.st_dev, b.st_ino):
                    raise RuntimeError(f'Hardlink mismatch: {relative}')
        elif stat.S_ISDIR(a.st_mode):
            stack.extend(relative/name for name in os.listdir(src))
        elif a.st_rdev != b.st_rdev:
            raise RuntimeError(f'Device metadata mismatch: {relative}')
    actual = {'.'}
    for parent, dirs, files in os.walk(destination, followlinks=False):
        for name in dirs+files:
            actual.add((Path(parent)/name).relative_to(destination).as_posix())
    if seen != actual:
        raise RuntimeError('Source/destination entry inventory differs')


def best_mount():
    result = run(['findmnt', '--json', '--output', 'TARGET,FSTYPE,OPTIONS'], capture_output=True, text=True)
    nodes = json.loads(result.stdout)['filesystems']
    candidates = {}
    def visit(entries):
        for entry in entries:
            path = Path(entry['target'])
            options = set(entry.get('options', '').split(','))
            if entry['fstype'] in LOCAL_FILESYSTEMS and 'ro' not in options and 'noexec' not in options and path.is_dir() and os.access(path, os.W_OK):
                info = os.statvfs(path)
                free = info.f_bavail * info.f_frsize
                dev = path.stat().st_dev
                # Prefer the shallow mount entry when several bind mounts share a device.
                old = candidates.get(dev)
                if old is None or len(path.parts) < len(old[1].parts):
                    candidates[dev] = (free, path)
            visit(entry.get('children', []))
    visit(nodes)
    if not candidates:
        raise RuntimeError('No writable, executable local POSIX filesystem found')
    free, path = max(candidates.values(), key=lambda pair: pair[0])
    return path, free


def compact_roots(entries):
    roots = []
    for label, path in entries:
        path = Path(path).resolve(strict=True)
        critical = {Path(p) for p in ('/', '/etc', '/usr', '/usr/local', '/var', '/var/lib', '/home', '/mnt', '/opt')}
        if not path.is_dir() or path in critical or len(path.parts) < 3:
            raise ValueError(f'Refusing unsafe source directory: {path}')
        if any(path == other or path.is_relative_to(other) for _, other in roots):
            continue
        roots = [(name, other) for name, other in roots if not other.is_relative_to(path)]
        roots.append((label, path))
    return roots


def transfer(source, destination):
    """Preserve the old absolute prefix as a forwarding symlink."""
    source, destination = Path(source), Path(destination)
    if destination == source or destination.is_relative_to(source) or source.is_relative_to(destination):
        raise ValueError('Migration target overlaps its source')
    if destination.exists() or destination.is_symlink():
        raise ValueError(f'Destination already exists: {destination}')
    destination.parent.mkdir(parents=True, exist_ok=True)
    original = source.resolve(strict=True)
    if original != source:
        raise ValueError('Transfer sources must be resolved directories')
    if source.stat().st_dev == destination.parent.stat().st_dev:
        # Same filesystem: rename is atomic, preserves every inode, needs no duplicate copy.
        source.rename(destination)
        try:
            source.symlink_to(destination, target_is_directory=True)
        except BaseException:
            destination.rename(source)
            raise
        return 'atomic_rename'
    destination.mkdir()
    try:
        run(['cp', '-a', '--reflink=auto', '--', str(source)+'/.', str(destination)+'/' ])
        verify_tree(source, destination)
    except BaseException:
        print(f'Copy/verification failed. Original retained at {source}; partial copy retained at {destination}.', file=sys.stderr)
        raise
    # Check again immediately before removing anything: never recurse on a symlink.
    if source.resolve(strict=True) != original or source.is_symlink() or not destination.is_dir():
        raise RuntimeError('Source/target changed during migration; refusing removal')
    backup = source.with_name(source.name+'.migration-original-'+destination.parent.name)
    if backup.exists():
        raise RuntimeError(f'Backup collision: {backup}')
    source.rename(backup)
    try:
        source.symlink_to(destination, target_is_directory=True)
    except BaseException:
        backup.rename(source)
        raise
    if source.resolve(strict=True) != destination.resolve(strict=True):
        raise RuntimeError('Forwarding link verification failed; original backup retained')
    if backup.is_symlink() or backup.parent != original.parent:
        raise RuntimeError('Unsafe original backup path; refusing removal')
    shutil.rmtree(backup)
    return 'verified_copy'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path('/mnt/hard/home/toroghi/NarrationStack'))
    parser.add_argument('--llm-root', type=Path, default=Path('/home/ali/miniconda-LLM'))
    parser.add_argument('--tts-root', type=Path, default=Path('/home/ali/miniconda-TTS'))
    parser.add_argument('--extra-path', action='append', type=Path, default=[])
    parser.add_argument('--move-docker-data', action='store_true')
    parser.add_argument('--execute', action='store_true', help='Without this flag print the migration plan only')
    args = parser.parse_args()
    if sys.platform != 'linux':
        parser.error('Run on the Linux device')
    if os.geteuid() != 0:
        parser.error('Run with sudo to preserve ownership and move Docker data; nothing will be installed')
    entries = [('project', args.project), ('miniconda-LLM', args.llm_root), ('miniconda-TTS', args.tts_root)]
    entries += [(f'extra-{i}', p) for i, p in enumerate(args.extra_path)]
    active_services = []
    if args.move_docker_data:
        data = run(['docker', 'info', '--format', '{{.DockerRootDir}}'], capture_output=True, text=True).stdout.strip()
        if not data:
            raise RuntimeError('Docker did not report a data root')
        entries.append(('docker-data', Path(data)))
        if Path('/var/lib/containerd').is_dir():
            entries.append(('containerd-data', Path('/var/lib/containerd')))
        for service in ('docker.service', 'docker.socket', 'containerd.service'):
            if subprocess.run(['systemctl', 'is-active', '--quiet', service]).returncode == 0:
                active_services.append(service)
    roots = compact_roots(entries)
    mount, free = best_mount()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    target = mount/'NarrationStackStorage'/stamp
    plans = []
    copy_bytes = 0
    for label, source in roots:
        size = int(run(['du', '-s', '--block-size=1', str(source)], capture_output=True, text=True).stdout.split()[0])
        destination = target/label
        if destination.is_relative_to(source) or source.is_relative_to(destination):
            raise RuntimeError(f'Chosen destination overlaps source: {source}. No data moved.')
        if source.stat().st_dev != mount.stat().st_dev:
            copy_bytes += size
        plans.append({'label': label, 'source': str(source), 'destination': str(destination), 'allocated_bytes': size})
    print(json.dumps({'chosen_mount': str(mount), 'free_bytes': free, 'cross_filesystem_copy_bytes': copy_bytes,
                      'target': str(target), 'moves': plans, 'services_to_stop': active_services}, indent=2), flush=True)
    if free < copy_bytes + max(1024**3, copy_bytes//20):
        raise RuntimeError('The filesystem with most free space lacks room for verified copies plus reserve. No data moved.')
    if not args.execute:
        print('Plan only. Add --execute to move. All project downloads/results/build contexts are included.')
        return
    # Refuse live host inference. Closing it is necessary for consistent SQLite/model state.
    processes = run(['ps', '-eo', 'args='], capture_output=True, text=True).stdout.splitlines()
    for command in processes:
        if ('llama-server' in command or
            (any(name in command for name in ('api_server.py', 'run_server.py', 'run_pipeline.py', 'run_mock.py')) and 'python' in command)):
            raise RuntimeError(f'Stop this host inference process before migration: {command}')
    for service in active_services:
        run(['systemctl', 'stop', service])
    target.mkdir(parents=True)
    user_uid, user_gid = int(os.getenv('SUDO_UID', '0')), int(os.getenv('SUDO_GID', '0'))
    os.chown(target, user_uid, user_gid)
    report = {'target': str(target), 'plan': plans, 'moves': [], 'note': 'Original prefixes remain forwarding symlinks; no downloads/installations.'}
    manifest = target/'migration.json'
    manifest.write_text(json.dumps(report, indent=2)+'\n')
    os.chown(manifest, user_uid, user_gid)
    try:
        for plan in plans:
            print(f"Moving {plan['source']} -> {plan['destination']}", flush=True)
            method = transfer(plan['source'], plan['destination'])
            report['moves'].append({**plan, 'method': method})
            manifest.write_text(json.dumps(report, indent=2)+'\n')
            os.chown(manifest, user_uid, user_gid)
        os.sync()
    except BaseException:
        print(f'Migration stopped; verified earlier moves retained. Inspect {manifest}. Docker remains stopped to protect incomplete data.', file=sys.stderr)
        raise
    for service in reversed(active_services):
        run(['systemctl', 'start', service])
    print(f'Complete. Manifest: {manifest}. Original project/environment paths continue to work.', flush=True)
    if args.move_docker_data:
        run(['docker', 'info', '--format', 'Docker logical root: {{.DockerRootDir}}'])
        print('The logical Docker path is retained as a symlink; its physical data is on the chosen filesystem.')


if __name__ == '__main__':
    main()
