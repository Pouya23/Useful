#!/usr/bin/env bash
# Finds the largest free local filesystem, preserves everything, then builds small images.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON="${MIGRATION_PYTHON:-/home/ali/miniconda-LLM/envs/LLM/bin/python}"
LLM_ROOT="${LLM_CONDA_ROOT:-/home/ali/miniconda-LLM}"
TTS_ROOT="${TTS_CONDA_ROOT:-/home/ali/miniconda-TTS}"
# Preview before stopping/moving data. No download or installation commands.
sudo "$PYTHON" "$ROOT/containers/migrate_storage.py" --project "$ROOT" \
  --llm-root "$LLM_ROOT" --tts-root "$TTS_ROOT" --move-docker-data "$@"
docker compose -f "$ROOT/compose.existing.yaml" down
sudo "$PYTHON" "$ROOT/containers/migrate_storage.py" --project "$ROOT" \
  --llm-root "$LLM_ROOT" --tts-root "$TTS_ROOT" --move-docker-data --execute "$@"
LLM_ENV="$LLM_ROOT/envs/LLM" TTS_ENV="$TTS_ROOT/envs/TTS" bash "$ROOT/containers/build_existing.sh"
echo "Build complete. Start only when ready: cd '$ROOT'; docker compose --env-file existing-paths.env -f compose.existing.yaml up -d --no-build --pull never"
