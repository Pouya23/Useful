#!/usr/bin/env bash
# Temporary containers test mounted environments/native dependency closure, no model downloads.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
docker compose --env-file existing-paths.env -f compose.existing.yaml run --rm --no-deps llm -c \
 'import flask,pydantic,waitress,pynvml; pynvml.nvmlInit(); print("LLM runtime/NVML ready"); pynvml.nvmlShutdown()'
docker compose --env-file existing-paths.env -f compose.existing.yaml run --rm --no-deps tts -c \
 'import torch,torchaudio,kokoro,spacy,espeakng_loader; assert spacy.util.is_package("en_core_web_sm"); assert torch.cuda.is_available(); print(torch.ones(2,device="cuda").sum().item()); print("TTS runtime/CUDA ready",torch.__version__)'
