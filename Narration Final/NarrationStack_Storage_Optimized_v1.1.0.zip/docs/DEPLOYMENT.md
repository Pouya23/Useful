# Storage-optimized offline containers and complete storage migration

Your screenshot shows **24.03 GB being sent as the old Docker build context**, followed by `No space left on device` while copying LibreOffice into Docker's image storage. That 24.03 GB is the build context, not a measured final image size. The old method duplicated desktop/system files, conda roots, native/CUDA libraries and FFmpeg into snapshots and image layers. Docker also needs space in its own data filesystem, which can differ from the model/download filesystem.

This patch replaces that approach. Images contain only application source and the system ELF dependency closure found with `ldd`. Installed conda roots, the compiled native server, CUDA toolkit/runtime and FFmpeg are **read-only host mounts**, as are the models. No environment/package/model is installed or downloaded. Both images reuse the same base/source layers. There is no full `/usr/share`, LibreOffice, Ollama, full-system snapshot or environment archive in the new build context. The collector prints actual bytes; final size is measured by `docker image inspect` and `docker system df`, not guessed here.

## 1. Replace the patch files

Extract this ZIP directly into `/mnt/hard/home/toroghi/NarrationStack`, keeping its file layout. It replaces deployment/container scripts and API Swagger examples; it does not replace any installed environment, model or package cache. Stop the old build first with Ctrl+C. Do not rerun the old snapshot builder.

## 2. Move everything to the filesystem with most free space, then build

Stop any host inference processes (`api_server.py`, `run_server.py`, `run_pipeline.py`, `run_mock.py`) before migration. The script refuses to move live inference state. It automatically stops this Compose stack and then Docker/containerd services while migrating their data. **Other Docker workloads on this device are also paused during the Docker-data move.** They are not deleted; normal daemon restart policies apply when Docker restarts.

Run:

```bash
cd /mnt/hard/home/toroghi/NarrationStack
bash containers/move_and_build_existing.sh
```

Unlike the earlier permission fix, sudo is required **only for migration**, to preserve ownership/permissions and move Docker's system-owned data. The wrapper asks for sudo and uses your already installed Python 3.11; it installs nothing. The image build itself runs under your normal user.

The script discovers local mounted ext2/3/4, XFS, Btrfs, ZFS or F2FS filesystems using `findmnt`/`statvfs`. It ignores read-only, no-exec, virtual, network and incompatible non-POSIX filesystems. Among usable filesystems it selects the one with the most available bytes. It prints the selected mount, free space, all source/target paths and estimated cross-filesystem copy size before moving. The new physical base is:

```text
CHOSEN_MOUNT/NarrationStackStorage/UTC_TIMESTAMP/
```

It moves the entire project, so **all previous downloads, models, sources, compiled code, tools, partial downloads, old build contexts, results, SQLite state, docs and configuration inside it are included**. It also moves `/home/ali/miniconda-LLM`, `/home/ali/miniconda-TTS`, Docker's reported data root, and `/var/lib/containerd` when present. Caches/files outside these directories can be explicitly added using repeatable `--extra-path /absolute/path`:

```bash
bash containers/move_and_build_existing.sh --extra-path /path/to/another/download-cache
```

Specify actual environment roots through `LLM_CONDA_ROOT`, `TTS_CONDA_ROOT` and `MIGRATION_PYTHON` if your paths differ. Default migration interpreter is `/home/ali/miniconda-LLM/envs/LLM/bin/python`.

Moving installed conda directories normally breaks embedded absolute paths. This script keeps **forwarding symlinks at each original path**, so `/mnt/hard/home/toroghi/NarrationStack` and both original conda prefixes still work while the data physically lives on the selected disk. No activation scripts, shebangs or model paths need rewriting. Docker keeps its logical data-root path as a forwarding symlink too, so its daemon configuration is preserved. The copied installations are intentionally tied to this host's preserved prefixes; these small images are not standalone portable environment images.

Same-filesystem moves use atomic renames, preserving inodes without duplicating storage. Cross-filesystem moves use `cp -a --reflink=auto`, then verify the complete entry inventory, file SHA256, types, permissions, ownership, symlink targets and internal hardlink relationships before deleting original data. Copies include all existing files, not only current package versions. A failure before verification retains the original; partial destination data remains available for inspection. No automatic global prune/delete is run. If migration fails, Docker remains stopped to avoid writing into incompletely moved state; read the printed error and `migration.json` before restarting or retrying.

The script requires space for all cross-filesystem copies plus a reserve. If even the largest compatible filesystem lacks enough free space, it stops before moving anything. It cannot manufacture disk capacity. Full verification can take time for large model/cache files; this is local I/O, not a download.

For a plan without any move or service stop:

```bash
sudo /home/ali/miniconda-LLM/envs/LLM/bin/python containers/migrate_storage.py \
  --project /mnt/hard/home/toroghi/NarrationStack --move-docker-data
```

This can be used before the wrapper. The wrapper itself previews its plan and then proceeds; no interactive approval is needed beyond sudo authentication. Do not pass `--execute` manually to the wrapper. The migration manifest records completed moves and their physical destinations. If you change files while they are being copied, verification can fail: keep services/builds/installers stopped.

## 3. Verify the smaller mounted runtime and start services

After the move/build finishes, the old project path still works:

```bash
cd /mnt/hard/home/toroghi/NarrationStack
# Runs two temporary verification containers, no models/downloads:
bash containers/verify_existing.sh
docker compose --env-file existing-paths.env -f compose.existing.yaml \
  up -d --no-build --pull never
docker compose --env-file existing-paths.env -f compose.existing.yaml logs -f
```

The verifier checks LLM NVML imports and TTS Torch/Kokoro/spaCy imports plus a tiny real CUDA operation. This verifies the collected system dependencies and read-only environment mounts on your actual host; it does not claim a completed model generation. The ELF collector records unresolved optional-module dependencies in its inventory; required runtime failures should stop deployment, not trigger package downloads. The existing NVIDIA runtime supplies the driver libraries.

Addresses remain:

- LLM: `http://DEVICE_IP:8083`, bound to `0.0.0.0`.
- TTS: `http://DEVICE_IP:8084`, bound to `0.0.0.0`.
- Swagger: `/docs/` on each port.

Both container processes listen internally on 8083. The LLM duration API uses `tts:8083`, not the external 8084 mapping. GPU 0 and a shared admission lock remain unchanged. Resident model weights still must fit together in 11 GB VRAM. Set `LLM_API_KEY` and `TTS_API_KEY` in your shell when needed; `existing-paths.env` contains paths only, no credentials. Swagger generation examples are valid, and progress examples use the latest existing job after generation and a Swagger reload. Models, job timestamps and retry behavior are unchanged.

If you only need to rebuild later, run `bash containers/build_existing.sh`; do not repeat the migration unnecessarily. It creates a separate `existing-image-context-small` rather than reusing the bloated old archives. The `existing-paths.env` file ensures Compose uses the same original paths baked into the container entrypoint.

## 4. See the real storage footprint

```bash
cd /mnt/hard/home/toroghi/NarrationStack
du -sh existing-image-context-small existing-image-context 2>/dev/null || true
docker image inspect narration-llm:existing narration-tts:existing \
  --format '{{.RepoTags}} logical bytes={{.Size}}'
docker system df -v
docker info --format '{{.DockerRootDir}}'
df -h "$(docker info --format '{{.DockerRootDir}}')"
readlink -f "$(docker info --format '{{.DockerRootDir}}')"
```

Image logical sizes include common layers; do not add both image sizes to infer unique disk usage. `docker system df -v` distinguishes shared/unique storage. Docker's data directory now resolves to the selected disk; moving only the project would not have achieved this.

Old 24 GB context archives are preserved during migration because you asked to move everything. Once the new images pass verification, the old `existing-image-context` is only a generated staging copy; it is not used by the new images. Keeping it consumes disk space. Archive/remove only that known staging directory if you want to reclaim it, after checking that you did not put unique user files there. Do **not** remove `LLM-downloads`, `TTS-downloads`, models, conda roots, native runtime or the new context. No broad Docker prune is run: that could affect unrelated images/containers/build caches.

## Scope and validation

The new scripts were checked locally; tests cover migration overlap rejection, verification failures and source consolidation. Linux storage discovery, root-owned Docker migration, GPU runtime collection and image builds remain device-side operations. No data was moved on your device and no containers were started by the assistant. The wrapper's commands perform the requested migration/build when you execute it. Do not treat the old 24.03 GB context as an optimized image, and do not assume a new final size before running the collector/build measurements.
