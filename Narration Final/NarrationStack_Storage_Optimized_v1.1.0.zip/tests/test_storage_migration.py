import importlib.util
from pathlib import Path
import sys
import json
import os
from types import SimpleNamespace

import pytest

spec = importlib.util.spec_from_file_location('storage_migration',
    Path(__file__).resolve().parents[1]/'containers/migrate_storage.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_same_filesystem_move_preserves_paths_content_and_inode(tmp_path):
    source = tmp_path/'source'
    source.mkdir()
    (source/'model.bin').write_bytes(b'checkpoint')
    inode = (source/'model.bin').stat().st_ino
    target = tmp_path/'storage'/'project'
    try:
        method = module.transfer(source, target)
    except OSError as exc:
        if sys.platform == 'win32' and getattr(exc, 'winerror', 0) == 1314:
            pytest.skip('Windows symlink privilege is unavailable')
        raise
    assert method == 'atomic_rename'
    assert source.is_symlink()
    assert (source/'model.bin').read_bytes() == b'checkpoint'
    assert (target/'model.bin').stat().st_ino == inode


def test_move_refuses_nested_or_existing_destination(tmp_path):
    source = tmp_path/'source'
    source.mkdir()
    with pytest.raises(ValueError, match='overlaps'):
        module.transfer(source, source/'nested')
    target = tmp_path/'existing'
    target.mkdir()
    with pytest.raises(ValueError, match='already exists'):
        module.transfer(source, target)
    assert source.is_dir()


def test_verification_detects_corruption_and_extra_entries(tmp_path):
    source, target = tmp_path/'source', tmp_path/'target'
    source.mkdir()
    target.mkdir()
    for root in (source,target):
        (root/'checkpoint').write_bytes(b'working weights')
    module.verify_tree(source,target)
    (target/'checkpoint').write_bytes(b'changed weights')
    with pytest.raises(RuntimeError, match='checksum'):
        module.verify_tree(source,target)
    assert (source/'checkpoint').read_bytes() == b'working weights'
    (target/'checkpoint').write_bytes(b'working weights')
    (target/'extra').touch()
    with pytest.raises(RuntimeError, match='inventory'):
        module.verify_tree(source,target)


def test_overlapping_sources_are_not_copied_twice(tmp_path):
    project = tmp_path/'project'
    models = project/'models'
    models.mkdir(parents=True)
    roots = module.compact_roots([('models',models),('project',project)])
    assert roots == [('project',project.resolve())]


def test_failed_forwarding_symlink_rolls_back_atomic_rename(tmp_path, monkeypatch):
    source = tmp_path/'source'
    source.mkdir()
    (source/'generation').write_text('preserve me')
    target = tmp_path/'newbase'/'source'
    def refuse(*args, **kwargs):
        raise OSError('simulated symlink failure')
    monkeypatch.setattr(Path, 'symlink_to', refuse)
    with pytest.raises(OSError, match='simulated'):
        module.transfer(source,target)
    assert (source/'generation').read_text() == 'preserve me'
    assert not target.exists()


def test_mount_selection_prefers_most_free_usable_local_filesystem(tmp_path, monkeypatch):
    paths = [tmp_path/n for n in ('small','large','readonly','noexec','virtual')]
    for path in paths:
        path.mkdir()
    rows = [{'target':str(p),'fstype':'tmpfs' if i==4 else 'ext4',
             'options':'ro' if i==2 else 'rw,noexec' if i==3 else 'rw'} for i,p in enumerate(paths)]
    monkeypatch.setattr(module,'run',lambda *a,**k:SimpleNamespace(stdout=json.dumps({'filesystems':rows})))
    real_stat=Path.stat
    def stats(path,*args,**kwargs):
        value=real_stat(path,*args,**kwargs)
        if path in paths:
            fields=list(value)
            fields[2]=paths.index(path)+100
            return os.stat_result(fields)
        return value
    monkeypatch.setattr(Path,'stat',stats)
    free={path: amount for path,amount in zip(paths,[10,20,1000,2000,3000])}
    monkeypatch.setattr(module.os,'statvfs',lambda p:SimpleNamespace(f_bavail=free[p],f_frsize=1),raising=False)
    assert module.best_mount()==(paths[1],20)
