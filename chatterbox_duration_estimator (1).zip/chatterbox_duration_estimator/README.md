# Local English Chatterbox duration estimator

This project is for the **original English-only** `chatterbox.tts.ChatterboxTTS`, loaded from files already on your machine. It does not use a hosted TTS API.

## Why this design

With only 1000 synthesized examples, a neural duration Transformer trained from scratch is a poor use of the data. The estimator instead uses:

- exact Chatterbox text-token count,
- CMU pronunciation-derived phoneme/syllable counts,
- punctuation / sentence / numeric features,
- additive character and word hashing features,
- a relative-error-weighted Ridge model,
- an optional shallow histogram-gradient-boosting residual correction,
- out-of-fold calibration,
- an untouched 15% holdout test,
- deterministic chunking for arbitrary-length text.

The sampling seed is reset to the **same value before every Chatterbox call**. Do the same in production. If production synthesis is randomly seeded, sub-1% error for individual stochastic generations is generally not a realistic guarantee.

## Expected local checkpoint directory

Point `--checkpoint-dir` to a directory containing at least:

```text
ve.safetensors
t3_cfg.safetensors
s3gen.safetensors
tokenizer.json
```

`conds.pt` may also be present but is not required when you provide `--ref`.

Your Python environment also needs the Chatterbox package/source importable. For a local source checkout:

```bash
cd /path/to/chatterbox
pip install -e .
```

Then install the small extra dependencies:

```bash
pip install -r requirements-extra.txt
```


## Build the recommended general-English corpus automatically

For a broad general-English candidate pool, use the included FineWeb streaming builder:

```bash
pip install -r requirements-extra.txt

python build_corpus.py \
  --output general_english_corpus.jsonl \
  --count 12000 \
  --max-chars 260
```

It streams `HuggingFaceFW/fineweb` with the `sample-10BT` configuration and stops once enough high-quality passages have been collected. It does **not** intentionally download the full dataset.

The resulting corpus is balanced for duration estimation across:
- passage length,
- ordinary prose,
- punctuation-heavy prose,
- numbers/dates/percentages,
- questions,
- quotations,
- abbreviations/acronyms,
- mixed cases.

Ten percent of the candidate file is generated locally from timing-stress templates so the final 1000 TTS samples are less likely to have blind spots around normalized numbers and abbreviations.

Then run the TTS/data/training pipeline:

```bash
python duration_pipeline.py wizard \
  --checkpoint-dir /models/chatterbox \
  --ref /voices/reference.wav \
  --corpus general_english_corpus.jsonl \
  --workdir ./duration_run \
  --samples 1000
```

`general_english_corpus.jsonl.summary.json` records the source/bucket/length distribution.

If your real application has a known text domain, your own production-like corpus is still better than a generic web corpus. You can also concatenate your own JSONL/text with this candidate pool before running the wizard.


## Best one-command workflow

Use a **real local text corpus matching what your application will speak**. A `.txt` file or JSONL file with a `text` field is accepted.

```bash
python duration_pipeline.py wizard \
  --checkpoint-dir /models/chatterbox \
  --ref /voices/reference.wav \
  --corpus /data/my_real_english_texts.txt \
  --workdir ./duration_run \
  --samples 1000
```

The program:

1. Creates a CFG × exaggeration audio grid.
2. Writes `duration_run/grid/index.html`.
3. Prints its local `file://` URL.
4. Waits for you to type the preferred grid ID.
5. Selects 1000 unique text chunks.
6. Synthesizes `duration_run/dataset/audio/0000.wav` ... locally.
7. Appends every completed row immediately to `dataset.csv`, so collection is resumable.
8. Trains the estimator.
9. Prints untouched-holdout metrics and writes them to `duration_run/model/evaluation.json`.
10. Refits the production estimator on all 1000 examples.

If you already know the grid ID, pass `--choice ID`.

## Grid ranges

Defaults:

```text
cfg_weight:   0.25, 0.35, 0.45, 0.55, 0.65
exaggeration: 0.35, 0.50, 0.65, 0.80, 1.00
```

Override them:

```bash
--cfg-grid 0.20,0.30,0.40,0.50,0.60 \
--exag-grid 0.40,0.55,0.70,0.85
```

Temperature/min-p/top-p/repetition penalty are held fixed during the grid and the 1000-sample dataset:

```bash
--temperature 0.8 --min-p 0.05 --top-p 1.0 --repetition-penalty 1.2
```

Do not change these later without retraining/calibrating.

## Corpus recommendation

For the best estimator, do not rely on the built-in Faker fallback. Supply several thousand or more real candidate passages from the same distribution as your production text: narration, dialogue, numbers, abbreviations, questions, punctuation, etc.

Only 1000 passages are synthesized; the larger corpus is merely a candidate pool from which those 1000 are selected.

JSONL example:

```json
{"text":"The first candidate passage."}
{"text":"Another passage with 18.5% and a date, September 30, 2026."}
```

Use `--jsonl-field content` if your field has another name.

## Resume after interruption

Re-run:

```bash
python duration_pipeline.py collect \
  --workdir ./duration_run \
  --corpus /data/my_real_english_texts.txt \
  --samples 1000
```

It validates existing IDs/text hashes and skips completed rows.

Then train:

```bash
python duration_pipeline.py train --workdir ./duration_run
```

## Predict duration

Short text:

```bash
python duration_pipeline.py predict \
  --model-dir ./duration_run/model \
  --text "This is the text whose duration I want to estimate."
```

Long document:

```bash
python duration_pipeline.py predict \
  --model-dir ./duration_run/model \
  --text-file ./chapter.txt
```

Long text is deterministically split into the same <=260-character chunks used during training. The predicted total is:

```text
sum(predicted chunk durations) + exact inserted join silences
```

This is the correct way to make the estimator scale to arbitrary-length text.

## Generate long speech with matching behavior

If you want the estimator and actual TTS duration to refer to exactly the same process:

```bash
python duration_pipeline.py synthesize-long \
  --checkpoint-dir /models/chatterbox \
  --ref /voices/reference.wav \
  --model-dir ./duration_run/model \
  --text-file ./chapter.txt \
  --output ./chapter.wav
```

The command prints predicted duration, actual duration and absolute percent error.

## Files produced

```text
duration_run/
  run_config.json
  selected_texts.jsonl
  grid/
    index.html
    grid.json
    *.wav
  dataset/
    dataset.csv
    audio/
      0000.wav
      ...
  model/
    estimator.joblib
    tokenizer.json
    metadata.json
    evaluation.json
    holdout_predictions.csv
```

## Interpreting the accuracy report

The main metrics are:

- `mape_percent`: mean absolute percentage error.
- `median_ape_percent`.
- `p95_ape_percent`.
- `within_1_percent_fraction`: fraction of untouched holdout examples whose error is under 1%.

Do not interpret a low training/OOF error as proof of sub-1% accuracy. The untouched holdout is the meaningful check.

For arbitrary long text, the estimator will usually become relatively more accurate if chunk errors are approximately unbiased, because positive and negative chunk errors partly cancel. Systematic pacing bias does not cancel; the OOF affine calibration is included specifically to reduce that bias.

## Important validity constraints

The saved estimator is tied to:

- this reference voice,
- the selected `cfg_weight`,
- selected `exaggeration`,
- temperature,
- `min_p`,
- `top_p`,
- repetition penalty,
- fixed sampling seed,
- this Chatterbox checkpoint/version,
- the provided chunking rule.

Change any of these materially and collect/retrain again.

## Why not a neural network?

With only 1000 labels, training a text encoder/Transformer from scratch wastes the data on learning spelling and language structure that are only indirectly related to duration. The hybrid estimator has a much stronger inductive bias for duration: its main features are counts that remain additive as text gets longer, while the small nonlinear residual model is only allowed to correct systematic interactions when cross-validation proves useful.
