#!/usr/bin/env python3
"""
Build a high-quality English candidate corpus for the Chatterbox duration estimator.

Default source:
    HuggingFaceFW/fineweb, config="sample-10BT", streamed with `datasets`.

The output is JSONL:
    {"text": "...", "source": "fineweb", "bucket": "...", "length": 123}

The builder does NOT download the entire dataset. It streams documents until it
has enough high-quality Chatterbox-sized passages, then stops.

Recommended:
    python build_corpus.py \
        --output general_english_corpus.jsonl \
        --count 12000 \
        --max-chars 260

Then:
    python duration_pipeline.py wizard \
        --checkpoint-dir /path/to/chatterbox \
        --ref /path/to/ref.wav \
        --corpus general_english_corpus.jsonl \
        --workdir ./duration_run \
        --samples 1000
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

try:
    from datasets import load_dataset
except ImportError as e:
    raise SystemExit(
        "Missing Hugging Face datasets. Install with:\n"
        "    pip install 'datasets>=3.0' huggingface_hub"
    ) from e

# Reuse exactly the same chunking policy as the estimator pipeline when possible.
try:
    from duration_pipeline import chunk_text, normalize_ws
except ImportError:
    _SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")
    _CLAUSE_SPLIT = re.compile(r"(?<=[,;:])\s+")

    def normalize_ws(text: str) -> str:
        return " ".join(str(text).replace("\u00a0", " ").split()).strip()

    def _split_words(text: str, max_chars: int) -> list[str]:
        words = text.split()
        out, buf = [], ""
        for w in words:
            if len(w) > max_chars:
                if buf:
                    out.append(buf)
                    buf = ""
                out.extend(w[i : i + max_chars] for i in range(0, len(w), max_chars))
                continue
            cand = w if not buf else f"{buf} {w}"
            if len(cand) <= max_chars:
                buf = cand
            else:
                if buf:
                    out.append(buf)
                buf = w
        if buf:
            out.append(buf)
        return out

    def _split_unit(text: str, max_chars: int) -> list[str]:
        text = normalize_ws(text)
        if len(text) <= max_chars:
            return [text] if text else []
        clauses = [normalize_ws(x) for x in _CLAUSE_SPLIT.split(text) if normalize_ws(x)]
        if len(clauses) <= 1:
            return _split_words(text, max_chars)
        out, buf = [], ""
        for c in clauses:
            cand = c if not buf else f"{buf} {c}"
            if len(cand) <= max_chars:
                buf = cand
            else:
                if buf:
                    out.append(buf)
                if len(c) <= max_chars:
                    buf = c
                else:
                    out.extend(_split_words(c, max_chars))
                    buf = ""
        if buf:
            out.append(buf)
        return out

    def chunk_text(text: str, max_chars: int = 260) -> list[str]:
        text = normalize_ws(text)
        units = []
        for s in _SENTENCE_SPLIT.split(text):
            units.extend(_split_unit(s, max_chars))
        out, buf = [], ""
        for u in units:
            cand = u if not buf else f"{buf} {u}"
            if len(cand) <= max_chars:
                buf = cand
            else:
                if buf:
                    out.append(buf)
                buf = u
        if buf:
            out.append(buf)
        return [x for x in out if x]


URL_RE = re.compile(r"(?:https?://|www\.)\S+", re.I)
EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b")
HTML_RE = re.compile(r"<[^>]{1,200}>")
CODEISH_RE = re.compile(
    r"(?:\b(?:function|const|var|let|class|def|import|SELECT|INSERT|DOCTYPE)\b.*[{};]"
    r"|[{}][^{}]{0,80}[{}]"
    r"|(?:=>|::|</\w+>|```))",
    re.I,
)
WORD_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?")
NUMBER_RE = re.compile(r"\b\d+(?:[.,:/-]\d+)*%?\b")
ABBREV_RE = re.compile(
    r"\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|vs|etc|e\.g|i\.e|U\.S|U\.K|a\.m|p\.m)\."
    r"|\b(?:[A-Z]\.){2,}"
)
ACRONYM_RE = re.compile(r"\b[A-Z]{2,6}\b")
QUOTE_RE = re.compile(r'["“”‘’]')
QUESTION_RE = re.compile(r"\?")
EXCL_RE = re.compile(r"!")
PUNCT_RE = re.compile(r"[,;:—–()-]")
REPEATED_PUNCT_RE = re.compile(r"([!?.,;:_=\-*#])\1{2,}")
NAVISH_RE = re.compile(
    r"\b(?:cookie policy|privacy policy|terms of service|sign in|log in|subscribe now|"
    r"accept cookies|all rights reserved|javascript is disabled|menu|skip to content)\b",
    re.I,
)

# Natural target mixture for the FINAL candidate corpus.
# "plain" is deliberately dominant. Rare timing-sensitive structures are oversampled
# enough to be learned by a 1000-example model, but not enough to dominate it.
BUCKET_WEIGHTS = {
    "plain": 0.50,
    "punctuated": 0.15,
    "numeric": 0.12,
    "question": 0.07,
    "quoted": 0.06,
    "abbrev_acronym": 0.05,
    "mixed": 0.05,
}

# Chatterbox-sized passage distribution. Longer chunks matter because arbitrary-long
# text is estimated by summing these chunks.
LENGTH_BINS = [
    (25, 59, 0.08),
    (60, 99, 0.12),
    (100, 149, 0.18),
    (150, 199, 0.20),
    (200, 229, 0.18),
    (230, 260, 0.24),
]


def canonical_key(text: str) -> str:
    norm = re.sub(r"\W+", " ", text.lower()).strip()
    return hashlib.sha1(norm.encode("utf-8")).hexdigest()


def ascii_letter_ratio(text: str) -> float:
    letters = [ch for ch in text if ch.isalpha()]
    if not letters:
        return 0.0
    ascii_letters = sum(("a" <= ch.lower() <= "z") for ch in letters)
    return ascii_letters / len(letters)


def printable_ratio(text: str) -> float:
    if not text:
        return 0.0
    return sum(ch.isprintable() for ch in text) / len(text)


def is_good_tts_passage(text: str, min_chars: int, max_chars: int) -> bool:
    t = normalize_ws(text)
    if not (min_chars <= len(t) <= max_chars):
        return False

    words = WORD_RE.findall(t)
    if len(words) < 5:
        return False

    # Avoid code, markup, navigation boilerplate, and malformed web fragments.
    if HTML_RE.search(t) or CODEISH_RE.search(t) or REPEATED_PUNCT_RE.search(t):
        return False
    if NAVISH_RE.search(t):
        return False

    if printable_ratio(t) < 0.995:
        return False
    if ascii_letter_ratio(t) < 0.96:
        return False

    alpha = sum(ch.isalpha() for ch in t)
    digit = sum(ch.isdigit() for ch in t)
    spaces = sum(ch.isspace() for ch in t)
    punct = len(t) - alpha - digit - spaces

    if alpha / max(1, len(t)) < 0.55:
        return False
    if punct / max(1, len(t)) > 0.18:
        return False

    # URLs/emails are real text but are highly application-dependent and can dominate
    # duration in a way that is not useful for a general speech estimator.
    if URL_RE.search(t) or EMAIL_RE.search(t):
        return False

    # Filter title/menu fragments and ALL-CAPS boilerplate.
    uppercase_letters = sum(ch.isupper() for ch in t if ch.isalpha())
    if alpha and uppercase_letters / alpha > 0.45:
        return False

    # Reject strings with very low lexical diversity, common in boilerplate.
    low_words = [w.lower() for w in words]
    if len(low_words) >= 10 and len(set(low_words)) / len(low_words) < 0.45:
        return False

    return True


def classify_bucket(text: str) -> str:
    numeric = bool(NUMBER_RE.search(text))
    question = bool(QUESTION_RE.search(text))
    quoted = bool(QUOTE_RE.search(text))
    abbrev = bool(ABBREV_RE.search(text) or ACRONYM_RE.search(text))
    punct = bool(PUNCT_RE.search(text))

    active = sum([numeric, question, quoted, abbrev])
    if active >= 2:
        return "mixed"
    if numeric:
        return "numeric"
    if question:
        return "question"
    if quoted:
        return "quoted"
    if abbrev:
        return "abbrev_acronym"
    if punct:
        return "punctuated"
    return "plain"


def length_bin_name(text: str, max_chars: int) -> str | None:
    n = len(text)
    for lo, hi, _ in LENGTH_BINS:
        hi_eff = min(hi, max_chars)
        if lo <= n <= hi_eff:
            return f"{lo:03d}-{hi_eff:03d}"
    return None


def target_counts(total: int, weights: dict[str, float]) -> dict[str, int]:
    raw = {k: total * v for k, v in weights.items()}
    out = {k: int(math.floor(v)) for k, v in raw.items()}
    while sum(out.values()) < total:
        k = max(raw, key=lambda x: raw[x] - out[x])
        out[k] += 1
    return out


def length_targets(total: int, max_chars: int) -> dict[str, int]:
    bins = [(lo, min(hi, max_chars), w) for lo, hi, w in LENGTH_BINS if lo <= max_chars]
    s = sum(w for _, _, w in bins)
    weights = {f"{lo:03d}-{hi:03d}": w / s for lo, hi, w in bins}
    return target_counts(total, weights)


def paragraph_sources(doc_text: str) -> Iterable[str]:
    """
    Yield paragraph-like sources. FineWeb text often contains useful paragraph breaks,
    but some pages arrive as long blocks.
    """
    text = doc_text.replace("\r\n", "\n").replace("\r", "\n")
    blocks = re.split(r"\n\s*\n+", text)
    if len(blocks) == 1:
        blocks = text.split("\n")
    for block in blocks:
        block = normalize_ws(block)
        if len(block) >= 25:
            yield block


def extract_candidates(doc_text: str, max_chars: int) -> Iterable[str]:
    """
    Produce natural Chatterbox-sized chunks while preserving sentence boundaries.
    We additionally make single-sentence candidates so the short-length bins do not
    rely only on web fragments.
    """
    seen_local = set()
    for para in paragraph_sources(doc_text):
        # Main packed chunks: representative of long-form synthesis.
        for c in chunk_text(para, max_chars=max_chars):
            c = normalize_ws(c)
            if c and c not in seen_local:
                seen_local.add(c)
                yield c

        # Sentence-level candidates for short and medium utterances.
        sentences = re.split(r"(?<=[.!?])\s+", para)
        for s in sentences:
            s = normalize_ws(s)
            if 25 <= len(s) <= max_chars and s not in seen_local:
                seen_local.add(s)
                yield s


def make_stress_cases(n: int, seed: int, max_chars: int) -> list[dict]:
    """
    Fully synthetic edge cases. These are not language-model data and are intentionally
    limited; they give the duration estimator examples of normalization-sensitive text.
    """
    rng = random.Random(seed)
    first = ["Maya", "Daniel", "Priya", "James", "Sofia", "Noah", "Ava", "Liam", "Elena", "Marcus"]
    last = ["Chen", "Patel", "Morgan", "Rivera", "Taylor", "Kim", "Walker", "Singh", "Bennett", "Nguyen"]
    orgs = ["NASA", "WHO", "FBI", "BBC", "MIT", "IBM", "UNESCO", "NATO", "EPA", "CDC"]
    cities = ["Boston", "Seattle", "Austin", "Denver", "Miami", "Chicago", "Phoenix", "Portland", "Atlanta", "Dallas"]
    nouns = ["report", "proposal", "forecast", "prototype", "budget", "schedule", "dataset", "contract", "survey", "analysis"]
    verbs = ["reviewed", "updated", "approved", "questioned", "compared", "published", "revised", "tested", "measured", "checked"]

    templates = [
        lambda: f"Dr. {rng.choice(first)} {rng.choice(last)} {rng.choice(verbs)} the {rng.choice(nouns)} at {rng.randint(1,12)}:{rng.choice(['00','15','30','45'])} {rng.choice(['a.m.','p.m.'])}.",
        lambda: f"The value changed from {rng.uniform(10,900):.1f} to {rng.uniform(10,900):.1f}, a difference of {rng.uniform(0.5,45):.1f}%.",
        lambda: f"In {rng.randint(1990,2035)}, {rng.choice(orgs)} recorded {rng.randint(1_000,999_999):,} observations across {rng.randint(3,48)} locations.",
        lambda: f'"Should we revise the {rng.choice(nouns)} before Friday?" {rng.choice(first)} asked.',
        lambda: f"{rng.choice(orgs)} and {rng.choice(orgs)} will meet in {rng.choice(cities)} on {rng.choice(['Monday','Tuesday','Wednesday','Thursday','Friday'])}, {rng.choice(['January','March','June','September','November'])} {rng.randint(1,28)}.",
        lambda: f"The estimated cost is ${rng.randint(20,900):,}.{rng.randint(0,99):02d}, excluding a {rng.randint(1,20)}% service charge.",
        lambda: f"Version {rng.randint(1,9)}.{rng.randint(0,9)}.{rng.randint(0,20)} completed {rng.randint(2,80)} tests; {rng.randint(0,7)} warnings remained.",
        lambda: f"Prof. {rng.choice(last)} said, \"The result is clear, but the next step isn't obvious.\"",
        lambda: f"At {rng.randint(1,12)}:{rng.choice(['05','20','35','50'])}, the team compared items A, B, and C; item B was {rng.uniform(1,30):.1f}% faster.",
        lambda: f"Is {rng.choice(orgs)} expecting {rng.randint(10,500)} units by Q{rng.randint(1,4)} {rng.randint(2024,2032)}? The current plan says yes.",
    ]

    out = []
    seen = set()
    attempts = 0
    while len(out) < n and attempts < n * 30:
        attempts += 1
        # Sometimes combine two templates to create medium-length stress examples.
        text = templates[rng.randrange(len(templates))]()
        if rng.random() < 0.45:
            text = f"{text} {templates[rng.randrange(len(templates))]()}"
        text = normalize_ws(text)
        if len(text) > max_chars:
            chunks = chunk_text(text, max_chars=max_chars)
            text = chunks[0] if chunks else ""
        key = canonical_key(text)
        if 25 <= len(text) <= max_chars and key not in seen:
            seen.add(key)
            out.append(
                {
                    "text": text,
                    "source": "synthetic_timing_stress",
                    "bucket": classify_bucket(text),
                    "length": len(text),
                }
            )
    return out


def stream_fineweb(dataset_name: str, config: str, seed: int, shuffle_buffer: int):
    ds = load_dataset(dataset_name, name=config, split="train", streaming=True)
    if shuffle_buffer > 0:
        ds = ds.shuffle(seed=seed, buffer_size=shuffle_buffer)
    return ds


def build_corpus(
    output: Path,
    count: int,
    max_chars: int,
    min_chars: int,
    dataset_name: str,
    config: str,
    seed: int,
    shuffle_buffer: int,
    max_documents: int,
    stress_fraction: float,
) -> dict:
    rng = random.Random(seed)
    output.parent.mkdir(parents=True, exist_ok=True)

    stress_n = int(round(count * stress_fraction))
    natural_n = count - stress_n

    bucket_target = target_counts(natural_n, BUCKET_WEIGHTS)
    len_target = length_targets(natural_n, max_chars)

    # We need joint diversity but should not deadlock if a rare bucket-length pair is scarce.
    # Keep a generously sized reservoir per category, then solve the final selection after streaming.
    reservoir: dict[str, list[dict]] = defaultdict(list)
    reservoir_cap = max(250, math.ceil(count * 0.35))
    seen = set()
    stats = Counter()

    ds = stream_fineweb(dataset_name, config, seed, shuffle_buffer)

    for doc_idx, row in enumerate(ds):
        if doc_idx >= max_documents:
            break
        raw = row.get("text", "")
        if not raw:
            continue
        stats["documents_seen"] += 1

        for text in extract_candidates(str(raw), max_chars=max_chars):
            stats["candidates_seen"] += 1
            text = normalize_ws(text)
            if not is_good_tts_passage(text, min_chars=min_chars, max_chars=max_chars):
                stats["rejected_quality"] += 1
                continue
            key = canonical_key(text)
            if key in seen:
                stats["rejected_duplicate"] += 1
                continue
            seen.add(key)

            bucket = classify_bucket(text)
            lbin = length_bin_name(text, max_chars)
            if lbin is None:
                continue

            # Keep both a bucket reservoir and joint bucket:length reservoir.
            item = {
                "text": text,
                "source": "fineweb",
                "bucket": bucket,
                "length": len(text),
                "length_bin": lbin,
            }
            joint = f"{bucket}|{lbin}"
            if len(reservoir[joint]) < reservoir_cap:
                reservoir[joint].append(item)
                stats["accepted_to_reservoir"] += 1

        # Stop once every bucket and every length bin has healthy coverage.
        if doc_idx > 500:
            bucket_available = Counter()
            len_available = Counter()
            for joint, items in reservoir.items():
                b, lb = joint.split("|", 1)
                bucket_available[b] += len(items)
                len_available[lb] += len(items)

            buckets_ready = all(
                bucket_available[b] >= max(need * 2, need + 50)
                for b, need in bucket_target.items()
            )
            lengths_ready = all(
                len_available[lb] >= max(need * 2, need + 50)
                for lb, need in len_target.items()
            )
            if buckets_ready and lengths_ready:
                break

    all_items = []
    for items in reservoir.values():
        all_items.extend(items)
    rng.shuffle(all_items)

    if len(all_items) < natural_n:
        raise RuntimeError(
            f"Only collected {len(all_items)} usable candidates for {natural_n} requested. "
            f"Increase --max-documents or reduce filtering/count."
        )

    # Greedy two-dimensional quota matching:
    # Prefer items whose bucket AND length bin are still under target.
    bucket_left = bucket_target.copy()
    len_left = len_target.copy()
    selected = []
    used = set()

    def take_pass(require_both: bool):
        nonlocal selected
        for item in all_items:
            if len(selected) >= natural_n:
                return
            k = canonical_key(item["text"])
            if k in used:
                continue
            b = item["bucket"]
            lb = item["length_bin"]
            need_b = bucket_left.get(b, 0) > 0
            need_l = len_left.get(lb, 0) > 0
            ok = (need_b and need_l) if require_both else (need_b or need_l)
            if not ok:
                continue
            selected.append(item)
            used.add(k)
            if bucket_left.get(b, 0) > 0:
                bucket_left[b] -= 1
            if len_left.get(lb, 0) > 0:
                len_left[lb] -= 1

    take_pass(require_both=True)
    take_pass(require_both=False)

    # Fill any remainder from diverse unused natural candidates.
    if len(selected) < natural_n:
        for item in all_items:
            if len(selected) >= natural_n:
                break
            k = canonical_key(item["text"])
            if k not in used:
                selected.append(item)
                used.add(k)

    if len(selected) < natural_n:
        raise RuntimeError("Could not satisfy requested natural corpus size.")

    stress = make_stress_cases(stress_n, seed + 991, max_chars)
    if len(stress) < stress_n:
        raise RuntimeError("Could not generate enough synthetic timing stress cases.")

    final = selected + stress
    rng.shuffle(final)

    with output.open("w", encoding="utf-8") as f:
        for item in final:
            item = dict(item)
            item.pop("length_bin", None)
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

    summary = {
        "output": str(output.resolve()),
        "count": len(final),
        "fineweb_count": len(selected),
        "synthetic_stress_count": len(stress),
        "dataset": dataset_name,
        "config": config,
        "seed": seed,
        "max_chars": max_chars,
        "bucket_counts": dict(Counter(x["bucket"] for x in final)),
        "source_counts": dict(Counter(x["source"] for x in final)),
        "length_bin_counts": dict(
            Counter(length_bin_name(x["text"], max_chars) or "other" for x in final)
        ),
        "stream_stats": dict(stats),
    }

    summary_path = output.with_suffix(output.suffix + ".summary.json")
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main():
    p = argparse.ArgumentParser(
        description="Stream FineWeb and build a Chatterbox duration-training corpus."
    )
    p.add_argument("--output", default="general_english_corpus.jsonl")
    p.add_argument(
        "--count",
        type=int,
        default=12000,
        help="Candidate passages to save. 8k-20k is plenty for selecting 1000 TTS labels.",
    )
    p.add_argument("--max-chars", type=int, default=260)
    p.add_argument("--min-chars", type=int, default=25)
    p.add_argument(
        "--dataset",
        default="HuggingFaceFW/fineweb",
        help="Hugging Face dataset repository.",
    )
    p.add_argument(
        "--config",
        default="sample-10BT",
        help="FineWeb config. sample-10BT is broad and supports streaming.",
    )
    p.add_argument("--seed", type=int, default=20260930)
    p.add_argument(
        "--shuffle-buffer",
        type=int,
        default=10000,
        help="Streaming shuffle buffer; 0 disables shuffling.",
    )
    p.add_argument(
        "--max-documents",
        type=int,
        default=100000,
        help="Safety cap; collection usually stops much earlier.",
    )
    p.add_argument(
        "--stress-fraction",
        type=float,
        default=0.10,
        help="Fraction of fully synthetic timing-stress passages (default 10%%).",
    )
    args = p.parse_args()

    if args.count < 1000:
        p.error("--count should be at least 1000; 8000-12000 is recommended.")
    if not (0.0 <= args.stress_fraction <= 0.30):
        p.error("--stress-fraction must be between 0 and 0.30.")
    if args.max_chars > 260:
        print(
            "Warning: the supplied duration pipeline is calibrated around <=260-char chunks.",
            file=sys.stderr,
        )

    summary = build_corpus(
        output=Path(args.output),
        count=args.count,
        max_chars=args.max_chars,
        min_chars=args.min_chars,
        dataset_name=args.dataset,
        config=args.config,
        seed=args.seed,
        shuffle_buffer=args.shuffle_buffer,
        max_documents=args.max_documents,
        stress_fraction=args.stress_fraction,
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
