#!/usr/bin/env python3
"""
Local English-only Chatterbox duration-estimator pipeline.

Workflow:
  1) Generate a CFG/exaggeration audition grid from a local Chatterbox checkpoint.
  2) Pause for the user to choose one grid cell.
  3) Select 1000 unique, representative text chunks.
  4) Synthesize them locally with one fixed sampling seed and save a resumable dataset.
  5) Train/evaluate a sample-efficient hybrid duration estimator.
  6) Refit on all 1000 examples and save a lightweight estimator.
  7) Predict arbitrary-length text by using the exact same deterministic chunker.
  8) Optionally synthesize arbitrary-length text with that same chunker.

No hosted API is used. Chatterbox is loaded with ChatterboxTTS.from_local().
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import math
import os
import random
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import joblib
import numpy as np
import pandas as pd
import soundfile as sf
import torch
from scipy import sparse
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.linear_model import Ridge
from sklearn.model_selection import StratifiedKFold, train_test_split
from tqdm import tqdm

try:
    import cmudict
except ImportError as e:
    raise SystemExit("Missing cmudict. Install requirements-extra.txt") from e

try:
    from faker import Faker
except ImportError:
    Faker = None


# ----------------------------- Defaults -------------------------------------

DEFAULT_CFG_GRID = [0.25, 0.35, 0.45, 0.55, 0.65]
DEFAULT_EXAG_GRID = [0.35, 0.50, 0.65, 0.80, 1.00]

DEFAULT_GRID_TEXT = (
    "Good morning. At 9:30, the research team will review the latest results, "
    "discuss two unexpected changes, and decide what to test next. "
    "Are we ready to begin? Yes—we have everything we need."
)

DEFAULT_ALPHA_GRID = [0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0, 30.0, 100.0]

# These are intentionally below the UI's common ~300-character range.
DEFAULT_MAX_CHARS = 260

# For arbitrary-length synthesis, this silence is inserted between chunks.
DEFAULT_JOIN_SILENCE_MS = 120.0

# A fixed seed removes one major source of irreducible duration variance.
DEFAULT_SAMPLING_SEED = 12345

REQUIRED_CKPT_FILES = [
    "ve.safetensors",
    "t3_cfg.safetensors",
    "s3gen.safetensors",
    "tokenizer.json",
]


# ----------------------------- Utilities ------------------------------------

def parse_float_list(value: str) -> list[float]:
    return [float(x.strip()) for x in value.split(",") if x.strip()]


def auto_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


def stable_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def normalize_ws(text: str) -> str:
    return " ".join(str(text).replace("\u00a0", " ").split()).strip()


def ensure_checkpoint_dir(ckpt_dir: Path) -> None:
    missing = [f for f in REQUIRED_CKPT_FILES if not (ckpt_dir / f).exists()]
    if missing:
        raise FileNotFoundError(
            f"Checkpoint directory {ckpt_dir} is missing: {', '.join(missing)}"
        )


def load_local_chatterbox(ckpt_dir: Path, device: str):
    """Load the original English-only Chatterbox locally."""
    ensure_checkpoint_dir(ckpt_dir)
    from chatterbox.tts import ChatterboxTTS

    if not hasattr(ChatterboxTTS, "from_local"):
        raise RuntimeError(
            "Your installed chatterbox package does not expose ChatterboxTTS.from_local(). "
            "Install a recent local checkout of resemble-ai/chatterbox with `pip install -e .`."
        )
    return ChatterboxTTS.from_local(str(ckpt_dir), device=device)


def chatterbox_normalizer():
    from chatterbox.tts import punc_norm
    return punc_norm


def load_english_tokenizer(tokenizer_json: Path):
    from chatterbox.models.tokenizers import EnTokenizer
    return EnTokenizer(str(tokenizer_json))


def tensor_to_numpy_mono(wav: torch.Tensor | np.ndarray) -> np.ndarray:
    if torch.is_tensor(wav):
        wav = wav.detach().cpu().numpy()
    arr = np.asarray(wav)
    arr = np.squeeze(arr)
    if arr.ndim != 1:
        raise ValueError(f"Expected mono waveform after squeeze, got {arr.shape}")
    return arr.astype(np.float32, copy=False)


def save_wav(path: Path, wav: torch.Tensor | np.ndarray, sr: int) -> float:
    arr = tensor_to_numpy_mono(wav)
    path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(path, arr, sr, subtype="PCM_16")
    return len(arr) / float(sr)


# ----------------------------- Text chunking --------------------------------

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")
_CLAUSE_SPLIT = re.compile(r"(?<=[,;:])\s+")


def _split_oversized_unit(text: str, max_chars: int) -> list[str]:
    text = normalize_ws(text)
    if len(text) <= max_chars:
        return [text] if text else []

    # First split on clause punctuation.
    clauses = [normalize_ws(x) for x in _CLAUSE_SPLIT.split(text) if normalize_ws(x)]
    if len(clauses) > 1:
        out: list[str] = []
        buf = ""
        for c in clauses:
            candidate = c if not buf else f"{buf} {c}"
            if len(candidate) <= max_chars:
                buf = candidate
            else:
                if buf:
                    out.append(buf)
                if len(c) <= max_chars:
                    buf = c
                else:
                    out.extend(_split_oversized_unit_by_words(c, max_chars))
                    buf = ""
        if buf:
            out.append(buf)
        return out

    return _split_oversized_unit_by_words(text, max_chars)


def _split_oversized_unit_by_words(text: str, max_chars: int) -> list[str]:
    words = text.split()
    out, buf = [], ""
    for word in words:
        # Pathological giant token/URL: hard split only as last resort.
        if len(word) > max_chars:
            if buf:
                out.append(buf)
                buf = ""
            out.extend(word[i:i + max_chars] for i in range(0, len(word), max_chars))
            continue
        candidate = word if not buf else f"{buf} {word}"
        if len(candidate) <= max_chars:
            buf = candidate
        else:
            if buf:
                out.append(buf)
            buf = word
    if buf:
        out.append(buf)
    return out


def chunk_text(text: str, max_chars: int = DEFAULT_MAX_CHARS) -> list[str]:
    """
    Deterministic sentence-first chunker. Use this exact function both for
    prediction and long-form TTS.
    """
    text = normalize_ws(text)
    if not text:
        return []

    sentence_units: list[str] = []
    for s in _SENTENCE_SPLIT.split(text):
        sentence_units.extend(_split_oversized_unit(s, max_chars))

    chunks: list[str] = []
    buf = ""
    for s in sentence_units:
        candidate = s if not buf else f"{buf} {s}"
        if len(candidate) <= max_chars:
            buf = candidate
        else:
            if buf:
                chunks.append(buf)
            buf = s
    if buf:
        chunks.append(buf)

    return [c for c in chunks if c]


# ----------------------------- Grid audition --------------------------------

@dataclass(frozen=True)
class SamplingConfig:
    temperature: float = 0.8
    min_p: float = 0.05
    top_p: float = 1.0
    repetition_penalty: float = 1.2
    sampling_seed: int = DEFAULT_SAMPLING_SEED


def synthesize_one(
    model,
    text: str,
    cfg_weight: float,
    exaggeration: float,
    sampling: SamplingConfig,
) -> torch.Tensor:
    # IMPORTANT: reset to the same seed before every utterance.
    set_seed(sampling.sampling_seed)
    with torch.inference_mode():
        return model.generate(
            text,
            exaggeration=float(exaggeration),
            cfg_weight=float(cfg_weight),
            temperature=float(sampling.temperature),
            min_p=float(sampling.min_p),
            top_p=float(sampling.top_p),
            repetition_penalty=float(sampling.repetition_penalty),
        )


def create_grid(
    ckpt_dir: Path,
    ref_audio: Path,
    workdir: Path,
    cfg_values: Sequence[float],
    exag_values: Sequence[float],
    grid_text: str,
    device: str,
    sampling: SamplingConfig,
) -> list[dict]:
    grid_dir = workdir / "grid"
    grid_dir.mkdir(parents=True, exist_ok=True)

    model = load_local_chatterbox(ckpt_dir, device)
    # Compute the expensive voice reference conditioning once.
    model.prepare_conditionals(str(ref_audio), exaggeration=float(exag_values[0]))

    rows: list[dict] = []
    config_id = 1
    for exag in exag_values:
        for cfg in cfg_values:
            filename = f"{config_id:02d}_cfg-{cfg:.2f}_exag-{exag:.2f}.wav"
            wav = synthesize_one(model, grid_text, cfg, exag, sampling)
            duration = save_wav(grid_dir / filename, wav, model.sr)
            rows.append(
                {
                    "id": config_id,
                    "cfg_weight": float(cfg),
                    "exaggeration": float(exag),
                    "duration_sec": float(duration),
                    "filename": filename,
                }
            )
            print(
                f"[grid {config_id:02d}] cfg={cfg:.2f}, exag={exag:.2f}, "
                f"duration={duration:.3f}s -> {filename}"
            )
            config_id += 1

    with (grid_dir / "grid.json").open("w", encoding="utf-8") as f:
        json.dump(
            {
                "text": grid_text,
                "sampling": sampling.__dict__,
                "configs": rows,
            },
            f,
            indent=2,
        )

    _write_grid_html(grid_dir, cfg_values, exag_values, rows, grid_text)
    print(f"\nAudition page: {(grid_dir / 'index.html').resolve().as_uri()}")
    return rows


def _write_grid_html(
    grid_dir: Path,
    cfg_values: Sequence[float],
    exag_values: Sequence[float],
    rows: Sequence[dict],
    grid_text: str,
) -> None:
    by_pair = {
        (round(r["cfg_weight"], 6), round(r["exaggeration"], 6)): r for r in rows
    }
    parts = [
        "<!doctype html><html><head><meta charset='utf-8'>",
        "<title>Chatterbox CFG / exaggeration grid</title>",
        "<style>",
        "body{font-family:system-ui,sans-serif;margin:24px;max-width:1500px}",
        "table{border-collapse:collapse;width:100%}",
        "th,td{border:1px solid #bbb;padding:10px;vertical-align:top}",
        "th{background:#f4f4f4;position:sticky;top:0}",
        "audio{width:240px}",
        ".id{font-weight:700}",
        "</style></head><body>",
        "<h1>Chatterbox audition grid</h1>",
        f"<p><strong>Text:</strong> {html.escape(grid_text)}</p>",
        "<p>Choose by ID in the terminal after listening.</p>",
        "<table><tr><th>Exaggeration \\ CFG</th>",
    ]
    for cfg in cfg_values:
        parts.append(f"<th>{cfg:.2f}</th>")
    parts.append("</tr>")

    for exag in exag_values:
        parts.append(f"<tr><th>{exag:.2f}</th>")
        for cfg in cfg_values:
            r = by_pair[(round(float(cfg), 6), round(float(exag), 6))]
            parts.append(
                "<td>"
                f"<div class='id'>ID {r['id']:02d}</div>"
                f"<div>{r['duration_sec']:.3f} s</div>"
                f"<audio controls preload='none' src='{html.escape(r['filename'])}'></audio>"
                "</td>"
            )
        parts.append("</tr>")
    parts.append("</table></body></html>")

    (grid_dir / "index.html").write_text("\n".join(parts), encoding="utf-8")


def choose_grid_config(rows: Sequence[dict], preset_id: int | None = None) -> dict:
    ids = {int(r["id"]): r for r in rows}
    if preset_id is not None:
        if preset_id not in ids:
            raise ValueError(f"Invalid --choice {preset_id}; valid IDs are {sorted(ids)}")
        return ids[preset_id]

    while True:
        raw = input("\nEnter the grid ID you want to use for the 1000-sample run: ").strip()
        try:
            choice = int(raw)
        except ValueError:
            print("Enter a numeric grid ID.")
            continue
        if choice in ids:
            return ids[choice]
        print(f"Unknown ID. Valid range: {min(ids)}..{max(ids)}")


# ----------------------------- Corpus selection ------------------------------

def _sentences_from_text(text: str) -> list[str]:
    text = normalize_ws(text)
    if not text:
        return []
    return [normalize_ws(x) for x in _SENTENCE_SPLIT.split(text) if normalize_ws(x)]


def read_corpus(path: Path | None, jsonl_field: str = "text") -> list[str]:
    if path is None:
        return []
    if not path.exists():
        raise FileNotFoundError(path)

    items: list[str] = []
    if path.suffix.lower() == ".jsonl":
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                if isinstance(obj, str):
                    items.append(obj)
                elif isinstance(obj, dict):
                    value = obj.get(jsonl_field)
                    if value is None:
                        for fallback in ("text", "content", "sentence", "body"):
                            if fallback in obj:
                                value = obj[fallback]
                                break
                    if value:
                        items.append(str(value))
    else:
        raw = path.read_text(encoding="utf-8", errors="ignore")
        # Keep both lines and paragraphs as possible sources.
        paragraphs = [normalize_ws(x) for x in re.split(r"\n\s*\n", raw) if normalize_ws(x)]
        lines = [normalize_ws(x) for x in raw.splitlines() if normalize_ws(x)]
        items.extend(paragraphs)
        items.extend(lines)

    return list(dict.fromkeys(x for x in items if x))


def candidates_from_corpus(
    corpus_items: Sequence[str],
    max_chars: int,
    min_chars: int = 20,
) -> list[str]:
    candidates: set[str] = set()

    for item in corpus_items:
        sentences = _sentences_from_text(item)
        if not sentences:
            continue

        # Single sentences / oversize splits.
        for s in sentences:
            for part in _split_oversized_unit(s, max_chars):
                p = normalize_ws(part)
                if min_chars <= len(p) <= max_chars:
                    candidates.add(p)

        # Adjacent multi-sentence combinations to cover medium/long chunks.
        for start in range(len(sentences)):
            buf = ""
            for j in range(start, min(len(sentences), start + 5)):
                candidate = sentences[j] if not buf else f"{buf} {sentences[j]}"
                if len(candidate) <= max_chars:
                    buf = candidate
                    if len(buf) >= min_chars:
                        candidates.add(buf)
                else:
                    break

    return sorted(candidates)


def synthetic_candidates(
    count: int,
    max_chars: int,
    seed: int,
) -> list[str]:
    """
    Offline fallback only. For best accuracy, use a real local corpus matching
    your production text distribution.
    """
    if Faker is None:
        raise RuntimeError(
            "No --corpus was supplied and Faker is unavailable. "
            "Install requirements-extra.txt or provide a local corpus."
        )

    fake = Faker("en_US")
    Faker.seed(seed)
    rng = random.Random(seed)
    out: set[str] = set()

    while len(out) < count:
        target = rng.randint(35, max_chars)
        s = normalize_ws(fake.text(max_nb_chars=max(target, 40)))

        style = rng.random()
        if style < 0.12:
            s = re.sub(r"[.!]+$", "", s) + "?"
        elif style < 0.22:
            n = rng.randint(2, 9999)
            pct = rng.uniform(1.0, 99.0)
            s = f"In {rng.randint(1990, 2035)}, {s} The reported value was {n}, or {pct:.1f}%."
        elif style < 0.28:
            s = f'"{re.sub(r"[.!?]+$", "", s)}," the report said.'
        elif style < 0.34:
            s = f"Dr. {fake.last_name()} reviewed the U.S. data at {rng.randint(1,12)}:{rng.choice(['00','15','30','45'])} p.m. {s}"

        chunks = chunk_text(s, max_chars=max_chars)
        for c in chunks:
            if 20 <= len(c) <= max_chars:
                out.add(c)
            if len(out) >= count:
                break

    return sorted(out)


def length_bin(n: int, max_chars: int) -> int:
    edges = [20, 50, 80, 120, 170, 220, max_chars + 1]
    for i in range(len(edges) - 1):
        if edges[i] <= n < edges[i + 1]:
            return i
    return len(edges) - 2


def select_training_texts(
    candidates: Sequence[str],
    n: int,
    max_chars: int,
    seed: int,
) -> list[str]:
    """
    Stratifies by chunk length. Coverage is preferable to drawing 1000 nearly
    identical medium-length sentences.
    """
    if n > 1000:
        raise ValueError("This workflow intentionally caps synthesized training data at 1000.")
    unique = list(dict.fromkeys(normalize_ws(x) for x in candidates if x))
    unique = [x for x in unique if 20 <= len(x) <= max_chars]
    if len(unique) < n:
        raise ValueError(f"Need at least {n} unique candidates; found {len(unique)}.")

    rng = random.Random(seed)
    groups: dict[int, list[str]] = {}
    for text in unique:
        groups.setdefault(length_bin(len(text), max_chars), []).append(text)
    for g in groups.values():
        rng.shuffle(g)

    # General-purpose coverage profile. Change the corpus itself to match your
    # real production distribution more closely.
    weights = np.array([0.10, 0.15, 0.20, 0.25, 0.20, 0.10], dtype=float)
    weights = weights[: max(groups.keys()) + 1]
    weights = weights / weights.sum()
    quotas = np.floor(weights * n).astype(int)
    while quotas.sum() < n:
        quotas[np.argmax(weights - quotas / max(n, 1))] += 1

    chosen: list[str] = []
    leftovers: list[str] = []
    for b in range(len(weights)):
        g = groups.get(b, [])
        take = min(int(quotas[b]), len(g))
        chosen.extend(g[:take])
        leftovers.extend(g[take:])

    if len(chosen) < n:
        rng.shuffle(leftovers)
        chosen.extend(leftovers[: n - len(chosen)])

    if len(chosen) < n:
        # Should only happen if bins beyond our profile contained candidates.
        remaining = [x for x in unique if x not in set(chosen)]
        rng.shuffle(remaining)
        chosen.extend(remaining[: n - len(chosen)])

    rng.shuffle(chosen)
    return chosen[:n]


def prepare_text_list(
    workdir: Path,
    corpus_path: Path | None,
    jsonl_field: str,
    n_samples: int,
    max_chars: int,
    seed: int,
) -> list[str]:
    selected_path = workdir / "selected_texts.jsonl"
    if selected_path.exists():
        texts = []
        with selected_path.open("r", encoding="utf-8") as f:
            for line in f:
                obj = json.loads(line)
                texts.append(obj["text"])
        if len(texts) != n_samples:
            raise RuntimeError(
                f"{selected_path} contains {len(texts)} texts, but --samples={n_samples}. "
                "Use a new workdir or remove selected_texts.jsonl intentionally."
            )
        return texts

    corpus_items = read_corpus(corpus_path, jsonl_field=jsonl_field)
    candidates = candidates_from_corpus(corpus_items, max_chars=max_chars)

    # If a real corpus is too small (or absent), supplement offline.
    target_candidates = max(n_samples * 6, 4000)
    if len(candidates) < target_candidates:
        fallback = synthetic_candidates(
            count=target_candidates - len(candidates),
            max_chars=max_chars,
            seed=seed + 91,
        )
        candidates = list(dict.fromkeys(candidates + fallback))

    selected = select_training_texts(
        candidates=candidates,
        n=n_samples,
        max_chars=max_chars,
        seed=seed,
    )

    with selected_path.open("w", encoding="utf-8") as f:
        for i, text in enumerate(selected):
            f.write(json.dumps({"id": i, "text": text}, ensure_ascii=False) + "\n")

    return selected


# ----------------------------- Dataset synthesis -----------------------------

DATASET_FIELDS = [
    "id",
    "text_hash",
    "text",
    "char_count",
    "word_count",
    "cfg_weight",
    "exaggeration",
    "temperature",
    "min_p",
    "top_p",
    "repetition_penalty",
    "sampling_seed",
    "sample_rate",
    "num_samples",
    "duration_sec",
    "audio_path",
]


def collect_dataset(
    ckpt_dir: Path,
    ref_audio: Path,
    workdir: Path,
    texts: Sequence[str],
    cfg_weight: float,
    exaggeration: float,
    device: str,
    sampling: SamplingConfig,
) -> Path:
    dataset_dir = workdir / "dataset"
    audio_dir = dataset_dir / "audio"
    dataset_dir.mkdir(parents=True, exist_ok=True)
    audio_dir.mkdir(parents=True, exist_ok=True)
    csv_path = dataset_dir / "dataset.csv"

    completed: dict[int, dict] = {}
    if csv_path.exists():
        old = pd.read_csv(csv_path)
        for _, row in old.iterrows():
            completed[int(row["id"])] = row.to_dict()
        print(f"Resuming: {len(completed)} samples already recorded.")

    model = load_local_chatterbox(ckpt_dir, device)
    model.prepare_conditionals(str(ref_audio), exaggeration=float(exaggeration))

    # Append safely; flush after every row so interruption loses at most one item.
    file_exists = csv_path.exists() and csv_path.stat().st_size > 0
    with csv_path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=DATASET_FIELDS)
        if not file_exists:
            writer.writeheader()
            f.flush()

        for i, text in enumerate(tqdm(texts, desc="Synthesizing dataset")):
            if i in completed:
                expected_hash = stable_hash(text)
                if str(completed[i].get("text_hash")) != expected_hash:
                    raise RuntimeError(
                        f"Resume mismatch at id={i}. selected_texts.jsonl changed."
                    )
                continue

            wav = synthesize_one(
                model=model,
                text=text,
                cfg_weight=cfg_weight,
                exaggeration=exaggeration,
                sampling=sampling,
            )
            arr = tensor_to_numpy_mono(wav)
            rel_audio = Path("audio") / f"{i:04d}.wav"
            sf.write(audio_dir / f"{i:04d}.wav", arr, model.sr, subtype="PCM_16")

            row = {
                "id": i,
                "text_hash": stable_hash(text),
                "text": text,
                "char_count": len(text),
                "word_count": len(re.findall(r"\b[\w']+\b", text)),
                "cfg_weight": cfg_weight,
                "exaggeration": exaggeration,
                "temperature": sampling.temperature,
                "min_p": sampling.min_p,
                "top_p": sampling.top_p,
                "repetition_penalty": sampling.repetition_penalty,
                "sampling_seed": sampling.sampling_seed,
                "sample_rate": model.sr,
                "num_samples": len(arr),
                "duration_sec": len(arr) / float(model.sr),
                "audio_path": rel_audio.as_posix(),
            }
            writer.writerow(row)
            f.flush()

            if torch.cuda.is_available() and ((i + 1) % 100 == 0):
                torch.cuda.empty_cache()

    df = pd.read_csv(csv_path).sort_values("id")
    if len(df) != len(texts):
        raise RuntimeError(f"Expected {len(texts)} dataset rows, found {len(df)}.")
    return csv_path


# ----------------------------- Features -------------------------------------

_WORD_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?|\d+(?:[.,]\d+)*")
_ALPHA_WORD_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?")
_DIGIT_GROUP_RE = re.compile(r"\d+(?:[.,]\d+)*")

NUMERIC_FEATURE_NAMES = [
    "chars_100",
    "nonspace_chars_100",
    "words_20",
    "chatterbox_tokens_50",
    "syllables_30",
    "phonemes_80",
    "vowel_phonemes_30",
    "oov_words_10",
    "letters_100",
    "digits_10",
    "digit_groups_5",
    "punct_10",
    "commas_5",
    "periods_5",
    "questions_3",
    "exclamations_3",
    "hyphens_3",
    "apostrophes_5",
    "quotes_4",
    "parentheses_4",
    "sentence_enders_5",
    "clauses_5",
    "long_words_10",
    "very_long_words_5",
    "uppercase_words_5",
    "contractions_5",
    "avg_word_len",
    "syllables_per_word",
    "phonemes_per_word",
    "tokens_per_word",
    "punct_per_word",
    "digit_fraction",
    "oov_fraction",
]


def heuristic_syllables(word: str) -> int:
    w = re.sub(r"[^a-z]", "", word.lower())
    if not w:
        return 0
    groups = re.findall(r"[aeiouy]+", w)
    n = len(groups)
    if len(w) > 3 and w.endswith("e") and not w.endswith(("le", "ye")) and n > 1:
        n -= 1
    if w.endswith("ed") and len(w) > 4 and not w.endswith(("ted", "ded")) and n > 1:
        n -= 1
    return max(1, n)


class TextFeatureExtractor:
    def __init__(self, tokenizer_json: Path):
        self.tokenizer_json = Path(tokenizer_json)
        self.tokenizer = load_english_tokenizer(self.tokenizer_json)
        self.punc_norm = chatterbox_normalizer()
        self.cmu = cmudict.dict()

        # Counts, not normalized TF-IDF: this preserves additivity with length.
        self.char_vec = HashingVectorizer(
            analyzer="char_wb",
            ngram_range=(2, 5),
            n_features=2**15,
            lowercase=True,
            norm=None,
            alternate_sign=True,
        )
        self.word_vec = HashingVectorizer(
            analyzer="word",
            ngram_range=(1, 2),
            n_features=2**14,
            lowercase=True,
            norm=None,
            alternate_sign=True,
            token_pattern=r"(?u)\b[\w']+\b",
        )

    def normalized(self, text: str) -> str:
        return self.punc_norm(normalize_ws(text))

    def _one_numeric(self, text: str) -> np.ndarray:
        t = self.normalized(text)
        words_all = _WORD_RE.findall(t)
        alpha_words = _ALPHA_WORD_RE.findall(t)
        n_words = max(1, len(words_all))

        try:
            tok = self.tokenizer.text_to_tokens(t)
            token_count = int(tok.numel())
        except Exception:
            token_count = max(1, len(t) // 4)

        phonemes = 0
        vowel_phonemes = 0
        syllables = 0
        oov = 0
        long_words = 0
        very_long_words = 0
        uppercase_words = 0
        contractions = 0

        for original in alpha_words:
            lower = original.lower()
            if len(lower) >= 8:
                long_words += 1
            if len(lower) >= 12:
                very_long_words += 1
            if original.isupper() and len(original) >= 2:
                uppercase_words += 1
            if "'" in original:
                contractions += 1

            prons = self.cmu.get(lower)
            if prons:
                pron = prons[0]
                phonemes += len(pron)
                v = sum(1 for ph in pron if ph and ph[-1:].isdigit())
                vowel_phonemes += v
                syllables += max(1, v)
            else:
                oov += 1
                syl = heuristic_syllables(lower)
                syllables += syl
                vowel_phonemes += syl
                # A conservative orthographic proxy for unknown-word phoneme count.
                phonemes += max(syl, round(len(lower) * 0.72))

        digit_groups = len(_DIGIT_GROUP_RE.findall(t))
        letters = sum(ch.isalpha() for ch in t)
        digits = sum(ch.isdigit() for ch in t)
        nonspace = sum(not ch.isspace() for ch in t)

        commas = t.count(",")
        periods = t.count(".")
        questions = t.count("?")
        exclamations = t.count("!")
        hyphens = t.count("-")
        apostrophes = t.count("'")
        quotes = t.count('"')
        parentheses = t.count("(") + t.count(")")
        punct = sum(ch in ".,!?;:-'\"()" for ch in t)
        sentence_enders = periods + questions + exclamations
        clauses = commas + t.count(";") + t.count(":")

        alpha_chars = max(1, sum(len(w) for w in alpha_words))
        alpha_word_n = max(1, len(alpha_words))

        vals = [
            len(t) / 100.0,
            nonspace / 100.0,
            len(words_all) / 20.0,
            token_count / 50.0,
            syllables / 30.0,
            phonemes / 80.0,
            vowel_phonemes / 30.0,
            oov / 10.0,
            letters / 100.0,
            digits / 10.0,
            digit_groups / 5.0,
            punct / 10.0,
            commas / 5.0,
            periods / 5.0,
            questions / 3.0,
            exclamations / 3.0,
            hyphens / 3.0,
            apostrophes / 5.0,
            quotes / 4.0,
            parentheses / 4.0,
            sentence_enders / 5.0,
            clauses / 5.0,
            long_words / 10.0,
            very_long_words / 5.0,
            uppercase_words / 5.0,
            contractions / 5.0,
            alpha_chars / alpha_word_n,
            syllables / alpha_word_n,
            phonemes / alpha_word_n,
            token_count / n_words,
            punct / n_words,
            digits / max(1, len(t)),
            oov / alpha_word_n,
        ]
        return np.asarray(vals, dtype=np.float32)

    def numeric(self, texts: Sequence[str]) -> np.ndarray:
        return np.vstack([self._one_numeric(t) for t in texts]).astype(np.float32)

    def full_sparse(self, texts: Sequence[str]) -> tuple[sparse.csr_matrix, np.ndarray]:
        normalized = [self.normalized(t) for t in texts]
        numeric = self.numeric(texts)
        char_x = self.char_vec.transform(normalized).tocsr()
        word_x = self.word_vec.transform(normalized).tocsr()
        x = sparse.hstack(
            [sparse.csr_matrix(numeric), char_x, word_x],
            format="csr",
            dtype=np.float32,
        )
        return x, numeric


# ----------------------------- Model training -------------------------------

def relative_weights(y: np.ndarray, power: float = 2.0) -> np.ndarray:
    y_safe = np.clip(np.asarray(y, dtype=float), 1.0, None)
    w = 1.0 / np.power(y_safe, power)
    return w / np.mean(w)


def ape_percent(y: np.ndarray, pred: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    pred = np.asarray(pred, dtype=float)
    return np.abs(pred - y) / np.clip(y, 1e-9, None) * 100.0


def metrics_dict(y: np.ndarray, pred: np.ndarray) -> dict:
    y = np.asarray(y, dtype=float)
    pred = np.asarray(pred, dtype=float)
    ape = ape_percent(y, pred)
    rel_signed = (pred - y) / np.clip(y, 1e-9, None) * 100.0
    return {
        "n": int(len(y)),
        "mape_percent": float(np.mean(ape)),
        "median_ape_percent": float(np.median(ape)),
        "p90_ape_percent": float(np.percentile(ape, 90)),
        "p95_ape_percent": float(np.percentile(ape, 95)),
        "p99_ape_percent": float(np.percentile(ape, 99)),
        "max_ape_percent": float(np.max(ape)),
        "within_1_percent_fraction": float(np.mean(ape < 1.0)),
        "within_2_percent_fraction": float(np.mean(ape < 2.0)),
        "mean_signed_error_percent": float(np.mean(rel_signed)),
        "mae_seconds": float(np.mean(np.abs(pred - y))),
        "rmse_seconds": float(np.sqrt(np.mean((pred - y) ** 2))),
    }


def make_strata(lengths: np.ndarray, n_bins: int = 6) -> np.ndarray:
    s = pd.Series(lengths)
    try:
        bins = pd.qcut(s, q=n_bins, labels=False, duplicates="drop")
        return np.asarray(bins, dtype=int)
    except Exception:
        return np.zeros(len(lengths), dtype=int)


def fit_ridge(
    x: sparse.csr_matrix,
    y: np.ndarray,
    alpha: float,
) -> Ridge:
    model = Ridge(alpha=float(alpha), solver="lsqr", fit_intercept=True)
    model.fit(x, y, sample_weight=relative_weights(y, power=2.0))
    return model


def make_residual_model() -> HistGradientBoostingRegressor:
    return HistGradientBoostingRegressor(
        loss="absolute_error",
        learning_rate=0.04,
        max_iter=220,
        max_leaf_nodes=15,
        min_samples_leaf=18,
        l2_regularization=1.0,
        random_state=7,
        early_stopping=True,
        validation_fraction=0.15,
        n_iter_no_change=25,
    )


def residual_inputs(numeric: np.ndarray, base_pred: np.ndarray) -> np.ndarray:
    return np.column_stack([numeric, base_pred]).astype(np.float32)


def fit_calibration(y: np.ndarray, pred: np.ndarray) -> tuple[float, float, bool]:
    """
    Weighted affine calibration. It is retained only if it improves OOF MAPE,
    and clipping prevents pathological extrapolation.
    """
    y = np.asarray(y, dtype=float)
    pred = np.asarray(pred, dtype=float)
    w = relative_weights(y, power=2.0)

    X = np.column_stack([pred, np.ones_like(pred)])
    sw = np.sqrt(w)[:, None]
    beta, *_ = np.linalg.lstsq(X * sw, y * sw[:, 0], rcond=None)
    slope = float(np.clip(beta[0], 0.85, 1.15))
    intercept = float(np.clip(beta[1], -0.75, 0.75))

    raw_mape = np.mean(ape_percent(y, pred))
    cal_pred = slope * pred + intercept
    cal_mape = np.mean(ape_percent(y, cal_pred))
    use = cal_mape + 0.01 < raw_mape
    return (slope if use else 1.0, intercept if use else 0.0, use)


def cross_validate_hybrid(
    x: sparse.csr_matrix,
    numeric: np.ndarray,
    y: np.ndarray,
    lengths: np.ndarray,
    alpha: float,
    n_splits: int = 5,
) -> tuple[np.ndarray, np.ndarray]:
    strata = make_strata(lengths, n_bins=6)
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=2026)

    base_oof = np.zeros(len(y), dtype=float)
    residual_oof = np.zeros(len(y), dtype=float)

    for tr, va in cv.split(np.arange(len(y)), strata):
        ridge = fit_ridge(x[tr], y[tr], alpha)
        base_tr = ridge.predict(x[tr])
        base_va = ridge.predict(x[va])
        base_oof[va] = base_va

        resid = y[tr] - base_tr
        residual = make_residual_model()
        residual.fit(
            residual_inputs(numeric[tr], base_tr),
            resid,
            sample_weight=relative_weights(y[tr], power=1.0),
        )
        residual_oof[va] = residual.predict(
            residual_inputs(numeric[va], base_va)
        )

    return base_oof, residual_oof


def choose_alpha(
    x: sparse.csr_matrix,
    y: np.ndarray,
    lengths: np.ndarray,
    alphas: Sequence[float] = DEFAULT_ALPHA_GRID,
) -> float:
    strata = make_strata(lengths, n_bins=6)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=2025)
    best_alpha, best_score = None, float("inf")

    print("\nRidge alpha cross-validation:")
    for alpha in alphas:
        preds = np.zeros(len(y), dtype=float)
        for tr, va in cv.split(np.arange(len(y)), strata):
            model = fit_ridge(x[tr], y[tr], alpha)
            preds[va] = model.predict(x[va])
        score = float(np.mean(ape_percent(y, preds)))
        print(f"  alpha={alpha:<7g} OOF MAPE={score:.4f}%")
        if score < best_score:
            best_alpha, best_score = float(alpha), score

    assert best_alpha is not None
    print(f"Selected alpha={best_alpha:g}")
    return best_alpha


def choose_residual_blend(
    y: np.ndarray,
    base_oof: np.ndarray,
    residual_oof: np.ndarray,
) -> float:
    candidates = [0.0, 0.25, 0.50, 0.75, 1.0]
    best_beta, best = 0.0, float("inf")
    print("\nResidual blend selection:")
    for beta in candidates:
        pred = base_oof + beta * residual_oof
        score = float(np.mean(ape_percent(y, pred)))
        print(f"  beta={beta:.2f} OOF MAPE={score:.4f}%")
        if score < best:
            best_beta, best = beta, score
    return float(best_beta)


def fit_final_components(
    x: sparse.csr_matrix,
    numeric: np.ndarray,
    y: np.ndarray,
    alpha: float,
    beta: float,
) -> tuple[Ridge, HistGradientBoostingRegressor | None]:
    ridge = fit_ridge(x, y, alpha)
    if beta <= 0.0:
        return ridge, None

    base = ridge.predict(x)
    residual = make_residual_model()
    residual.fit(
        residual_inputs(numeric, base),
        y - base,
        sample_weight=relative_weights(y, power=1.0),
    )
    return ridge, residual


def predict_components(
    ridge: Ridge,
    residual,
    beta: float,
    slope: float,
    intercept: float,
    x: sparse.csr_matrix,
    numeric: np.ndarray,
) -> np.ndarray:
    base = ridge.predict(x)
    pred = base.copy()
    if residual is not None and beta > 0:
        pred += beta * residual.predict(residual_inputs(numeric, base))
    pred = slope * pred + intercept
    return np.clip(pred, 0.05, None)


def fit_bundle(
    texts: Sequence[str],
    y: np.ndarray,
    extractor: TextFeatureExtractor,
    alpha: float | None = None,
) -> tuple[dict, dict]:
    x, numeric = extractor.full_sparse(texts)
    lengths = np.array([len(t) for t in texts], dtype=int)

    if alpha is None:
        alpha = choose_alpha(x, y, lengths)

    base_oof, residual_oof = cross_validate_hybrid(
        x=x,
        numeric=numeric,
        y=y,
        lengths=lengths,
        alpha=alpha,
    )
    beta = choose_residual_blend(y, base_oof, residual_oof)

    combined_oof = base_oof + beta * residual_oof
    slope, intercept, calibration_used = fit_calibration(y, combined_oof)
    calibrated_oof = slope * combined_oof + intercept

    ridge, residual = fit_final_components(
        x=x,
        numeric=numeric,
        y=y,
        alpha=alpha,
        beta=beta,
    )

    bundle = {
        "ridge": ridge,
        "residual": residual,
        "alpha": float(alpha),
        "residual_beta": float(beta),
        "calibration_slope": float(slope),
        "calibration_intercept": float(intercept),
        "numeric_feature_names": NUMERIC_FEATURE_NAMES,
        "feature_version": 1,
    }
    oof_report = {
        "metrics": metrics_dict(y, calibrated_oof),
        "calibration_used": bool(calibration_used),
        "alpha": float(alpha),
        "residual_beta": float(beta),
        "calibration_slope": float(slope),
        "calibration_intercept": float(intercept),
    }
    return bundle, oof_report


def predict_bundle(
    bundle: dict,
    extractor: TextFeatureExtractor,
    texts: Sequence[str],
) -> np.ndarray:
    x, numeric = extractor.full_sparse(texts)
    return predict_components(
        ridge=bundle["ridge"],
        residual=bundle["residual"],
        beta=float(bundle["residual_beta"]),
        slope=float(bundle["calibration_slope"]),
        intercept=float(bundle["calibration_intercept"]),
        x=x,
        numeric=numeric,
    )


def report_by_duration(y: np.ndarray, pred: np.ndarray) -> dict:
    bins = [
        ("<5s", 0.0, 5.0),
        ("5-10s", 5.0, 10.0),
        ("10-20s", 10.0, 20.0),
        (">=20s", 20.0, float("inf")),
    ]
    out = {}
    for name, lo, hi in bins:
        mask = (y >= lo) & (y < hi)
        if np.any(mask):
            out[name] = metrics_dict(y[mask], pred[mask])
    return out


def train_estimator(
    dataset_csv: Path,
    ckpt_dir: Path,
    workdir: Path,
    max_chars: int,
    join_silence_ms: float,
    run_config: dict,
) -> Path:
    df = pd.read_csv(dataset_csv).sort_values("id").reset_index(drop=True)
    if len(df) < 200:
        raise ValueError("Too few rows. This estimator is intended for hundreds of samples.")
    if len(df) > 1000:
        raise ValueError("Dataset exceeds the requested 1000-sample cap.")

    texts = df["text"].astype(str).tolist()
    y = df["duration_sec"].to_numpy(dtype=float)
    lengths = df["char_count"].to_numpy(dtype=int)

    model_dir = workdir / "model"
    model_dir.mkdir(parents=True, exist_ok=True)
    tokenizer_dst = model_dir / "tokenizer.json"
    shutil.copy2(ckpt_dir / "tokenizer.json", tokenizer_dst)

    extractor = TextFeatureExtractor(tokenizer_dst)

    strata = make_strata(lengths, n_bins=6)
    idx = np.arange(len(df))
    train_idx, test_idx = train_test_split(
        idx,
        test_size=0.15,
        random_state=314159,
        stratify=strata,
    )

    print(
        f"\nTraining/evaluation split: {len(train_idx)} development, "
        f"{len(test_idx)} untouched holdout."
    )

    # Hyperparameter selection and OOF calibration use only the development set.
    dev_texts = [texts[i] for i in train_idx]
    y_dev = y[train_idx]
    dev_bundle, dev_oof_report = fit_bundle(dev_texts, y_dev, extractor, alpha=None)

    # Evaluate on untouched holdout.
    test_texts = [texts[i] for i in test_idx]
    pred_test = predict_bundle(dev_bundle, extractor, test_texts)
    test_metrics = metrics_dict(y[test_idx], pred_test)
    test_by_duration = report_by_duration(y[test_idx], pred_test)

    evaluation = {
        "development_oof": dev_oof_report,
        "holdout": test_metrics,
        "holdout_by_duration": test_by_duration,
        "holdout_indices": [int(i) for i in test_idx],
    }
    (model_dir / "evaluation.json").write_text(
        json.dumps(evaluation, indent=2), encoding="utf-8"
    )

    print("\nUNTOUCHED HOLDOUT RESULTS")
    print(json.dumps(test_metrics, indent=2))
    print("\nHoldout by duration:")
    print(json.dumps(test_by_duration, indent=2))

    # Production refit: use all 1000, retaining the selected ridge alpha.
    # Recompute OOF residual blend/calibration across all data.
    print("\nRefitting production estimator on all available examples...")
    final_bundle, full_oof_report = fit_bundle(
        texts=texts,
        y=y,
        extractor=extractor,
        alpha=float(dev_bundle["alpha"]),
    )

    metadata = {
        "model_type": "ridge_hashing_plus_optional_histgb_residual",
        "n_training_samples": int(len(df)),
        "max_chars_per_chunk": int(max_chars),
        "join_silence_ms": float(join_silence_ms),
        "run_config": run_config,
        "full_data_oof_report": full_oof_report,
        "holdout_report": test_metrics,
        "important": (
            "Estimator is valid for this reference voice, CFG/exaggeration, "
            "sampling settings, fixed seed, Chatterbox checkpoint/version, "
            "and chunking policy. Change any of these and recalibrate/retrain."
        ),
    }

    joblib.dump(final_bundle, model_dir / "estimator.joblib", compress=3)
    (model_dir / "metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )

    # Export holdout predictions for inspection.
    holdout_df = df.iloc[test_idx].copy()
    holdout_df["predicted_duration_sec"] = pred_test
    holdout_df["ape_percent"] = ape_percent(y[test_idx], pred_test)
    holdout_df.to_csv(model_dir / "holdout_predictions.csv", index=False)

    return model_dir


# ----------------------------- Inference ------------------------------------

def load_estimator(model_dir: Path):
    bundle = joblib.load(model_dir / "estimator.joblib")
    metadata = json.loads((model_dir / "metadata.json").read_text(encoding="utf-8"))
    extractor = TextFeatureExtractor(model_dir / "tokenizer.json")
    return bundle, metadata, extractor


def estimate_long_text(model_dir: Path, text: str) -> dict:
    bundle, metadata, extractor = load_estimator(model_dir)
    max_chars = int(metadata["max_chars_per_chunk"])
    join_silence_sec = float(metadata["join_silence_ms"]) / 1000.0

    chunks = chunk_text(text, max_chars=max_chars)
    if not chunks:
        return {"duration_sec": 0.0, "chunks": []}

    chunk_pred = predict_bundle(bundle, extractor, chunks)
    joins = max(0, len(chunks) - 1)
    total = float(np.sum(chunk_pred) + joins * join_silence_sec)

    return {
        "duration_sec": total,
        "num_chunks": len(chunks),
        "join_silence_sec_each": join_silence_sec,
        "chunks": [
            {
                "index": i,
                "text": chunk,
                "predicted_duration_sec": float(d),
            }
            for i, (chunk, d) in enumerate(zip(chunks, chunk_pred))
        ],
    }


def synthesize_long_text(
    ckpt_dir: Path,
    ref_audio: Path,
    model_dir: Path,
    text: str,
    output_wav: Path,
    device: str,
) -> dict:
    """
    Long-form local synthesis that exactly matches the estimator's chunk policy.
    This is important: estimating chunks but synthesizing one giant T3 request
    invalidates the calibration and can hit Chatterbox's generation ceiling.
    """
    _, metadata, _ = load_estimator(model_dir)
    cfg = metadata["run_config"]
    sampling_dict = cfg["sampling"]
    sampling = SamplingConfig(**sampling_dict)
    max_chars = int(metadata["max_chars_per_chunk"])
    join_silence_sec = float(metadata["join_silence_ms"]) / 1000.0

    chunks = chunk_text(text, max_chars=max_chars)
    if not chunks:
        raise ValueError("No text to synthesize.")

    model = load_local_chatterbox(ckpt_dir, device)
    model.prepare_conditionals(
        str(ref_audio), exaggeration=float(cfg["exaggeration"])
    )

    rendered: list[np.ndarray] = []
    chunk_durations: list[float] = []
    silence = np.zeros(int(round(model.sr * join_silence_sec)), dtype=np.float32)

    for i, chunk in enumerate(tqdm(chunks, desc="Synthesizing long text")):
        wav = synthesize_one(
            model=model,
            text=chunk,
            cfg_weight=float(cfg["cfg_weight"]),
            exaggeration=float(cfg["exaggeration"]),
            sampling=sampling,
        )
        arr = tensor_to_numpy_mono(wav)
        rendered.append(arr)
        chunk_durations.append(len(arr) / float(model.sr))
        if i != len(chunks) - 1 and len(silence):
            rendered.append(silence)

    full = np.concatenate(rendered)
    output_wav.parent.mkdir(parents=True, exist_ok=True)
    sf.write(output_wav, full, model.sr, subtype="PCM_16")

    return {
        "actual_duration_sec": len(full) / float(model.sr),
        "num_chunks": len(chunks),
        "chunk_actual_durations_sec": chunk_durations,
        "output_wav": str(output_wav),
    }


# ----------------------------- Workflow -------------------------------------

def save_run_config(workdir: Path, config: dict) -> None:
    (workdir / "run_config.json").write_text(
        json.dumps(config, indent=2), encoding="utf-8"
    )


def load_run_config(workdir: Path) -> dict:
    path = workdir / "run_config.json"
    if not path.exists():
        raise FileNotFoundError(f"Missing {path}; run grid/choose or wizard first.")
    return json.loads(path.read_text(encoding="utf-8"))


def wizard(args) -> None:
    ckpt_dir = Path(args.checkpoint_dir).expanduser().resolve()
    ref_audio = Path(args.ref).expanduser().resolve()
    workdir = Path(args.workdir).expanduser().resolve()
    corpus = Path(args.corpus).expanduser().resolve() if args.corpus else None
    workdir.mkdir(parents=True, exist_ok=True)

    device = args.device if args.device != "auto" else auto_device()
    sampling = SamplingConfig(
        temperature=args.temperature,
        min_p=args.min_p,
        top_p=args.top_p,
        repetition_penalty=args.repetition_penalty,
        sampling_seed=args.sampling_seed,
    )

    cfg_values = parse_float_list(args.cfg_grid)
    exag_values = parse_float_list(args.exag_grid)

    print(f"Device: {device}")
    print("Stage 1/4: creating audition grid...")
    rows = create_grid(
        ckpt_dir=ckpt_dir,
        ref_audio=ref_audio,
        workdir=workdir,
        cfg_values=cfg_values,
        exag_values=exag_values,
        grid_text=args.grid_text,
        device=device,
        sampling=sampling,
    )

    chosen = choose_grid_config(rows, preset_id=args.choice)
    run_config = {
        "checkpoint_dir": str(ckpt_dir),
        "reference_audio": str(ref_audio),
        "cfg_weight": float(chosen["cfg_weight"]),
        "exaggeration": float(chosen["exaggeration"]),
        "sampling": sampling.__dict__,
        "max_chars_per_chunk": int(args.max_chars),
        "join_silence_ms": float(args.join_silence_ms),
        "grid_choice_id": int(chosen["id"]),
    }
    save_run_config(workdir, run_config)

    print(
        f"\nChosen configuration: cfg={chosen['cfg_weight']:.2f}, "
        f"exaggeration={chosen['exaggeration']:.2f}"
    )

    print("\nStage 2/4: selecting training texts...")
    texts = prepare_text_list(
        workdir=workdir,
        corpus_path=corpus,
        jsonl_field=args.jsonl_field,
        n_samples=args.samples,
        max_chars=args.max_chars,
        seed=args.text_seed,
    )
    print(f"Selected {len(texts)} unique texts.")

    print("\nStage 3/4: synthesizing the dataset...")
    dataset_csv = collect_dataset(
        ckpt_dir=ckpt_dir,
        ref_audio=ref_audio,
        workdir=workdir,
        texts=texts,
        cfg_weight=run_config["cfg_weight"],
        exaggeration=run_config["exaggeration"],
        device=device,
        sampling=sampling,
    )

    print("\nStage 4/4: training and evaluating estimator...")
    model_dir = train_estimator(
        dataset_csv=dataset_csv,
        ckpt_dir=ckpt_dir,
        workdir=workdir,
        max_chars=args.max_chars,
        join_silence_ms=args.join_silence_ms,
        run_config=run_config,
    )

    print(f"\nSaved estimator: {model_dir / 'estimator.joblib'}")
    print(f"Evaluation:      {model_dir / 'evaluation.json'}")
    print(f"Holdout rows:    {model_dir / 'holdout_predictions.csv'}")


def command_grid(args) -> None:
    workdir = Path(args.workdir).expanduser().resolve()
    workdir.mkdir(parents=True, exist_ok=True)
    device = args.device if args.device != "auto" else auto_device()
    sampling = SamplingConfig(
        temperature=args.temperature,
        min_p=args.min_p,
        top_p=args.top_p,
        repetition_penalty=args.repetition_penalty,
        sampling_seed=args.sampling_seed,
    )
    rows = create_grid(
        ckpt_dir=Path(args.checkpoint_dir).expanduser().resolve(),
        ref_audio=Path(args.ref).expanduser().resolve(),
        workdir=workdir,
        cfg_values=parse_float_list(args.cfg_grid),
        exag_values=parse_float_list(args.exag_grid),
        grid_text=args.grid_text,
        device=device,
        sampling=sampling,
    )
    chosen = choose_grid_config(rows, preset_id=args.choice)
    run_config = {
        "checkpoint_dir": str(Path(args.checkpoint_dir).expanduser().resolve()),
        "reference_audio": str(Path(args.ref).expanduser().resolve()),
        "cfg_weight": float(chosen["cfg_weight"]),
        "exaggeration": float(chosen["exaggeration"]),
        "sampling": sampling.__dict__,
        "max_chars_per_chunk": int(args.max_chars),
        "join_silence_ms": float(args.join_silence_ms),
        "grid_choice_id": int(chosen["id"]),
    }
    save_run_config(workdir, run_config)
    print(json.dumps(run_config, indent=2))


def command_collect(args) -> None:
    workdir = Path(args.workdir).expanduser().resolve()
    cfg = load_run_config(workdir)
    ckpt_dir = Path(cfg["checkpoint_dir"])
    ref_audio = Path(cfg["reference_audio"])
    device = args.device if args.device != "auto" else auto_device()
    corpus = Path(args.corpus).expanduser().resolve() if args.corpus else None

    texts = prepare_text_list(
        workdir=workdir,
        corpus_path=corpus,
        jsonl_field=args.jsonl_field,
        n_samples=args.samples,
        max_chars=int(cfg["max_chars_per_chunk"]),
        seed=args.text_seed,
    )
    collect_dataset(
        ckpt_dir=ckpt_dir,
        ref_audio=ref_audio,
        workdir=workdir,
        texts=texts,
        cfg_weight=float(cfg["cfg_weight"]),
        exaggeration=float(cfg["exaggeration"]),
        device=device,
        sampling=SamplingConfig(**cfg["sampling"]),
    )


def command_train(args) -> None:
    workdir = Path(args.workdir).expanduser().resolve()
    cfg = load_run_config(workdir)
    model_dir = train_estimator(
        dataset_csv=workdir / "dataset" / "dataset.csv",
        ckpt_dir=Path(cfg["checkpoint_dir"]),
        workdir=workdir,
        max_chars=int(cfg["max_chars_per_chunk"]),
        join_silence_ms=float(cfg["join_silence_ms"]),
        run_config=cfg,
    )
    print(model_dir)


def command_predict(args) -> None:
    text = args.text
    if args.text_file:
        text = Path(args.text_file).read_text(encoding="utf-8")
    if not text:
        raise ValueError("Provide --text or --text-file.")

    result = estimate_long_text(Path(args.model_dir), text)
    print(json.dumps(result, indent=2, ensure_ascii=False))


def command_synthesize_long(args) -> None:
    text = args.text
    if args.text_file:
        text = Path(args.text_file).read_text(encoding="utf-8")
    if not text:
        raise ValueError("Provide --text or --text-file.")

    device = args.device if args.device != "auto" else auto_device()
    result = synthesize_long_text(
        ckpt_dir=Path(args.checkpoint_dir).expanduser().resolve(),
        ref_audio=Path(args.ref).expanduser().resolve(),
        model_dir=Path(args.model_dir).expanduser().resolve(),
        text=text,
        output_wav=Path(args.output).expanduser().resolve(),
        device=device,
    )
    estimate = estimate_long_text(Path(args.model_dir), text)
    result["predicted_duration_sec"] = estimate["duration_sec"]
    result["absolute_percent_error"] = (
        abs(result["predicted_duration_sec"] - result["actual_duration_sec"])
        / result["actual_duration_sec"]
        * 100.0
    )
    print(json.dumps(result, indent=2))


# ----------------------------- CLI ------------------------------------------

def add_sampling_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--temperature", type=float, default=0.8)
    p.add_argument("--min-p", type=float, default=0.05)
    p.add_argument("--top-p", type=float, default=1.0)
    p.add_argument("--repetition-penalty", type=float, default=1.2)
    p.add_argument("--sampling-seed", type=int, default=DEFAULT_SAMPLING_SEED)


def add_grid_args(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--cfg-grid",
        default=",".join(str(x) for x in DEFAULT_CFG_GRID),
        help="Comma-separated CFG values.",
    )
    p.add_argument(
        "--exag-grid",
        default=",".join(str(x) for x in DEFAULT_EXAG_GRID),
        help="Comma-separated exaggeration values.",
    )
    p.add_argument("--grid-text", default=DEFAULT_GRID_TEXT)
    p.add_argument(
        "--choice",
        type=int,
        default=None,
        help="Skip the interactive prompt and choose this grid ID.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Local English Chatterbox duration-estimator pipeline."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("wizard", help="Run grid -> choose -> 1000 syntheses -> train.")
    p.add_argument("--checkpoint-dir", required=True)
    p.add_argument("--ref", required=True)
    p.add_argument("--workdir", required=True)
    p.add_argument(
        "--corpus",
        default=None,
        help="Local .txt or .jsonl corpus. Strongly recommended for <1%% error.",
    )
    p.add_argument("--jsonl-field", default="text")
    p.add_argument("--samples", type=int, default=1000)
    p.add_argument("--max-chars", type=int, default=DEFAULT_MAX_CHARS)
    p.add_argument("--join-silence-ms", type=float, default=DEFAULT_JOIN_SILENCE_MS)
    p.add_argument("--text-seed", type=int, default=20260930)
    p.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu", "mps"])
    add_sampling_args(p)
    add_grid_args(p)
    p.set_defaults(func=wizard)

    p = sub.add_parser("grid", help="Generate audition grid and store chosen config.")
    p.add_argument("--checkpoint-dir", required=True)
    p.add_argument("--ref", required=True)
    p.add_argument("--workdir", required=True)
    p.add_argument("--max-chars", type=int, default=DEFAULT_MAX_CHARS)
    p.add_argument("--join-silence-ms", type=float, default=DEFAULT_JOIN_SILENCE_MS)
    p.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu", "mps"])
    add_sampling_args(p)
    add_grid_args(p)
    p.set_defaults(func=command_grid)

    p = sub.add_parser("collect", help="Create/resume the 1000-speech dataset.")
    p.add_argument("--workdir", required=True)
    p.add_argument("--corpus", default=None)
    p.add_argument("--jsonl-field", default="text")
    p.add_argument("--samples", type=int, default=1000)
    p.add_argument("--text-seed", type=int, default=20260930)
    p.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu", "mps"])
    p.set_defaults(func=command_collect)

    p = sub.add_parser("train", help="Train from workdir/dataset/dataset.csv.")
    p.add_argument("--workdir", required=True)
    p.set_defaults(func=command_train)

    p = sub.add_parser("predict", help="Estimate arbitrary-length text.")
    p.add_argument("--model-dir", required=True)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--text")
    g.add_argument("--text-file")
    p.set_defaults(func=command_predict)

    p = sub.add_parser(
        "synthesize-long",
        help="Generate long text locally with the same chunking used by the estimator.",
    )
    p.add_argument("--checkpoint-dir", required=True)
    p.add_argument("--ref", required=True)
    p.add_argument("--model-dir", required=True)
    p.add_argument("--output", required=True)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--text")
    g.add_argument("--text-file")
    p.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu", "mps"])
    p.set_defaults(func=command_synthesize_long)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if hasattr(args, "samples") and args.samples > 1000:
        parser.error("--samples must be <= 1000.")
    if hasattr(args, "samples") and args.samples < 200:
        print(
            "Warning: fewer than 200 samples will usually give unstable duration estimates.",
            file=sys.stderr,
        )
    args.func(args)


if __name__ == "__main__":
    main()
