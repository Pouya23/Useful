# Construction Montage Narrator

A deliberately modular local pipeline for:

1. accepting a construction/industrial montage,
2. separating the source into silent MP4 + optional source WAV,
3. using Qwen3-4B to write a duration-aware narration,
4. using Chatterbox to synthesize the narration,
5. measuring the real speech duration,
6. rewriting the script when the duration is too far off,
7. applying a small final FFmpeg tempo correction,
8. producing a narrated MP4.

The design targets a GPU with about **10.5 GB VRAM**. Qwen and Chatterbox are
never intentionally kept in GPU memory at the same time.

## Project layout

```text
construction_narrator/
├── run.py
├── requirements.txt
├── README.md
└── narrator/
    ├── __init__.py
    ├── config.py
    ├── media.py
    ├── prompts.py
    ├── llm.py
    ├── tts.py
    ├── timing.py
    └── pipeline.py
```

Each component has one job:

- `config.py` — defaults and tuning knobs.
- `media.py` — FFmpeg/FFprobe only.
- `prompts.py` — narration instructions only.
- `llm.py` — Qwen loading and generation only.
- `tts.py` — Chatterbox loading, chunking and synthesis only.
- `timing.py` — word targets and audio duration fitting only.
- `pipeline.py` — orchestration only.
- `run.py` — command-line interface only.

This makes it straightforward to replace Qwen, replace Chatterbox, change the
prompting policy, or change the timing algorithm without rewriting the rest.

## Important limitation

This version does **not** visually analyze the montage. It uses:

- the video's duration,
- the general subject,
- your optional description,
- and optional reference text.

The prompt explicitly tells Qwen not to invent site-specific visual facts.
If you later want narration tied to exact shots, add a separate `vision.py`
module that samples scenes/frames and passes factual visual notes to
`prompts.py`.

## Requirements

Recommended:

- Python 3.11
- NVIDIA CUDA-capable GPU
- about 10.5 GB VRAM or more
- FFmpeg (`ffmpeg` and `ffprobe`) available on `PATH`

Chatterbox's current package pins several dependencies, including a PyTorch
version. GPU compatibility varies by GPU generation and operating system, so
verify that the installed PyTorch build can see your GPU:

```bash
python -c "import torch; print(torch.__version__); print(torch.cuda.is_available())"
```

It should print `True` for CUDA availability.

## Install

### 1. Install FFmpeg

Ubuntu/Debian:

```bash
sudo apt update
sudo apt install ffmpeg
```

Windows: install an FFmpeg build and add its `bin` directory to `PATH`.

### 2. Create an environment

```bash
python3.11 -m venv .venv
source .venv/bin/activate
```

Windows PowerShell:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
```

### 3. Install Python packages

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If the PyTorch build pulled by Chatterbox does not support your particular GPU,
install a compatible CUDA-enabled PyTorch/torchaudio build for your system
first, then install the remaining dependencies. This is hardware-specific.

## Basic run

```bash
python run.py montage.mp4 \
  --topic "Maintenance of pipe handling systems" \
  --output job_001
```

## With a description

```bash
python run.py montage.mp4 \
  --topic "Maintenance of pipe handling systems" \
  --description "General maintenance, inspection, cleaning and reliable operation." \
  --output job_001
```

## With optional non-binding reference text

```bash
python run.py montage.mp4 \
  --topic "Maintenance of pipe handling systems" \
  --reference reference.txt \
  --output job_001
```

The reference text is deliberately described to Qwen as background only. The
prompt instructs it not to copy the reference's wording, structure, sequence,
opinions or conclusions.

## With a Chatterbox voice reference

```bash
python run.py montage.mp4 \
  --topic "Maintenance of pipe handling systems" \
  --voice narrator_reference.wav \
  --output job_001
```

If `--voice` is omitted, Chatterbox's built-in conditioning is used.

## Change narration style

Writing style is controlled independently from TTS voice delivery.

Example:

```bash
python run.py montage.mp4 \
  --topic "Pipe handling maintenance" \
  --style "Calm senior technician. Practical, precise, approachable, mildly energetic. Explain why each principle matters. Avoid hype." \
  --output job_001
```

For a more energetic delivery:

```bash
python run.py montage.mp4 \
  --topic "Pipe handling maintenance" \
  --exaggeration 0.7 \
  --cfg-weight 0.35 \
  --output job_001
```

For a more neutral delivery:

```bash
python run.py montage.mp4 \
  --topic "Pipe handling maintenance" \
  --exaggeration 0.4 \
  --cfg-weight 0.5 \
  --tts-temperature 0.7 \
  --output job_001
```

The exact effect of Chatterbox controls depends on the voice. Treat them as
tuning controls rather than fixed semantic settings.

## Speech length strategy

The pipeline does not assume that a given number of words always produces the
same speech duration.

Instead it does this:

```text
video duration
    ↓
initial word estimate from WPM
    ↓
Qwen script
    ↓
Qwen unloaded from GPU
    ↓
Chatterbox audio
    ↓
Chatterbox unloaded from GPU
    ↓
measure actual WAV duration
    ↓
if mismatch is large:
    compute corrected word target
    ↓
    Qwen rewrite
    ↓
    Qwen unloaded
    ↓
    Chatterbox regenerate
    ↓
small final FFmpeg tempo correction
```

Default initial pacing is 145 WPM:

```bash
--wpm 145
```

Slower initial narration:

```bash
--wpm 130
```

Faster initial narration:

```bash
--wpm 160
```

The real duration is still measured afterward.

## Duration correction controls

By default, the script is rewritten if synthesized speech differs from the
video by more than 8 percent:

```bash
--rewrite-threshold 0.08
```

Maximum rewrite passes:

```bash
--max-rewrites 2
```

After rewriting, FFmpeg makes the final correction so narration has the same
duration as the video.

## Main Chatterbox controls

```text
--exaggeration
--cfg-weight
--tts-temperature
--tts-min-p
--tts-top-p
--tts-repetition-penalty
--chunk-chars
--chunk-pause
--seed
```

Defaults are in `narrator/config.py`.

Narration is split into short chunks before synthesis. The default is:

```text
max_chunk_chars = 260
```

This avoids sending a multi-minute script to Chatterbox in one call.

## Main Qwen controls

```text
--llm-model
--llm-temperature
--llm-top-p
--llm-top-k
--llm-repetition-penalty
--max-new-tokens
--no-4bit
```

Qwen3-4B is loaded in 4-bit by default to make the 10.5 GB VRAM target more
comfortable.

The code uses Qwen3's non-thinking mode:

```python
enable_thinking=False
```

This is appropriate for direct narration generation and avoids spending output
tokens on a reasoning block.

## Output

A typical run produces:

```text
job_001/
├── video_only.mp4
├── original.wav             # only if the source contains audio
├── prompt_initial.txt
├── prompt_rewrite_1.txt     # only if a rewrite was required
├── prompt_rewrite_2.txt     # only if a second rewrite was required
├── script.txt
├── narration_raw.wav
├── narration.wav
├── narrated.mp4
└── run_metadata.json
```

`run_metadata.json` records the effective settings and timing attempts so a run
can be inspected and reproduced more easily.

## Changing individual components

### Change only what Qwen is told

Edit:

```text
narrator/prompts.py
```

### Replace Qwen with another LLM

Replace the implementation behind:

```python
generate_script(...)
```

or replace `QwenGenerator` in:

```text
narrator/llm.py
```

Keep its simple `load() / generate() / unload()` interface.

### Replace Chatterbox

Replace:

```text
narrator/tts.py
```

Keep `generate_voice(...)` in `pipeline.py` returning a WAV and the rest of the
pipeline does not care which TTS engine produced it.

### Change timing policy

Edit:

```text
narrator/timing.py
```

### Mix the original job-site audio with narration

Currently the final MP4 uses narration as its audio track and preserves the
source audio separately as `original.wav`.

If you want ducking/mixing instead, change only `mux_narration()` in
`narrator/media.py`.

## Running components manually

You can test media separation without running either model:

```python
from narrator.media import split_input

video, source_audio, seconds = split_input("montage.mp4", "test_media")
print(video, source_audio, seconds)
```

You can test prompt construction without a GPU:

```python
from narrator.prompts import initial_prompt

print(
    initial_prompt(
        topic="Pipe handling maintenance",
        description="Inspection and maintenance.",
        reference_text="",
        style="Calm and technical.",
        target_words=700,
    )
)
```

You can test only Qwen:

```python
from narrator.config import LLMConfig
from narrator.llm import QwenGenerator

model = QwenGenerator(LLMConfig())
try:
    model.load()
    print(model.generate("Write 100 words explaining preventive maintenance."))
finally:
    model.unload()
```

You can test only Chatterbox:

```python
from narrator.config import TTSConfig
from narrator.tts import ChatterboxEngine

tts = ChatterboxEngine(TTSConfig())
try:
    tts.load()
    tts.synthesize(
        "Preventive maintenance reduces unplanned interruptions.",
        "test.wav",
    )
finally:
    tts.unload()
```

## VRAM behavior

The orchestrator intentionally creates and destroys one model at a time.
A timing rewrite therefore looks like:

```text
Qwen load
Qwen generate
Qwen unload
CUDA cache clear

Chatterbox load
Chatterbox synthesize
Chatterbox unload
CUDA cache clear

Qwen load only if rewrite is necessary
...
```

This is the main reason the architecture is suitable for a GPU around 10.5 GB.

## Notes

- First use downloads model files from Hugging Face/Chatterbox repositories.
- Subsequent runs normally reuse the local model cache.
- Long videos may require increasing `--max-new-tokens`.
- This pipeline generates one continuous narration track; it does not yet align
  individual sentences to individual shots.
- The final FFmpeg tempo correction should normally be small because large
  mismatches are handled by rewriting first.
