"""Modular construction-site narration pipeline."""
__version__ = "0.1.0"
