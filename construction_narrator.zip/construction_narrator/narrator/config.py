from dataclasses import dataclass


@dataclass
class LLMConfig:
    model: str = "Qwen/Qwen3-4B"
    load_in_4bit: bool = True
    temperature: float = 0.7
    top_p: float = 0.8
    top_k: int = 20
    repetition_penalty: float = 1.08
    max_new_tokens: int = 8192


@dataclass
class TTSConfig:
    device: str = "cuda"
    exaggeration: float = 0.5
    cfg_weight: float = 0.5
    temperature: float = 0.8
    min_p: float = 0.05
    top_p: float = 1.0
    repetition_penalty: float = 1.2
    max_chunk_chars: int = 260
    chunk_pause_seconds: float = 0.10
    seed: int | None = None


@dataclass
class TimingConfig:
    # Used only to estimate the first script length.
    target_wpm: float = 145.0

    # If generated speech differs from video by more than this fraction,
    # rewrite the script before doing the final small tempo correction.
    rewrite_threshold: float = 0.08
    max_rewrites: int = 2

    # Final WAV sample rate after FFmpeg tempo fitting.
    output_sample_rate: int = 48000
