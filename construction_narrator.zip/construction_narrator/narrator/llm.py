import gc

import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
)

from .config import LLMConfig


class QwenGenerator:
    """Qwen-only component. No video or TTS logic lives here."""

    def __init__(self, config: LLMConfig):
        self.cfg = config
        self.model = None
        self.tokenizer = None

    def load(self) -> None:
        kwargs = {
            "device_map": "auto",
            "torch_dtype": torch.float16,
        }

        if self.cfg.load_in_4bit:
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=torch.float16,
            )

        self.tokenizer = AutoTokenizer.from_pretrained(self.cfg.model)
        self.model = AutoModelForCausalLM.from_pretrained(
            self.cfg.model,
            **kwargs,
        )
        self.model.eval()

    def generate(self, prompt: str) -> str:
        if self.model is None or self.tokenizer is None:
            raise RuntimeError("QwenGenerator.load() must be called first.")

        messages = [{"role": "user", "content": prompt}]
        chat_text = self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )

        inputs = self.tokenizer(chat_text, return_tensors="pt")
        input_device = next(self.model.parameters()).device
        inputs = {k: v.to(input_device) for k, v in inputs.items()}

        with torch.inference_mode():
            output = self.model.generate(
                **inputs,
                max_new_tokens=self.cfg.max_new_tokens,
                do_sample=True,
                temperature=self.cfg.temperature,
                top_p=self.cfg.top_p,
                top_k=self.cfg.top_k,
                repetition_penalty=self.cfg.repetition_penalty,
                pad_token_id=self.tokenizer.eos_token_id,
            )

        generated = output[0, inputs["input_ids"].shape[1] :]
        return self.tokenizer.decode(
            generated,
            skip_special_tokens=True,
        ).strip()

    def unload(self) -> None:
        self.model = None
        self.tokenizer = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
