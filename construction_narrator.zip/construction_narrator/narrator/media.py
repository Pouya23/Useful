import json
import shutil
import subprocess
from pathlib import Path


def require_ffmpeg() -> None:
    missing = [name for name in ("ffmpeg", "ffprobe") if shutil.which(name) is None]
    if missing:
        raise RuntimeError(
            "Missing system executable(s): "
            + ", ".join(missing)
            + ". Install FFmpeg and ensure ffmpeg/ffprobe are on PATH."
        )


def _run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


def _check_output(cmd: list[str]) -> str:
    return subprocess.check_output(cmd, text=True).strip()


def probe_media(path: str | Path) -> tuple[float, bool]:
    """Return (duration_seconds, has_audio_stream)."""
    require_ffmpeg()
    path = Path(path)

    data = json.loads(
        _check_output(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration:stream=codec_type",
                "-of",
                "json",
                str(path),
            ]
        )
    )

    duration = float(data["format"]["duration"])
    has_audio = any(
        stream.get("codec_type") == "audio"
        for stream in data.get("streams", [])
    )
    return duration, has_audio


def audio_duration(path: str | Path) -> float:
    require_ffmpeg()
    return float(
        _check_output(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=nw=1:nk=1",
                str(path),
            ]
        )
    )


def split_input(
    src: str | Path,
    out_dir: str | Path,
) -> tuple[Path, Path | None, float]:
    """
    Save video without audio as video_only.mp4.
    If source audio exists, save first audio stream as original.wav.
    """
    require_ffmpeg()
    src = Path(src)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if not src.exists():
        raise FileNotFoundError(src)

    duration, has_audio = probe_media(src)

    video_out = out_dir / "video_only.mp4"
    audio_out = out_dir / "original.wav"

    _run(
        [
            "ffmpeg",
            "-y",
            "-i",
            str(src),
            "-map",
            "0:v:0",
            "-c:v",
            "copy",
            "-an",
            "-movflags",
            "+faststart",
            str(video_out),
        ]
    )

    if has_audio:
        _run(
            [
                "ffmpeg",
                "-y",
                "-i",
                str(src),
                "-map",
                "0:a:0",
                "-vn",
                "-ac",
                "2",
                "-ar",
                "48000",
                "-c:a",
                "pcm_s16le",
                str(audio_out),
            ]
        )
    else:
        audio_out = None

    return video_out, audio_out, duration


def mux_narration(
    video: str | Path,
    narration: str | Path,
    output: str | Path,
) -> None:
    """Mux narration into the silent video."""
    require_ffmpeg()
    _run(
        [
            "ffmpeg",
            "-y",
            "-i",
            str(video),
            "-i",
            str(narration),
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
            "-movflags",
            "+faststart",
            "-shortest",
            str(output),
        ]
    )
