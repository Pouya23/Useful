import json
from dataclasses import asdict
from pathlib import Path

from .config import LLMConfig, TTSConfig, TimingConfig
from .llm import QwenGenerator
from .media import audio_duration, mux_narration, split_input
from .prompts import initial_prompt, rewrite_for_duration_prompt
from .timing import (
    corrected_word_target,
    fit_audio_to_duration,
    initial_word_target,
    relative_timing_error,
)
from .tts import ChatterboxEngine


def generate_script(prompt: str, cfg: LLMConfig) -> str:
    """Load Qwen, generate once, then immediately release GPU memory."""
    llm = QwenGenerator(cfg)
    try:
        llm.load()
        return llm.generate(prompt)
    finally:
        llm.unload()


def generate_voice(
    script: str,
    output: str | Path,
    cfg: TTSConfig,
    voice_reference: str | Path | None = None,
) -> None:
    """Load Chatterbox, synthesize once, then immediately release GPU memory."""
    tts = ChatterboxEngine(cfg)
    try:
        tts.load(voice_reference)
        tts.synthesize(script, output)
    finally:
        tts.unload()


def run_pipeline(
    input_video: str | Path,
    output_dir: str | Path,
    topic: str,
    description: str = "",
    reference_text: str = "",
    style: str = (
        "Clear, practical, moderately energetic, educational, and natural. "
        "Sound like an experienced instructor, not an advertisement."
    ),
    voice_reference: str | Path | None = None,
    llm_cfg: LLMConfig | None = None,
    tts_cfg: TTSConfig | None = None,
    timing_cfg: TimingConfig | None = None,
) -> dict[str, Path | None]:
    """
    End-to-end pipeline.

    GPU-heavy models are deliberately loaded sequentially:
      Qwen -> unload -> Chatterbox -> unload -> optional Qwen rewrite -> ...
    """
    llm_cfg = llm_cfg or LLMConfig()
    tts_cfg = tts_cfg or TTSConfig()
    timing_cfg = timing_cfg or TimingConfig()

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # 1. Separate media.
    video, original_audio, video_seconds = split_input(input_video, out)

    # 2. Estimate script length and write the first prompt to disk.
    target_words = initial_word_target(
        video_seconds,
        timing_cfg.target_wpm,
    )
    prompt = initial_prompt(
        topic=topic,
        description=description,
        reference_text=reference_text,
        style=style,
        target_words=target_words,
    )
    (out / "prompt_initial.txt").write_text(prompt, encoding="utf-8")

    # 3. Generate the initial script with Qwen.
    script = generate_script(prompt, llm_cfg)
    script_path = out / "script.txt"
    script_path.write_text(script, encoding="utf-8")

    # 4. TTS -> measure -> optionally rewrite to better match duration.
    raw_audio = out / "narration_raw.wav"
    timing_history: list[dict] = []

    for attempt in range(timing_cfg.max_rewrites + 1):
        generate_voice(
            script=script,
            output=raw_audio,
            cfg=tts_cfg,
            voice_reference=voice_reference,
        )

        spoken_seconds = audio_duration(raw_audio)
        error = relative_timing_error(spoken_seconds, video_seconds)
        timing_history.append(
            {
                "attempt": attempt,
                "script_words": len(script.split()),
                "audio_seconds": spoken_seconds,
                "video_seconds": video_seconds,
                "relative_error": error,
            }
        )

        print(
            f"[timing] attempt={attempt} "
            f"words={len(script.split())} "
            f"tts={spoken_seconds:.2f}s "
            f"video={video_seconds:.2f}s "
            f"error={error * 100:.1f}%"
        )

        if error <= timing_cfg.rewrite_threshold:
            break

        if attempt >= timing_cfg.max_rewrites:
            break

        target_words = corrected_word_target(
            script,
            spoken_seconds,
            video_seconds,
        )
        rewrite_prompt = rewrite_for_duration_prompt(
            script,
            target_words,
            style,
        )
        (out / f"prompt_rewrite_{attempt + 1}.txt").write_text(
            rewrite_prompt,
            encoding="utf-8",
        )

        # Chatterbox is already unloaded here. Load Qwen only for the rewrite.
        script = generate_script(rewrite_prompt, llm_cfg)
        script_path.write_text(script, encoding="utf-8")

    # 5. Small final tempo correction so narration exactly matches video length.
    narration = out / "narration.wav"
    tempo_factor = fit_audio_to_duration(
        raw_audio,
        narration,
        target_seconds=video_seconds,
        sample_rate=timing_cfg.output_sample_rate,
    )

    # 6. Create final narrated MP4.
    final_video = out / "narrated.mp4"
    mux_narration(video, narration, final_video)

    metadata = {
        "input_video": str(Path(input_video)),
        "topic": topic,
        "description": description,
        "style": style,
        "video_seconds": video_seconds,
        "final_script_words": len(script.split()),
        "final_tempo_factor": tempo_factor,
        "timing_history": timing_history,
        "llm_config": asdict(llm_cfg),
        "tts_config": asdict(tts_cfg),
        "timing_config": asdict(timing_cfg),
    }
    (out / "run_metadata.json").write_text(
        json.dumps(metadata, indent=2),
        encoding="utf-8",
    )

    return {
        "video": video,
        "original_audio": original_audio,
        "script": script_path,
        "narration_raw": raw_audio,
        "narration": narration,
        "final_video": final_video,
        "metadata": out / "run_metadata.json",
    }
