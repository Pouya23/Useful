def initial_prompt(
    topic: str,
    description: str,
    reference_text: str,
    style: str,
    target_words: int,
) -> str:
    description = description.strip() or "(none provided)"
    reference_text = reference_text.strip() or "(none provided)"

    return f"""
Write the complete voice-over narration for a construction/industrial job-site video.

GENERAL SUBJECT:
{topic}

OPTIONAL JOB DESCRIPTION:
{description}

OPTIONAL REFERENCE MATERIAL:
{reference_text}

IMPORTANT:
The reference material is background only. Do not imitate its wording, structure,
sequence, opinions, or conclusions. Build the narration independently from the
general subject and supplied description.

DESIRED NARRATION STYLE:
{style}

TARGET LENGTH:
Approximately {target_words} spoken words.

Requirements:
- Output only the narration that should be spoken.
- No title, headings, bullets, timestamps, notes, or stage directions.
- Be educational, practical, clear, and engaging without sounding promotional.
- Maintain useful information throughout the narration.
- Use natural transitions and varied sentence length.
- Avoid filler and repeated conclusions.
- Do not claim a particular action, tool, defect, measurement, procedure, or
  safety condition is visible unless the supplied information explicitly says so.
- Do not invent site-specific facts.
- Explain principles and purposes when exact visual details are unknown.
- Use natural spoken English, not report-writing language.
- Aim to stay within about 5 percent of the target word count.
""".strip()


def rewrite_for_duration_prompt(
    script: str,
    target_words: int,
    style: str,
) -> str:
    return f"""
Rewrite the narration below to approximately {target_words} spoken words.

Keep its factual meaning, subject, and educational purpose.
Do not add site-specific facts that were not already present.

DESIRED STYLE:
{style}

Requirements:
- Output only the rewritten narration.
- No headings, bullets, timestamps, notes, or stage directions.
- Preserve useful information.
- Keep the voice natural and suitable for narration.
- Do not pad with empty filler.
- Aim to stay within about 5 percent of {target_words} words.

CURRENT NARRATION:
{script}
""".strip()
