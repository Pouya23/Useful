import subprocess
from pathlib import Path

from .media import audio_duration, require_ffmpeg


def initial_word_target(seconds: float, wpm: float) -> int:
    return max(20, round((seconds / 60.0) * wpm))


def corrected_word_target(
    script: str,
    generated_seconds: float,
    target_seconds: float,
) -> int:
    current_words = len(script.split())
    if generated_seconds <= 0:
        raise ValueError("Generated audio duration must be > 0.")
    return max(
        20,
        round(current_words * target_seconds / generated_seconds),
    )


def relative_timing_error(
    generated_seconds: float,
    target_seconds: float,
) -> float:
    if target_seconds <= 0:
        raise ValueError("Target duration must be > 0.")
    return abs(generated_seconds / target_seconds - 1.0)


def atempo_chain(factor: float) -> str:
    """
    Build an FFmpeg atempo chain with each factor in [0.5, 2.0].
    factor > 1 speeds up audio; factor < 1 slows it down.
    """
    if factor <= 0:
        raise ValueError("Tempo factor must be > 0.")

    factors: list[float] = []

    while factor > 2.0:
        factors.append(2.0)
        factor /= 2.0

    while factor < 0.5:
        factors.append(0.5)
        factor /= 0.5

    factors.append(factor)
    return ",".join(f"atempo={part:.8f}" for part in factors)


def fit_audio_to_duration(
    src: str | Path,
    dst: str | Path,
    target_seconds: float,
    sample_rate: int = 48000,
) -> float:
    """
    Make final narration exactly target_seconds long.

    Returns the tempo factor that was applied.
    """
    require_ffmpeg()
    current_seconds = audio_duration(src)
    if current_seconds <= 0:
        raise ValueError("Source narration duration must be > 0.")

    tempo = current_seconds / target_seconds
    filters = f"{atempo_chain(tempo)},apad"

    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-i",
            str(src),
            "-af",
            filters,
            "-t",
            f"{target_seconds:.6f}",
            "-ar",
            str(sample_rate),
            "-c:a",
            "pcm_s16le",
            str(dst),
        ],
        check=True,
    )
    return tempo
