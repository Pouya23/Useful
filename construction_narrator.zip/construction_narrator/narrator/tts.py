import gc
import random
import re
import textwrap
from pathlib import Path

import numpy as np
import torch
import torchaudio as ta
from chatterbox.tts import ChatterboxTTS

from .config import TTSConfig


def split_text(text: str, max_chars: int = 260) -> list[str]:
    """
    Split narration into TTS-sized chunks, preferring sentence boundaries.
    Chatterbox's demo UI currently uses a 300-character text limit, so the
    default leaves some margin.
    """
    text = " ".join(text.split())
    if not text:
        return []

    sentences = re.split(r"(?<=[.!?])\s+", text)
    chunks: list[str] = []
    current = ""

    for sentence in sentences:
        pieces = (
            textwrap.wrap(
                sentence,
                width=max_chars,
                break_long_words=False,
                break_on_hyphens=False,
            )
            if len(sentence) > max_chars
            else [sentence]
        )

        for piece in pieces:
            candidate = f"{current} {piece}".strip() if current else piece
            if len(candidate) <= max_chars:
                current = candidate
            else:
                if current:
                    chunks.append(current)
                current = piece

    if current:
        chunks.append(current)

    return chunks


def _seed_everything(seed: int | None) -> None:
    if seed is None:
        return
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class ChatterboxEngine:
    """Chatterbox-only component. No LLM or video logic lives here."""

    def __init__(self, config: TTSConfig):
        self.cfg = config
        self.model = None

    def load(self, voice_reference: str | Path | None = None) -> None:
        self.model = ChatterboxTTS.from_pretrained(device=self.cfg.device)

        if voice_reference:
            self.model.prepare_conditionals(
                str(voice_reference),
                exaggeration=self.cfg.exaggeration,
            )

    def synthesize(self, text: str, output: str | Path) -> None:
        if self.model is None:
            raise RuntimeError("ChatterboxEngine.load() must be called first.")

        chunks = split_text(text, self.cfg.max_chunk_chars)
        if not chunks:
            raise ValueError("Cannot synthesize empty narration.")

        _seed_everything(self.cfg.seed)

        parts: list[torch.Tensor] = []
        pause = torch.zeros(
            1,
            max(0, int(self.model.sr * self.cfg.chunk_pause_seconds)),
        )

        for index, chunk in enumerate(chunks):
            wav = self.model.generate(
                chunk,
                exaggeration=self.cfg.exaggeration,
                cfg_weight=self.cfg.cfg_weight,
                temperature=self.cfg.temperature,
                min_p=self.cfg.min_p,
                top_p=self.cfg.top_p,
                repetition_penalty=self.cfg.repetition_penalty,
            )
            parts.append(wav.detach().cpu())

            if index != len(chunks) - 1 and pause.shape[1] > 0:
                parts.append(pause)

        result = torch.cat(parts, dim=1)
        ta.save(str(output), result, self.model.sr)

    def unload(self) -> None:
        self.model = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
