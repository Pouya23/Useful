import argparse
from pathlib import Path

from narrator.config import LLMConfig, TTSConfig, TimingConfig
from narrator.pipeline import run_pipeline


DEFAULT_STYLE = (
    "Clear, practical, moderately energetic, educational, and natural. "
    "Sound like an experienced instructor, not an advertisement."
)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description=(
            "Generate duration-matched construction/job-site narration "
            "with Qwen3-4B + Chatterbox."
        )
    )
    p.add_argument("video", help="Input montage/video file")
    p.add_argument("--topic", required=True, help="General subject of the job")
    p.add_argument("--description", default="", help="Optional job description")
    p.add_argument(
        "--reference",
        help="Optional text file used only as non-binding background material",
    )
    p.add_argument(
        "--voice",
        help="Optional reference WAV/audio for Chatterbox voice conditioning",
    )
    p.add_argument("--style", default=DEFAULT_STYLE, help="Narration writing style")
    p.add_argument("--wpm", type=float, default=145.0, help="Initial words/minute target")
    p.add_argument("--output", default="output", help="Output directory")

    # Main Chatterbox style/pacing controls.
    p.add_argument("--exaggeration", type=float, default=0.5)
    p.add_argument("--cfg-weight", type=float, default=0.5)
    p.add_argument("--tts-temperature", type=float, default=0.8)
    p.add_argument("--tts-min-p", type=float, default=0.05)
    p.add_argument("--tts-top-p", type=float, default=1.0)
    p.add_argument("--tts-repetition-penalty", type=float, default=1.2)
    p.add_argument("--chunk-chars", type=int, default=260)
    p.add_argument("--chunk-pause", type=float, default=0.10)
    p.add_argument("--seed", type=int)

    # Timing loop.
    p.add_argument(
        "--rewrite-threshold",
        type=float,
        default=0.08,
        help="Rewrite if TTS/video duration mismatch exceeds this fraction",
    )
    p.add_argument("--max-rewrites", type=int, default=2)

    # Qwen controls.
    p.add_argument("--llm-model", default="Qwen/Qwen3-4B")
    p.add_argument("--llm-temperature", type=float, default=0.7)
    p.add_argument("--llm-top-p", type=float, default=0.8)
    p.add_argument("--llm-top-k", type=int, default=20)
    p.add_argument("--llm-repetition-penalty", type=float, default=1.08)
    p.add_argument("--max-new-tokens", type=int, default=8192)
    p.add_argument(
        "--no-4bit",
        action="store_true",
        help="Disable Qwen 4-bit loading (not recommended for a 10.5 GB GPU)",
    )

    return p.parse_args()


def main() -> None:
    args = parse_args()

    reference_text = ""
    if args.reference:
        reference_text = Path(args.reference).read_text(encoding="utf-8")

    llm_cfg = LLMConfig(
        model=args.llm_model,
        load_in_4bit=not args.no_4bit,
        temperature=args.llm_temperature,
        top_p=args.llm_top_p,
        top_k=args.llm_top_k,
        repetition_penalty=args.llm_repetition_penalty,
        max_new_tokens=args.max_new_tokens,
    )

    tts_cfg = TTSConfig(
        exaggeration=args.exaggeration,
        cfg_weight=args.cfg_weight,
        temperature=args.tts_temperature,
        min_p=args.tts_min_p,
        top_p=args.tts_top_p,
        repetition_penalty=args.tts_repetition_penalty,
        max_chunk_chars=args.chunk_chars,
        chunk_pause_seconds=args.chunk_pause,
        seed=args.seed,
    )

    timing_cfg = TimingConfig(
        target_wpm=args.wpm,
        rewrite_threshold=args.rewrite_threshold,
        max_rewrites=args.max_rewrites,
    )

    outputs = run_pipeline(
        input_video=args.video,
        output_dir=args.output,
        topic=args.topic,
        description=args.description,
        reference_text=reference_text,
        style=args.style,
        voice_reference=args.voice,
        llm_cfg=llm_cfg,
        tts_cfg=tts_cfg,
        timing_cfg=timing_cfg,
    )

    print("\nOutputs:")
    for name, path in outputs.items():
        if path is not None:
            print(f"  {name}: {path}")


if __name__ == "__main__":
    main()
