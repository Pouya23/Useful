# Fast Qwen writing pipeline

Readable Python source for **Qwen3.5 9B Q5_K_M**. There are no manifests,
encoded source bundles or notebook dependencies in this package.

## Start here

Extract this ZIP, open its `fast_qwen_pipeline` directory, then choose:

```bash
# Interactive maintenance example with samples and a fictional demo reference:
python maintenance_example.py

# Your own approved reference and instructions:
python run_pipeline.py --source approved_reference.txt --title "Maintenance of pipe handling systems" --instructions "Cover inspection, defect reporting and handover."
```

On **Kaggle**, enable **GPU T4 x2** and **Internet**. The existing native runtime,
dependencies and model from your previous notebook are reused when present;
otherwise they download automatically. No venv, ensurepip, Transformers or
PyTorch installation is needed. See [setup](docs/SETUP.md) for extraction and
notebook/API instructions. Outside Kaggle, supply a compatible native server path.

## How a round works

1. `job.draft()` generates the first text directly. It displays the full text,
   latency and sampled peak total GPU VRAM.
2. Python counts its words and determines whether it should expand, shorten or
   keep its length. This feedback makes **no LLM call**.
3. You supply quality feedback. `job.revise(...)` makes at most **one generation**
   using the latest draft, the original brief and both feedback signals.
4. Repeat for **unlimited revisions**. Every generated version is displayed and
   saved. There are no model planning, critique or judging passes.

The CLI asks for feedback after every generation. **Enter** accepts when length
is satisfied; otherwise it requests one length repair and asks again.
**`/shorter`, `/longer`, `/keep`** set a new relative length policy. **`/done`**
accepts the latest text even when its length request remains unmet.

Keep a `FastQwenSession` open across multiple writing jobs to avoid reloading the
model. Prompts contain the original context, current draft and latest feedback;
they do not accumulate every previous generation.

## Memory and validation

Default: one GPU, 32,768 context tokens, CPU KV cache, a 10.5 decimal-GB ceiling
and a conservative 9.0 GB sampled guard. Continuous NVML sampling includes loading
and decoding; each generation has a fresh peak. **Polling is reactive and cannot
guarantee that every very short allocation transient stayed below 10.5 GB.**
CPU KV saves GPU memory at a speed cost. GPU KV is an optional, unmeasured speed
mode with extra VRAM use; start with the default. Inputs and partial output are
never silently truncated to satisfy context or word limits.

The chosen model's earlier measured peak was 6.651 GB with CPU KV. The new direct
pipeline's T4 performance still needs measurement. Native transport and caching
were exercised on a real local CPU model; the package also includes focused
offline tests. See [model selection](docs/MODEL_SELECTION.md).

## Files

- `run_pipeline.py`: your-input CLI.
- `maintenance_example.py`: complete interactive example.
- `qwen_writer/writer.py`: draft/revision logic and resident model session.
- `qwen_writer/requests.py`: brief, reference types and word counting.
- `qwen_writer/model.py`: fixed model identity and resumable download.
- `qwen_writer/runtime.py`: private native server and VRAM guard.
- `qwen_writer/telemetry.py`: per-round measurements and logs.
- `qwen_writer/kaggle_setup.py`: native CUDA runtime setup on Kaggle.
- `docs/`: setup, API, model choice and troubleshooting.
- `tests/`: offline tests; no model download or GPU required.

Model identity and download integrity constants are ordinary Python constants
inside `model.py`. You do not need to create, edit or upload a metadata file.

Outputs include each text, local word counts, feedback, request/response records,
per-pass CSV/JSON metrics and continuous VRAM samples. These are generated results,
not configuration files required to run the code.
