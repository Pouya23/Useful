# Python API

## Separate, visible rounds

```python
from pathlib import Path
from qwen_writer import FastQwenSession, Source, WritingRequest

brief = WritingRequest(
    title="Maintenance of pipe handling systems",
    instructions="Write calm spoken training; emphasize defect reporting and handover.",
    required_points=("Follow the approved maintenance procedure.", "Record and report defects."),
    samples=(),  # Optional tuple of writing samples.
    sources=(Source("approved-site", Path("approved_reference.txt").read_text(encoding="utf-8")),),
    min_words=350, max_words=500,
)

model = FastQwenSession(context_tokens=32768, kv_cache_device="cpu")
model.__enter__()  # In a script, prefer a with block for automatic cleanup.
job = model.new_job(brief)
initial = job.draft()
```

Read the displayed text, then run each next round independently:

```python
current = job.revise(quality_feedback="Make the transition to handover clearer.")
current = job.revise(length_direction="shorter")
current = job.revise(quality_feedback="Keep the concise style but clarify record keeping.")
current = job.revise(word_range=(250, 350))
# Continue for as many feedback rounds as useful.
final = job.accept()
model.close()  # Always release the native process and finish the metric files.
```

For an interactive console loop:

```python
from qwen_writer import review_interactively
final = review_interactively(job)
```

## Length semantics

- Counting is local Python: whitespace tokens containing letters/numbers;
  hyphenated words count as one. This suits English and other space-delimited
  languages; it is not a Chinese/Japanese segmentation algorithm.
- A numeric range is approximate. Python reports its actual satisfaction and
  supplies expand/shorten/keep feedback; no sentence is cut to force compliance.
- A new `shorter`/`longer` direction uses the immediately preceding text as its
  baseline and clears the older numeric range unless you provide new bounds.
- `keep` measures ±10% of its baseline. New bounds and a direction may be combined
  if they do not conflict.
- Omit a direction/range to retain the latest policy. `length_direction=None`
  clears an existing direction; `word_range=None` clears numeric bounds.
- Empty quality feedback with satisfactory length makes **no generation**.
  Otherwise each call makes exactly one attempt. Revisions have no fixed limit.

## Inputs and results

`WritingRequest` also supports language, audience, tone, output_format
(`narration` or `article`), and an optional existing `draft`. To change the length
of an existing input draft in the initial call, set its `length_direction`.
Samples guide style; they are not treated as approved technical references.

`draft()`/`revise()` return a dictionary with `text`, `word_count`, `length_feedback`,
`sample_overlap_flags`, `warnings` and the user feedback. Self-scoring is not used.
`finalize()` remains an alias of `revise()`; it does not prohibit later revisions.

Each model session can create multiple independent `new_job(...)` objects without
loading weights again. Use jobs sequentially. Prompts carry only the original
brief, latest accepted draft and latest feedback; complete history is saved to disk.

`model.new_job(brief, max_output_tokens=2048, seed=42)` overrides the output token
allowance. The default is derived from the requested length and language. Actual
native token admission rejects requests that exceed the active context; it never
silently removes a source or sample. If a revision is truncated, its partial text
is saved/displayed and the last accepted text is retained. Increase
`job.max_output_tokens` before another feedback submission.

`FastQwenSession` accepts `server`, `model`, `context_tokens`, `gpu_index`,
`kv_cache_device`, a fresh `output` directory, `install_dependencies` and a
`render` callback. Leaving `output` unset creates a fresh run directory. A custom
callback receives each generation's full text, latency and memory record.
