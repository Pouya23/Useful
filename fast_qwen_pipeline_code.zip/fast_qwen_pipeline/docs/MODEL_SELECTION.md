# Why Qwen3.5 9B Q5_K_M

Selection uses your completed `llm-pipeline.ipynb`, rather than a model's own
quality score. The task requested 350–500 words on pipe handling maintenance.

| Candidate | Initial words | Drafting-stage seconds | Observed peak GB | Main finding |
|---|---:|---:|---:|---|
| Qwen3.5 9B Q5_K_M | 387 | 34.1 | 6.651 | All requested areas present; range met; strong quality/speed balance |
| Gemma 4 12B Q4_K_M | 404 | 73.6 | 7.822 | Range met; more conversational prose, over twice the draft-stage time |
| Ministral 3 8B Q6_K | 589 | 78.3 | 7.295 | Over range; introduced unsupported device/testing details |
| Qwen3.5 4B Q6_K | 329 | 25.1 | 4.298 | Faster, but missed the lower word bound and copied sample phrasing |

Qwen 9B is the **provisional best choice** for this setup, with initial-draft
quality emphasized. This is one brief and run, not a universal ranking. The
initial drafts in the test followed a generated plan, so these numbers are not
a clean measurement of the new pure one-shot pipeline. First-call cold-start
latency may also differ. No fixed speedup or new T4 throughput is promised.

The self-reviews made counting and factual errors: for example Qwen 9B's review
claimed its 387-word draft was below the 350-word minimum. The new pipeline removes
these judge calls, counts words locally, and receives quality feedback from you.
It makes one direct drafting call and at most one generation per feedback round.

Model: [Qwen3.5 9B](https://huggingface.co/Qwen/Qwen3.5-9B).
The package fixes the tested Q5_K_M weight revision and verifies its file identity.
No worksite-specialized fine-tuning is claimed. Replace the fictional example
reference with approved manufacturer/site material for actual equipment.
