# Setup and execution

## Kaggle

1. Upload `fast_qwen_pipeline_code.zip` as a Kaggle Dataset and attach it to a
   notebook. Select **GPU T4 x2** and enable **Internet**.
2. Extract and add the code directory to Python's import path:

```python
from pathlib import Path
import sys, zipfile

ZIP_PATH = Path("/kaggle/input/YOUR-DATASET/fast_qwen_pipeline_code.zip")
with zipfile.ZipFile(ZIP_PATH) as archive:
    archive.extractall("/kaggle/working")
CODE = Path("/kaggle/working/fast_qwen_pipeline")
sys.path.insert(0, str(CODE))
```

3. Use the [API](API.md) for separate notebook cells, or run the example in a
   terminal where interactive input is supported. Importing the modules does not
   load a model, install packages or generate text.

The code automatically installs the small NVML/wrapt requirements in a local
scratch directory if necessary. It leaves the notebook's Torch environment alone.
The fixed `llama.cpp b11384` CUDA runtime is reused from
`/kaggle/temp/worksite_llm_benchmark_runtime/llama_cpp`. Weights are reused from
`/kaggle/temp/pipe_maintenance_llm_lab/models`. Internet is needed when these files
are missing. Scratch storage is temporary; result files live in `/kaggle/working`.

## Local NVIDIA GPU

Use Python 3.11–3.13 and a compatible native llama.cpp CUDA server. The runtime
must support Qwen3.5, its chat template and the required flags; the tested build
is [b11384](https://github.com/ggml-org/llama.cpp/releases/tag/b11384).

```bash
python -m pip install -r requirements.txt
python run_pipeline.py --server /path/to/llama-server --source approved_reference.txt
```

Windows accepts `--server "C:\tools\llama.cpp\llama-server.exe"`. Use the
matching native CUDA runtime libraries and a compatible NVIDIA driver.
Alternatively set `LLAMA_SERVER` to the executable path.

The fixed model downloads automatically when no local model path is supplied:

```bash
python run_pipeline.py --server /path/to/llama-server --model /path/to/Qwen3.5-9B-Q5_K_M.gguf --source approved_reference.txt
```

The supplied model must match the fixed Q5_K_M checkpoint. Different quants are
not silently treated as the measured model. A download interruption retains its
`.part` file and resumes on retry. Allow at least 6.58 GB for the weight file plus
the download margin and native runtime storage.

## CLI controls

`--instructions` supplies general or detailed guidance. Repeat `--point` for
mandatory coverage, `--sample` for optional style examples and `--source` for
UTF-8 reference files. `--min-words`/`--max-words` set the initial approximate range.
`--context-tokens` and `--max-output-tokens` are token budgets, not word targets.
`--gpu-index` selects a physical GPU; the model is never split across GPUs.

Omit `--quality-feedback` for unlimited interactive rounds. Supplying it runs
one noninteractive feedback round and exits, suitable for scripted use:

```bash
python run_pipeline.py --source approved_reference.txt --quality-feedback "Explain the handover more clearly."
```

Default CPU KV retains the tested conservative configuration. Experimental
`--kv-cache-device gpu` enables GPU KV and operation offload with the same guard.
Its memory use and speed are not promised; measure them before adopting it.
