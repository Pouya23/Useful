# Troubleshooting and validation

## Missing wrapt / ensurepip

This package does not create a venv or call ensurepip. Its automatic dependency
setup supplies wrapt in a local directory and checks fresh Python startup. If
network installation fails, enable Internet, inspect the printed error and the
dependency `installation.log`, then rerun. On local systems you can install
`requirements.txt` yourself and use `install_dependencies=False`.

## No accelerator / incompatible runtime

Automatic Kaggle provisioning requires T4 x2. Enable the accelerator before
starting the session. Outside Kaggle, provide the CUDA server explicitly.
The code checks required native flags, actual GPU layer offload, active context
and native prompt-token accounting; it does not silently fall back to CPU.

## Download interrupted or wrong GGUF

Partial model downloads are retained and resumed, with up to five attempts.
Rerun the session startup after a persistent network failure. Use the exact
Qwen3.5 9B Q5_K_M checkpoint, or omit `model` to fetch it. A different file is
rejected rather than assumed to have the same memory/quality behavior.

## Output truncated / context too small

The partial text is displayed and saved but not accepted. For revisions, increase
`job.max_output_tokens` and submit feedback again. For a failed initial draft,
create a new job. Larger output allowances need remaining context; shorten input
or explicitly increase `context_tokens` when appropriate. Source documents are
never silently truncated. CPU KV uses additional host RAM for longer contexts.

## VRAM guard stops the server

Close the session, inspect its native log and VRAM samples, and release competing
GPU workloads before retrying. The guard covers total device usage, not just the
model. Use the default CPU KV mode first. GPU KV adds memory, and changes in driver,
context, batch or other applications can change peaks. Sampling is not an allocator
cap and cannot prove the absence of shorter transients.

## A word range is still unmet

This is visible model behavior. Submit another feedback round, or use `/done` to
accept the current text explicitly. There is no hidden rewrite loop and no word
or sentence clipping. Quality still requires human review against the references.

## Tests

The included tests need no GPU, network or model files:

```bash
python -m pip install -r tests/requirements.txt
python -m pytest tests -q
```

They exercise unlimited visible rounds, current-text/policy retention, local
length signals, absence of growing prompt history, input validation, failure
retention and native cache options. Packaging verification additionally compiles
every source and runs the CLI from a fresh extraction. Real native CPU drafting
and revision were also exercised; new T4 inference remains to be measured.
