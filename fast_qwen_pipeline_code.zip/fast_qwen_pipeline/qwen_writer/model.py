"""Pinned model provenance, resumable download and checksum validation."""

from __future__ import annotations

import hashlib
import http.client
import shutil
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable

ROOT = Path(__file__).resolve().parent


MODEL = {'id': 'qwen35_9b',
 'title': 'Qwen3.5 9B (Q5_K_M)',
 'repository': 'unsloth/Qwen3.5-9B-GGUF',
 'revision': '3885219b6810b007914f3a7950a8d1b469d598a5',
 'filename': 'Qwen3.5-9B-Q5_K_M.gguf',
 'sha256': 'dc2a39aef291f91a9116ad214058da0d86eb648743a124bd8c333787c4b9c91c',
 'bytes': 6577841376,
 'upstream': 'Qwen/Qwen3.5-9B',
 'architecture': 'qwen35'}


def load_spec(model_id: str) -> dict:
    if model_id != MODEL['id']:
        raise ValueError('This package supports only Qwen3.5 9B Q5_K_M')
    return MODEL.copy()



def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def resolve_model(spec: dict, path: Path | None = None, *, download: bool = False,
                  allow_custom: bool = False, progress: Callable[[str], None] = print) -> tuple[Path, dict]:
    path = (path or ROOT / "models" / spec["filename"]).resolve()
    if not path.exists():
        if not download:
            raise RuntimeError(f"Model file missing: {path}. Supply a valid model path, or omit model to download it automatically.")
        path.parent.mkdir(parents=True, exist_ok=True)
        _download(spec, path, progress)
    if not path.is_file():
        raise RuntimeError(f"Expected a GGUF file: {path}")
    progress(f"Verifying SHA256 of {path.name}")
    checksum = sha256_file(path)
    verified = checksum == spec["sha256"] and path.stat().st_size == spec["bytes"]
    if not verified and not allow_custom:
        raise RuntimeError("Model size/checksum differs from the pinned profile. Use the documented "
                           "Qwen3.5 9B Q5_K_M GGUF.")
    return path, {"profile": spec["id"], "path": str(path), "bytes": path.stat().st_size,
                  "sha256": checksum, "matches_pinned_profile": verified,
                  "repository": spec["repository"] if verified else None,
                  "revision": spec["revision"] if verified else None,
                  "upstream": spec["upstream"] if verified else None,
                  "quant_filename": spec["filename"] if verified else path.name}


def _download(spec: dict, destination: Path, progress: Callable[[str], None]) -> None:
    partial = destination.with_suffix(destination.suffix + ".part")
    expected = spec["bytes"]
    existing = partial.stat().st_size if partial.exists() else 0
    if existing > expected:
        raise RuntimeError(f"Oversized partial download: {partial}; inspect/remove it before retrying.")
    if shutil.disk_usage(destination.parent).free < expected - existing + 512 * 1024 * 1024:
        raise RuntimeError("Insufficient free disk space for the GGUF and a 512 MiB margin")
    url = f"https://huggingface.co/{spec['repository']}/resolve/{spec['revision']}/{spec['filename']}"
    progress(f"Downloading pinned {spec['filename']} ({expected / 1e9:.3f} GB)")
    last_error = None
    for attempt in range(5):
        offset = partial.stat().st_size if partial.exists() else 0
        if offset == expected:
            break
        headers = {"User-Agent": "worksite-writing/1.0", "Accept-Encoding": "identity"}
        if offset:
            headers["Range"] = f"bytes={offset}-"
        try:
            request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(request, timeout=60) as response:
                append = offset > 0 and response.status == 206
                if response.status not in {200, 206}:
                    raise RuntimeError(f"Unexpected download HTTP status {response.status}")
                if response.status == 206:
                    actual_range = response.headers.get("Content-Range", "")
                    if not actual_range.startswith(f"bytes {offset}-") or not actual_range.endswith(f"/{expected}"):
                        raise RuntimeError(f"Unexpected resumed byte range: {actual_range}")
                with partial.open("ab" if append else "wb") as stream:
                    count = offset if append else 0
                    last_update = time.monotonic()
                    while block := response.read(4 * 1024 * 1024):
                        count += len(block)
                        if count > expected:
                            raise RuntimeError("Download exceeds published size; refusing it")
                        stream.write(block)
                        if time.monotonic() - last_update >= 10:
                            progress(f"Model download: {100 * count / expected:.1f}%")
                            last_update = time.monotonic()
            if partial.stat().st_size != expected:
                raise RuntimeError("Download ended before the expected byte count")
            break
        except (OSError, urllib.error.URLError, http.client.IncompleteRead, RuntimeError) as exc:
            last_error = exc
            progress(f"Download interrupted (attempt {attempt + 1}/5); saved bytes will be resumed: {exc}")
            if attempt < 4:
                time.sleep(min(2 ** attempt, 8))
    if not partial.exists() or partial.stat().st_size != expected:
        raise RuntimeError(f"Download incomplete; .part retained for resumption: {last_error}")
    if sha256_file(partial) != spec["sha256"]:
        raise RuntimeError(f"Download SHA256 mismatch; partial file retained for inspection: {partial}")
    # Never replace a file that appeared while this download was in progress.
    if destination.exists():
        raise RuntimeError(f"Destination appeared during download: {destination}")
    partial.rename(destination)
