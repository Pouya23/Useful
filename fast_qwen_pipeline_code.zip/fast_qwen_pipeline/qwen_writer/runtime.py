"""Private local llama.cpp server, conservative VRAM fitting, and sampled guard.

GPU monitoring is reactive: sampled NVML device usage is not an allocator cap,
cannot catch every transient allocation, and includes memory used by other apps.
CPU inference allocates no inference tensors on a GPU. GPU mode defaults to a
CPU KV cache so increasing context mostly consumes host RAM, at a speed cost.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import secrets
import socket
import struct
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO
from urllib import error, request

GB = 1_000_000_000
MIB = 1_048_576
MAX_RESPONSE_BYTES = 16 * MIB
MONITOR_INTERVAL = 0.020


class RuntimeFailure(RuntimeError):
    """The local backend cannot safely satisfy the requested configuration."""


class MemoryBudgetExceeded(RuntimeFailure):
    """Sampled total device memory reached the conservative abort threshold."""


@dataclass(frozen=True)
class RuntimeConfig:
    server: Path
    model: Path
    context_size: int = 32768
    batch_size: int = 256
    ubatch_size: int = 128
    device: str = "cuda"
    gpu_index: int = 0
    vram_limit_gb: float = 10.5
    headroom_gb: float = 1.5
    startup_timeout: float = 240.0
    request_timeout: float = 900.0
    threads: int = 0
    log_path: Path = Path("llama-server.log")
    expected_architecture: str | None = None
    kv_cache_device: str = "cpu"

    def __post_init__(self) -> None:
        for name in ("server", "model", "log_path"):
            object.__setattr__(self, name, Path(getattr(self, name)).expanduser().resolve())
        for name in ("context_size", "batch_size", "ubatch_size"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if self.ubatch_size > self.batch_size:
            raise ValueError("ubatch_size must not exceed batch_size")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("device must be 'cpu' or 'cuda'")
        if self.kv_cache_device not in {"cpu", "gpu"}:
            raise ValueError("kv_cache_device must be 'cpu' or 'gpu'")
        if self.device == "cpu" and self.kv_cache_device == "gpu":
            raise ValueError("CPU inference requires a CPU KV cache")
        for name in ("threads", "gpu_index"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a nonnegative integer")
        for name in ("vram_limit_gb", "headroom_gb", "startup_timeout", "request_timeout"):
            value = getattr(self, name)
            if (isinstance(value, bool) or not isinstance(value, (int, float))
                    or not math.isfinite(value) or value <= 0):
                raise ValueError(f"{name} must be finite and positive")
        if self.vram_limit_gb > 10.5:
            raise ValueError("vram_limit_gb must not exceed the requested 10.5 GB ceiling")
        if self.headroom_gb >= self.vram_limit_gb:
            raise ValueError("headroom_gb must be smaller than vram_limit_gb")


class _GGUFReader:
    """Read only GGUF metadata, without importing tensor libraries."""

    _formats = {0: "B", 1: "b", 2: "H", 3: "h", 4: "I", 5: "i", 6: "f",
                7: "?", 10: "Q", 11: "q", 12: "d"}

    def __init__(self, stream: BinaryIO, size: int) -> None:
        self.stream = stream
        self.bound = min(size, 128 * MIB)

    def read(self, size: int) -> bytes:
        if size < 0 or self.stream.tell() + size > self.bound:
            raise RuntimeFailure("Malformed or excessively large GGUF metadata")
        data = self.stream.read(size)
        if len(data) != size:
            raise RuntimeFailure("Truncated GGUF metadata")
        return data

    def unpack(self, fmt: str) -> Any:
        return struct.unpack("<" + fmt, self.read(struct.calcsize(fmt)))[0]

    def skip(self, size: int) -> None:
        if size < 0 or self.stream.tell() + size > self.bound:
            raise RuntimeFailure("Malformed or excessively large GGUF metadata")
        self.stream.seek(size, 1)

    def string(self, keep: bool = True) -> str | None:
        length = self.unpack("Q")
        if not keep:
            self.skip(length)
            return None
        try:
            return self.read(length).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise RuntimeFailure("GGUF metadata is not valid UTF-8") from exc

    def value(self, kind: int, keep: bool, depth: int = 0) -> Any:
        if depth > 8:
            raise RuntimeFailure("Excessively nested GGUF metadata")
        if kind in self._formats:
            return self.unpack(self._formats[kind])
        if kind == 8:
            return self.string(keep)
        if kind == 9:
            subtype = self.unpack("I")
            count = self.unpack("Q")
            if count > 10_000_000:
                raise RuntimeFailure("Excessively large GGUF metadata array")
            if subtype in self._formats:
                self.skip(count * struct.calcsize(self._formats[subtype]))
            else:
                for _ in range(count):
                    self.value(subtype, False, depth + 1)
            return None
        raise RuntimeFailure(f"Unsupported GGUF metadata type: {kind}")


def inspect_gguf(path: Path) -> dict[str, Any]:
    """Return model identity and context metadata without loading the model."""
    path = Path(path)
    try:
        with path.open("rb") as stream:
            reader = _GGUFReader(stream, path.stat().st_size)
            if reader.read(4) != b"GGUF":
                raise RuntimeFailure(f"Model is not a GGUF file: {path}")
            version = reader.unpack("I")
            if version not in {2, 3}:
                raise RuntimeFailure(f"Unsupported GGUF version {version}; expected 2 or 3")
            tensors = reader.unpack("Q")
            count = reader.unpack("Q")
            if count > 100_000:
                raise RuntimeFailure("Excessively large GGUF metadata table")
            metadata: dict[str, Any] = {}
            has_chat_template = False
            for _ in range(count):
                key = reader.string()
                kind = reader.unpack("I")
                keep = (key in {"general.architecture", "general.name", "general.file_type"}
                        or key.endswith((".context_length", ".block_count")))
                if key == "tokenizer.chat_template" or key.startswith("tokenizer.chat_template."):
                    if kind == 8:
                        has_chat_template = bool(reader.string()) or has_chat_template
                    else:
                        reader.value(kind, False)
                else:
                    value = reader.value(kind, keep)
                    if keep:
                        metadata[key] = value
            architecture = metadata.get("general.architecture")
            return {
                "architecture": architecture,
                "name": metadata.get("general.name"),
                "context_length": metadata.get(f"{architecture}.context_length"),
                "block_count": metadata.get(f"{architecture}.block_count"),
                "file_type": metadata.get("general.file_type"),
                "has_chat_template": has_chat_template,
                "gguf_version": version,
                "tensor_count": tensors,
                "file_bytes": path.stat().st_size,
            }
    except OSError as exc:
        raise RuntimeFailure(f"Cannot inspect GGUF model: {path}: {exc}") from exc


class _DeviceLock:
    def __init__(self, identity: str) -> None:
        digest = hashlib.sha256(identity.encode()).hexdigest()[:24]
        self.path = Path(tempfile.gettempdir()) / f"worksite-llm-gpu-{digest}.lock"
        self.stream: BinaryIO | None = None

    def acquire(self) -> None:
        self.stream = self.path.open("a+b")
        self.stream.seek(0)
        if self.stream.read(1) == b"":
            self.stream.write(b"0")
            self.stream.flush()
        self.stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.stream.close()
            self.stream = None
            raise RuntimeFailure("Another writing pipeline already owns this GPU; run one at a time") from exc

    def release(self) -> None:
        if self.stream is None:
            return
        try:
            self.stream.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(), fcntl.LOCK_UN)
        finally:
            self.stream.close()
            self.stream = None


class LlamaServer:
    """A private, single-slot, authenticated loopback llama-server process."""

    def __init__(self, config: RuntimeConfig) -> None:
        self.config = config
        self._process: subprocess.Popen | None = None
        self._log: BinaryIO | None = None
        self._monitor: threading.Thread | None = None
        self._stop_monitor = threading.Event()
        self._failure: RuntimeFailure | None = None
        self._nvml: Any = None
        self._gpu_handle: Any = None
        self._gpu_lock: _DeviceLock | None = None
        self._gpu_info: dict[str, Any] = {}
        self._sample_lock = threading.Lock()
        self._samples = 0
        self._baseline_bytes = 0
        self._peak_bytes = 0
        self._fit_target_mib: int | None = None
        self._props: dict[str, Any] = {}
        self._metadata: dict[str, Any] = {}
        self._effective_context_size = 0
        self._started = False
        self._closed = False
        self._api_key = secrets.token_urlsafe(32)
        self._port = 0
        self._command: list[str] = []
        self._opener = request.build_opener(request.ProxyHandler({}))

    @property
    def effective_context_size(self) -> int:
        return self._effective_context_size

    @property
    def context_size(self) -> int:
        return self._effective_context_size

    def __enter__(self) -> LlamaServer:
        if self._started or self._closed:
            raise RuntimeFailure("LlamaServer instances may be entered only once")
        self._started = True
        try:
            self._start()
            return self
        except BaseException:
            self.close()
            raise

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.close()
        if exc_type is None:
            self._check_failure()

    @staticmethod
    def _subprocess_options() -> dict[str, Any]:
        if os.name == "nt":
            return {"creationflags": subprocess.CREATE_NO_WINDOW}
        return {"start_new_session": True}

    def _environment(self) -> dict[str, str]:
        env = {key: value for key, value in os.environ.items()
               if not key.upper().startswith(("LLAMA_ARG_", "GGML_", "MTMD_"))}
        env["CUDA_VISIBLE_DEVICES"] = self._gpu_info.get("uuid", "")
        env["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
        # Only the explicitly selected CUDA device may receive inference tensors.
        env["HIP_VISIBLE_DEVICES"] = ""
        env["ROCR_VISIBLE_DEVICES"] = ""
        return env

    def _start_gpu_guard(self) -> None:
        try:
            import pynvml
        except ImportError as exc:
            raise RuntimeFailure("CUDA mode requires nvidia-ml-py; install it or select --device cpu") from exc
        try:
            pynvml.nvmlInit()
            self._nvml = pynvml
            self._gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(self.config.gpu_index)
            uuid = pynvml.nvmlDeviceGetUUID(self._gpu_handle)
            name = pynvml.nvmlDeviceGetName(self._gpu_handle)
            if isinstance(uuid, bytes):
                uuid = uuid.decode("ascii")
            if isinstance(name, bytes):
                name = name.decode("utf-8", errors="replace")
            memory = pynvml.nvmlDeviceGetMemoryInfo(self._gpu_handle)
            if not isinstance(memory.total, int) or memory.total <= 0:
                raise RuntimeFailure("NVML returned invalid device memory capacity")
            self._gpu_info = {"index": self.config.gpu_index, "uuid": uuid,
                              "name": name, "total_bytes": memory.total}
            self._gpu_lock = _DeviceLock(uuid)
            self._gpu_lock.acquire()
            limit = math.floor(self.config.vram_limit_gb * GB)
            reserve = math.ceil(self.config.headroom_gb * GB)
            if memory.total <= reserve:
                raise RuntimeFailure("GPU capacity is smaller than the required reserve; select CPU mode")
            self._fit_target_mib = max(math.ceil(reserve / MIB),
                                       math.ceil((memory.total - limit + reserve) / MIB))
            self._sample_memory()
            self._monitor = threading.Thread(target=self._watch_memory, daemon=True,
                                             name="llama-device-memory-guard")
            self._monitor.start()
        except RuntimeFailure:
            raise
        except Exception as exc:
            raise RuntimeFailure(f"Cannot initialize reliable NVML monitoring: {exc}; select CPU mode") from exc

    def _sample_memory(self) -> None:
        memory = self._nvml.nvmlDeviceGetMemoryInfo(self._gpu_handle)
        used = memory.used
        if (not isinstance(used, int) or used < 0 or used > memory.total
                or memory.total != self._gpu_info["total_bytes"]):
            raise RuntimeFailure("NVML device-memory telemetry became invalid")
        with self._sample_lock:
            if self._samples == 0:
                self._baseline_bytes = used
            self._samples += 1
            self._peak_bytes = max(self._peak_bytes, used)
        threshold = self._abort_threshold_bytes()
        if used >= threshold:
            raise MemoryBudgetExceeded(
                f"Total GPU VRAM is {used / GB:.3f} GB; reached the conservative "
                f"{threshold / GB:.3f} GB abort threshold "
                f"({self.config.vram_limit_gb:g} GB ceiling, {self.config.headroom_gb:g} GB reserve). "
                "Close other GPU workloads, increase CPU offload, or select CPU mode."
            )

    def _abort_threshold_bytes(self) -> int:
        limit = math.floor(self.config.vram_limit_gb * GB)
        capacity = self._gpu_info.get("total_bytes", limit)
        return min(limit, capacity) - math.ceil(self.config.headroom_gb * GB)

    def _watch_memory(self) -> None:
        while not self._stop_monitor.wait(MONITOR_INTERVAL):
            try:
                self._sample_memory()
            except Exception as exc:
                self._failure = exc if isinstance(exc, RuntimeFailure) else RuntimeFailure(
                    f"GPU telemetry failed; stopped inference: {exc}")
                self._kill_process()
                return

    def _check_failure(self) -> None:
        if self._failure is not None:
            raise self._failure

    def _check_live(self) -> None:
        self._check_failure()
        if self._process is None or self._process.poll() is not None:
            code = None if self._process is None else self._process.returncode
            raise RuntimeFailure(f"llama-server is not running (exit {code}); inspect {self.config.log_path}")

    def _available_flags(self, env: dict[str, str]) -> set[str]:
        self._process = subprocess.Popen([str(self.config.server), "--help"], env=env,
                                         stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, **self._subprocess_options())
        try:
            output, _ = self._process.communicate(timeout=30)
        except subprocess.TimeoutExpired as exc:
            self._kill_process()
            raise RuntimeFailure("llama-server --help timed out") from exc
        self._check_failure()
        if self._process.returncode != 0:
            raise RuntimeFailure("llama-server --help failed: " + output[-2000:].decode("utf-8", "replace"))
        self._process = None
        return set(re.findall(r"--[a-z][a-z0-9-]*", output.decode("utf-8", "replace")))

    def _build_command(self, flags: set[str]) -> list[str]:
        cfg = self.config
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.bind(("127.0.0.1", 0))
            self._port = probe.getsockname()[1]
        args = [str(cfg.server), "--model", str(cfg.model), "--ctx-size", str(cfg.context_size),
                "--parallel", "1", "--batch-size", str(cfg.batch_size),
                "--ubatch-size", str(cfg.ubatch_size), "--split-mode", "none",
                "--no-op-offload", "--no-context-shift", "--jinja", "--reasoning", "off",
                "--reasoning-budget", "0", "--reasoning-format", "deepseek",
                "--chat-template-kwargs", '{"enable_thinking":false}',
                "--host", "127.0.0.1", "--port", str(self._port), "--api-key", self._api_key,
                "--no-mmproj", "--cache-type-k", "f16", "--cache-type-v", "f16",
                # b11384 maps library INFO messages (including actual layer
                # offload) to TRACE/4. Default verbosity 3 omits that evidence.
                "--log-verbosity", "4", "--log-colors", "off"]
        if cfg.device == "cuda":
            args += ["--device", "CUDA0", "--gpu-layers", "auto", "--fit", "on",
                     "--fit-target", str(self._fit_target_mib)]
        else:
            args += ["--device", "none", "--gpu-layers", "0", "--fit", "off"]
        args += ["--kv-offload" if cfg.kv_cache_device == "gpu" else "--no-kv-offload"]
        if cfg.threads:
            args += ["--threads", str(cfg.threads)]
        # Do not serve a browser UI or make remote downloads if the build supports these controls.
        for optional in ("--no-webui", "--offline"):
            if optional in flags:
                args.append(optional)
        required = {argument for argument in args[1:] if argument.startswith("--")}
        missing = sorted(required - flags)
        if missing:
            raise RuntimeFailure("llama-server is too old or incompatible; required flags missing: "
                                 + ", ".join(missing))
        return args

    def _start(self) -> None:
        cfg = self.config
        if not cfg.server.is_file():
            raise RuntimeFailure(f"llama-server executable does not exist: {cfg.server}")
        if not cfg.model.is_file():
            raise RuntimeFailure(f"GGUF model does not exist: {cfg.model}")
        self._metadata = inspect_gguf(cfg.model)
        if cfg.expected_architecture and self._metadata["architecture"] != cfg.expected_architecture:
            raise RuntimeFailure(f"Wrong GGUF architecture: expected {cfg.expected_architecture}, "
                                 f"found {self._metadata['architecture']}")
        if not self._metadata["has_chat_template"]:
            raise RuntimeFailure("GGUF lacks a native chat template; use the model's instruct GGUF")
        native_context = self._metadata["context_length"]
        if isinstance(native_context, int) and cfg.context_size > native_context:
            raise RuntimeFailure(f"Requested context {cfg.context_size} exceeds GGUF context {native_context}")
        if cfg.device == "cuda":
            self._start_gpu_guard()
        env = self._environment()
        flags = self._available_flags(env)
        self._command = self._build_command(flags)
        cfg.log_path.parent.mkdir(parents=True, exist_ok=True)
        # Exclusive creation preserves existing user logs rather than truncating them.
        self._log = cfg.log_path.open("xb")
        self._check_failure()
        self._process = subprocess.Popen(self._command, env=env, stdin=subprocess.DEVNULL,
                                         stdout=self._log, stderr=subprocess.STDOUT,
                                         **self._subprocess_options())
        self._check_failure()
        deadline = time.monotonic() + cfg.startup_timeout
        last_error = "server has not accepted connections"
        while time.monotonic() < deadline:
            self._check_live()
            try:
                health = self._request("GET", "/health", None, timeout=2)
                if health.get("status") == "ok":
                    break
            except MemoryBudgetExceeded:
                raise
            except RuntimeFailure as exc:
                self._check_failure()
                last_error = str(exc)
            self._stop_monitor.wait(0.20)
        else:
            raise RuntimeFailure(f"Server startup timed out: {last_error}; inspect {cfg.log_path}")
        self._props = self.get("/props")
        self._validate_props()

    def _validate_props(self) -> None:
        if self._props.get("total_slots") != 1:
            raise RuntimeFailure("Server did not honor the required single inference slot")
        settings = self._props.get("default_generation_settings", {})
        context = settings.get("n_ctx")
        if isinstance(context, bool) or not isinstance(context, int) or context <= 0:
            raise RuntimeFailure("Server did not report an effective context size")
        if context > self.config.context_size:
            raise RuntimeFailure("Server context exceeds the explicitly requested memory budget")
        # A lower context is surfaced to the pipeline; inputs are never silently trimmed.
        self._effective_context_size = context
        if not self._props.get("chat_template"):
            raise RuntimeFailure("Server did not load the GGUF chat template")

    def _request(self, method: str, path: str, payload: dict | None, timeout: float | None = None) -> dict:
        self._check_live()
        if not path.startswith("/") or path.startswith("//") or "://" in path:
            raise ValueError("Only private server endpoint paths are accepted")
        data = None if payload is None else json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
        req = request.Request(f"http://127.0.0.1:{self._port}{path}", data=data, method=method,
                              headers={"Authorization": f"Bearer {self._api_key}",
                                       "Content-Type": "application/json"})
        try:
            with self._opener.open(req, timeout=timeout or self.config.request_timeout) as response:
                raw = response.read(MAX_RESPONSE_BYTES + 1)
                if len(raw) > MAX_RESPONSE_BYTES:
                    raise RuntimeFailure("Local server response exceeds the size limit")
            parsed = json.loads(raw)
            if not isinstance(parsed, dict):
                raise RuntimeFailure("Local server returned an unexpected JSON response shape")
            self._check_live()
            if "error" in parsed:
                raise RuntimeFailure("Local server error: " + str(parsed["error"])[:2000])
            return parsed
        except error.HTTPError as exc:
            self._check_failure()
            detail = exc.read(2048).decode("utf-8", "replace")
            raise RuntimeFailure(f"Local server HTTP {exc.code} at {path}: {detail}") from exc
        except (error.URLError, TimeoutError, OSError, json.JSONDecodeError, UnicodeError) as exc:
            self._check_failure()
            raise RuntimeFailure(f"Local server request failed at {path}: {exc}") from exc

    def get(self, path: str) -> dict:
        return self._request("GET", path, None)

    def post(self, path: str, payload: dict) -> dict:
        return self._request("POST", path, payload)

    def health(self) -> bool:
        return self.get("/health").get("status") == "ok"

    @staticmethod
    def _chat_options() -> dict:
        return {"chat_template_kwargs": {"enable_thinking": False},
                "reasoning_effort": "none", "reasoning_format": "deepseek"}

    def prompt_tokens(self, messages: list[dict]) -> int:
        formatted = self.post("/apply-template", {"messages": messages, **self._chat_options(),
                                                  "add_generation_prompt": True})
        prompt = formatted.get("prompt")
        if not isinstance(prompt, str):
            raise RuntimeFailure("Server cannot apply the model's native chat template")
        tokenized = self.post("/tokenize", {"content": prompt, "add_special": True,
                                            "parse_special": True, "with_pieces": False})
        tokens = tokenized.get("tokens")
        if not isinstance(tokens, list) or not all(type(token) is int and token >= 0 for token in tokens):
            raise RuntimeFailure("Server did not return valid prompt token IDs")
        return len(tokens)

    def complete(self, messages: list[dict], max_tokens: int, temperature: float,
                 top_p: float, top_k: int, seed: int, json_schema: dict | None = None) -> dict:
        if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens < 1:
            raise ValueError("max_tokens must be a positive integer")
        if (isinstance(temperature, bool) or not isinstance(temperature, (int, float))
                or not math.isfinite(temperature) or temperature < 0):
            raise ValueError("temperature must be finite and nonnegative")
        if (isinstance(top_p, bool) or not isinstance(top_p, (int, float))
                or not math.isfinite(top_p) or not 0 < top_p <= 1):
            raise ValueError("top_p must be in (0, 1]")
        if isinstance(top_k, bool) or not isinstance(top_k, int) or top_k < 0:
            raise ValueError("top_k must be a nonnegative integer")
        if isinstance(seed, bool) or not isinstance(seed, int):
            raise ValueError("seed must be an integer")
        prompt_count = self.prompt_tokens(messages)
        if prompt_count + max_tokens + 16 > self.context_size:
            raise RuntimeFailure(f"Prompt ({prompt_count}) + output budget ({max_tokens}) exceeds "
                                 f"effective context ({self.context_size}); reduce input or output budget")
        payload = {"messages": messages, "max_tokens": max_tokens, "stream": False,
                   "temperature": temperature, "top_p": top_p, "top_k": top_k,
                   "min_p": 0.0, "seed": seed, "n": 1, "cache_prompt": False,
                   **self._chat_options()}
        if json_schema is not None:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {"name": "writing_result", "strict": True, "schema": json_schema},
            }
        result = self.post("/v1/chat/completions", payload)
        choices = result.get("choices")
        if not isinstance(choices, list) or len(choices) != 1 or not isinstance(choices[0], dict):
            raise RuntimeFailure("Server did not return exactly one completion")
        choice = choices[0]
        message = choice.get("message", {})
        text = message.get("content") if isinstance(message, dict) else None
        if not isinstance(text, str):
            raise RuntimeFailure("Server did not return assistant text content")
        # Deepseek-format parsing excludes reasoning_content. Fail closed on unparsed thought tags.
        if re.search(r"</?think\b", text, flags=re.IGNORECASE):
            raise RuntimeFailure("Server returned unparsed reasoning tags; refusing to publish the completion")
        reason = choice.get("finish_reason")
        if not isinstance(reason, str):
            raise RuntimeFailure("Server did not return a completion finish reason")
        usage = result.get("usage", {})
        if not isinstance(usage, dict):
            raise RuntimeFailure("Server returned invalid token usage")
        actual_prompt_count = usage.get("prompt_tokens")
        if type(actual_prompt_count) is not int or actual_prompt_count != prompt_count:
            raise RuntimeFailure(f"Native template token admission ({prompt_count}) differs from "
                                 f"actual server prompt usage ({actual_prompt_count}); refusing the completion")
        return {"text": text.strip(), "finish_reason": reason, "usage": usage}

    def report(self) -> dict[str, Any]:
        with self._sample_lock:
            samples, peak = self._samples, self._peak_bytes
        command = list(self._command)
        if "--api-key" in command:
            command[command.index("--api-key") + 1] = "<redacted>"
        return {
            "backend": "local llama.cpp server", "device": self.config.device,
            "gpu": self._gpu_info or None, "kv_cache_device": self.config.kv_cache_device,
            "requested_context_tokens": self.config.context_size,
            "effective_context_tokens": self.context_size,
            "model_metadata": self._metadata, "server_build": self._props.get("build_info"),
            "limit_bytes": math.floor(self.config.vram_limit_gb * GB),
            "headroom_bytes": math.ceil(self.config.headroom_gb * GB),
            "abort_threshold_bytes": self._abort_threshold_bytes(),
            "fit_target_mib": self._fit_target_mib,
            "baseline_device_used_bytes": self._baseline_bytes if samples else None,
            "sampled_peak_device_used_bytes": peak if samples else None,
            "sampled_peak_device_used_gb": peak / GB if samples else None,
            "memory_samples": samples, "sample_interval_seconds": MONITOR_INTERVAL,
            "memory_measurement": "NVML total device usage, including other applications" if samples else None,
            "hard_vram_cap_guaranteed": False,
            "monitor_caveat": "Reactive sampling can miss brief peaks; --fit is a startup estimate, not an allocator cap.",
            "command": command, "log_path": str(self.config.log_path),
            "guard_failure": None if self._failure is None else str(self._failure),
        }

    def _kill_process(self) -> None:
        process = self._process
        if process is not None and process.poll() is None:
            try:
                process.kill()
            except OSError:
                pass

    def close(self) -> None:
        if self._closed:
            return
        self._kill_process()
        if self._process is not None:
            try:
                self._process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._kill_process()
                try:
                    self._process.wait(timeout=10)
                except subprocess.TimeoutExpired as exc:
                    # Do not abandon the monitor or let another writer acquire the GPU.
                    # A later close() can retry once the OS lets the child terminate.
                    raise RuntimeFailure("Cannot confirm llama-server terminated; GPU guard and ownership "
                                         "remain active. Close the server process before another run.") from exc
        self._closed = True
        # The monitor remains active until the subprocess has stopped.
        self._stop_monitor.set()
        if self._monitor is not None:
            self._monitor.join(timeout=2)
        if self._log is not None:
            self._log.close()
        if self._gpu_lock is not None:
            self._gpu_lock.release()
        if self._nvml is not None:
            try:
                self._nvml.nvmlShutdown()
            except Exception:
                pass
