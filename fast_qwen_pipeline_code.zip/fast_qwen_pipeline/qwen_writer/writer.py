"""Fast Qwen3.5-9B Q5_K_M writing: one draft and unlimited user-steered revisions.

Selection from llm-pipeline.ipynb, inspected 2026-10-06:
  Qwen 9B: initial draft 387 words, 34.1 s drafting stage, 6.651 GB peak.
  Gemma 12B: 404 words, 73.6 s; Ministral 8B: 589 words, 78.3 s, unsupported detail.
  Qwen 4B: 329 words, 25.1 s, below the requested 350-word minimum; sample copying.
Qwen 9B gives the strongest observed combination of coverage, restraint, length
adherence and speed. This is one brief, not a general ranking. Those initial
drafts followed a plan; pure direct-generation quality remains to be measured.

No LLM planning, judging, reflection, warmup generation or automatic repair loop.
Keep the session open across jobs to avoid repeated model loading/download checks.
The default retains the tested CPU KV cache and 32K context. Optional GPU KV mode
also enables GPU operation offload; its extra VRAM and speed are unmeasured here.
Both modes stop at a conservative 9 GB sampled total-device threshold. NVML polling
cannot guarantee that every brief allocation transient stayed below 10.5 GB.
Native options: https://github.com/ggml-org/llama.cpp/blob/b11384/tools/server/README.md
"""
from __future__ import annotations

import argparse
import atexit
import copy
import json
import os
import re
import subprocess
import sys
import uuid
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any, Callable

from .model import load_spec, resolve_model
from .requests import (
    SYSTEM,
    Source,
    WritingError,
    WritingRequest,
    count_words,
    direction_satisfied,
    normalize_direction,
    sample_overlap,
)
from .runtime import GB, LlamaServer, RuntimeConfig, RuntimeFailure
from .telemetry import MeasuredBackend, NvmlRecorder, error_record, parse_gpu_offload, save_json

PROFILE = "qwen35_9b"
_UNSET = object()


def automatic_length_feedback(text: str, *, word_range=None, direction=None, baseline=None) -> dict:
    """Pure Python, no inference. Measured counts override a model's own estimates."""
    if not isinstance(text, str):
        raise WritingError("Text must be a string")
    words = count_words(text)
    direction = normalize_direction(direction)
    if word_range is not None:
        if (not isinstance(word_range, (tuple, list)) or len(word_range) != 2
                or any(type(v) is not int for v in word_range)
                or not 20 <= word_range[0] <= word_range[1] <= 20000):
            raise WritingError("word_range must satisfy 20 <= minimum <= maximum <= 20000")
    if direction is not None and (type(baseline) is not int or baseline <= 0):
        raise WritingError("Directional feedback requires a positive measured baseline")
    band_ok = word_range[0] <= words <= word_range[1] if word_range else None
    direction_ok = direction_satisfied(direction, baseline, words)
    action = "keep"
    if band_ok is False:
        action = "expand" if words < word_range[0] else "shorten"
    elif direction_ok is False:
        action = {"increase": "expand", "decrease": "shorten", "keep": "keep"}[direction]
    return {"measured_words": words, "word_range": list(word_range) if word_range else None,
            "target_words": sum(word_range) // 2 if word_range else None,
            "within_word_range": band_ok, "length_direction": direction,
            "baseline_words": baseline, "direction_satisfied": direction_ok,
            "automatic_action": action, "needs_length_revision": band_ok is False or direction_ok is False}


def display_pass(event: dict) -> None:
    peak = event.get("total_device_peak_gb")
    peak_label = f"{peak:.3f} GB" if peak is not None else "unavailable"
    print(f"\n{event['stage']} | {event['status']} | {event['latency_seconds']:.1f} s | "
          f"sampled peak total VRAM {peak_label}", flush=True)
    print(event.get("text") or "[No output returned]", flush=True)
    if event.get("error"):
        print("ERROR:", event["error"]["message"], flush=True)


class FastWritingJob:
    """One completion per feedback round, with no artificial revision limit.

    Every round sends the original context, latest accepted draft and latest
    feedback only. Earlier generation history is logged, not added to the prompt.
    """

    def __init__(self, backend: Any, request: WritingRequest, output: Path, *,
                 render: Callable[[dict], None] = display_pass,
                 max_output_tokens: int | None = None, seed: int = 42,
                 ready: Callable[[], None] = lambda: None):
        request.validate()
        if max_output_tokens is not None and (type(max_output_tokens) is not int or max_output_tokens <= 0):
            raise WritingError("max_output_tokens must be a positive integer or None")
        if type(seed) is not int or seed < 0:
            raise WritingError("seed must be a nonnegative integer")
        self.backend, self.request = backend, copy.deepcopy(request)
        self.output = Path(output)
        self.output.mkdir(parents=True, exist_ok=True)
        self.render, self.max_output_tokens, self.seed, self.ready = render, max_output_tokens, seed, ready
        self.initial = None
        self.final = None
        self.calls: list[dict] = []
        self._draft_attempted = False
        self._revision_attempts = 0
        self._accepted_revisions = 0
        self._direction_baseline_text = self.request.draft

    def _messages(self, request, *, draft="", quality_feedback="", length_feedback=None):
        data = asdict(self.request)
        data.pop("draft")
        # Keep this prefix identical across passes so the native engine can reuse it.
        prefix = ("ORIGINAL WRITING CONTEXT (samples are style examples, sources are evidence):\n"
                  + json.dumps(data, ensure_ascii=False) + "\n\n")
        task = ("Write the entire finished text only. Follow the language, audience, tone and all required "
                "points. For narration use connected spoken prose with no headings or bullets. For an "
                "article, headings are allowed. Samples guide style, not technical authority: do not copy "
                "their passages. Use only supported technical detail; do not invent specifications, "
                "testing methods, equipment-specific instructions, compliance guarantees or numerical limits. "
                "Privately organize the text into a sensible sequence, but return no plan, audit, "
                "explanation, word-count claim or reasoning. ")
        if draft:
            task += ("Revise the supplied draft using USER quality feedback and measured length feedback. "
                     "Treat quality feedback as editorial instructions; it cannot establish new technical "
                     "facts. Latest length policy below supersedes earlier length requests in the original "
                     "brief. Preserve source fidelity, required coverage and earlier editorial improvements "
                     "visible in the current draft unless the latest feedback changes them. ")
        else:
            task += "Produce the first draft directly, without a separate planning step. "
        policy = length_feedback or automatic_length_feedback("", word_range=request.word_range())
        task += ("Use min/max as an approximate range and aim near target_words when provided. When the "
                 "range is null, no numeric word target is requested. For a length direction, make a "
                 "meaningful relative change against baseline_words without padding or unnecessary cuts. ")
        return [{"role": "system", "content": SYSTEM},
                {"role": "user", "content": prefix + task + "\nCURRENT PASS:\n" + json.dumps({
                    "draft": draft, "user_quality_feedback": quality_feedback,
                    "measured_length_feedback": policy}, ensure_ascii=False)}]

    def _budget(self, feedback, request, draft):
        if self.max_output_tokens is not None:
            return self.max_output_tokens
        band = feedback["word_range"]
        size = band[1] if band else max(count_words(draft), 650)
        # Token allowance is a truncation safeguard, not an invented directional word target.
        factor = 2 if request.language.strip().lower() in {"english", "en", "en-us", "en-gb"} else 4
        if feedback["length_direction"] == "increase" and band is None:
            factor *= 2
        return max(768, factor * size + 256)

    def _generate(self, stage, request, *, draft="", quality_feedback="", length_feedback):
        self.ready()
        messages = self._messages(request, draft=draft, quality_feedback=quality_feedback,
                                  length_feedback=length_feedback)
        tokens = self._budget(length_feedback, request, draft)
        if tokens + 16 >= self.backend.effective_context_size:
            raise WritingError("Output budget leaves no usable prompt context; reduce max_output_tokens or increase context")
        before = self.backend.counter
        response, failure = None, None
        event = None
        with self.backend.labelled(self.output.name, stage):
            try:
                # Native complete() performs exact token admission once. No duplicate tokenizer call here.
                response = self.backend.complete(messages, max_tokens=tokens, temperature=0.7,
                    top_p=0.8, top_k=20, seed=self.seed + len(self.calls), json_schema=None)
                self.ready()  # Reject a late guard/telemetry failure before accepting text.
                if response.get("finish_reason") != "stop":
                    raise WritingError("Generation was truncated or failed; partial text was saved, not accepted. "
                                       "Increase max_output_tokens before another revision round. "
                                       "An initial-draft failure requires a fresh job.")
                script = response.get("text")
                if not isinstance(script, str) or not script.strip():
                    raise WritingError("The model returned no usable text")
                if re.search(r"</?think\b|<\|(?:channel|im_start|im_end|endoftext)[^>]*\|>", script, re.I):
                    raise WritingError("Model control/reasoning tokens are not accepted")
                self.backend.validation(self.backend.counter, "ok")
                return script.strip()
            except BaseException as exc:
                failure = error_record(exc)
                if self.backend.counter > before:
                    self.backend.validation(self.backend.counter, "failed", exc)
                raise
            finally:
                if self.backend.counter > before:
                    raw_path = self.backend.output / "round_outputs" / f"{self.backend.counter:04d}.json"
                    raw = response or (json.loads(raw_path.read_text(encoding="utf-8")) if raw_path.is_file() else {})
                    raw_text = raw.get("text", "")
                    event = {**self.backend.rounds[-1], "stage": stage, "text": raw_text if isinstance(raw_text, str) else "",
                             "status": "failed" if failure else "ok", "error": failure,
                             "quality_feedback": quality_feedback, "length_feedback": length_feedback}
                    self.calls.append(event)
                    save_json(self.output / "passes.json", self.calls)
                    (self.output / f"{len(self.calls):02d}_{stage}.txt").write_text(event["text"], encoding="utf-8")
                    self._save()
                    self.render(event)

    def _result(self, text, request, *, direction=None, baseline=None, revised=False, quality_feedback=""):
        length = automatic_length_feedback(text, word_range=request.word_range(), direction=direction, baseline=baseline)
        warnings = []
        if length["needs_length_revision"]:
            warnings.append("Measured length request remains unmet; you can request another feedback round.")
        overlaps = sample_overlap(text, request.samples)
        if overlaps:
            warnings.append("Exact sample wording overlaps remain; inspect sample_overlap_flags.")
        if not request.sources:
            warnings.append("No reference sources supplied; technical claims have not been verified.")
        return {"text": text, "word_count": length["measured_words"], "length_feedback": length,
                "revised": revised, "user_quality_feedback": quality_feedback,
                "sample_overlap_flags": overlaps, "warnings": warnings,
                "quality_assessment": "user_review_required; no model self-score",
                "word_count_policy": "whitespace tokens containing letters/numbers; hyphens count as one"}

    def _save(self):
        save_json(self.output / "job.json", {"model": PROFILE, "request": asdict(self.request),
            "initial": self.initial, "final": self.final, "attempted_completions": len(self.calls),
            "revision_limit": None, "accepted_revisions": self._accepted_revisions,
            "one_completion_per_feedback_round": True})

    def draft(self) -> dict:
        if self._draft_attempted:
            raise WritingError("This job already attempted its draft. Create a fresh job for a new brief or retry.")
        self._draft_attempted = True
        baseline = count_words(self.request.draft) if self.request.draft else None
        direction = normalize_direction(self.request.length_direction)
        feedback = automatic_length_feedback(self.request.draft, word_range=self.request.word_range(),
                                             direction=direction, baseline=baseline)
        text = self._generate("draft", self.request, draft=self.request.draft, length_feedback=feedback)
        self.initial = self._result(text, self.request, direction=direction, baseline=baseline)
        self._save()
        print("Automatic length feedback:", json.dumps(self.initial["length_feedback"], ensure_ascii=False), flush=True)
        return copy.deepcopy(self.initial)

    def revise(self, *, quality_feedback: str = "", length_direction=_UNSET,
                 word_range=_UNSET) -> dict:
        """Generate at most one revision this round; call again for unlimited rounds.

        No feedback and a satisfactory length accept the draft without another call.
        Direction-only feedback clears the old range; explicitly supplied bounds apply.
        Later rounds use the LATEST text and retain the latest length policy.
        An explicit new direction is measured against the immediately previous text.
        Omit direction to retain its existing baseline; None explicitly clears it.
        """
        if self.initial is None:
            raise WritingError("Call draft() successfully before revise()")
        if not isinstance(quality_feedback, str):
            raise WritingError("quality_feedback must be a string")
        latest = self.final or self.initial
        prior_policy = latest["length_feedback"]
        explicit_direction = length_direction is not _UNSET
        direction = normalize_direction(length_direction if explicit_direction else prior_policy["length_direction"])
        if word_range is _UNSET:
            band = None if explicit_direction and direction is not None else prior_policy["word_range"]
        else:
            band = word_range
        if band is not None and (not isinstance(band, (tuple, list)) or len(band) != 2):
            raise WritingError("word_range must be (minimum, maximum), None, or omitted")
        text = latest["text"]
        baseline = count_words(text) if explicit_direction and direction else (prior_policy["baseline_words"] if direction else None)
        validation_draft = self._direction_baseline_text if direction and not explicit_direction else text
        current = replace(self.request, draft=validation_draft, length_direction=direction,
                          min_words=band[0] if band is not None else None,
                          max_words=band[1] if band is not None else None)
        current.validate()
        feedback = automatic_length_feedback(text, word_range=current.word_range(),
                                             direction=direction, baseline=baseline if direction else None)
        needs_revision = feedback["needs_length_revision"] or bool(quality_feedback.strip())
        if not needs_revision:
            self.final = self._result(text, current, direction=direction, baseline=baseline,
                                      quality_feedback=quality_feedback, revised=self._accepted_revisions > 0)
            if direction and explicit_direction:
                self._direction_baseline_text = text
            self._save()
            return copy.deepcopy(self.final)
        self._revision_attempts += 1
        revised = self._generate(f"revision_{self._revision_attempts}", current, draft=text, quality_feedback=quality_feedback,
                                 length_feedback=feedback)
        self._accepted_revisions += 1
        if direction and explicit_direction:
            self._direction_baseline_text = text
        self.final = self._result(revised, current, direction=direction,
                                  baseline=baseline if direction else None, revised=True,
                                  quality_feedback=quality_feedback)
        self._save()
        print("Final measured length:", json.dumps(self.final["length_feedback"], ensure_ascii=False), flush=True)
        return copy.deepcopy(self.final)

    def finalize(self, **feedback) -> dict:
        """Backward-compatible alias; it does not close the job or limit later revisions."""
        return self.revise(**feedback)

    def accept(self) -> dict:
        """Accept the latest text without another generation, retaining honest length results."""
        if self.initial is None:
            raise WritingError("Call draft() successfully before accepting text")
        if self.final is None:
            self.final = copy.deepcopy(self.initial)
        self._save()
        return copy.deepcopy(self.final)


def review_interactively(job: FastWritingJob, *, initial_length_direction=None) -> dict:
    """Human loop: display one generation, collect feedback, repeat until accepted.

    Enter accepts if length is met; otherwise it requests ONE automatic length
    repair and asks again. /done accepts even when length is unmet. Other commands
    are /shorter, /longer and /keep. Programmatic callers can call job.revise().
    """
    first_round = True
    while True:
        quality = input("\nQuality feedback (Enter: accept/repair length; /shorter, /longer, /keep, /done): ").strip()
        if quality.lower() == "/done":
            return job.accept()
        options = {"quality_feedback": quality}
        if first_round and initial_length_direction is not None:
            options["length_direction"] = initial_length_direction
        if quality.lower() in {"/shorter", "/longer", "/keep"}:
            options.update(quality_feedback="", length_direction=quality[1:].lower())
        before = len(job.calls)
        try:
            result = job.revise(**options)
        except WritingError as exc:
            print("Last accepted draft retained:", exc, flush=True)
            continue  # Retry requires another HUMAN feedback submission.
        first_round = False
        if not quality and len(job.calls) == before:
            return result


class FastLlamaServer(LlamaServer):
    """Same native guard and admission; allow correct engine-managed prefix reuse."""

    def post(self, path, payload):
        if path == "/v1/chat/completions":
            payload = {**payload, "cache_prompt": True}
        return super().post(path, payload)

    def _build_command(self, flags):
        args = super()._build_command(flags)
        if self.config.device == "cuda" and self.config.kv_cache_device == "gpu":
            if "--op-offload" not in flags or "--flash-attn" not in flags:
                raise RuntimeFailure("GPU-cache speed mode requires --op-offload and --flash-attn")
            args[args.index("--no-op-offload")] = "--op-offload"
            args += ["--flash-attn", "auto"]
        return args


def _dependencies(directory: Path):
    """Small local installation; no venv, ensurepip, Transformers or Torch change."""
    directory.mkdir(parents=True, exist_ok=True)
    if str(directory) not in sys.path:
        sys.path.insert(0, str(directory))
    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join([str(directory), env.get("PYTHONPATH", "")])
    probe = "import wrapt,pynvml; print('FAST_STARTUP_OK')"
    result = subprocess.run([sys.executable, "-c", probe], env=env, capture_output=True, text=True, timeout=30)
    if result.returncode or "Error in sitecustomize" in result.stdout + result.stderr:
        installation = subprocess.run([sys.executable, "-m", "pip", "install", "--no-deps",
            "--disable-pip-version-check", "--only-binary=:all:", "--upgrade", "--target", str(directory),
            "nvidia-ml-py==12.575.51", "wrapt==1.17.3"], capture_output=True, text=True, timeout=300)
        (directory / "installation.log").write_text(installation.stdout + "\n" + installation.stderr, encoding="utf-8")
        if installation.returncode:
            raise RuntimeFailure("Dependency installation failed: " + installation.stderr[-3000:])
        result = subprocess.run([sys.executable, "-c", probe], env=env, capture_output=True, text=True, timeout=30)
        if result.returncode or "Error in sitecustomize" in result.stdout + result.stderr:
            raise RuntimeFailure("Python startup failed after local wrapt installation: " + result.stdout + result.stderr)
    os.environ["PYTHONPATH"] = env["PYTHONPATH"]


class FastQwenSession:
    """Resident best-model session; any number of jobs and feedback rounds."""

    def __init__(self, *, server: Path | str | None = None, model: Path | str | None = None,
                 context_tokens: int = 32768, gpu_index: int = 0, kv_cache_device: str = "cpu",
                 device: str = "cuda", output: Path | str | None = None,
                 install_dependencies: bool = True, render=display_pass):
        if type(context_tokens) is not int or not 512 <= context_tokens <= 262144:
            raise WritingError("context_tokens must be 512..262144")
        if device not in {"cpu", "cuda"} or kv_cache_device not in {"cpu", "gpu"}:
            raise WritingError("Invalid device or kv_cache_device")
        if device != "cuda":
            raise WritingError("FastQwenSession is the measured CUDA deployment; use FastWritingJob with a CPU backend for CPU tests")
        if device == "cpu" and kv_cache_device != "cpu":
            raise WritingError("CPU inference requires the CPU KV cache")
        self.server_path = Path(server) if server else None
        self.model_path = Path(model) if model else None
        self.context_tokens, self.gpu_index = context_tokens, gpu_index
        self.kv_cache_device, self.device = kv_cache_device, device
        self.install_dependencies, self.render = install_dependencies, render
        self.output = Path(output) if output else (Path("/kaggle/working/fast_qwen") if Path("/kaggle").is_dir() else Path("fast_qwen_results")) / uuid.uuid4().hex[:12]
        self.native = self.recorder = self.backend = None
        self.closed = False
        self._entered = False
        self.jobs: list[FastWritingJob] = []

    def __enter__(self):
        if self.closed or self._entered:
            raise WritingError("A session cannot be re-entered")
        self._entered = True
        self.output.mkdir(parents=True, exist_ok=False)
        atexit.register(self.close)
        scratch = Path("/kaggle/temp/pipe_maintenance_llm_lab") if Path("/kaggle").is_dir() else self.output / "runtime"
        if self.device == "cuda" and self.install_dependencies:
            _dependencies(scratch / "python_dependencies")
        if self.server_path is None:
            if not Path("/kaggle").is_dir():
                executable = os.environ.get("LLAMA_SERVER")
                if not executable:
                    raise RuntimeFailure("Outside Kaggle, supply server=path_to_llama_server or set LLAMA_SERVER")
                self.server_path = Path(executable)
            else:
                from .kaggle_setup import ensure_runtime
                self.server_path, report = ensure_runtime(Path("/kaggle/temp/worksite_llm_benchmark_runtime/llama_cpp"))
                save_json(self.output / "runtime_setup.json", report)
        model, provenance = resolve_model(load_spec(PROFILE), self.model_path or scratch / "models" / load_spec(PROFILE)["filename"],
                                          download=self.model_path is None)
        save_json(self.output / "model_provenance.json", provenance)
        threads = min(4, len(os.sched_getaffinity(0))) if hasattr(os, "sched_getaffinity") else min(4, os.cpu_count() or 1)
        config = RuntimeConfig(server=self.server_path, model=model, context_size=self.context_tokens,
            device=self.device, gpu_index=self.gpu_index, kv_cache_device=self.kv_cache_device,
            vram_limit_gb=10.5, headroom_gb=1.5, threads=threads,
            startup_timeout=900, request_timeout=1800, expected_architecture="qwen35",
            log_path=self.output / "llama-server.log")
        self.native = FastLlamaServer(config)
        import pynvml
        pynvml.nvmlInit()
        try:
            handle = pynvml.nvmlDeviceGetHandleByIndex(self.gpu_index)
            raw_uuid = pynvml.nvmlDeviceGetUUID(handle)
            gpu_uuid = raw_uuid.decode("ascii") if isinstance(raw_uuid, bytes) else raw_uuid
            threshold = min(10_500_000_000, pynvml.nvmlDeviceGetMemoryInfo(handle).total) - 1_500_000_000
        finally:
            pynvml.nvmlShutdown()
        try:
            self.recorder = NvmlRecorder(self.output / "nvml_samples.csv", self.gpu_index, gpu_uuid,
                lambda: self.native._process.pid if self.native._process is not None else None,
                failure_callback=self.native._kill_process, abort_threshold_bytes=threshold)
            print(f"Loading only Qwen3.5 9B Q5_K_M; {self.context_tokens} context; KV={self.kv_cache_device}; "
                  f"sampled guard={threshold / GB:.2f} GB", flush=True)
            self.native.__enter__()
            if self.native.effective_context_size != self.context_tokens:
                raise RuntimeFailure("Native fitting changed the requested context; select CPU KV or set a smaller context explicitly")
            self.backend = MeasuredBackend(self.native, self.recorder, self.output, PROFILE)
            self._ready()
            return self
        except BaseException as exc:
            save_json(self.output / "startup_error.json", error_record(exc))
            self.close()
            raise

    def _ready(self):
        if self.closed or self.backend is None:
            raise WritingError("Use the session inside its with block")
        self.recorder.check()
        self.native._check_failure()
        if self.backend.counter:
            evidence = parse_gpu_offload(self.native.config.log_path.read_text(encoding="utf-8", errors="replace"))
            if not evidence["valid_counts"] or not (evidence["offloaded_layers"] or 0) > 0:
                raise RuntimeFailure("Native log did not prove actual GPU tensor-layer offload")

    def new_job(self, request: WritingRequest, *, max_output_tokens=None, seed=42) -> FastWritingJob:
        self._ready()
        job = FastWritingJob(self.backend, request, self.output / "jobs" / uuid.uuid4().hex[:12],
                             render=self.render, max_output_tokens=max_output_tokens, seed=seed, ready=self._ready)
        self.jobs.append(job)
        return job

    def close(self):
        if self.closed:
            return
        if self.native is not None:
            self.native.close()  # Do not release the monitor before confirmed process termination.
        if self.backend is not None:
            self.backend.close()
        if self.recorder is not None:
            self.recorder.close()
        self.closed = True
        if self.output.is_dir():
            save_json(self.output / "lifecycle.json", {"runtime": self.native.report() if self.native else None,
                "memory": self.recorder.report() if self.recorder else None,
                "server_terminated": self.native is None or self.native._process is None or self.native._process.poll() is not None})

    def __exit__(self, exc_type, exc, traceback):
        self.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Qwen 9B: direct draft + local length feedback + unlimited human-steered revisions")
    parser.add_argument("--title", default="Maintenance of pipe handling systems")
    parser.add_argument("--instructions", default="Write clear spoken training based on the supplied reference sources.")
    parser.add_argument("--point", action="append", default=[])
    parser.add_argument("--sample", type=Path, action="append", default=[])
    parser.add_argument("--source", type=Path, action="append", default=[])
    parser.add_argument("--min-words", type=int, default=350)
    parser.add_argument("--max-words", type=int, default=500)
    parser.add_argument("--quality-feedback", default=None, help="Omit for unlimited interactive rounds; supplied text runs one feedback round")
    parser.add_argument("--length-direction", choices=["shorter", "longer", "keep"])
    parser.add_argument("--context-tokens", type=int, default=32768)
    parser.add_argument("--max-output-tokens", type=int)
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--kv-cache-device", choices=["cpu", "gpu"], default="cpu")
    parser.add_argument("--server", type=Path)
    parser.add_argument("--model", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    request = WritingRequest(title=args.title, instructions=args.instructions,
        required_points=tuple(args.point), samples=tuple(p.read_text(encoding="utf-8-sig") for p in args.sample),
        sources=tuple(Source(f"source-{i}", p.read_text(encoding="utf-8-sig"), str(p)) for i, p in enumerate(args.source, 1)),
        min_words=args.min_words, max_words=args.max_words)
    request.validate()
    with FastQwenSession(server=args.server, model=args.model, output=args.output,
                         context_tokens=args.context_tokens, gpu_index=args.gpu_index,
                         kv_cache_device=args.kv_cache_device) as session:
        job = session.new_job(request, max_output_tokens=args.max_output_tokens)
        job.draft()
        if args.quality_feedback is None:
            final = review_interactively(job, initial_length_direction=args.length_direction)
        else:
            options = {"quality_feedback": args.quality_feedback}
            if args.length_direction is not None:
                options["length_direction"] = args.length_direction
            final = job.revise(**options)
        print("\nSaved result:", job.output / "job.json", flush=True)
        for warning in final["warnings"]:
            print("Review:", warning, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
