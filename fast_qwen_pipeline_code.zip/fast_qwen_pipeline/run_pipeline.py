"""CLI entry point. See README.md for setup and examples."""
from qwen_writer.writer import main

if __name__ == "__main__":
    raise SystemExit(main())
