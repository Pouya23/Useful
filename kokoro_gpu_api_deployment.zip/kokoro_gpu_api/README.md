# Kokoro GPU API: start here

This ZIP contains a complete Flask service derived from your `kokoro_fit_duration.py`, plus Docker configuration, Swagger documentation, tests, example requests, and the original scripts for comparison. **A GPU container has not been started:** the GPU server is still unknown. Your current computer reports Intel Iris Xe graphics and a stopped Docker engine. Fill in the marked blanks below when your server/backend team answers.

## 1. What this system does

- **Flask** receives HTTP requests and returns JSON: this is the API implementation.
- **Swagger UI** is the web page at `/docs/`. It describes the API and lets you click “Try it out” to send requests. It is not another model or backend you need to develop.
- **Waitress** runs Flask as a server. You start `run_server.py`, not Flask's development/debug server.
- **Docker** runs Python, Kokoro, FFmpeg, and the API together on the GPU machine.
- **SQLite and the data volume** retain requests, plans, job status, completed MP3 files, and measured timing history.

One persistent Kokoro model is loaded. One background worker generates speech on the selected GPU. Model forwards are serialized to avoid concurrent GPU allocations; estimation may wait for a current chunk to release the model lock. Up to 32 jobs are pending by default. This service is separate from the older narration project.

```mermaid
flowchart LR
    Backend -->|POST /estimate| Plan[Duration predictor and tempo check]
    Backend -->|POST /generate| Plan
    Plan -->|accepted generation only| Queue[(Saved jobs and plans)]
    Queue --> Worker[GPU waveform generation]
    Worker --> FFmpeg[Tempo fitting and MP3 export]
    FFmpeg --> Result[(Completed MP3 and measured durations)]
    Backend -->|GET or POST /progress| Status[Job status and ETA]
    Queue --> Status
    Result --> Status
```

## 2. Ask these questions, and fill these blanks

You do not need to choose a cloud provider or guess an IP address. Send this table to the people responsible for the GPU server and backend.

| Information needed | Fill in the answer | Who to ask |
|---|---|---|
| GPU server IP address or hostname | **________________** | Server administrator |
| SSH alias/login method, or how they want you to upload this ZIP | **________________** | Server administrator; keep credentials outside this document |
| Does the server have an NVIDIA GPU and a working `nvidia-smi`? | **________________** | Server administrator |
| Which GPU index should we reserve? | **________________** | Server administrator; default configuration selects 0 |
| Are Docker, Docker Compose, and NVIDIA Container Toolkit ready? | **________________** | Server administrator |
| Is Internet available for building the image and first model download? | **________________** | Server administrator |
| Does the backend run on the same server or a different server? | **________________** | Backend team |
| Backend server IP/hostname, if different | **________________** | Backend team |
| Is port 8080 acceptable and reachable from the backend? | **________________** | Both teams |
| Does the backend accept the supplied request/response schema? | **________________** | Backend team; send `openapi.json` or the `/docs/` link |
| Do they require an API key? If so, how should it be provided? | **________________** | Backend team |

**Port and endpoint alone work only when both teams already agree on the JSON contract and the server is reachable.** The original backend contract was not provided, so this package defines one clearly; the backend team must confirm it or supply its existing schema. Do not assume an arbitrary API with the same path names is compatible.

## 3. Server prerequisites

Ask the server administrator to make these checks pass on the intended NVIDIA GPU host:

```bash
nvidia-smi
docker version
docker compose version
```

Docker GPU access also needs NVIDIA Container Toolkit. Its official [installation guide](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html) explains configuring the Docker runtime. The administrator should handle any driver/runtime installation or daemon restart, especially on a shared server. GPU reservations in this package follow the [Docker Compose GPU documentation](https://docs.docker.com/compose/how-tos/gpu-support/).

The container targets Linux x86_64 with an NVIDIA GPU. The image uses Python 3.11 and CUDA-enabled PyTorch 2.5.1/cu121. Building dependencies needs Internet and several GB of disk/download space. First startup downloads the pinned Kokoro checkpoint and English voice packs. Model weights are not embedded in this code ZIP; the downloader and exact revision are included. Downloads persist in a Docker volume.

The configured GPU memory target is **5 decimal GB**, with 768 MB reserved outside PyTorch's allocator allowance. This is an allocator limit and reported PyTorch peaks, not certification of an instantaneous whole-process 5 GB ceiling. Test the completed deployment on the actual GPU before relying on its resource usage. GPU mode fails if CUDA is unavailable; it does not silently switch to CPU.

## 4. Upload, configure, and start

Upload and extract this ZIP on the GPU server, then open a terminal in the extracted `kokoro_gpu_api` folder. Your administrator can do the upload/extraction if you do not have SSH access yet.

Copy the environment template:

```bash
cp .env.example .env
nano .env
```

Fill the empty information fields using your team's answers. The selected defaults are:

```dotenv
API_PORT=8080
BIND_ADDRESS=127.0.0.1
GPU_DEVICE_ID=0
MAX_VRAM_GB=5
CPU_THREADS=4
MAX_PENDING_JOBS=32
API_KEY=
GPU_SERVER_ADDRESS=
GPU_SERVER_SSH_ALIAS=
BACKEND_SERVER_ADDRESS=
BACKEND_CONTRACT_CONFIRMED=
```

- `GPU_SERVER_ADDRESS` and the other blank handoff fields are records for you; they do not magically create a server or configure SSH.
- If the backend is on the **same machine**, keep `BIND_ADDRESS=127.0.0.1`.
- If the backend is on a **different machine**, ask the administrator to configure reachability, then set `BIND_ADDRESS=0.0.0.0` or the server's agreed interface IP. Keep the port reachable only through the team's agreed network/access controls.
- `GPU_DEVICE_ID=0` selects physical GPU 0. Use the index the administrator supplies. The container then uses logical `cuda:0`.
- `API_PORT` is the host-facing port. Internal container port 8000 is already configured; do not change it independently.
- Leave `API_KEY` empty only if the team agrees to an unauthenticated private endpoint. If set, the backend must send `X-API-Key` and Swagger's “Authorize” button accepts it.

Start the service:

```bash
bash start_gpu.sh
docker compose logs -f api
```

The script checks the host GPU, builds the image, verifies CUDA inside that image, and starts the service. It does not install GPU drivers. Wait for the log line `Ready on 0.0.0.0:8000`. The model download and first initialization happen before readiness. Press **Ctrl+C** to leave the log view; the detached container keeps running.

Check it:

```bash
curl http://127.0.0.1:8080/health
docker compose ps
```

Health should report `ready:true`, `device:"cuda:0"`, and a live generation worker. `docker compose exec api nvidia-smi` shows container GPU visibility. On the same server, Swagger is `http://127.0.0.1:8080/docs/`. From another machine, use the actual GPU server address instead of `127.0.0.1`, after network access is configured. Never give the backend `0.0.0.0` as its destination address.

If the service should remain bound to the server's localhost, your administrator can give you an SSH alias for a tunnel. On your Windows computer, run `ssh -L 8080:127.0.0.1:8080 YOUR_SSH_ALIAS`, keep that terminal open, then open `http://127.0.0.1:8080/docs/` locally. Replace the alias with the supplied value; this forwards your local browser to the server without changing its API binding.

## 5. Exactly what to give the backend team

Fill this handoff card and send it with `openapi.json`:

```text
GPU server address: ________________________________
External port: 8080 (or the agreed replacement: ______)
Base URL: http://________________________:__________
Swagger URL: BASE_URL/docs/
OpenAPI schema: BASE_URL/openapi.json

POST /estimate       JSON specifications -> fit decision and duration preview
POST /generate       Same JSON + generate:true -> accepted job_id
GET  /progress?job_id=JOB_ID -> status, estimated remaining seconds, progress percent
POST /progress       {"job_id":"JOB_ID"} -> same JSON status
GET  /progress?job_id=JOB_ID&download=true -> completed MP3

API-key header required? __________
Request/response contract confirmed by: __________
```

There are **three functional endpoint paths**. `/health`, `/docs/`, and `/openapi.json` are operational/documentation routes. Download uses `/progress`, so no fourth functional path is necessary.

## 6. Test from Swagger: no programming required

1. Open `/docs/` in a browser. If `API_KEY` is enabled, click **Authorize** first.
2. Expand **POST /estimate**, click **Try it out**, and paste `examples/estimate.json`. Click **Execute**.
3. A fit success returns HTTP 200, `success:true`, natural duration, the required `atempo_factor`, and estimated final seconds. A valid request outside the permitted tempo range returns HTTP 422 with `reason:"too_short"` or `"too_long"`; it generates no speech and creates no job.
4. Expand **POST /generate**. Paste `examples/generate.json`, including `"generate":true`. A new accepted job returns HTTP **202** and `job_id`.
5. Copy that `job_id` into **POST /progress**. Execute repeatedly until `status:"completed"`. The returned `result.audio_url` points to the MP3; prepend the same base URL if opening it from another client.

The example uses a wider tempo range (0.5–2.0) for an easy smoke test. Production defaults are 0.93–1.15 when those fields are omitted. Use the range agreed for your narration quality; changing the range does not change the fit algorithm.

Equivalent terminal commands:

```bash
curl -X POST http://127.0.0.1:8080/estimate -H 'Content-Type: application/json' --data @examples/estimate.json
curl -X POST http://127.0.0.1:8080/generate -H 'Content-Type: application/json' --data @examples/generate.json
curl 'http://127.0.0.1:8080/progress?job_id=PASTE_JOB_ID_HERE'
curl 'http://127.0.0.1:8080/progress?job_id=PASTE_JOB_ID_HERE&download=true' -o my_speech.mp3
```

If using an API key, add `-H 'X-API-Key:YOUR_KEY'` to each functional request. A Python convenience client is also included: `python demo_client.py --base-url http://ACTUAL_SERVER_ADDRESS:8080` estimates, submits, displays a progress bar, and downloads the MP3. It requires the `requests` package.

## 7. Generation fields

| JSON field | Default / accepted values | Effect |
|---|---|---|
| `text` | Required; 10–500 whitespace-delimited words, <=40,000 characters | Complete text sent to the English frontend |
| `voice` | `am_onyx`; installed American/British `.pt` preset ID | Speaker embedding; no arbitrary WAV cloning or path upload |
| `lang_code` | `a` or `b`; default `a` | American/British pronunciation. Must match the voice prefix |
| `speed` | 1.0; 0.25–4.0 | Native Kokoro duration scaling, before FFmpeg |
| `desired_duration` | Required, positive, <=1800 seconds | Requested final tempo-fit target |
| `atempo_min`, `atempo_max` | 0.93 / 1.15; each 0.125–8.0, min<=max | Allowed inclusive range for natural seconds / target seconds |
| `split_pattern` | `"\\n+"` or null | Split input at newlines or disable explicit newline splitting; Kokoro's context splitting and the server's 20s chunk guard still apply. Arbitrary regexes are not accepted |
| `seed` | 42; integer 0..2^32−1 | Reproducible decoder noise under the same runtime/config; duration plan is deterministic |
| `sample_rate` | 48000; MP3-supported 8000/11025/12000/16000/22050/24000/32000/44100/48000 | Export sample rate; native Kokoro synthesis remains 24 kHz |
| `bitrate_kbps` | 320; 64/96/128/160/192/224/256/320 | MP3 storage bitrate. Rates below 32 kHz require <=160 kbps |
| `generate` | Required boolean true on `/generate` only | Explicitly requests a generation job; omit on `/estimate` |

`/health` and the Swagger schema list the actually installed voices. The downloader obtains all English presets from the pinned Kokoro-82M v1.0 repository. Compatible local voice packs must be installed administratively before restarting; an HTTP request cannot read arbitrary server files.

The API accepts underscore names, not CLI `--flags` or camelCase guesses. Unknown fields fail validation. If the existing backend uses other names, send its schema so the API can be adapted explicitly.

## 8. What the estimates mean

### Speech length

`/estimate` runs G2P, text encodings, and Kokoro's **duration predictor**. It stores integer durations/encodings; it does not invoke the waveform decoder or FFmpeg. Each duration unit corresponds to 600 samples at 24 kHz. The generation worker reuses the cached plan and checks that actual natural PCM sample count agrees.

```text
natural_seconds = planned_native_samples / 24000
required_atempo = natural_seconds / desired_duration
accept when atempo_min <= required_atempo <= atempo_max
estimated_final_seconds = natural_seconds / required_atempo
```

The final expression is the **requested target**, not a measurement. FFmpeg `atempo` can have content-dependent buffering/length effects, and MP3 adds encoder/container timing. Consequently `estimated_final_duration_s` is **not a universal <1% or sample-exact guarantee**. The service does not silently crop speech, add a forced silence tail, or time-stretch a completed file again to hide this. `result.actual_final_duration_s` and `duration_error_percent` are measured independently with ffprobe after encoding; the latter compares container duration to the requested target.

`natural_duration_is_sample_exact:true` refers to the frozen Kokoro PCM plan. `final_duration_is_sample_exact:false` refers to the exported MP3. Exact natural length does not establish intelligibility or perfect word completeness. FFmpeg stage factors are chained within 0.5–2.0, as supported by the [atempo filter](https://ffmpeg.org/ffmpeg-filters.html#atempo).

### Generation time and progress

Generation time is different from speech duration. A 60-second clip can take much less than 60 seconds to synthesize on a GPU.

Initially the service uses your supplied helper's rough **0.024 GPU real-time factor plus 1.5s encoding overhead**. This is marked `uncalibrated_default`, not claimed accurate on an unknown GPU. After completed jobs, it uses the median measured synthesis real-time factor and median encoding time from up to 64 jobs on the same model/runtime/hardware profile. During a job, completed chunks refine its remaining-time estimate.

```text
estimated_runtime = estimated_synthesis_time + estimated_encoding_time
running_progress = min(99, 100 * elapsed_running_time / estimated_runtime)
```

Progress is kept monotonic even when the ETA changes. It becomes 100 only after successful MP3 creation. Queued jobs show 0%; their remaining time includes estimated jobs ahead. `eta_overrun:true` means the current estimate has elapsed but work is still running: remaining 0 is a forecast overrun, not completion. Always use `status`, not percentage/ETA alone. Failed jobs return an error and are never presented as successful completion.

Model downloads/loading and `/estimate` admission time are separate from the reported generation runtime. Estimation is warmed/cached where possible, but not promised instantly for every text or under GPU contention.

## 9. Storage, restarts, and operations

Completed files and job records persist in `kokoro-jobs`; weights persist in `kokoro-models`. Stopping/restarting the service keeps both volumes. Queued plans resume after restart. A job interrupted while running is marked failed, so the backend can deliberately resubmit it. Model/source signatures are checked before reusing queued plans.

```bash
docker compose logs -f api
docker compose restart api
docker compose down
```

Do **not** add `-v` to `docker compose down` if you want to retain model downloads and completed audio. The service retains jobs/audio until the team implements its agreed storage-retention policy; monitor disk space. Only one process should use a data volume/GPU; do not scale the API service or enable Flask's reload/debug mode.

For retry-safe submissions, the backend may send `Idempotency-Key: client-request-123` to `/generate`. The same key/specification returns the same job ID. Reusing a key with different specifications returns HTTP 409. A full queue returns HTTP 503 and `Retry-After:10`.

## 10. Files and validation

- `app.py`: Flask routes and Swagger registration.
- `contracts.py`: input validation and environment controls.
- `kokoro_fit_core.py`: frozen duration planning, native synthesis, tempo range evaluation, FFmpeg MP3 export.
- `jobs.py`: SQLite records, worker queue, idempotency, restart recovery, ETA.
- `run_server.py`: production startup with Waitress.
- `download_models.py`: pinned weights/voice downloader with recorded SHA256 hashes.
- `Dockerfile`, `compose.yaml`, `start_gpu.sh`, `.env.example`: GPU deployment.
- `openapi.json`, `examples/`, `demo_client.py`: backend handoff and hands-on testing.
- `original_scripts/`: unmodified supplied CLI/core/grid scripts and their hashes; your original files are untouched.
- `tests/`: model-free API/lifecycle tests; these use clearly identified fixtures.
- `verification/`: actual CPU speech checks and deployment-validation limitations. CPU testing is not GPU certification; Docker build/start must be checked on the chosen host.

The checkpoint/source are pinned to [Kokoro's source](https://github.com/hexgrad/kokoro/tree/dfb907a02bba8152ca444717ca5d78747ccb4bec) and [model revision](https://huggingface.co/hexgrad/Kokoro-82M/tree/f3ff3571791e39611d31c381e3a41a3af07b4987). Full checkpoint access is retained; only source/runtime code is included in this ZIP, with automatic model retrieval.

To run tests in a configured Python environment:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q tests
```

The exact final deployment status is recorded in `verification/validation.json`. Fill the unknown host/network/contract fields, ask the administrator to start the container, and have the backend team confirm the Swagger contract. These are the remaining external steps.
