"""Validate the delivery evidence and package only explicit release files."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

from openapi_spec_validator import validate

from contracts import FitPreview, GenerationAccepted, JobProgress


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-source-dir", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    schema = json.loads((root / "openapi.json").read_text(encoding="utf-8"))
    validate(schema)
    assert set(schema["paths"]) == {"/estimate", "/generate", "/progress"}
    for path in root.glob("*.py"):
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    original_hashes = {}
    for path in (root / "original_scripts").glob("*.py"):
        if args.original_source_dir:
            assert path.read_bytes() == (args.original_source_dir / path.name).read_bytes()
        original_hashes[path.name] = digest(path)
    assert len(original_hashes) == 3
    (root / "original_scripts" / "source_hashes.json").write_text(json.dumps(original_hashes, indent=2) + "\n", encoding="utf-8")
    speech = json.loads((root / "verification" / "real_cpu_output" / "real_cpu_report.json").read_text())
    http = json.loads((root / "verification" / "http_output" / "http_report.json").read_text())
    assert speech["device"] == "cpu" and speech["runtime_profile"].startswith("cpu:2.5.1+cpu")
    assert [case["word_count"] for case in speech["cases"]] == [10, 100, 500]
    cases = []
    for case in speech["cases"]:
        FitPreview.model_validate(case["estimate"])
        JobProgress.model_validate(case["completed_job"])
        result = case["completed_job"]["result"]
        assert case["waveform_decoder_calls_during_estimate"] == 0
        assert result["actual_natural_duration_s"] == case["estimate"]["estimated_natural_duration_s"]
        assert case["completed_job"]["status"] == "completed"
        cases.append({"words": case["word_count"], "natural_duration_error_percent": 0,
                      "final_mp3_target_error_percent": result["duration_error_percent"],
                      "waveform_decoder_calls_during_estimate": 0})
    FitPreview.model_validate(http["estimate"])
    GenerationAccepted.model_validate(http["generation_admission"])
    JobProgress.model_validate(http["completed_progress"])
    assert http["completed_progress"]["status"] == "completed" and http["download_bytes"] > 0
    script = root / "start_gpu.sh"
    script.write_bytes(script.read_bytes().replace(b"\r\n", b"\n"))
    validation = {
        "api_framework": "Flask", "http_server": "Waitress", "swagger_ui": "/docs/",
        "functional_paths": ["/estimate", "/generate", "/progress"],
        "chosen_host_port": 8080, "container_port": 8000,
        "gpu_server_address": "", "backend_contract_confirmed": "",
        "container_started": False,
        "deployment_limitation": "GPU host is intentionally unspecified. Local Docker daemon is stopped and the visible local adapter is Intel Iris Xe. No GPU container build/start or GPU-memory certification is claimed.",
        "model_free_regression_tests": {"passed": 33, "failed": 0},
        "ruff": "passed", "compose_syntax": "passed", "openapi_schema": "valid 3.1.0",
        "pinned_torch_cpu_model_validation": cases,
        "actual_waitress_http_workflow": "passed on loopback using real CPU Kokoro; server stopped afterward",
        "gpu_inference_verified": False,
        "final_mp3_duration_guarantee": "Approximate target; observed errors are not a universal <1% guarantee.",
        "original_sources_sha256": original_hashes,
    }
    (root / "verification" / "validation.json").write_text(json.dumps(validation, indent=2) + "\n", encoding="utf-8")
    include = []
    for path in root.iterdir():
        if path.is_file() and (path.suffix in {".py", ".txt", ".md", ".json", ".toml", ".yaml", ".sh"}
                              or path.name in {"Dockerfile", ".dockerignore", ".env.example"}):
            include.append(path)
    for folder in ("examples", "tests", "original_scripts"):
        include.extend(path for path in (root / folder).rglob("*") if path.is_file()
                       and path.suffix in {".py", ".json", ".txt"} and "__pycache__" not in path.parts)
    include.extend(path for path in (root / "verification").glob("*") if path.is_file() and path.suffix in {".py", ".json"})
    for folder in ("real_cpu_output", "http_output"):
        include.extend(path for path in (root / "verification" / folder).glob("*") if path.is_file()
                       and path.suffix in {".json", ".mp3", ".log"})
    include = sorted(set(include))
    assert not any(".verification_runtime" in path.parts or ".env" == path.name or "data" in path.relative_to(root).parts for path in include)
    manifest = {str(path.relative_to(root)).replace("\\", "/"): {"sha256": digest(path), "bytes": path.stat().st_size}
                for path in include}
    manifest_path = root / "release_manifest.json"
    manifest.pop("release_manifest.json", None)
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    if manifest_path not in include:
        include.append(manifest_path)
    archive = root.parent / "kokoro_gpu_api_deployment.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
        for path in include:
            relative = Path(root.name) / path.relative_to(root)
            zipped.write(path, str(relative).replace("\\", "/"))
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        for name, record in manifest.items():
            assert hashlib.sha256(zipped.read(f"{root.name}/{name}")).hexdigest() == record["sha256"]
    print(json.dumps({"zip": str(archive), "bytes": archive.stat().st_size, "files": len(include),
                      "sha256": digest(archive), "validation": validation}, indent=2))


if __name__ == "__main__":
    main()
