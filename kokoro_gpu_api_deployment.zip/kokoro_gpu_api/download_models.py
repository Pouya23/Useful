"""Download the pinned complete Kokoro checkpoint and English voice packs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

REVISION = "f3ff3571791e39611d31c381e3a41a3af07b4987"


def download(directory: Path):
    from huggingface_hub import snapshot_download

    directory.mkdir(parents=True, exist_ok=True)
    snapshot_download("hexgrad/Kokoro-82M", revision=REVISION,
                      allow_patterns=["config.json", "kokoro-v1_0.pth", "voices/a*.pt", "voices/b*.pt", "LICENSE"],
                      local_dir=directory, max_workers=2)
    records = {}
    for path in [directory / "config.json", directory / "kokoro-v1_0.pth", *sorted((directory / "voices").glob("[ab][fm]_*.pt"))]:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
                digest.update(block)
        records[str(path.relative_to(directory))] = {"sha256": digest.hexdigest(), "bytes": path.stat().st_size}
    (directory / "download_manifest.json").write_text(json.dumps({"repository": "hexgrad/Kokoro-82M", "revision": REVISION,
        "files": records}, indent=2) + "\n", encoding="utf-8")
    print(f"Pinned Kokoro weights ready in {directory}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", type=Path, default=Path("models"))
    download(parser.parse_args().model_dir)
