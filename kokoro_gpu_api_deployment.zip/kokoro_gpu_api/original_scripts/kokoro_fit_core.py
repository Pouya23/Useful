#!/usr/bin/env python3
"""Shared Kokoro duration-fit helpers (estimate + synthesize + atempo MP3)."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from kokoro import KModel, KPipeline

from kokoro_male_grid import (
    SAMPLE_RATE,
    concat_audio,
    estimate_duration_seconds,
)

DEFAULT_SPLIT_PATTERN = r"\n+"
# Empirical GPU RTF from kokoro_male_grid (~0.024); used for job ETA only.
DEFAULT_GPU_RTF = 0.024
ATEMPO_ENCODE_OVERHEAD_S = 1.5


@dataclass
class FitEvaluation:
    ok: bool
    reason: str | None
    estimated_natural_duration_s: float
    desired_duration_s: float
    atempo_factor: float
    estimated_final_duration_s: float
    estimated_generation_time_s: float
    atempo_min: float
    atempo_max: float


def phonemize_chunks(
    quiet_pipeline: KPipeline, text: str, split_pattern: str | None
) -> list[tuple[str, str]]:
    chunks: list[tuple[str, str]] = []
    for result in quiet_pipeline(text, voice=None, split_pattern=split_pattern):
        if result.phonemes:
            chunks.append((result.graphemes, result.phonemes))
    return chunks


def estimate_text_duration(
    quiet_pipeline: KPipeline,
    model: KModel,
    pack: torch.Tensor,
    text: str,
    speed: float,
    split_pattern: str | None,
) -> float:
    total = 0.0
    for _, ps in phonemize_chunks(quiet_pipeline, text, split_pattern):
        idx = min(len(ps) - 1, pack.shape[0] - 1)
        if idx < 0:
            continue
        total += estimate_duration_seconds(model, ps, pack[idx], speed)
    return total


def estimate_generation_wall_time(natural_duration_s: float, rtf: float = DEFAULT_GPU_RTF) -> float:
    """Rough wall-clock estimate for synthesis + atempo encode."""
    return max(0.5, natural_duration_s * rtf + ATEMPO_ENCODE_OVERHEAD_S)


def evaluate_fit(
    quiet_pipeline: KPipeline,
    model: KModel,
    pack: torch.Tensor,
    text: str,
    speed: float,
    split_pattern: str | None,
    desired_duration: float,
    atempo_min: float,
    atempo_max: float,
    rtf: float = DEFAULT_GPU_RTF,
) -> FitEvaluation:
    est_sec = estimate_text_duration(quiet_pipeline, model, pack, text, speed, split_pattern)
    if est_sec <= 0:
        return FitEvaluation(
            ok=False,
            reason="no_phoneme_content",
            estimated_natural_duration_s=0.0,
            desired_duration_s=desired_duration,
            atempo_factor=0.0,
            estimated_final_duration_s=0.0,
            estimated_generation_time_s=0.0,
            atempo_min=atempo_min,
            atempo_max=atempo_max,
        )

    needed = est_sec / desired_duration
    gen_eta = estimate_generation_wall_time(est_sec, rtf=rtf)

    if needed < atempo_min:
        return FitEvaluation(
            ok=False,
            reason="too_short",
            estimated_natural_duration_s=est_sec,
            desired_duration_s=desired_duration,
            atempo_factor=needed,
            estimated_final_duration_s=desired_duration,
            estimated_generation_time_s=gen_eta,
            atempo_min=atempo_min,
            atempo_max=atempo_max,
        )
    if needed > atempo_max:
        return FitEvaluation(
            ok=False,
            reason="too_long",
            estimated_natural_duration_s=est_sec,
            desired_duration_s=desired_duration,
            atempo_factor=needed,
            estimated_final_duration_s=desired_duration,
            estimated_generation_time_s=gen_eta,
            atempo_min=atempo_min,
            atempo_max=atempo_max,
        )

    return FitEvaluation(
        ok=True,
        reason=None,
        estimated_natural_duration_s=est_sec,
        desired_duration_s=desired_duration,
        atempo_factor=needed,
        estimated_final_duration_s=desired_duration,
        estimated_generation_time_s=gen_eta,
        atempo_min=atempo_min,
        atempo_max=atempo_max,
    )


def generate_audio(
    pipeline: KPipeline,
    model: KModel,
    text: str,
    voice: str,
    speed: float,
    split_pattern: str | None,
) -> np.ndarray:
    results = list(
        pipeline(text, voice=voice, speed=speed, split_pattern=split_pattern, model=model)
    )
    audio = concat_audio(r.audio for r in results)
    if audio.size == 0:
        raise RuntimeError("Kokoro produced empty audio")
    return audio


def build_atempo_filter(factor: float) -> str:
    if factor <= 0:
        raise ValueError(f"atempo factor must be positive, got {factor}")
    parts: list[str] = []
    f = float(factor)
    while f > 2.0 + 1e-9:
        parts.append("atempo=2.0")
        f /= 2.0
    while f < 0.5 - 1e-9:
        parts.append("atempo=0.5")
        f /= 0.5
    parts.append(f"atempo={f:.8f}")
    return ",".join(parts)


def save_mp3_with_atempo(
    path: Path,
    audio: np.ndarray,
    atempo_factor: float,
    sample_rate: int = SAMPLE_RATE,
    bitrate_kbps: int = 320,
) -> float:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pcm = np.clip(np.asarray(audio, dtype=np.float32).reshape(-1), -1.0, 1.0)
    af = build_atempo_filter(atempo_factor)
    cmd = [
        "ffmpeg",
        "-y",
        "-loglevel",
        "error",
        "-f",
        "f32le",
        "-ar",
        str(sample_rate),
        "-ac",
        "1",
        "-i",
        "pipe:0",
        "-af",
        af,
        "-ar",
        "48000",
        "-ac",
        "1",
        "-c:a",
        "libmp3lame",
        "-b:a",
        f"{bitrate_kbps}k",
        str(path),
    ]
    proc = subprocess.run(cmd, input=pcm.tobytes(), capture_output=True)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.decode("utf-8", errors="replace"))

    probe = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=nw=1:nk=1",
            str(path),
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    return float(probe.stdout.strip())


def resolve_voice_path(model_dir: Path, voice: str) -> Path:
    if voice.endswith(".pt") and Path(voice).exists():
        return Path(voice)
    p = model_dir / "voices" / f"{voice}.pt"
    if not p.exists():
        raise FileNotFoundError(f"Voice pack not found: {p}")
    return p


def load_kokoro(
    model_dir: Path,
    lang_code: str = "a",
    device: str | None = None,
) -> tuple[KModel, KPipeline, KPipeline, str]:
    model_dir = Path(model_dir).resolve()
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    model = (
        KModel(
            repo_id="hexgrad/Kokoro-82M",
            config=str(model_dir / "config.json"),
            model=str(model_dir / "kokoro-v1_0.pth"),
        )
        .to(device)
        .eval()
    )
    pipeline = KPipeline(lang_code=lang_code, repo_id="hexgrad/Kokoro-82M", model=model)
    quiet = KPipeline(lang_code=lang_code, repo_id="hexgrad/Kokoro-82M", model=False)
    return model, pipeline, quiet, device


def synthesize_fit_mp3(
    pipeline: KPipeline,
    model: KModel,
    text: str,
    voice_arg: str,
    speed: float,
    split_pattern: str | None,
    desired_duration: float,
    atempo_min: float,
    atempo_max: float,
    output: Path,
) -> tuple[float, float]:
    """Generate + atempo; return (actual_natural_s, output_duration_s)."""
    audio = generate_audio(pipeline, model, text, voice_arg, speed, split_pattern)
    actual_sec = float(len(audio)) / SAMPLE_RATE
    atempo = actual_sec / desired_duration
    if atempo < atempo_min or atempo > atempo_max:
        kind = "too_short" if atempo < atempo_min else "too_long"
        raise RuntimeError(f"post_synthesis_{kind}: atempo={atempo:.4f}")
    out_dur = save_mp3_with_atempo(output, audio, atempo)
    return actual_sec, out_dur
