#!/usr/bin/env python3
"""CLI: fit Kokoro speech to a target duration using ffmpeg atempo."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from kokoro_fit_core import (
    DEFAULT_SPLIT_PATTERN,
    evaluate_fit,
    load_kokoro,
    resolve_voice_path,
    synthesize_fit_mp3,
)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--text-file", type=Path, required=True, help="Input .txt file")
    p.add_argument("--output", type=Path, required=True, help="Output .mp3 path")
    p.add_argument("--voice", default="am_onyx", help="Kokoro voice id or path to .pt")
    p.add_argument("--speed", type=float, default=1.0, help="Kokoro speed parameter")
    p.add_argument(
        "--split-pattern",
        default=DEFAULT_SPLIT_PATTERN,
        help=r"Regex split for Kokoro (default: \n+)",
    )
    p.add_argument("--lang-code", default="a", choices=["a", "b"], help="Kokoro lang_code")
    p.add_argument("--atempo-min", type=float, required=True, help="Min atempo factor")
    p.add_argument("--atempo-max", type=float, required=True, help="Max atempo factor")
    p.add_argument(
        "--desired-duration",
        type=float,
        required=True,
        help="Target output duration in seconds",
    )
    p.add_argument("--model-dir", type=Path, default=Path("/home/ali/Narration/Final/TTS/models"))
    p.add_argument("--cpu", action="store_true")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    if args.desired_duration <= 0:
        print("desired-duration must be positive", file=sys.stderr)
        return 2
    if args.atempo_min <= 0 or args.atempo_max <= 0 or args.atempo_min > args.atempo_max:
        print("Invalid atempo range: require 0 < atempo-min <= atempo-max", file=sys.stderr)
        return 2

    text = args.text_file.read_text(encoding="utf-8").strip()
    if not text:
        print("Text file is empty", file=sys.stderr)
        return 2

    split_pattern = args.split_pattern if args.split_pattern else None
    model_dir = args.model_dir.resolve()
    voice_arg = str(resolve_voice_path(model_dir, args.voice))
    device = "cpu" if args.cpu else None
    model, pipeline, quiet, used_device = load_kokoro(model_dir, args.lang_code, device=device)
    pack = pipeline.load_voice(voice_arg)

    fit = evaluate_fit(
        quiet,
        model,
        pack,
        text,
        args.speed,
        split_pattern,
        args.desired_duration,
        args.atempo_min,
        args.atempo_max,
    )
    print(f"Device: {used_device}")
    print(f"Estimated natural duration: {fit.estimated_natural_duration_s:.3f}s")
    print(f"Desired duration:         {fit.desired_duration_s:.3f}s")
    print(
        f"Required atempo factor:   {fit.atempo_factor:.4f}  "
        f"(allowed [{args.atempo_min}, {args.atempo_max}])"
    )

    if not fit.ok:
        if fit.reason == "too_short":
            print(
                f"The text is too short for the desired duration: "
                f"would need atempo {fit.atempo_factor:.4f} < minimum {args.atempo_min} "
                f"(slow down more than allowed)."
            )
        elif fit.reason == "too_long":
            print(
                f"The text is too long for the desired duration: "
                f"would need atempo {fit.atempo_factor:.4f} > maximum {args.atempo_max} "
                f"(speed up more than allowed)."
            )
        else:
            print(f"Fit failed: {fit.reason}", file=sys.stderr)
        return 1

    print("Within range — generating speech…")
    try:
        actual_sec, out_dur = synthesize_fit_mp3(
            pipeline,
            model,
            text,
            voice_arg,
            args.speed,
            split_pattern,
            args.desired_duration,
            args.atempo_min,
            args.atempo_max,
            args.output,
        )
    except RuntimeError as e:
        print(str(e), file=sys.stderr)
        return 1

    print(f"Generated duration:       {actual_sec:.3f}s")
    print(f"Wrote {args.output} ({out_dur:.3f}s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
