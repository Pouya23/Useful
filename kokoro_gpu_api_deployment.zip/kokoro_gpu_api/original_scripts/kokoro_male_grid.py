#!/usr/bin/env python3
"""Kokoro TTS parameter-grid pipeline for male English voices.

Generates speech across a speed grid for all default American/British male
voices, times duration estimation vs full generation, and records accuracy
of the model's duration predictor against actual audio length.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import subprocess
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import torch
from kokoro import KModel, KPipeline

SAMPLE_RATE = 24000
# Kokoro pred_dur frames are 600 samples @ 24 kHz => 40 frames/sec
FRAMES_PER_SECOND = 40.0

MALE_VOICES = {
    "a": [  # American English
        "am_adam",
        "am_echo",
        "am_eric",
        "am_fenrir",
        "am_liam",
        "am_michael",
        "am_onyx",
        "am_puck",
        "am_santa",
    ],
    "b": [  # British English
        "bm_daniel",
        "bm_fable",
        "bm_george",
        "bm_lewis",
    ],
}

DEFAULT_SPEEDS = [0.50, 0.75, 1.00, 1.25, 1.50, 1.75, 2.00]


@dataclass
class RunResult:
    text_id: str
    word_count: int
    voice: str
    lang_code: str
    speed: float
    audio_path: str
    n_chunks: int
    estimate_seconds: float
    actual_seconds: float
    abs_error_seconds: float
    rel_error_pct: float
    estimate_latency_s: float
    generation_latency_s: float
    realtime_factor: float
    phoneme_chars: int


def word_count(text: str) -> int:
    return len(re.findall(r"\b[\w']+\b", text))


def load_texts(texts_dir: Path) -> list[tuple[str, str, int]]:
    items = []
    for path in sorted(texts_dir.glob("*.txt")):
        text = path.read_text(encoding="utf-8").strip()
        items.append((path.stem, text, word_count(text)))
    return items


def _normalize_ref_s(ref_s: torch.Tensor) -> torch.Tensor:
    """Voice packs store style as [1, 256]; accept [256] or [1, 256]."""
    if ref_s.ndim == 1:
        ref_s = ref_s.unsqueeze(0)
    elif ref_s.ndim == 3:
        ref_s = ref_s.squeeze(0)
    if ref_s.ndim != 2 or ref_s.shape[-1] < 256:
        raise ValueError(f"Unexpected ref_s shape: {tuple(ref_s.shape)}")
    return ref_s


@torch.no_grad()
def estimate_duration_seconds(
    model: KModel,
    phonemes: str,
    ref_s: torch.Tensor,
    speed: float,
) -> float:
    """Run only the duration predictor (no decoder) and return seconds."""
    input_ids = list(filter(lambda i: i is not None, map(lambda p: model.vocab.get(p), phonemes)))
    if not input_ids:
        return 0.0
    input_ids = torch.LongTensor([[0, *input_ids, 0]]).to(model.device)
    ref_s = _normalize_ref_s(ref_s).to(model.device)

    input_lengths = torch.full((input_ids.shape[0],), input_ids.shape[-1], device=model.device, dtype=torch.long)
    text_mask = torch.arange(input_lengths.max(), device=model.device).unsqueeze(0).expand(input_lengths.shape[0], -1)
    text_mask = torch.gt(text_mask + 1, input_lengths.unsqueeze(1))

    bert_dur = model.bert(input_ids, attention_mask=(~text_mask).int())
    d_en = model.bert_encoder(bert_dur).transpose(-1, -2)
    s = ref_s[:, 128:]
    d = model.predictor.text_encoder(d_en, s, input_lengths, text_mask)
    x, _ = model.predictor.lstm(d)
    duration = model.predictor.duration_proj(x)
    duration = torch.sigmoid(duration).sum(axis=-1) / float(speed)
    pred_dur = torch.round(duration).clamp(min=1).long().squeeze()
    return float(pred_dur.sum().item()) / FRAMES_PER_SECOND


def phonemize_chunks(quiet_pipeline: KPipeline, text: str) -> list[tuple[str, str]]:
    """Return (graphemes, phonemes) chunks without generating audio."""
    chunks: list[tuple[str, str]] = []
    for result in quiet_pipeline(text, voice=None, split_pattern=r"\n+"):
        if result.phonemes:
            chunks.append((result.graphemes, result.phonemes))
    return chunks


def concat_audio(pieces: Iterable[torch.Tensor]) -> np.ndarray:
    arrays = []
    for p in pieces:
        if p is None:
            continue
        arr = p.detach().cpu().numpy()
        if arr.ndim > 1:
            arr = arr.squeeze()
        arrays.append(arr)
    if not arrays:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate(arrays).astype(np.float32)


def synthesize_one(
    pipeline: KPipeline,
    quiet_pipeline: KPipeline,
    model: KModel,
    text: str,
    voice_name: str,
    voice_path: Path,
    speed: float,
) -> tuple[np.ndarray, dict]:
    voice = str(voice_path)
    pack = pipeline.load_voice(voice)

    # 1) Phonemize once (shared by estimate + generate)
    chunks = phonemize_chunks(quiet_pipeline, text)
    if not chunks:
        raise RuntimeError(f"No phoneme chunks produced for voice={voice_name}")
    phoneme_chars = sum(len(ps) for _, ps in chunks)

    # 2) Duration estimate only (no waveform decode)
    # pack[i] is already [1, 256] — do not unsqueeze again.
    if model.device.type == "cuda":
        torch.cuda.synchronize()
    t_est0 = time.perf_counter()
    est_seconds = 0.0
    for _, ps in chunks:
        idx = min(len(ps) - 1, pack.shape[0] - 1)
        if idx < 0:
            continue
        est_seconds += estimate_duration_seconds(model, ps, pack[idx], speed)
    if model.device.type == "cuda":
        torch.cuda.synchronize()
    estimate_latency_s = time.perf_counter() - t_est0

    # 3) Full generation
    if model.device.type == "cuda":
        torch.cuda.synchronize()
    t_gen0 = time.perf_counter()
    results = list(pipeline(text, voice=voice, speed=speed, split_pattern=r"\n+", model=model))
    if model.device.type == "cuda":
        torch.cuda.synchronize()
    generation_latency_s = time.perf_counter() - t_gen0

    audio = concat_audio(r.audio for r in results)
    if audio.size == 0:
        raise RuntimeError(f"Empty audio for voice={voice_name} speed={speed}")

    actual_seconds = float(len(audio)) / SAMPLE_RATE
    abs_err = abs(est_seconds - actual_seconds)
    rel_err = (100.0 * abs_err / actual_seconds) if actual_seconds > 0 else float("nan")
    rtf = (generation_latency_s / actual_seconds) if actual_seconds > 0 else float("nan")

    meta = {
        "n_chunks": len(results),
        "estimate_seconds": est_seconds,
        "actual_seconds": actual_seconds,
        "abs_error_seconds": abs_err,
        "rel_error_pct": rel_err,
        "estimate_latency_s": estimate_latency_s,
        "generation_latency_s": generation_latency_s,
        "realtime_factor": rtf,
        "phoneme_chars": phoneme_chars,
    }
    return audio, meta

def build_filename(text_id: str, voice: str, speed: float) -> str:
    speed_tag = f"speed{speed:.2f}".replace(".", "p")
    return f"{text_id}__{voice}__{speed_tag}.mp3"


def save_mp3(path: Path, audio: np.ndarray, sample_rate: int = SAMPLE_RATE, bitrate_kbps: int = 320) -> None:
    """Encode float PCM to CBR MP3 320k via ffmpeg.

    Resamples to 48 kHz because MPEG-1 Layer III (needed for 320 kbps)
    does not support 24 kHz input — at 24 kHz LAME caps around 160 kbps.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pcm = np.asarray(audio, dtype=np.float32)
    if pcm.ndim > 1:
        pcm = pcm.reshape(-1)
    pcm = np.clip(pcm, -1.0, 1.0)
    cmd = [
        "ffmpeg",
        "-y",
        "-loglevel",
        "error",
        "-f",
        "f32le",
        "-ar",
        str(sample_rate),
        "-ac",
        "1",
        "-i",
        "pipe:0",
        "-ar",
        "48000",
        "-ac",
        "1",
        "-c:a",
        "libmp3lame",
        "-b:a",
        f"{bitrate_kbps}k",
        str(path),
    ]
    proc = subprocess.run(cmd, input=pcm.tobytes(), capture_output=True)
    if proc.returncode != 0:
        err = proc.stderr.decode("utf-8", errors="replace")
        raise RuntimeError(f"ffmpeg MP3 encode failed ({proc.returncode}): {err}")


def run_grid(args: argparse.Namespace) -> None:
    root = Path(args.root).resolve()
    model_dir = Path(args.model_dir).resolve()
    out_audio = Path(args.out_dir).resolve() / "audio"
    out_metrics = Path(args.out_dir).resolve() / "metrics"
    out_audio.mkdir(parents=True, exist_ok=True)
    out_metrics.mkdir(parents=True, exist_ok=True)

    texts = load_texts(root / "texts")
    if not texts:
        raise SystemExit(f"No texts found in {root / 'texts'}")

    speeds = args.speeds
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    print(f"Device: {device}")
    print(f"Texts: {[(tid, wc) for tid, _, wc in texts]}")
    print(f"Speeds: {speeds}")

    model = KModel(
        repo_id="hexgrad/Kokoro-82M",
        config=str(model_dir / "config.json"),
        model=str(model_dir / "kokoro-v1_0.pth"),
    ).to(device).eval()

    pipelines = {
        "a": KPipeline(lang_code="a", repo_id="hexgrad/Kokoro-82M", model=model),
        "b": KPipeline(lang_code="b", repo_id="hexgrad/Kokoro-82M", model=model),
    }
    quiet_pipelines = {
        "a": KPipeline(lang_code="a", repo_id="hexgrad/Kokoro-82M", model=False),
        "b": KPipeline(lang_code="b", repo_id="hexgrad/Kokoro-82M", model=False),
    }

    rows: list[RunResult] = []
    total = sum(len(v) for v in MALE_VOICES.values()) * len(texts) * len(speeds)
    done = 0

    for lang_code, voices in MALE_VOICES.items():
        pipeline = pipelines[lang_code]
        quiet_pipeline = quiet_pipelines[lang_code]
        for voice in voices:
            voice_path = model_dir / "voices" / f"{voice}.pt"
            if not voice_path.exists():
                print(f"SKIP missing voice file: {voice_path}")
                continue
            # Warm-load voice pack once
            pipelines[lang_code].load_voice(str(voice_path))

            for text_id, text, wc in texts:
                for speed in speeds:
                    done += 1
                    fname = build_filename(text_id, voice, speed)
                    audio_path = out_audio / fname
                    print(f"[{done}/{total}] {fname}")

                    if args.skip_existing and audio_path.exists():
                        print("  exists, skipping generation (metrics not recomputed)")
                        continue

                    audio, meta = synthesize_one(
                        pipeline=pipeline,
                        quiet_pipeline=quiet_pipeline,
                        model=model,
                        text=text,
                        voice_name=voice,
                        voice_path=voice_path,
                        speed=speed,
                    )
                    save_mp3(audio_path, audio, SAMPLE_RATE, bitrate_kbps=320)

                    row = RunResult(
                        text_id=text_id,
                        word_count=wc,
                        voice=voice,
                        lang_code=lang_code,
                        speed=speed,
                        audio_path=str(audio_path),
                        **meta,
                    )
                    rows.append(row)
                    print(
                        f"  est={row.estimate_seconds:.3f}s actual={row.actual_seconds:.3f}s "
                        f"err={row.abs_error_seconds:.4f}s ({row.rel_error_pct:.3f}%) | "
                        f"est_lat={row.estimate_latency_s:.4f}s gen_lat={row.generation_latency_s:.3f}s "
                        f"RTF={row.realtime_factor:.3f}"
                    )

    # Persist metrics
    csv_path = out_metrics / "kokoro_male_grid_metrics.csv"
    json_path = out_metrics / "kokoro_male_grid_metrics.json"
    summary_path = out_metrics / "kokoro_male_grid_summary.json"

    if rows:
        fieldnames = list(asdict(rows[0]).keys())
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for r in rows:
                writer.writerow(asdict(r))
        with json_path.open("w", encoding="utf-8") as f:
            json.dump([asdict(r) for r in rows], f, indent=2)

        # Per-voice aggregates
        by_voice: dict[str, list[RunResult]] = {}
        for r in rows:
            by_voice.setdefault(r.voice, []).append(r)

        summary = {
            "n_runs": len(rows),
            "device": device,
            "speeds": speeds,
            "sample_rate": SAMPLE_RATE,
            "overall": {
                "mean_abs_error_s": float(np.mean([r.abs_error_seconds for r in rows])),
                "mean_rel_error_pct": float(np.mean([r.rel_error_pct for r in rows])),
                "mean_estimate_latency_s": float(np.mean([r.estimate_latency_s for r in rows])),
                "mean_generation_latency_s": float(np.mean([r.generation_latency_s for r in rows])),
                "mean_realtime_factor": float(np.mean([r.realtime_factor for r in rows])),
            },
            "per_voice": {},
        }
        for voice, items in sorted(by_voice.items()):
            summary["per_voice"][voice] = {
                "n": len(items),
                "mean_abs_error_s": float(np.mean([r.abs_error_seconds for r in items])),
                "mean_rel_error_pct": float(np.mean([r.rel_error_pct for r in items])),
                "mean_estimate_latency_s": float(np.mean([r.estimate_latency_s for r in items])),
                "mean_generation_latency_s": float(np.mean([r.generation_latency_s for r in items])),
                "mean_realtime_factor": float(np.mean([r.realtime_factor for r in items])),
                "by_text": {
                    tid: {
                        "mean_abs_error_s": float(np.mean([r.abs_error_seconds for r in grp])),
                        "mean_estimate_latency_s": float(np.mean([r.estimate_latency_s for r in grp])),
                        "mean_generation_latency_s": float(np.mean([r.generation_latency_s for r in grp])),
                    }
                    for tid, grp in _group(items, key=lambda x: x.text_id).items()
                },
            }

        with summary_path.open("w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)

        print(f"\nWrote {len(rows)} audio files under {out_audio}")
        print(f"Metrics CSV: {csv_path}")
        print(f"Summary:     {summary_path}")
    else:
        print("No new rows recorded (all skipped?).")


def _group(items: list[RunResult], key) -> dict[str, list[RunResult]]:
    out: dict[str, list[RunResult]] = {}
    for item in items:
        out.setdefault(key(item), []).append(item)
    return out


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", default="/home/ali/Narration/Final/TTS")
    p.add_argument("--model-dir", default="/home/ali/Narration/Final/TTS/models")
    p.add_argument("--out-dir", default="/home/ali/Narration/Final/TTS/outputs")
    p.add_argument(
        "--speeds",
        type=float,
        nargs="+",
        default=DEFAULT_SPEEDS,
        help="Speed grid values (Kokoro's main generation parameter)",
    )
    p.add_argument("--cpu", action="store_true", help="Force CPU even if CUDA is available")
    p.add_argument("--skip-existing", action="store_true")
    return p.parse_args()


if __name__ == "__main__":
    run_grid(parse_args())
