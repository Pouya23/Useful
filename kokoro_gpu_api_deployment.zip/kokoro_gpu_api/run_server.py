"""Production entry point: one Flask/Waitress process and one GPU worker."""

from __future__ import annotations

import logging
import os
import shutil

from waitress import serve

from app import create_app
from contracts import Settings
from jobs import SpeechService
from kokoro_fit_core import KokoroEngine


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    settings = Settings.from_env()
    for tool in ("ffmpeg", "ffprobe"):
        if not shutil.which(tool):
            raise RuntimeError(f"{tool} is required on PATH")
    if os.getenv("DOWNLOAD_MODELS", "1") == "1":
        from download_models import download
        download(settings.model_dir)
    service = SpeechService(settings, KokoroEngine)
    app = create_app(service)
    host = os.getenv("HTTP_HOST", "0.0.0.0")
    port = int(os.getenv("HTTP_PORT", "8000"))
    logging.info("Ready on %s:%s; device=%s; Swagger=/docs/", host, port, settings.device)
    try:
        serve(app, host=host, port=port, threads=8, channel_timeout=600,
              max_request_body_size=256 * 1024)
    finally:
        service.close()


if __name__ == "__main__":
    main()
