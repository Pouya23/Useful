#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [[ ! -f .env ]]; then
  cp .env.example .env
  printf 'Created .env. Fill the unknown server fields as described in README.md.\n'
fi
command -v nvidia-smi >/dev/null || { printf 'NVIDIA driver/GPU missing. Ask your server administrator; this script does not install drivers.\n' >&2; exit 1; }
nvidia-smi
docker info >/dev/null
docker compose config --quiet
docker compose build
docker compose run --rm --no-deps api python -c "import torch; assert torch.cuda.is_available(), 'GPU unavailable inside container'; print(torch.cuda.get_device_name(0))"
docker compose up -d
printf 'Service starting. Follow: docker compose logs -f api\n'
printf 'Open Swagger at http://YOUR_GPU_SERVER_ADDRESS:YOUR_API_PORT/docs/ after readiness.\n'
