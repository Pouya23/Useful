"""No-model contract/lifecycle tests. Fake MP3 bytes are not speech validation."""

import json
import threading
import time
from dataclasses import replace

import pytest

from app import create_app, openapi_document
from contracts import GenerationSpec, Settings
from jobs import SpeechService
from kokoro_fit_core import SpeechPlan, build_atempo_filter, evaluate_fit

TEXT = "The final decision required patience, clear evidence, and careful judgment."


class FakeEngine:
    signature = "contract-test-engine"
    voices = ["am_onyx", "am_fenrir", "bm_george"]

    def __init__(self, settings):
        self.calls = 0
        self.plan_calls = 0
        self.release = threading.Event()
        self.release.set()
        self.fail = False

    def memory_snapshot(self):
        return {"device": "contract-test-fixture"}

    def plan(self, spec):
        if spec.voice not in self.voices:
            raise ValueError("Unknown test voice")
        self.plan_calls += 1
        return SpeechPlan(self.signature, 120000, [{"native_samples": 120000}])

    def save_plan(self, plan, path):
        path.write_text(json.dumps({"engine_signature": plan.engine_signature,
                                    "natural_samples": plan.natural_samples, "chunks": plan.chunks}))

    def load_plan(self, path):
        return SpeechPlan(**json.loads(path.read_text()))

    def generate(self, plan, spec, destination, progress):
        self.calls += 1
        progress("synthesizing", 0, 1)
        assert self.release.wait(10), "Fake worker timed out"
        if self.fail:
            raise RuntimeError("Deliberate fixture failure")
        progress("synthesizing", 1, 1)
        progress("encoding", 1, 1)
        destination.write_bytes(b"NOT_REAL_MP3_TEST_FIXTURE")
        return {"actual_natural_duration_s": 5.0, "actual_final_duration_s": 5.04,
                "synthesis_seconds": .1, "encoding_seconds": .02}


def payload(**changes):
    return {"text": TEXT, "voice": "am_onyx", "desired_duration": 5.0, **changes}


@pytest.fixture
def service(tmp_path):
    instance = SpeechService(Settings(tmp_path / "models", tmp_path / "data", device="cpu"), FakeEngine)
    yield instance
    instance.engine.release.set()
    instance.close()


@pytest.fixture
def client(service):
    return create_app(service).test_client()


def wait_for(service, job_id, status):
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        found = service.progress(job_id)
        if found["status"] == status:
            return found
        time.sleep(.01)
    raise AssertionError(f"Job did not reach {status}: {service.progress(job_id)}")


def test_estimate_never_synthesizes_or_enqueues(client, service):
    response = client.post("/estimate", json=payload())
    assert response.status_code == 200
    assert response.json["waveform_generated"] is False
    assert response.json["natural_samples"] == 120000
    assert response.json["estimated_final_duration_s"] == 5
    assert response.json["final_duration_is_sample_exact"] is False
    assert service.engine.calls == 0
    assert not service.store.outstanding()
    assert not list(service.job_root.iterdir())


@pytest.mark.parametrize("duration,reason", [(100., "too_short"), (.5, "too_long")])
def test_fit_rejection_creates_no_job(client, service, duration, reason):
    for endpoint in ("/estimate", "/generate"):
        body = payload(desired_duration=duration)
        if endpoint == "/generate":
            body["generate"] = True
        response = client.post(endpoint, json=body)
        assert response.status_code == 422
        assert response.json["reason"] == reason
    assert service.engine.calls == 0
    assert not service.store.outstanding()


@pytest.mark.parametrize("changes", [
    {"text": "Too short."}, {"speed": 0}, {"speed": True}, {"desired_duration": "5"},
    {"atempo_min": 2., "atempo_max": 1.}, {"voice": "../private.pt"},
    {"voice": "bm_george", "lang_code": "a"}, {"split_pattern": "(a+)+"},
    {"unexpected_option": True}, {"sample_rate": 96000}, {"seed": True},
    {"sample_rate": 24000, "bitrate_kbps": 320},
])
def test_invalid_specs_rejected_before_model_calls(client, service, changes):
    assert client.post("/estimate", json=payload(**changes)).status_code == 422
    assert service.engine.plan_calls == 0


@pytest.mark.parametrize("flag", [False, "true", 1, None])
def test_generate_requires_boolean_true(client, service, flag):
    assert client.post("/generate", json=payload(generate=flag)).status_code == 422
    assert service.engine.calls == 0


def test_generate_missing_flag_is_rejected(client):
    assert client.post("/generate", json=payload()).status_code == 422


def test_full_job_lifecycle_and_download(client, service):
    service.engine.release.clear()
    submitted = client.post("/generate", json=payload(generate=True))
    assert submitted.status_code == 202
    job_id = submitted.json["job_id"]
    running = wait_for(service, job_id, "running")
    assert running["progress_percent"] < 100
    assert client.get(f"/progress?job_id={job_id}&download=true").status_code == 409
    service.engine.release.set()
    final = wait_for(service, job_id, "completed")
    assert final["progress_percent"] == 100
    assert final["time_remaining_s"] == 0
    assert final["result"]["audio_url"].endswith("download=true")
    assert client.post("/progress", json={"job_id": job_id}).json["status"] == "completed"
    downloaded = client.get(final["result"]["audio_url"])
    assert downloaded.status_code == 200
    assert downloaded.mimetype == "audio/mpeg"
    assert downloaded.data == b"NOT_REAL_MP3_TEST_FIXTURE"
    assert service.engine.calls == 1
    calibrated = client.post("/estimate", json=payload()).json
    assert calibrated["eta_source"] == "calibrated_median_rtf"
    assert calibrated["calibration_samples"] == 1


def test_idempotent_retry_does_not_create_another_job(client, service):
    headers = {"Idempotency-Key": "client-request-01"}
    first = client.post("/generate", json=payload(generate=True), headers=headers)
    second = client.post("/generate", json=payload(generate=True), headers=headers)
    assert second.status_code == 200
    assert first.json["job_id"] == second.json["job_id"]
    assert second.json["idempotent_replay"] is True
    changed = client.post("/generate", json=payload(generate=True, speed=1.1), headers=headers)
    assert changed.status_code == 409
    wait_for(service, first.json["job_id"], "completed")
    assert service.engine.calls == 1


def test_failed_generation_is_reported(client, service):
    service.engine.fail = True
    job_id = client.post("/generate", json=payload(generate=True)).json["job_id"]
    final = wait_for(service, job_id, "failed")
    assert final["success"] is False
    assert final["progress_percent"] < 100
    assert "Deliberate fixture failure" in final["error"]["message"]
    assert client.get(f"/progress?job_id={job_id}&download=true").status_code == 409


def test_unknown_and_invalid_job_ids(client):
    assert client.get("/progress?job_id=" + "0" * 32).status_code == 404
    assert client.get("/progress?job_id=../../private").status_code == 422
    assert client.get("/progress").status_code == 422


def test_json_errors_are_machine_readable(client):
    assert client.post("/estimate", data="{", content_type="application/json").status_code == 400
    response = client.post("/estimate", data="not-json")
    assert response.status_code == 415
    assert response.json["success"] is False


def test_queue_full_preserves_first_job_and_leaves_no_orphan_plan(tmp_path):
    settings = Settings(tmp_path / "models", tmp_path / "data", device="cpu", max_pending_jobs=1)
    service = SpeechService(settings, FakeEngine, start_worker=False)
    try:
        client = create_app(service).test_client()
        first = client.post("/generate", json=payload(generate=True))
        assert first.status_code == 202
        second = client.post("/generate", json=payload(generate=True))
        assert second.status_code == 503
        assert len(list(service.job_root.iterdir())) == 1
        queued = service.progress(first.json["job_id"])
        assert queued["progress_percent"] == 0
        assert queued["time_remaining_s"] > 0
    finally:
        service.close()


def test_time_progress_cannot_signal_completion_before_worker_finishes(service):
    service.engine.release.clear()
    created = service.submit(GenerationSpec.model_validate(payload()))
    wait_for(service, created["job_id"], "running")
    with service.store.connection() as db:
        db.execute("UPDATE jobs SET started_at=?,estimated_runtime_s=.1 WHERE job_id=?", (time.time() - 10, created["job_id"]))
    current = service.progress(created["job_id"])
    assert current["status"] == "running"
    assert current["progress_percent"] == 99
    assert current["eta_overrun"] is True


def test_restart_preserves_queued_plan_and_fails_interrupted_job(tmp_path):
    settings = Settings(tmp_path / "models", tmp_path / "data", device="cpu")
    first = SpeechService(settings, FakeEngine, start_worker=False)
    queued = first.submit(GenerationSpec.model_validate(payload()))["job_id"]
    interrupted = first.store.claim()["job_id"]
    another = first.submit(GenerationSpec.model_validate(payload()))["job_id"]
    first.close()
    second = SpeechService(settings, FakeEngine, start_worker=False)
    try:
        assert interrupted == queued
        assert second.progress(interrupted)["status"] == "failed"
        assert second.progress(another)["status"] == "queued"
        assert (second.job_root / another / "plan.pt").is_file()
    finally:
        second.close()


def test_only_one_service_can_own_a_data_volume(tmp_path):
    settings = Settings(tmp_path / "models", tmp_path / "data", device="cpu")
    first = SpeechService(settings, FakeEngine, start_worker=False)
    try:
        with pytest.raises(RuntimeError, match="Another service"):
            SpeechService(settings, FakeEngine, start_worker=False)
    finally:
        first.close()


def test_optional_api_key_and_swagger(service):
    service.settings = replace(service.settings, api_key="test-only-key")
    client = create_app(service).test_client()
    assert client.post("/estimate", json=payload()).status_code == 401
    assert client.post("/estimate", json=payload(), headers={"X-API-Key": "test-only-key"}).status_code == 200
    assert client.get("/docs/").status_code == 200
    document = client.get("/openapi.json").json
    assert set(document["paths"]) == {"/estimate", "/generate", "/progress"}
    assert document["paths"]["/generate"]["post"]["security"]


def test_atempo_chain_product_and_safe_stage_ranges():
    for factor in (.125, .5, 1, 2, 8):
        stages = [float(stage.split("=")[1]) for stage in build_atempo_filter(factor).split(",")]
        assert all(.5 <= value <= 2 for value in stages)
        product = 1
        for value in stages:
            product *= value
        assert product == pytest.approx(factor)
    with pytest.raises(ValueError):
        build_atempo_filter(float("nan"))


def test_tempo_boundaries_are_inclusive():
    plan = SpeechPlan("fixture", 120000, [{"native_samples": 120000}])
    spec = GenerationSpec.model_validate(payload(atempo_min=1., atempo_max=1.))
    assert evaluate_fit(plan, spec)["success"] is True


def test_swagger_document_is_valid_openapi(service):
    from openapi_spec_validator import validate
    validate(openapi_document(service))
