"""Real-model Flask/worker/FFmpeg checks; explicit CPU verification only.

Run with a Python environment containing the deployment requirements and
--model-dir pointing to the complete checkpoint plus English voice packs.
It writes actual speech and a JSON evidence report, never mock speech.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))

from app import create_app
from contracts import Settings
from jobs import SpeechService
from kokoro_fit_core import KokoroEngine


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--cases-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    settings = Settings(args.model_dir.resolve(), (args.output_dir / "data").resolve(), device="cpu")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    service = SpeechService(settings, KokoroEngine)
    client = create_app(service).test_client()
    decoder_calls = []
    hook = service.engine.model.decoder.register_forward_hook(lambda *_: decoder_calls.append(time.time()))
    report = {"device": "cpu", "cuda_verified": False, "engine_signature": service.engine.signature,
              "runtime_profile": service.engine.runtime_profile, "cases": []}
    try:
        for count in (10, 100, 500):
            text = (args.cases_dir / f"sample_text_{count}.txt").read_text(encoding="utf-8").strip()
            base = {"text": text, "voice": "am_onyx", "speed": 1.0, "desired_duration": float(max(5, count / 2.5)),
                    "atempo_min": .5, "atempo_max": 2.0}
            before = len(decoder_calls)
            preview = client.post("/estimate", json=base)
            assert preview.status_code == 200, preview.json
            assert len(decoder_calls) == before, "Estimator called the waveform decoder"
            assert not preview.json["waveform_generated"]
            generation = client.post("/generate", json={**base, "generate": True})
            assert generation.status_code == 202, generation.json
            job_id = generation.json["job_id"]
            sampled_progress = []
            last_stage = None
            deadline = time.monotonic() + 900
            while True:
                response = client.get(f"/progress?job_id={job_id}")
                assert response.status_code == 200
                current = response.json
                sampled_progress.append({key: current[key] for key in ("status", "stage", "progress_percent", "time_remaining_s", "completed_chunks")})
                if current["stage"] != last_stage:
                    print(json.dumps({"words": count, "stage": current["stage"], "progress": current["progress_percent"]}), flush=True)
                    last_stage = current["stage"]
                if current["status"] in {"completed", "failed"}:
                    break
                assert current["progress_percent"] < 100
                if time.monotonic() > deadline:
                    raise TimeoutError("CPU verification exceeded its deadline")
                time.sleep(.25)
            assert current["status"] == "completed", current
            assert current["result"]["actual_natural_duration_s"] == preview.json["estimated_natural_duration_s"]
            download = client.get(current["result"]["audio_url"])
            assert download.status_code == 200 and download.mimetype == "audio/mpeg"
            audio = args.output_dir / f"real_am_onyx_{count:03d}words.mp3"
            audio.write_bytes(download.data)
            report["cases"].append({"word_count": count, "estimate": preview.json,
                                    "completed_job": current, "waveform_decoder_calls_during_estimate": 0,
                                    "generation_decoder_calls": len(decoder_calls) - before,
                                    "sampled_progress": sampled_progress,
                                    "downloaded_mp3": audio.name})
            print(json.dumps({"words": count, "natural_seconds": current["result"]["actual_natural_duration_s"],
                              "final_seconds": current["result"]["actual_final_duration_s"],
                              "final_target_error_percent": current["result"]["duration_error_percent"]}), flush=True)
        (args.output_dir / "real_cpu_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        (root / "openapi.json").write_text(json.dumps(client.get("/openapi.json").json, indent=2) + "\n", encoding="utf-8")
    finally:
        hook.remove()
        service.close()


if __name__ == "__main__":
    main()
