# Modular Qwen worksite writer

Plain Python, one model, three inference engines. Start with `maintenance_example.py`,
then read `qwen_writer/pipeline.py`. No manifests, encoded source, hidden LLM calls,
planning passes, model judges, or automatic retry loops are included.

## What stays the same

1. Supply a title, instructions, required points, optional writing samples and reference sources.
2. Supply the intended narration duration in **seconds**.
3. Generate **one direct draft**. Its complete text is printed and saved.
4. Python counts words and calculates length feedback. You review quality.
5. Submit feedback: one completion generates the next full text, then Python measures it again.
6. Repeat for as many rounds as you want, or accept the latest text without another call.

The same job, prompt construction, sampling settings, output allowance, output validation,
and feedback policy apply to all three engines. Each pass includes the original brief,
the latest accepted draft and the current feedback. Previous drafts stay in the logs,
not the prompt. A rejected/truncated revision never replaces an accepted draft.
Changing the engine does not introduce another generation stage.

The previous prompt wording and revision behavior are retained. Duration fields add
task context and replace manual word bounds in the public examples and command line.
`min_words`, `max_words` and `revise(word_range=...)` remain only for old Python callers;
do not combine those bounds with `duration_seconds`.

## Files to read

| File | Responsibility |
|---|---|
| `maintenance_example.py` | Complete pipe-handling maintenance brief, two style samples, fictional reference |
| `qwen_writer/requests.py` | Validated writing input and local word counter |
| `qwen_writer/duration.py` | Seconds → target words → tolerance band |
| `qwen_writer/prompts.py` | Shared prompt and output-token allowance |
| `qwen_writer/pipeline.py` | Draft, revise, accept; unlimited interactive review |
| `qwen_writer/session.py` | Engine selection and measured Python-engine session |
| `qwen_writer/engines/llama_cpp.py` | Adapter to the original native session |
| `qwen_writer/engines/transformers.py` | NF4, one GPU, automatic attention backend, chunked prefill and generate |
| `qwen_writer/engines/vllm.py` | NF4, one GPU, eager execution, bounded KV memory pool |
| `qwen_writer/engines/base.py` | Readable settings and token-admission contract |
| `qwen_writer/worker.py` | Resident Transformers/vLLM process and message protocol |
| `qwen_writer/process.py` | Worker launch, communication timeout, process-tree cleanup |
| `qwen_writer/llama_session.py` | Existing native lifecycle and dependency bootstrap |
| `qwen_writer/runtime.py` | Low-level native server, admission, GPU isolation and guard |
| `qwen_writer/telemetry.py` | Continuous NVML measurements and round logs |
| `qwen_writer/model.py`, `kaggle_setup.py` | Verified GGUF download and pinned native CUDA runtime |
| `run_pipeline.py` | Interactive command line |
| `compare_engines.py` | Sequential replay of one brief and identical feedback |
| `tests/` | Offline policy, duration, prompt and adapter contract tests |

The low-level native safety code is necessarily longer; the writing path no longer
contains server provisioning or telemetry plumbing.

## Duration rules

Default speaking rate: **130 words/minute**. Default tolerance: **±10%**.
These are configurable assumptions, not an empirically measured rate for your speaker.

```text
target_words = round_half_up(duration_seconds × speaking_rate_wpm / 60)
minimum_words = floor(target_words × (1 − duration_tolerance))
maximum_words = ceil(target_words × (1 + duration_tolerance))
estimated_seconds = measured_words × 60 / speaking_rate_wpm
```

For 180 seconds at 130 words/minute: target **390**, accepted band **351–429**.
Decimal arithmetic prevents binary floating-point rounding from adding an extra word.
Targets must be 20–20,000 words. Rates must be 40–300 words/minute; tolerance 0–0.5.
The band is clamped to those word limits. Invalid or conflicting input fails before inference.

This is a narration estimate. Pauses, numbers, abbreviations, technical terms, and
delivery speed change actual duration. Calibrate with `words × 60 / measured_audio_seconds`
from a representative recording. Actual audio timing would require a TTS/recording step,
which this package does not add. Chinese/Japanese require a different segmentation policy;
the current word counter is intended for space-delimited languages such as English/Persian.

The target is approximate: unmet length is reported rather than hidden by truncation.
No extra generation runs automatically. Press Enter to request **one** local length repair
when needed, then inspect the new text before another round.

## Install without the old ensurepip failure

Extract this ZIP into a normal directory. Run commands there. Enable Kaggle Internet
and a GPU accelerator. One session uses exactly one CUDA GPU; another GPU is not required.
Do not load a second model onto the same GPU while comparing engines.

Parent/llama.cpp dependencies are small and do not replace Kaggle's Torch installation:

```bash
python -m pip install -r requirements.txt
```

For Kaggle, a notebook cell can use the current kernel interpreter:

```python
import subprocess, sys
subprocess.run([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'], check=True)
```

The native adapter retains the existing local `wrapt`/NVML repair and pinned CUDA runtime
setup. There is **no** call to `venv` or `ensurepip` in this package. Missing `wrapt` in an
isolated worker interpreter is fixed by installing its requirements **with that interpreter**;
installing it in another interpreter cannot fix that environment.

Use separate environments for Transformers and vLLM so their Torch requirements do not
fight. `uv` manages Python and seeds pip without relying on system `ensurepip`:

```bash
python -m pip install uv
uv venv --python 3.12 --managed-python --seed /kaggle/temp/qwen-transformers
uv pip install --python /kaggle/temp/qwen-transformers/bin/python -r requirements-transformers.txt
uv venv --python 3.12 --managed-python --seed /kaggle/temp/qwen-vllm
uv pip install --python /kaggle/temp/qwen-vllm/bin/python -r requirements-vllm.txt
```

These commands need Internet and substantial disk space for CUDA packages and model
weights. Allow installation/download time separately from generation time. On Windows,
use ordinary Windows paths for the Transformers environment. Native vLLM needs Linux/WSL.
Do not run `uv` commands from the blocked empty venv left by the earlier failed setup.

Dependencies: Transformers 5.13.0 (Qwen3.5 support), bitsandbytes 0.50.2,
accelerate 1.15.0; vLLM 0.31.0 plus its bitsandbytes plugin 0.0.3.
vLLM selects compatible Torch/Transformers dependencies in its own environment.
The Transformers Torch constraint is deliberately broad: record the resolved version
from `engine_settings.json`; align versions manually for stricter comparisons.
No custom remote model code is trusted, and optimized remote kernels are not downloaded.

## Run one engine

On Kaggle, the native runtime and verified GGUF download are automatic:

```bash
python run_pipeline.py --engine llama_cpp --duration-seconds 180
```

Outside Kaggle supply your compatible `llama-server` executable and GGUF:

```bash
python run_pipeline.py --engine llama_cpp --duration-seconds 180 --server /path/llama-server --gguf-model /path/Qwen3.5-9B-Q5_K_M.gguf
```

Use the Python worker environments explicitly:

```bash
python run_pipeline.py --engine transformers --duration-seconds 180 --worker-python /kaggle/temp/qwen-transformers/bin/python
python run_pipeline.py --engine vllm --duration-seconds 180 --worker-python /kaggle/temp/qwen-vllm/bin/python
```

Add `--sample file.txt`, `--source approved-reference.txt`, and `--point "Cover defect reporting"`
as needed. Repeat them to supply multiple inputs. Use `--speaking-rate-wpm 120`,
`--duration-tolerance 0.15`, `--gpu-index 1`, `--context-tokens 16384`, or
`--max-output-tokens 1600` explicitly. Text files use UTF-8.

Interactive commands:

| Input | Effect |
|---|---|
| Ordinary text | Quality instructions combined with measured length feedback; one revision |
| `/shorter` | Relative decrease against the immediately previous accepted text; clears numeric duration band |
| `/longer` | Relative increase against the immediately previous accepted text; clears numeric duration band |
| `/keep` | Preserve approximate length (±10% of prior accepted text); clears numeric duration band |
| `/duration 150` | New duration target using the configured speaking rate/tolerance; clears prior direction |
| Enter | Accept if length is met; otherwise request one length repair |
| `/done` | Accept without generation, even when length is unmet |

Directional satisfaction checks any decrease/increase; the prompt asks for a meaningful
change. You decide whether that change is sufficient. Commands are not mixed with quality
text in the same console entry; combine both through the Python API if needed.

## Python / notebook use

```python
from qwen_writer import EngineSettings, WritingSession, WritingRequest, Source

brief = WritingRequest(
    title='Maintenance of pipe handling systems',
    instructions='Write calm spoken training. Use only supported technical detail.',
    required_points=('Report defects.', 'Follow approved maintenance and return-to-service procedures.'),
    sources=(Source('site', 'Paste your verified manufacturer/site reference here.'),),
    duration_seconds=180,
    speaking_rate_wpm=130,
    duration_tolerance=0.10,
)
settings = EngineSettings(name='transformers',
    worker_python='/kaggle/temp/qwen-transformers/bin/python', context_tokens=32768)

with WritingSession(settings) as session:
    job = session.new_job(brief)
    first = job.draft()  # Full text printed; one completion.
    second = job.revise(quality_feedback='Make transitions more natural.')
    third = job.revise(length_direction='shorter')
    fourth = job.revise(duration_seconds=150, quality_feedback='Keep the maintenance sequence clear.')
    accepted = job.accept()  # No generation; later revise() calls remain allowed.
    print(accepted['estimated_duration_seconds'])
```

For separate notebook cells, enter the session explicitly, call `draft()` and `revise()`
in separate cells, and finish with `session.close()` in a `finally` block. Prefer a
`with` block in scripts for reliable cleanup. Keep a session open across briefs to
avoid reloading weights. `render=` accepts a callback receiving the full generation event.

New duration/range policy persists in later revisions. Omitted direction retains its
baseline; a newly supplied direction measures against the latest accepted text.
`duration_seconds=None` explicitly clears the numeric band. Invalid input consumes no
completion. If initial drafting fails, create a fresh job; if a revision fails, its
attempt is saved and the previous accepted text remains available.

## Model and precision

Selected model remains **Qwen3.5-9B**. Your earlier test favored its balance of coverage,
restraint and speed: initial draft 387 words, 34.1 s, approximately 6.651 GB sampled peak.
Those older drafts followed planning; they are not proof of direct one-shot performance.
It is a general model, not a verified worksite-safety fine-tune.

| Engine | Weight format | Compute / KV | Important difference |
|---|---|---|---|
| llama.cpp | Existing verified Q5_K_M GGUF | Native defaults; CPU KV by default | Preserves previously tested deployment, prefix reuse enabled |
| Transformers | Official Qwen9B quantized to BNB NF4 with double quantization | Hardware-selected FP16/BF16 / GPU cache | Full supported conditional-generation class used with text only; 512-token prefill chunks |
| vLLM | Official Qwen9B, BNB plugin in-flight 4-bit | Backend automatic dtype / GPU cache | Eager mode; bounded preallocated memory pool; 512-token prefill chunks |

HF revision is pinned to `c202236235762e1c871ad0ccb60c8ee5ba337b9a`.
Use `EngineSettings(hf_model=..., revision=...)` to change it deliberately.
Do not assume arbitrary prequantized repositories are compatible with these adapters.
The Transformers adapter currently expects the official full checkpoint and quantizes
it during loading; it does not implement exporting or reusing quantized checkpoints.

**This compares deployment stacks, not engine math in isolation.** Q5 versus NF4,
double-quantization settings, native kernels, KV placement, and prefix reuse can change
quality and speed. Equal seeds do not imply equal RNG sequences or identical text.
All engines receive the same raw messages; chat-template rendering can differ.
Transformers/vLLM save the rendered prompt hash and actual prompt-token count.
Native token admission uses its own tokenizer. Quantization and settings are recorded.
Transformers/vLLM prefix caching is disabled; llama.cpp preserves original prefix reuse.

## Compare quality and speed

```bash
python compare_engines.py --output comparison_run_01 --duration-seconds 180 --transformers-python /kaggle/temp/qwen-transformers/bin/python --vllm-python /kaggle/temp/qwen-vllm/bin/python
```

All three run **sequentially** on the selected GPU. Each receives the same fictional
maintenance brief and the same feedback sequence: natural transitions, shorter text,
then a 150-second request with an editorial instruction. Full texts and round logs are
saved under separate engine directories. The script stops on an engine failure: inspect
its logs and fix it before another engine is started. It does not hide unsupported engines
or substitute another model. Unique output folders prevent overwriting prior results.

`comparison.csv` includes elapsed seconds, output tokens, output tokens per end-to-end
second, peak total-device GB and a blank user quality score. This throughput includes
admission, IPC/HTTP, prefill and decoding; it is **not pure decode throughput or TTFT**.
Startup/model download is outside generation latency, but loading remains monitored.
Python engines save startup seconds separately. Inspect native server startup logs for
the native load phase. Cold first calls and later calls should be compared separately.
Run multiple independent sessions/seeds for statistical confidence; no hidden warmup is used.

Assess one-shot quality first: source fidelity, required coverage, natural spoken prose,
sample copying, and duration adherence. Score initial drafts separately from revisions.
For an optional aggregate score, give initial draft quality twice the weight of revised
quality, but retain the individual scores and latency/memory columns. This package
does not pretend to know which engine writes better until you review generated outputs.

## VRAM and long context

All GB figures are **decimal**, so 10.5 GB = 10,500,000,000 bytes.
Continuous NVML sampling starts before model loading and ends after worker termination.
Every generation round has boundary samples and a 10 ms periodic trace. Total device
usage includes other processes; per-process usage may be unavailable or, for vLLM,
exclude engine descendants. **Use total-device peak for your constraint.**

The abort threshold is `min(10.5 GB, device capacity) − 1.5 GB`, normally **9.0 GB**.
Python engines reserve another 0.5 GB when computing their allocator/pool budget:

```text
memory_fraction = min(0.8, (guard − existing_device_usage − 0.5 GB) / device_capacity)
```

Transformers applies this fraction to Torch's caching allocator before model loading;
vLLM receives it as `gpu_memory_utilization`. This avoids a default 90% device
reservation. Workers see only the selected GPU UUID, use no tensor parallelism, and
use a shared OS device lock with llama.cpp. Guard/telemetry failure kills the owned
worker process tree. Cleanup is confirmed before a session releases its device lock.

**Polling is reactive and is not a hard hardware VRAM cap.** Brief allocation transients,
non-Torch allocations and unrelated programs can outrun the guard. The package explicitly
logs `hard_vram_cap_guaranteed=false`. If an absolute never-exceed ceiling is essential,
this software-only design cannot guarantee it. Keep the conservative headroom.

Default active context is 32,768 tokens, with prompt + requested output + 16 reserved
tokens admitted before generation. Nothing truncates your brief silently. KV/recurrent
caches and activations consume memory in addition to weights. Transformers prefill is
chunked to limit temporary activation size; its per-pass cache is not retained for later
drafts. An incompatible kernel or insufficient memory is an explicit failure.

There is **no T4-specific optimization profile**. Attention backends use library
selection. Transformers `dtype=auto` chooses BF16 when the GPU reports support and
FP16 otherwise; vLLM receives its native `dtype=auto`. Override Python-engine precision
with `EngineSettings(dtype='float16')` or `--dtype float16` when appropriate for your
hardware. Native GGUF computation retains its existing settings and ignores this
Python-engine dtype option. The conservative chunk size/eager mode serve the memory
constraint, not a particular GPU architecture.

Hardware compatibility is **not proven by these offline tests**. The supported full
Transformers wrapper also loads its unused vision weights. Qwen's DeltaNet reference
fallback may be slower and use more memory than optimized kernels. vLLM's Qwen3.5/BNB/
hybrid kernels can fail on a particular GPU/build. There is no automatic architecture,
model or context downgrade.

Try a smaller explicit active context if loading/prefill fails under the guard, or keep
the tested native engine with CPU KV. Optional native GPU KV (`--kv-cache-device gpu`)
uses more VRAM and needs measurement. No backend speed advantage is promised beforehand.

## Outputs and troubleshooting

- `jobs/<id>/NN_draft.txt`, `NN_revision_N.txt`: every raw generation text, including failed partial output when returned.
- `jobs/<id>/job.json`, `passes.json`: latest accepted state and all generation events.
- `round_inputs/`, `round_outputs/`: exact raw prompts, sampler values, responses and usage.
- `rounds.csv`, `rounds.jsonl`, `round_validation.jsonl`: timing, sampled peak and output acceptance.
- `nvml_samples.csv`: continuous load/generation/shutdown trace.
- `engine_settings.json`, `memory_report.json`: Python-engine configuration, installed versions and lifecycle peak.
- `engine.log` or `llama-server.log`: library/native diagnostics.
- `startup_error.json`: setup failure with traceback. Runtime JSON logs are generated outputs, not bundled manifests.

`ModuleNotFoundError: wrapt`: install requirements with the failing interpreter.
`Error in sitecustomize`: Python workers remove inherited PYTHONPATH/PYTHONHOME; the
line protocol also ignores unmarked startup messages. Check `engine.log` and whether
you accidentally reused the earlier broken environment.
NVML unavailable/UUID changed: measurement fails closed; no unmeasured GPU run proceeds.
Context overflow: shorten inputs or set a smaller output-token budget deliberately.
`finish_reason=length`: partial text is displayed/saved but rejected; increase output
budget before another human-requested round. Never accept silent output truncation.
Memory guard/OOM: stop competing GPU jobs, inspect the total-device trace, and reduce
context explicitly. Do not raise the 9 GB guard merely to make a benchmark pass.
Another pipeline owns GPU: close its session first. Never delete the lock to evade it.

## Verification and limits

```bash
python -m pip install -r tests/requirements.txt
python -m pytest tests -q
```

Tests cover one-call drafting, unlimited revisions, latest-policy persistence,
relative baselines, immutable source context, failure preservation, exact prompt
compatibility, duration rounding/validation, context admission, memory budgeting,
lazy imports and adapter sampler/configuration contracts. They run without CUDA or
model downloads. **47 offline tests pass.** They do **not** prove GPU fit, kernel
compatibility, generated quality, or a hard memory ceiling. This delivery has not run
Transformers/vLLM GPU inference.

## Primary implementation references

- [Qwen3.5 official model](https://huggingface.co/Qwen/Qwen3.5-9B)
- [Transformers Qwen3.5 classes and kernel caveats](https://huggingface.co/docs/transformers/v5.13.0/model_doc/qwen3_5)
- [Transformers bitsandbytes quantization](https://huggingface.co/docs/transformers/quantization/bitsandbytes)
- [vLLM bitsandbytes plugin](https://docs.vllm.ai/en/stable/features/quantization/bnb/)
- [vLLM GPU requirements](https://docs.vllm.ai/en/stable/getting_started/installation/gpu/)
- [vLLM attention backends](https://docs.vllm.ai/en/stable/design/attention_backends/)
- [Pinned llama.cpp server API](https://github.com/ggml-org/llama.cpp/blob/b11384/tools/server/README.md)

All example references are fictional. Replace them with verified equipment-specific
documents before reviewing a real worksite training draft.
