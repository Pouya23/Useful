"""Replay the same maintenance brief and feedback sequentially on each engine.

Quality is for human inspection. This script does not invent model self-scores.
Worker interpreters can differ to avoid conflicting Torch requirements.
"""

import argparse
import csv
from dataclasses import replace
from pathlib import Path
from maintenance_example import BRIEF
from qwen_writer import EngineSettings, WritingSession


FEEDBACK = (
    {
        "quality_feedback": "Make transitions smoother and the voice more natural. Preserve the supported safety content."
    },
    {"length_direction": "shorter"},
    {
        "duration_seconds": 150,
        "quality_feedback": "Keep the maintenance sequence clear and avoid repetitive phrasing.",
    },
)


def compare(settings_list, output, *, duration_seconds=180):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    brief = replace(BRIEF, duration_seconds=duration_seconds)
    summary = []
    for settings in settings_list:
        engine_output = output / settings.name
        # No concurrent models: the previous with block confirms cleanup first.
        with WritingSession(settings, output=engine_output) as session:
            job = session.new_job(brief)
            job.draft()
            for feedback in FEEDBACK:
                job.revise(**feedback)  # Exactly one call, unless no change is needed.
            job.accept()
            for pass_number, event in enumerate(job.calls, 1):
                usage = event.get("usage", {})
                elapsed = event["latency_seconds"]
                tokens = usage.get("completion_tokens")
                summary.append(
                    {
                        "engine": settings.name,
                        "stage": event["stage"],
                        "seconds": elapsed,
                        "output_tokens": tokens,
                        "output_tokens_per_end_to_end_second": tokens / elapsed
                        if tokens is not None and elapsed > 0
                        else None,
                        "peak_total_vram_gb": event["total_device_peak_gb"],
                        "text_file": str(job.output / f"{pass_number:02d}_{event['stage']}.txt"),
                        "quality_score_by_user": "",
                    }
                )
    with (output / "comparison.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    print("Comparison saved:", output / "comparison.csv")
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--duration-seconds", type=float, default=180)
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--server")
    parser.add_argument("--gguf-model")
    parser.add_argument("--transformers-python")
    parser.add_argument("--vllm-python")
    args = parser.parse_args()
    settings = [
        EngineSettings(
            name="llama_cpp", server=args.server, gguf_model=args.gguf_model, gpu_index=args.gpu_index
        ),
        EngineSettings(name="transformers", worker_python=args.transformers_python, gpu_index=args.gpu_index),
        EngineSettings(name="vllm", worker_python=args.vllm_python, gpu_index=args.gpu_index),
    ]
    compare(settings, args.output, duration_seconds=args.duration_seconds)


if __name__ == "__main__":
    main()
