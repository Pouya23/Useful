"""Readable command line: brief → draft → unlimited human feedback."""

import argparse
from pathlib import Path
from .requests import Source, WritingRequest
from .pipeline import review_interactively
from .session import WritingSession
from .engines.base import EngineSettings


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Qwen 9B: duration-based direct draft and unlimited revisions"
    )
    parser.add_argument("--engine", choices=["llama_cpp", "transformers", "vllm"], default="llama_cpp")
    parser.add_argument("--duration-seconds", type=float, required=True)
    parser.add_argument("--speaking-rate-wpm", type=float, default=130)
    parser.add_argument("--duration-tolerance", type=float, default=0.10)
    parser.add_argument("--title", default="Maintenance of pipe handling systems")
    parser.add_argument("--instructions", default="Write clear spoken training using the supplied sources.")
    parser.add_argument("--point", action="append", default=[])
    parser.add_argument("--sample", type=Path, action="append", default=[])
    parser.add_argument("--source", type=Path, action="append", default=[])
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--context-tokens", type=int, default=32768)
    parser.add_argument("--max-output-tokens", type=int)
    parser.add_argument("--worker-python")
    parser.add_argument("--dtype", choices=["auto", "float16", "bfloat16"], default="auto")
    parser.add_argument("--server")
    parser.add_argument("--gguf-model")
    parser.add_argument("--kv-cache-device", choices=["cpu", "gpu"], default="cpu")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    brief = WritingRequest(
        title=args.title,
        instructions=args.instructions,
        required_points=tuple(args.point),
        samples=tuple(p.read_text(encoding="utf-8-sig") for p in args.sample),
        sources=tuple(
            Source(f"source-{i}", p.read_text(encoding="utf-8-sig"), str(p))
            for i, p in enumerate(args.source, 1)
        ),
        duration_seconds=args.duration_seconds,
        speaking_rate_wpm=args.speaking_rate_wpm,
        duration_tolerance=args.duration_tolerance,
    )
    brief.validate()
    settings = EngineSettings(
        name=args.engine,
        gpu_index=args.gpu_index,
        context_tokens=args.context_tokens,
        worker_python=args.worker_python,
        dtype=args.dtype,
        server=args.server,
        gguf_model=args.gguf_model,
        kv_cache_device=args.kv_cache_device,
    )
    with WritingSession(settings, output=args.output) as session:
        job = session.new_job(brief, max_output_tokens=args.max_output_tokens)
        job.draft()
        final = review_interactively(job)
        print("Estimated duration:", round(final["estimated_duration_seconds"], 1), "seconds")
        print("Saved texts and round metrics:", session.output)
    return 0
