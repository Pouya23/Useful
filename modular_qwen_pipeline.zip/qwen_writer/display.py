"""Print every draft and revision in full."""

from __future__ import annotations


def display_pass(event: dict) -> None:
    peak = event.get("total_device_peak_gb")
    peak_label = f"{peak:.3f} GB" if peak is not None else "unavailable"
    print(
        f"\n{event['stage']} | {event['status']} | {event['latency_seconds']:.1f} s | "
        f"sampled peak total VRAM {peak_label}",
        flush=True,
    )
    print(event.get("text") or "[No output returned]", flush=True)
    if event.get("error"):
        print("ERROR:", event["error"]["message"], flush=True)
