"""Hardware-selected computation / NF4 weights, with bounded chunked prefill."""

import hashlib
import time
from .base import admit


class TransformersEngine:
    def __init__(self, settings, memory_fraction):
        import torch
        from transformers import AutoTokenizer, BitsAndBytesConfig, Qwen3_5ForConditionalGeneration

        self.torch = torch
        self.settings = settings
        self.effective_context_size = settings.context_tokens
        if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
            raise RuntimeError("The worker must see exactly one CUDA GPU")
        torch.cuda.set_per_process_memory_fraction(memory_fraction, 0)
        use_bfloat16 = settings.dtype == "bfloat16" or (
            settings.dtype == "auto" and torch.cuda.is_bf16_supported()
        )
        compute_dtype = torch.bfloat16 if use_bfloat16 else torch.float16
        self.compute_dtype_name = "bfloat16" if use_bfloat16 else "float16"
        self.tokenizer = AutoTokenizer.from_pretrained(
            settings.hf_model, revision=settings.revision, trust_remote_code=False
        )
        quantization = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=compute_dtype,
            bnb_4bit_use_double_quant=True,
        )
        self.model = Qwen3_5ForConditionalGeneration.from_pretrained(
            settings.hf_model,
            revision=settings.revision,
            trust_remote_code=False,
            quantization_config=quantization,
            dtype=compute_dtype,
            device_map={"": 0},
        ).eval()
        if any(str(device) not in {"0", "cuda:0"} for device in self.model.hf_device_map.values()):
            raise RuntimeError("CPU/disk offload or multiple GPUs are not allowed")

    def prompt_ids(self, messages):
        rendered = self.tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True, enable_thinking=False
        )
        ids = self.tokenizer(rendered, add_special_tokens=False, return_tensors="pt")["input_ids"]
        return rendered, ids

    def prompt_tokens(self, messages):
        return self.prompt_ids(messages)[1].shape[1]

    def complete(self, messages, *, max_tokens, temperature, top_p, top_k, seed, json_schema=None):
        if json_schema is not None:
            raise ValueError("This writing pipeline does not request JSON generation")
        torch = self.torch
        rendered, input_ids = self.prompt_ids(messages)
        prompt_count = input_ids.shape[1]
        admit(prompt_count, max_tokens, self.effective_context_size)
        input_ids = input_ids.to("cuda:0")
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        started = time.perf_counter()
        # Cache only this pass. Exclude the last token so generate() always has
        # one uncached input token and never repeats the full prompt prefill.
        cache = None
        with torch.inference_mode():
            for start in range(0, prompt_count - 1, self.settings.prefill_chunk_tokens):
                end = min(start + self.settings.prefill_chunk_tokens, prompt_count - 1)
                output = self.model(
                    input_ids=input_ids[:, start:end],
                    position_ids=torch.arange(start, end, device="cuda:0").view(1, 1, -1).expand(4, 1, -1),
                    attention_mask=torch.ones((1, end), device="cuda:0", dtype=torch.long),
                    past_key_values=cache,
                    use_cache=True,
                    logits_to_keep=1,
                )
                cache = output.past_key_values
                del output
            generated = self.model.generate(
                input_ids=input_ids,
                attention_mask=torch.ones_like(input_ids),
                past_key_values=cache,
                max_new_tokens=max_tokens,
                do_sample=True,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                min_p=0.0,
                repetition_penalty=1.0,
                use_cache=True,
                return_dict_in_generate=False,
                logits_to_keep=1,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - started
        new_tokens = generated[0, prompt_count:].tolist()
        eos = self.model.generation_config.eos_token_id
        eos_ids = {eos} if isinstance(eos, int) else set(eos or [])
        finish = "stop" if new_tokens and new_tokens[-1] in eos_ids else "length"
        result = {
            # Preserve unexpected control/thinking tokens for shared validation.
            "text": self.tokenizer.decode(
                new_tokens[:-1] if finish == "stop" else new_tokens, skip_special_tokens=False
            ),
            "finish_reason": finish,
            "usage": {"prompt_tokens": prompt_count, "completion_tokens": len(new_tokens)},
            "rendered_prompt_sha256": hashlib.sha256(rendered.encode()).hexdigest(),
            "engine_seconds": elapsed,
            "quantization": "bitsandbytes NF4 double quant; " + self.compute_dtype_name + " compute",
            "prefix_cache": False,
        }
        del generated, cache, input_ids
        return result

    def close(self):
        del self.model
        self.torch.cuda.empty_cache()
