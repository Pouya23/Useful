"""Single-GPU eager vLLM with an explicit memory budget and NF4 weights."""

import hashlib
import time
from .base import admit


class VllmEngine:
    def __init__(self, settings, memory_fraction):
        import sys

        if sys.platform != "linux":
            raise RuntimeError("vLLM requires Linux (Kaggle or Linux/WSL), not native Windows")
        from transformers import AutoTokenizer
        from vllm import LLM

        self.settings = settings
        self.effective_context_size = settings.context_tokens
        self.tokenizer = AutoTokenizer.from_pretrained(
            settings.hf_model, revision=settings.revision, trust_remote_code=False
        )
        self.model = LLM(
            model=settings.hf_model,
            revision=settings.revision,
            tokenizer_revision=settings.revision,
            dtype=settings.dtype,
            quantization="bitsandbytes",
            tensor_parallel_size=1,
            max_model_len=settings.context_tokens,
            max_num_seqs=1,
            max_num_batched_tokens=settings.prefill_chunk_tokens,
            enable_chunked_prefill=True,
            enforce_eager=True,
            enable_prefix_caching=False,
            gpu_memory_utilization=memory_fraction,
            trust_remote_code=False,
            limit_mm_per_prompt={"image": 0, "video": 0},
        )

    def prompt_ids(self, messages):
        rendered = self.tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True, enable_thinking=False
        )
        return rendered, self.tokenizer.encode(rendered, add_special_tokens=False)

    def prompt_tokens(self, messages):
        return len(self.prompt_ids(messages)[1])

    def complete(self, messages, *, max_tokens, temperature, top_p, top_k, seed, json_schema=None):
        from vllm import SamplingParams

        if json_schema is not None:
            raise ValueError("This writing pipeline does not request JSON generation")
        rendered, ids = self.prompt_ids(messages)
        admit(len(ids), max_tokens, self.effective_context_size)
        sampling = SamplingParams(
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            min_p=0.0,
            seed=seed,
            repetition_penalty=1.0,
            skip_special_tokens=False,
        )
        started = time.perf_counter()
        results = self.model.generate([{"prompt_token_ids": ids}], sampling, use_tqdm=False)
        elapsed = time.perf_counter() - started
        output = results[0].outputs[0]
        return {
            "text": output.text,
            "finish_reason": output.finish_reason,
            "usage": {"prompt_tokens": len(ids), "completion_tokens": len(output.token_ids)},
            "rendered_prompt_sha256": hashlib.sha256(rendered.encode()).hexdigest(),
            "engine_seconds": elapsed,
            "quantization": "vLLM bitsandbytes in-flight 4bit",
            "prefix_cache": False,
        }

    def close(self):
        # Worker process exit is the authoritative cleanup for vLLM subprocesses.
        del self.model
