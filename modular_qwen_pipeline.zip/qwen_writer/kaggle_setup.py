"""Pinned, verified llama.cpp CUDA provisioning for Kaggle Linux x86-64.

This module never installs a driver, replaces PyTorch, or falls back to CPU.
``auto`` selects the official CUDA 12.8 release only on a sufficiently new
glibc/driver; otherwise it builds the same pinned source for T4 compute 7.5.
The CUDA release uses PTX for T4, making the driver check material.
"""

from __future__ import annotations

import ctypes
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import tarfile
import time
import uuid
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.request import Request, urlopen

TAG = "b11384"
COMMIT = "0faee5004297c3bcfa40b7bf11750127b8c1fd7d"
SOURCE_URL = f"https://codeload.github.com/ggml-org/llama.cpp/legacy.tar.gz/{COMMIT}"
SOURCE_SHA256 = "67c10b895e534bac0cf6ce107e08570f13a3e66d5550eef927cc74e03b2bebf7"
SOURCE_BYTES = 37_835_518
RELEASE_BASE = f"https://github.com/ggml-org/llama.cpp/releases/download/{TAG}"
ASSETS = {
    "binary": {
        "name": f"llama-{TAG}-bin-ubuntu-cuda-12.8-x64.tar.gz",
        "bytes": 171_530_284,
        "sha256": "0e68726d4cbdce6242955eddcfe1cc9e5dbb86e79b7a255f3d6946c25dae5ded",
    },
    "cudart": {
        "name": f"cudart-llama-{TAG}-bin-ubuntu-cuda-12.8-x64.tar.gz",
        "bytes": 594_377_730,
        "sha256": "989d43829ddb3e4d1e15dccbfad62107f02c032c684ac6eac2422708982cd8c7",
    },
}
SOURCES = {
    "release": f"https://github.com/ggml-org/llama.cpp/releases/tag/{TAG}",
    "build": f"https://github.com/ggml-org/llama.cpp/blob/{TAG}/docs/build.md",
    "workflow": f"https://github.com/ggml-org/llama.cpp/blob/{TAG}/.github/workflows/release.yml",
    "architectures": f"https://github.com/ggml-org/llama.cpp/blob/{TAG}/ggml/src/ggml-cuda/CMakeLists.txt",
    "kaggle": "https://www.kaggle.com/docs/notebooks",
    "cuda": "https://docs.nvidia.com/deploy/cuda-compatibility/latest/minor-version-compatibility.html",
}


class SetupFailure(RuntimeError):
    """The pinned CUDA backend could not be prepared or verified."""


def version_tuple(value: str) -> tuple[int, ...]:
    found = re.search(r"\d+(?:\.\d+)+", value)
    return tuple(map(int, found.group().split("."))) if found else ()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _member_path(name: str) -> PurePosixPath:
    # Tar paths are POSIX, including on Windows during local validation.
    part = PurePosixPath(name)
    if not name or "\\" in name or part.is_absolute() or ".." in part.parts or re.match(r"^[A-Za-z]:", name):
        raise SetupFailure(f"Unsafe archive path: {name!r}")
    return part


def safe_extract_tar(archive: Path, destination: Path, *, materialize_links: bool = False) -> None:
    """Extract after validating every member; links are never created.

    Links are rejected by default. Official shared-library release archives can
    explicitly materialize safe internal links as independent regular files.
    Absolute targets, traversal, dangling links and link cycles still fail.
    """
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:gz") as bundle:
        members = bundle.getmembers()
        by_name: dict[str, tarfile.TarInfo] = {}
        for member in members:
            part = _member_path(member.name)
            key = str(part)
            if key in by_name:
                raise SetupFailure(f"Duplicate archive path: {member.name!r}")
            by_name[key] = member
            if not (member.isfile() or member.isdir() or member.issym() or member.islnk()):
                raise SetupFailure(f"Unsupported special archive member: {member.name!r}")
            if (member.issym() or member.islnk()) and not materialize_links:
                raise SetupFailure(f"Archive links are disabled: {member.name!r}")
            target = destination.joinpath(*part.parts)
            if not target.resolve().is_relative_to(destination):
                raise SetupFailure(f"Archive destination escapes extraction root: {member.name!r}")
            if target.exists() or target.is_symlink():
                raise SetupFailure(f"Extraction destination already exists: {target}")

        def regular_target(member: tarfile.TarInfo, seen: set[str]) -> tarfile.TarInfo:
            key = str(_member_path(member.name))
            if key in seen:
                raise SetupFailure(f"Archive link cycle: {member.name!r}")
            if member.isfile():
                return member
            if not (member.issym() or member.islnk()):
                raise SetupFailure(f"Archive link does not resolve to a file: {member.name!r}")
            link = _member_path(member.linkname)
            link_key = str(PurePosixPath(key).parent / link) if member.issym() else str(link)
            target_member = by_name.get(link_key)
            if target_member is None:
                raise SetupFailure(f"Dangling archive link: {member.name!r}")
            return regular_target(target_member, seen | {key})

        # Resolve all links before creating any file, including malformed late entries.
        resolved = {
            str(_member_path(member.name)): regular_target(member, set())
            for member in members
            if not member.isdir()
        }
        for member in members:
            target = destination.joinpath(*_member_path(member.name).parts)
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with bundle.extractfile(resolved[str(_member_path(member.name))]) as source:
                with target.open("xb") as output:
                    shutil.copyfileobj(source, output, 1024 * 1024)
            # Strip setuid/setgid/sticky bits; retain executable permissions.
            target.chmod(member.mode & 0o777)


def ensure_extracted(
    archive: Path, destination: Path, checksum: str, *, materialize_links: bool = False
) -> None:
    """Publish complete extractions atomically; interrupted directories are not reused.

    Legacy/partial destinations are preserved alongside the new extraction.
    No recursive deletion or overwriting of an unmarked directory is required.
    """
    destination = Path(destination).absolute()
    parent = destination.parent.resolve()
    if destination.is_symlink() or destination.resolve().parent != parent:
        raise SetupFailure(
            "Extraction destination must be a direct, nonsymlink child of its runtime directory"
        )
    marker = destination / ".extraction.json"
    try:
        saved = json.loads(marker.read_text(encoding="utf-8"))
        sizes = saved.get("files", {})
        if (
            saved.get("archive_sha256") == checksum
            and saved.get("materialize_links") is materialize_links
            and isinstance(sizes, dict)
            and sizes
            and all(
                (destination / name).resolve().is_relative_to(destination.resolve())
                and not (destination / name).is_symlink()
                and (destination / name).is_file()
                and (destination / name).stat().st_size == size
                for name, size in sizes.items()
            )
        ):
            return
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    staging = parent / ("." + destination.name + ".extract-" + uuid.uuid4().hex)
    safe_extract_tar(archive, staging, materialize_links=materialize_links)
    sizes = {
        path.relative_to(staging).as_posix(): path.stat().st_size
        for path in staging.rglob("*")
        if path.is_file()
    }
    if not sizes:
        raise SetupFailure("Runtime archive contains no regular files")
    (staging / ".extraction.json").write_text(
        json.dumps(
            {"archive_sha256": checksum, "materialize_links": materialize_links, "files": sizes},
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    if destination.exists():
        backup = parent / ("." + destination.name + ".incomplete-" + uuid.uuid4().hex)
        destination.rename(backup)
    staging.rename(destination)


def _download_verified(url: str, destination: Path, size: int, checksum: str) -> dict[str, Any]:
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file():
        if destination.stat().st_size == size and sha256_file(destination) == checksum:
            return {"url": url, "path": str(destination), "bytes": size, "sha256": checksum, "cached": True}
        raise SetupFailure(f"Cached runtime archive failed integrity verification: {destination}")
    partial = destination.with_name(destination.name + ".part")
    if partial.exists():
        partial.unlink()  # Owned bootstrap partial only; no model cache is touched.
    if shutil.disk_usage(destination.parent).free < size + 1_000_000_000:
        raise SetupFailure("Insufficient free disk space for pinned runtime download")
    started = time.monotonic()
    request = Request(url, headers={"User-Agent": "worksite-writing-kaggle/1.0"})
    digest = hashlib.sha256()
    written = 0
    try:
        with urlopen(request, timeout=90) as response, partial.open("xb") as output:
            while True:
                block = response.read(8 * 1024 * 1024)
                if not block:
                    break
                written += len(block)
                if written > size:
                    raise SetupFailure("Pinned runtime download is larger than its expected byte count")
                digest.update(block)
                output.write(block)
                if time.monotonic() - started > 1800:
                    raise SetupFailure("Pinned runtime download exceeded its 30-minute deadline")
        if written != size or digest.hexdigest() != checksum:
            raise SetupFailure(f"Pinned runtime archive failed SHA256/byte verification: {destination.name}")
        partial.replace(destination)
    except BaseException:
        if partial.exists():
            partial.unlink()
        raise
    return {"url": url, "path": str(destination), "bytes": size, "sha256": checksum, "cached": False}


def _run(
    command: list[str], *, env: dict[str, str] | None = None, timeout: float = 60, log: Path | None = None
) -> str:
    if log is None:
        result = subprocess.run(
            command,
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            check=False,
        )
        if result.returncode:
            raise SetupFailure(f"Command failed ({result.returncode}): {command[0]}\n{result.stdout[-4000:]}")
        return result.stdout
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("w", encoding="utf-8") as output:
        output.write(json.dumps(command) + "\n")
        output.flush()
        result = subprocess.run(
            command, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=timeout, check=False
        )
    if result.returncode:
        raise SetupFailure(f"Command failed ({result.returncode}); inspect {log}")
    return str(log)


def probe_environment() -> dict[str, Any]:
    """Read the actual session; notebook quotas and images can change."""
    glibc = platform.libc_ver()[1]
    if platform.system() == "Linux":
        try:
            libc = ctypes.CDLL("libc.so.6")
            libc.gnu_get_libc_version.restype = ctypes.c_char_p
            glibc = libc.gnu_get_libc_version().decode("ascii")
        except (OSError, AttributeError):
            pass
    smi = _run(["nvidia-smi"], timeout=30)
    query = _run(
        [
            "nvidia-smi",
            "--query-gpu=index,uuid,name,driver_version,memory.total",
            "--format=csv,noheader,nounits",
        ],
        timeout=30,
    )
    gpus = []
    for line in query.strip().splitlines():
        values = [value.strip() for value in line.split(",")]
        if len(values) != 5:
            raise SetupFailure("Could not parse NVIDIA device inventory")
        index, uuid, name, driver, memory_mib = values
        gpus.append(
            {
                "index": int(index),
                "uuid": uuid,
                "name": name,
                "driver": driver,
                "total_bytes": int(memory_mib) * 1_048_576,
            }
        )
    cuda_match = re.search(r"CUDA Version:\s*([\d.]+)", smi)
    nvcc = shutil.which("nvcc")
    candidates = [Path(nvcc)] if nvcc else []
    candidates.extend(Path("/usr/local").glob("cuda*/bin/nvcc"))
    toolkits: list[dict[str, str]] = []
    seen: set[Path] = set()
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved in seen or not resolved.is_file():
            continue
        seen.add(resolved)
        output = _run([str(resolved), "--version"], timeout=30)
        match = re.search(r"release\s+(\d+\.\d+)", output)
        if match:
            toolkits.append({"path": str(resolved), "version": match.group(1), "version_output": output})
    memory: dict[str, int] = {}
    if Path("/proc/meminfo").is_file():
        for line in Path("/proc/meminfo").read_text().splitlines():
            match = re.match(r"(MemTotal|MemAvailable):\s*(\d+)\s+kB", line)
            if match:
                memory[match.group(1)] = int(match.group(2)) * 1024
    return {
        "system": platform.system(),
        "machine": platform.machine(),
        "glibc": glibc,
        "driver_cuda_max": cuda_match.group(1) if cuda_match else "",
        "gpus": gpus,
        "nvcc": nvcc,
        "cuda_toolkits": toolkits,
        "nvcc_version": toolkits[0]["version"] if toolkits else "",
        "cpu_count": os.cpu_count(),
        "host_memory": memory,
        "nvidia_smi": smi,
        "nvcc_version_output": toolkits[0]["version_output"] if toolkits else "",
    }


def select_cuda12_toolkit(environment: dict[str, Any]) -> dict[str, str]:
    """CUDA 13 dropped T4 offline compilation; choose an installed CUDA 12.

    Prefer a toolkit no newer than the driver's advertised CUDA API, then the
    newest installed CUDA 12 (native sm_75 avoids a newer PTX JIT requirement).
    No toolkit or driver is downloaded or replaced.
    """
    candidates = [
        toolkit
        for toolkit in environment.get("cuda_toolkits", [])
        if (12, 0) <= version_tuple(toolkit.get("version", "")) < (13, 0)
    ]
    # Keep compatibility with a caller supplying the previous environment schema.
    if (
        not candidates
        and environment.get("nvcc")
        and (12, 0) <= version_tuple(str(environment.get("nvcc_version", ""))) < (13, 0)
    ):
        candidates = [
            {
                "path": environment["nvcc"],
                "version": environment["nvcc_version"],
                "version_output": environment.get("nvcc_version_output", ""),
            }
        ]
    if not candidates:
        raise SetupFailure(
            "T4 source compilation requires an installed CUDA 12.x toolkit; CUDA 13 removed "
            "sm_75 compilation. This notebook does not install toolkits or drivers. "
            "Use a Kaggle image with CUDA 12 or a compatible prebuilt runtime."
        )
    driver_max = version_tuple(str(environment.get("driver_cuda_max", "")))
    if driver_max and driver_max < (12, 0):
        raise SetupFailure(
            "The session's NVIDIA driver does not advertise CUDA 12 support; refusing "
            "to install or replace the managed Kaggle driver"
        )
    not_newer = [toolkit for toolkit in candidates if version_tuple(toolkit["version"]) <= driver_max]
    return max(not_newer or candidates, key=lambda toolkit: version_tuple(toolkit["version"]))


def prebuilt_compatible(environment: dict[str, Any]) -> tuple[bool, list[str]]:
    reasons = []
    if environment.get("system") != "Linux" or environment.get("machine") not in {"x86_64", "AMD64"}:
        reasons.append("official prebuilt requires Linux x86-64")
    if version_tuple(str(environment.get("glibc", ""))) < (2, 39):
        reasons.append("official Ubuntu 24.04 CUDA release requires glibc >= 2.39")
    if version_tuple(str(environment.get("driver_cuda_max", ""))) < (12, 8):
        reasons.append("T4 PTX from CUDA 12.8 requires a driver advertising CUDA >= 12.8")
    return not reasons, reasons


def _configure_library_path(server: Path, cuda_toolkit_path: str | None = None) -> dict[str, str]:
    env = dict(os.environ)
    directories = [str(server.parent)]
    if cuda_toolkit_path:
        toolkit = Path(cuda_toolkit_path).resolve().parent.parent
        for candidate in (toolkit / "lib64", toolkit / "targets" / "x86_64-linux" / "lib"):
            if candidate.is_dir():
                directories.append(str(candidate))
    # A source build uses toolkit libraries; release CUDA libs sit beside server.
    for candidate in (Path("/usr/local/cuda/lib64"), Path("/usr/local/cuda/targets/x86_64-linux/lib")):
        if candidate.is_dir():
            directories.append(str(candidate))
    old = env.get("LD_LIBRARY_PATH", "")
    env["LD_LIBRARY_PATH"] = ":".join(directories + ([old] if old else []))
    return env


def probe_runtime(server: Path, *, cuda_toolkit_path: str | None = None) -> dict[str, Any]:
    """Verify required flags and actual CUDA discovery; no model is loaded."""
    server = Path(server).resolve()
    env = _configure_library_path(server, cuda_toolkit_path)
    version = _run([str(server), "--version"], env=env, timeout=60)
    help_text = _run([str(server), "--help"], env=env, timeout=60)
    flags = set(re.findall(r"--[a-z][a-z0-9-]*", help_text))
    required = {
        "--fit",
        "--fit-target",
        "--device",
        "--split-mode",
        "--gpu-layers",
        "--no-kv-offload",
        "--no-op-offload",
        "--no-context-shift",
        "--jinja",
        "--reasoning",
        "--reasoning-budget",
        "--chat-template-kwargs",
        "--no-mmproj",
        "--log-verbosity",
        "--log-colors",
    }
    if required - flags:
        raise SetupFailure("Pinned runtime lacks pipeline flags: " + ", ".join(sorted(required - flags)))
    if "--list-devices" not in flags:
        raise SetupFailure("Pinned runtime cannot demonstrate GPU discovery")
    devices = _run([str(server), "--list-devices"], env=env, timeout=60)
    if not re.search(r"\bCUDA\d+\b", devices):
        raise SetupFailure("Runtime did not discover a CUDA device; refusing CPU fallback\n" + devices)
    return {
        "server": str(server),
        "server_sha256": sha256_file(server),
        "version": version,
        "devices": devices,
        "required_flags": sorted(required),
        "library_path": env["LD_LIBRARY_PATH"],
    }


def _prebuilt(root: Path, report: dict[str, Any]) -> Path:
    destination = root / "release"
    destination.mkdir(parents=True, exist_ok=True)
    for label, asset in ASSETS.items():
        archive = root / "archives" / asset["name"]
        report["downloads"].append(
            _download_verified(f"{RELEASE_BASE}/{asset['name']}", archive, asset["bytes"], asset["sha256"])
        )
        extracted = destination / label
        ensure_extracted(archive, extracted, asset["sha256"], materialize_links=True)
    servers = list((destination / "binary").rglob("llama-server"))
    if len(servers) != 1:
        raise SetupFailure("Official binary archive did not contain exactly one llama-server")
    server = servers[0]
    for name in ("libcudart.so.12", "libcublas.so.12", "libcublasLt.so.12"):
        matches = list((destination / "cudart").rglob(name))
        if len(matches) != 1:
            raise SetupFailure(f"Matching CUDA runtime archive does not contain {name}")
        target = server.parent / name
        if not target.exists():
            shutil.copy2(matches[0], target)
    return server


def _source(root: Path, environment: dict[str, Any], report: dict[str, Any], build_jobs: int) -> Path:
    toolkit = select_cuda12_toolkit(environment)
    nvcc = toolkit["path"]
    report["selected_cuda_toolkit"] = toolkit
    if not shutil.which("cmake") or not shutil.which("g++"):
        raise SetupFailure("Source mode requires the session's nvcc, cmake and g++; enable Kaggle GPU")
    archive = root / "archives" / f"llama-{COMMIT}.tar.gz"
    report["downloads"].append(_download_verified(SOURCE_URL, archive, SOURCE_BYTES, SOURCE_SHA256))
    extracted = root / "source"
    ensure_extracted(archive, extracted, SOURCE_SHA256)
    candidates = [
        child for child in extracted.iterdir() if child.is_dir() and (child / "CMakeLists.txt").is_file()
    ]
    if len(candidates) != 1:
        raise SetupFailure("Pinned source archive did not contain exactly one project root")
    source = candidates[0]
    build = root / "build-sm75"
    configure = [
        "cmake",
        "-S",
        str(source),
        "-B",
        str(build),
        "-DCMAKE_BUILD_TYPE=Release",
        "-DGGML_CUDA=ON",
        "-DCMAKE_CUDA_ARCHITECTURES=75-real",
        "-DGGML_NATIVE=OFF",
        f"-DCMAKE_CUDA_COMPILER={nvcc}",
        "-DBUILD_SHARED_LIBS=ON",
        "-DGGML_CUDA_NCCL=OFF",
        "-DLLAMA_OPENSSL=OFF",
        "-DLLAMA_BUILD_TESTS=OFF",
        "-DLLAMA_BUILD_EXAMPLES=OFF",
        "-DLLAMA_BUILD_TOOLS=ON",
        "-DLLAMA_BUILD_SERVER=ON",
        "-DLLAMA_BUILD_APP=OFF",
        "-DLLAMA_BUILD_UI=OFF",
        "-DLLAMA_USE_PREBUILT_UI=OFF",
        "-DCMAKE_INSTALL_RPATH=$ORIGIN",
        "-DCMAKE_BUILD_WITH_INSTALL_RPATH=ON",
        "-DLLAMA_BUILD_NUMBER=11384",
        f"-DLLAMA_BUILD_COMMIT={COMMIT[:7]}",
    ]
    report["configure_command"] = configure
    env = dict(os.environ)
    # No inherited llama.cpp/ggml switches may enable another backend implicitly.
    env = {
        key: value
        for key, value in env.items()
        if not key.upper().startswith(("LLAMA_ARG_", "GGML_", "MTMD_"))
    }
    _run(configure, env=env, timeout=600, log=root / "configure.log")
    compile_command = [
        "cmake",
        "--build",
        str(build),
        "--config",
        "Release",
        "--target",
        "llama-server",
        "--parallel",
        str(build_jobs),
    ]
    report["build_command"] = compile_command
    print(f"Building pinned llama.cpp {TAG} for T4 sm_75 with {build_jobs} jobs; logs: {root}", flush=True)
    _run(compile_command, env=env, timeout=3600, log=root / "build.log")
    server = build / "bin" / "llama-server"
    if not server.is_file():
        raise SetupFailure("Source build did not create llama-server")
    return server


def ensure_runtime(root: Path, mode: str = "auto", *, build_jobs: int = 2) -> tuple[Path, dict[str, Any]]:
    """Return (server path, report), also saving runtime_setup.json in root.

    ``auto`` makes a logged platform-dependent prebuilt/source choice. A failed
    prebuilt probe may retry the pinned CUDA source build, never a CPU backend.
    Set ``prebuilt`` or ``source`` to forbid the other provisioning route.
    """
    if mode not in {"auto", "prebuilt", "source"}:
        raise ValueError("mode must be auto, prebuilt or source")
    if isinstance(build_jobs, bool) or not isinstance(build_jobs, int) or not 1 <= build_jobs <= 4:
        raise ValueError("build_jobs must be an integer from 1 to 4")
    root = Path(root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    if platform.system() != "Linux" or platform.machine() not in {"x86_64", "AMD64"}:
        raise SetupFailure("Kaggle GPU provisioning requires Linux x86-64")
    report: dict[str, Any] = {
        "tag": TAG,
        "commit": COMMIT,
        "requested_mode": mode,
        "sources": SOURCES,
        "downloads": [],
        "status": "preparing",
    }
    report_path = root / "runtime_setup.json"
    started = time.monotonic()
    try:
        environment = probe_environment()
        report["environment"] = environment
        compatible, reasons = prebuilt_compatible(environment)
        report["prebuilt_compatible"] = compatible
        report["prebuilt_incompatibilities"] = reasons
        if len(environment["gpus"]) != 2 or any("T4" not in gpu["name"] for gpu in environment["gpus"]):
            raise SetupFailure("Select Kaggle accelerator T4 x2 before provisioning this notebook")
        if mode == "prebuilt" and not compatible:
            raise SetupFailure("Requested prebuilt runtime is incompatible: " + "; ".join(reasons))
        chosen = "prebuilt" if mode != "source" and compatible else "source"
        report["chosen_mode"] = chosen
        print(
            f"llama.cpp {TAG}: {chosen} CUDA provisioning" + ("; " + "; ".join(reasons) if reasons else ""),
            flush=True,
        )
        try:
            server = (
                _prebuilt(root, report)
                if chosen == "prebuilt"
                else _source(root, environment, report, build_jobs)
            )
            probe = probe_runtime(
                server, cuda_toolkit_path=report.get("selected_cuda_toolkit", {}).get("path")
            )
        except (SetupFailure, OSError, subprocess.TimeoutExpired) as exc:
            if mode != "auto" or chosen != "prebuilt":
                raise
            report["prebuilt_failure"] = str(exc)
            report["chosen_mode"] = "source"
            print("Prebuilt CUDA probe failed; building the same pinned source for sm_75.", flush=True)
            server = _source(root, environment, report, build_jobs)
            probe = probe_runtime(server, cuda_toolkit_path=report["selected_cuda_toolkit"]["path"])
        # Runtime subprocesses inherit this; no Python CUDA/Torch import is needed.
        os.environ["LD_LIBRARY_PATH"] = probe["library_path"]
        report["probe"] = probe
        report["status"] = "ready"
        report["elapsed_seconds"] = time.monotonic() - started
        report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        return server, report
    except BaseException as exc:
        report["status"] = "failed"
        report["error"] = f"{type(exc).__name__}: {exc}"
        report["elapsed_seconds"] = time.monotonic() - started
        report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        raise
