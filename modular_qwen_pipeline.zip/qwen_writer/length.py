"""Measured length feedback. No model calls."""

from __future__ import annotations
from .requests import (
    WritingError,
    count_words,
    direction_satisfied,
    normalize_direction,
)


def automatic_length_feedback(text: str, *, word_range=None, direction=None, baseline=None) -> dict:
    """Pure Python, no inference. Measured counts override a model's own estimates."""
    if not isinstance(text, str):
        raise WritingError("Text must be a string")
    words = count_words(text)
    direction = normalize_direction(direction)
    if word_range is not None:
        if (
            not isinstance(word_range, (tuple, list))
            or len(word_range) != 2
            or any(type(v) is not int for v in word_range)
            or not 20 <= word_range[0] <= word_range[1] <= 20000
        ):
            raise WritingError("word_range must satisfy 20 <= minimum <= maximum <= 20000")
    if direction is not None and (type(baseline) is not int or baseline <= 0):
        raise WritingError("Directional feedback requires a positive measured baseline")
    band_ok = word_range[0] <= words <= word_range[1] if word_range else None
    direction_ok = direction_satisfied(direction, baseline, words)
    action = "keep"
    if band_ok is False:
        action = "expand" if words < word_range[0] else "shorten"
    elif direction_ok is False:
        action = {"increase": "expand", "decrease": "shorten", "keep": "keep"}[direction]
    return {
        "measured_words": words,
        "word_range": list(word_range) if word_range else None,
        "target_words": sum(word_range) // 2 if word_range else None,
        "within_word_range": band_ok,
        "length_direction": direction,
        "baseline_words": baseline,
        "direction_satisfied": direction_ok,
        "automatic_action": action,
        "needs_length_revision": band_ok is False or direction_ok is False,
    }
