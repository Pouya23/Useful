"""Resident llama.cpp engine with the original CUDA guard and native admission."""

from __future__ import annotations
import atexit
import os
import subprocess
import sys
import uuid
from pathlib import Path
from .model import load_spec, resolve_model
from .requests import WritingError, WritingRequest
from .runtime import GB, LlamaServer, RuntimeConfig, RuntimeFailure
from .telemetry import MeasuredBackend, NvmlRecorder, error_record, parse_gpu_offload, save_json
from .pipeline import FastWritingJob
from .display import display_pass

PROFILE = "qwen35_9b"


class FastLlamaServer(LlamaServer):
    """Same native guard and admission; allow correct engine-managed prefix reuse."""

    def post(self, path, payload):
        if path == "/v1/chat/completions":
            payload = {**payload, "cache_prompt": True}
        return super().post(path, payload)

    def _build_command(self, flags):
        args = super()._build_command(flags)
        if self.config.device == "cuda" and self.config.kv_cache_device == "gpu":
            if "--op-offload" not in flags or "--flash-attn" not in flags:
                raise RuntimeFailure("GPU-cache speed mode requires --op-offload and --flash-attn")
            args[args.index("--no-op-offload")] = "--op-offload"
            args += ["--flash-attn", "auto"]
        return args


def _dependencies(directory: Path):
    """Small local installation; no venv, ensurepip, Transformers or Torch change."""
    directory.mkdir(parents=True, exist_ok=True)
    if str(directory) not in sys.path:
        sys.path.insert(0, str(directory))
    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join([str(directory), env.get("PYTHONPATH", "")])
    probe = "import wrapt,pynvml; print('FAST_STARTUP_OK')"
    result = subprocess.run(
        [sys.executable, "-c", probe], env=env, capture_output=True, text=True, timeout=30
    )
    if result.returncode or "Error in sitecustomize" in result.stdout + result.stderr:
        installation = subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "--no-deps",
                "--disable-pip-version-check",
                "--only-binary=:all:",
                "--upgrade",
                "--target",
                str(directory),
                "nvidia-ml-py==12.575.51",
                "wrapt==1.17.3",
            ],
            capture_output=True,
            text=True,
            timeout=300,
        )
        (directory / "installation.log").write_text(
            installation.stdout + "\n" + installation.stderr, encoding="utf-8"
        )
        if installation.returncode:
            raise RuntimeFailure("Dependency installation failed: " + installation.stderr[-3000:])
        result = subprocess.run(
            [sys.executable, "-c", probe], env=env, capture_output=True, text=True, timeout=30
        )
        if result.returncode or "Error in sitecustomize" in result.stdout + result.stderr:
            raise RuntimeFailure(
                "Python startup failed after local wrapt installation: " + result.stdout + result.stderr
            )
    os.environ["PYTHONPATH"] = env["PYTHONPATH"]


class FastQwenSession:
    """Resident best-model session; any number of jobs and feedback rounds."""

    def __init__(
        self,
        *,
        server: Path | str | None = None,
        model: Path | str | None = None,
        context_tokens: int = 32768,
        gpu_index: int = 0,
        kv_cache_device: str = "cpu",
        device: str = "cuda",
        output: Path | str | None = None,
        install_dependencies: bool = True,
        render=display_pass,
    ):
        if type(context_tokens) is not int or not 512 <= context_tokens <= 262144:
            raise WritingError("context_tokens must be 512..262144")
        if device not in {"cpu", "cuda"} or kv_cache_device not in {"cpu", "gpu"}:
            raise WritingError("Invalid device or kv_cache_device")
        if device != "cuda":
            raise WritingError(
                "FastQwenSession is the measured CUDA deployment; use FastWritingJob with a CPU backend for CPU tests"
            )
        if device == "cpu" and kv_cache_device != "cpu":
            raise WritingError("CPU inference requires the CPU KV cache")
        self.server_path = Path(server) if server else None
        self.model_path = Path(model) if model else None
        self.context_tokens, self.gpu_index = context_tokens, gpu_index
        self.kv_cache_device, self.device = kv_cache_device, device
        self.install_dependencies, self.render = install_dependencies, render
        self.output = (
            Path(output)
            if output
            else (
                Path("/kaggle/working/fast_qwen") if Path("/kaggle").is_dir() else Path("fast_qwen_results")
            )
            / uuid.uuid4().hex[:12]
        )
        self.native = self.recorder = self.backend = None
        self.closed = False
        self._entered = False
        self.jobs: list[FastWritingJob] = []

    def __enter__(self):
        if self.closed or self._entered:
            raise WritingError("A session cannot be re-entered")
        self._entered = True
        self.output.mkdir(parents=True, exist_ok=False)
        atexit.register(self.close)
        scratch = (
            Path("/kaggle/temp/pipe_maintenance_llm_lab")
            if Path("/kaggle").is_dir()
            else self.output / "runtime"
        )
        if self.device == "cuda" and self.install_dependencies:
            _dependencies(scratch / "python_dependencies")
        if self.server_path is None:
            if not Path("/kaggle").is_dir():
                executable = os.environ.get("LLAMA_SERVER")
                if not executable:
                    raise RuntimeFailure(
                        "Outside Kaggle, supply server=path_to_llama_server or set LLAMA_SERVER"
                    )
                self.server_path = Path(executable)
            else:
                from .kaggle_setup import ensure_runtime

                self.server_path, report = ensure_runtime(
                    Path("/kaggle/temp/worksite_llm_benchmark_runtime/llama_cpp")
                )
                save_json(self.output / "runtime_setup.json", report)
        model, provenance = resolve_model(
            load_spec(PROFILE),
            self.model_path or scratch / "models" / load_spec(PROFILE)["filename"],
            download=self.model_path is None,
        )
        save_json(self.output / "model_provenance.json", provenance)
        threads = (
            min(4, len(os.sched_getaffinity(0)))
            if hasattr(os, "sched_getaffinity")
            else min(4, os.cpu_count() or 1)
        )
        config = RuntimeConfig(
            server=self.server_path,
            model=model,
            context_size=self.context_tokens,
            device=self.device,
            gpu_index=self.gpu_index,
            kv_cache_device=self.kv_cache_device,
            vram_limit_gb=10.5,
            headroom_gb=1.5,
            threads=threads,
            startup_timeout=900,
            request_timeout=1800,
            expected_architecture="qwen35",
            log_path=self.output / "llama-server.log",
        )
        self.native = FastLlamaServer(config)
        import pynvml

        pynvml.nvmlInit()
        try:
            handle = pynvml.nvmlDeviceGetHandleByIndex(self.gpu_index)
            raw_uuid = pynvml.nvmlDeviceGetUUID(handle)
            gpu_uuid = raw_uuid.decode("ascii") if isinstance(raw_uuid, bytes) else raw_uuid
            threshold = min(10_500_000_000, pynvml.nvmlDeviceGetMemoryInfo(handle).total) - 1_500_000_000
        finally:
            pynvml.nvmlShutdown()
        try:
            self.recorder = NvmlRecorder(
                self.output / "nvml_samples.csv",
                self.gpu_index,
                gpu_uuid,
                lambda: self.native._process.pid if self.native._process is not None else None,
                failure_callback=self.native._kill_process,
                abort_threshold_bytes=threshold,
            )
            print(
                f"Loading only Qwen3.5 9B Q5_K_M; {self.context_tokens} context; KV={self.kv_cache_device}; "
                f"sampled guard={threshold / GB:.2f} GB",
                flush=True,
            )
            self.native.__enter__()
            if self.native.effective_context_size != self.context_tokens:
                raise RuntimeFailure(
                    "Native fitting changed the requested context; select CPU KV or set a smaller context explicitly"
                )
            self.backend = MeasuredBackend(self.native, self.recorder, self.output, PROFILE)
            self._ready()
            return self
        except BaseException as exc:
            save_json(self.output / "startup_error.json", error_record(exc))
            self.close()
            raise

    def _ready(self):
        if self.closed or self.backend is None:
            raise WritingError("Use the session inside its with block")
        self.recorder.check()
        self.native._check_failure()
        if self.backend.counter:
            evidence = parse_gpu_offload(
                self.native.config.log_path.read_text(encoding="utf-8", errors="replace")
            )
            if not evidence["valid_counts"] or not (evidence["offloaded_layers"] or 0) > 0:
                raise RuntimeFailure("Native log did not prove actual GPU tensor-layer offload")

    def new_job(self, request: WritingRequest, *, max_output_tokens=None, seed=42) -> FastWritingJob:
        self._ready()
        job = FastWritingJob(
            self.backend,
            request,
            self.output / "jobs" / uuid.uuid4().hex[:12],
            render=self.render,
            max_output_tokens=max_output_tokens,
            seed=seed,
            ready=self._ready,
        )
        self.jobs.append(job)
        return job

    def close(self):
        if self.closed:
            return
        if self.native is not None:
            self.native.close()  # Do not release the monitor before confirmed process termination.
        if self.backend is not None:
            self.backend.close()
        if self.recorder is not None:
            self.recorder.close()
        self.closed = True
        if self.output.is_dir():
            save_json(
                self.output / "lifecycle.json",
                {
                    "runtime": self.native.report() if self.native else None,
                    "memory": self.recorder.report() if self.recorder else None,
                    "server_terminated": self.native is None
                    or self.native._process is None
                    or self.native._process.poll() is not None,
                },
            )

    def __exit__(self, exc_type, exc, traceback):
        self.close()
