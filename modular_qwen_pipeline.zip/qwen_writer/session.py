"""Select an engine; keep it loaded across jobs and unlimited revisions."""

import atexit
import time
import uuid
from dataclasses import asdict
from pathlib import Path
from .display import display_pass
from .engines.base import EngineSettings
from .pipeline import FastWritingJob
from .process import WorkerClient
from .requests import WritingError
from .runtime import RuntimeFailure, _DeviceLock
from .telemetry import MeasuredBackend, NvmlRecorder, error_record, save_json


def memory_fraction(capacity, baseline, guard):
    # vLLM's budget includes weights, activations and its preallocated KV pool.
    # Leave additional headroom for libraries and external allocator activity.
    available = guard - baseline - 500_000_000
    if available <= 0:
        raise RuntimeFailure("No memory headroom remains under the sampled guard")
    return min(0.8, available / capacity)


class PythonEngineSession:
    def __init__(self, settings, *, output=None, render=display_pass, install_dependencies=False):
        settings.validate()
        self.settings = settings
        self.render = render
        self.output = Path(output) if output else Path("qwen_results") / uuid.uuid4().hex[:12]
        self.worker = self.recorder = self.backend = None
        self.closed = False
        self.entered = False
        self.lock_file = None

    def __enter__(self):
        if self.closed or self.entered:
            raise WritingError("A session cannot be re-entered")
        self.entered = True
        self.output.mkdir(parents=True, exist_ok=False)
        atexit.register(self.close)
        started = time.monotonic()
        try:
            import pynvml

            pynvml.nvmlInit()
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(self.settings.gpu_index)
                gpu_uuid = pynvml.nvmlDeviceGetUUID(handle)
                gpu_uuid = gpu_uuid.decode() if isinstance(gpu_uuid, bytes) else gpu_uuid
                info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                guard = min(10_500_000_000, info.total) - 1_500_000_000
                fraction = memory_fraction(info.total, info.used, guard)
            finally:
                pynvml.nvmlShutdown()
            # OS advisory lock survives crashes safely; no stale PID lock deletion.
            self.lock_file = _DeviceLock(gpu_uuid)
            self.lock_file.acquire()
            self.worker = WorkerClient(self.settings, self.output, gpu_uuid)
            self.recorder = NvmlRecorder(
                self.output / "nvml_samples.csv",
                self.settings.gpu_index,
                gpu_uuid,
                lambda: self.worker.process.pid if self.worker.process else None,
                failure_callback=self.worker.kill,
                abort_threshold_bytes=guard,
            )
            self.recorder.check()
            self.worker.start(fraction)
            self.backend = MeasuredBackend(self.worker, self.recorder, self.output, self.settings.name)
            self._ready()
            save_json(
                self.output / "engine_settings.json",
                {
                    "settings": asdict(self.settings),
                    "packages": self.worker.metadata["packages"],
                    "startup_seconds": time.monotonic() - started,
                    "memory_fraction": fraction,
                    "guard_bytes": guard,
                    "hard_vram_cap_guaranteed": False,
                },
            )
            return self
        except BaseException as exc:
            save_json(self.output / "startup_error.json", error_record(exc))
            self.close()
            raise

    def _ready(self):
        if self.closed or self.backend is None:
            raise WritingError("Use the session inside its with block")
        self.recorder.check()
        self.worker.check()

    def new_job(self, request, *, max_output_tokens=None, seed=42):
        self._ready()
        return FastWritingJob(
            self.backend,
            request,
            self.output / "jobs" / uuid.uuid4().hex[:12],
            render=self.render,
            max_output_tokens=max_output_tokens,
            seed=seed,
            ready=self._ready,
        )

    def close(self):
        if self.closed:
            return
        if self.worker:
            self.worker.close()  # Monitor stays active until GPU worker termination.
        if self.backend:
            self.backend.close()
        if self.recorder:
            self.recorder.close()
            save_json(self.output / "memory_report.json", self.recorder.report())
        if self.lock_file:
            self.lock_file.release()
        self.closed = True

    def __exit__(self, *exception):
        self.close()


def WritingSession(settings=None, **options):
    """The same job API for all three inference engines."""
    settings = settings or EngineSettings()
    settings.validate()
    if settings.name == "llama_cpp":
        from .engines.llama_cpp import create_session

        return create_session(settings, **options)
    return PythonEngineSession(settings, **options)
