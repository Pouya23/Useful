"""Resident engine process. Stdout carries JSON; library logs go to stderr."""

import contextlib
import importlib.metadata
import json
import sys
import traceback
from .engines.base import EngineSettings


def main():
    engine = None
    reply_stream = sys.stdout
    # Mark replies and redirect Python prints; parent ignores unmarked native logs.
    for line in sys.stdin:
        command = {}
        try:
            command = json.loads(line)
            with contextlib.redirect_stdout(sys.stderr):
                if command["operation"] == "load":
                    settings = EngineSettings(**command["settings"])
                    settings.validate()
                    if settings.name == "transformers":
                        from .engines.transformers import TransformersEngine as Adapter
                    elif settings.name == "vllm":
                        from .engines.vllm import VllmEngine as Adapter
                    else:
                        raise ValueError("The native engine uses its own guarded server")
                    engine = Adapter(settings, command["memory_fraction"])
                    packages = {}
                    for name in ("torch", "transformers", "bitsandbytes", "vllm", "vllm-bnb-plugin"):
                        try:
                            packages[name] = importlib.metadata.version(name)
                        except importlib.metadata.PackageNotFoundError:
                            pass
                    result = {"context_tokens": engine.effective_context_size, "packages": packages}
                elif command["operation"] == "generate":
                    if engine is None:
                        raise RuntimeError("Load an engine before generating")
                    result = engine.complete(command["messages"], **command["sampling"])
                elif command["operation"] == "close":
                    if engine is not None:
                        engine.close()
                    result = {"closed": True}
                else:
                    raise ValueError("Unknown worker operation")
            reply = {"ok": True, "result": result}
        except Exception as exc:
            reply = {"ok": False, "error": str(exc), "traceback": traceback.format_exc()}
        reply_stream.write("QWEN_REPLY " + json.dumps(reply, ensure_ascii=False) + "\n")
        reply_stream.flush()
        if command.get("operation") == "close":
            return


if __name__ == "__main__":
    main()
