"""Run this file from the extracted package directory."""

from qwen_writer.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
