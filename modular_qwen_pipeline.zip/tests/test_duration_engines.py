"""Duration rules, context admission, and the shared generation path."""

from pathlib import Path
import pytest
from qwen_writer import DurationPolicy, EngineSettings, WritingRequest, WritingError
from qwen_writer.engines.base import admit
from qwen_writer.session import memory_fraction
from test_writer import job_for, text, current_pass


def test_duration_rules():
    policy = DurationPolicy(180, 130, 0.10)
    assert policy.target_words == 390
    assert policy.word_range() == (351, 429)
    assert policy.estimate_seconds(390) == 180
    assert DurationPolicy(120, 120, 0).word_range() == (240, 240)


@pytest.mark.parametrize("seconds", [0, -1, float("nan"), float("inf"), True, "180", 1])
def test_bad_duration(seconds):
    with pytest.raises(ValueError):
        DurationPolicy(seconds).word_range()


def test_duration_request_draft_and_revision(tmp_path):
    brief = WritingRequest("Maintenance of pipe handling systems", duration_seconds=60, speaking_rate_wpm=60)
    job, backend, _ = job_for(tmp_path, brief, [text(60), text(50), text(30)])
    assert job.draft()["estimated_duration_seconds"] == 60
    first_call = current_pass(backend.calls[0])
    assert first_call["measured_length_feedback"]["word_range"] == [54, 66]
    job.revise(length_direction="shorter")
    assert current_pass(backend.calls[1])["measured_length_feedback"]["word_range"] is None
    job.revise(duration_seconds=30)
    policy = current_pass(backend.calls[2])["measured_length_feedback"]
    assert policy["word_range"] == [27, 33] and policy["length_direction"] is None
    assert backend.counter == 3
    job.revise()
    assert backend.counter == 3


def test_new_duration_persists_until_changed(tmp_path):
    brief = WritingRequest("Maintenance", duration_seconds=60, speaking_rate_wpm=60)
    job, backend, _ = job_for(tmp_path, brief, [text(60), text(45), text(30)])
    job.draft()
    job.revise(duration_seconds=30)
    job.revise()
    assert current_pass(backend.calls[2])["measured_length_feedback"]["word_range"] == [27, 33]
    assert job.accept()["word_count"] == 30


def test_duration_conflicts_fail_before_generation(tmp_path):
    with pytest.raises(WritingError):
        WritingRequest("Maintenance", duration_seconds=60, min_words=20, max_words=30).validate()
    job, backend, _ = job_for(tmp_path, WritingRequest("Maintenance", duration_seconds=60), [text(130)])
    job.draft()
    with pytest.raises(WritingError):
        job.revise(duration_seconds=-1)
    assert backend.counter == 1


def test_memory_budget_accounts_for_existing_usage():
    assert memory_fraction(16_000_000_000, 1_000_000_000, 9_000_000_000) == 0.46875
    with pytest.raises(RuntimeError):
        memory_fraction(16_000_000_000, 9_000_000_000, 9_000_000_000)


def test_context_admission():
    admit(500, 500, 1016)
    with pytest.raises(ValueError):
        admit(501, 500, 1016)


@pytest.mark.parametrize("name", ["llama_cpp", "transformers", "vllm"])
def test_adapter_names(name):
    EngineSettings(name=name).validate()


def test_public_imports_do_not_import_heavy_engines():
    import subprocess, sys

    code = 'import qwen_writer,sys; assert "torch" not in sys.modules; assert "vllm" not in sys.modules'
    subprocess.run([sys.executable, "-c", code], check=True, cwd=Path(__file__).resolve().parents[1])
