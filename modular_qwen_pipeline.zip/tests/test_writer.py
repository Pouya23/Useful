"""No network/GPU: one generation per feedback round, without a revision limit."""

import copy
import json
from contextlib import contextmanager
from dataclasses import replace

import pytest
from qwen_writer.requests import Source, WritingError, WritingRequest
from qwen_writer.runtime import RuntimeConfig
from qwen_writer.writer import (
    FastLlamaServer,
    FastWritingJob,
    automatic_length_feedback,
    review_interactively,
)


@pytest.fixture
def brief():
    return WritingRequest(
        title="Maintenance of pipe handling systems",
        instructions="Use calm spoken prose.",
        required_points=("Report defects.", "Use approved maintenance procedures."),
        samples=("A demonstration of maintenance writing style.",),
        sources=(Source("demo", "A fictional maintenance reference."),),
        min_words=40,
        max_words=60,
    )


def job_for(tmp_path, brief, outputs, **kwargs):
    backend = MeasuredFake(tmp_path, outputs)
    events = []
    job = FastWritingJob(backend, brief, tmp_path / "job", render=events.append, **kwargs)
    return job, backend, events


def current_pass(call):
    return json.loads(call["messages"][1]["content"].split("CURRENT PASS:\n")[1])


@pytest.mark.parametrize(
    "words,action,needs", [(30, "expand", True), (50, "keep", False), (80, "shorten", True)]
)
def test_word_count_uses_local_measurement(words, action, needs):
    result = automatic_length_feedback(text(words), word_range=(40, 60))
    assert result["measured_words"] == words and result["automatic_action"] == action
    assert result["needs_length_revision"] is needs


def test_initial_draft_needs_one_call_and_no_planning_or_judging(tmp_path, brief):
    job, backend, events = job_for(tmp_path, brief, [text(50)])
    result = job.draft()
    assert backend.counter == 1 and result["word_count"] == 50
    assert len(events) == 1 and events[0]["stage"] == "draft"
    final = job.finalize()
    assert backend.counter == 1 and final["text"] == result["text"] and not final["revised"]


def test_auto_length_and_user_quality_combined_in_one_generation_each_round(tmp_path, brief):
    job, backend, events = job_for(tmp_path, brief, [text(90), text(50), text(45)])
    job.draft()
    final = job.finalize(quality_feedback="Make the handover explanation clearer.")
    assert backend.counter == 2 and final["word_count"] == 50 and final["revised"]
    data = current_pass(backend.calls[-1])
    assert data["draft"] == text(90)
    assert data["measured_length_feedback"]["automatic_action"] == "shorten"
    assert data["user_quality_feedback"] == "Make the handover explanation clearer."
    assert [e["stage"] for e in events] == ["draft", "revision_1"]
    job.revise(quality_feedback="Another change")
    assert backend.counter == 3 and current_pass(backend.calls[-1])["draft"] == text(50)
    assert events[-1]["stage"] == "revision_2"


def test_automatic_length_feedback_can_revise_without_quality_feedback(tmp_path, brief):
    job, backend, _ = job_for(tmp_path, brief, [text(20), text(45)])
    job.draft()
    result = job.finalize()
    assert backend.counter == 2 and result["length_feedback"]["within_word_range"]


def test_unsatisfied_second_pass_does_not_loop_or_truncate(tmp_path, brief):
    job, backend, _ = job_for(tmp_path, brief, [text(90), text(80), text(50)])
    job.draft()
    result = job.finalize()
    assert backend.counter == 2 and result["text"] == text(80)
    assert result["length_feedback"]["needs_length_revision"] and result["warnings"]
    repaired = job.revise()
    assert backend.counter == 3 and repaired["word_count"] == 50


def test_direction_only_feedback_clears_original_numeric_target(tmp_path, brief):
    job, backend, _ = job_for(tmp_path, brief, [text(50), text(30)])
    job.draft()
    result = job.finalize(length_direction="shorter")
    data = current_pass(backend.calls[-1])["measured_length_feedback"]
    assert data["word_range"] is None and data["target_words"] is None
    assert data["baseline_words"] == 50 and result["length_feedback"]["direction_satisfied"]


def test_new_numeric_range_can_be_requested_and_context_is_retained(tmp_path, brief):
    job, backend, _ = job_for(tmp_path, brief, [text(50), text(70)])
    job.draft()
    job.finalize(quality_feedback="Expand the description.", word_range=(65, 75))
    for call in backend.calls:
        content = call["messages"][1]["content"]
        assert brief.title in content and brief.sources[0].text in content
        assert brief.samples[0] in content and all(p in content for p in brief.required_points)
    assert current_pass(backend.calls[-1])["measured_length_feedback"]["target_words"] == 70


def test_accepted_draft_keeps_unused_revision_allowance(tmp_path, brief):
    job, backend, _ = job_for(tmp_path, brief, [text(50), text(45)])
    job.draft()
    job.finalize()
    job.finalize(quality_feedback="Improve the opening.")
    assert backend.counter == 2


def test_keep_length_without_quality_changes_does_not_make_a_pointless_call(tmp_path, brief):
    job, backend, _ = job_for(tmp_path, brief, [text(50)])
    job.draft()
    result = job.finalize(length_direction="keep")
    assert backend.counter == 1 and result["length_feedback"]["direction_satisfied"]


def test_non_text_response_is_rejected_without_losing_the_saved_failure(tmp_path, brief):
    job, backend, events = job_for(tmp_path, brief, [123])
    # Test a broken backend; the native runtime already rejects this contract violation.
    original = backend.complete

    def invalid(*args, **kwargs):
        response = original(*args, **kwargs)
        response["text"] = None
        return response

    backend.complete = invalid
    with pytest.raises(WritingError, match="usable text"):
        job.draft()
    assert events[-1]["status"] == "failed" and events[-1]["text"] == ""


def test_original_direction_policy_is_preserved_until_explicitly_overridden(tmp_path, brief):
    brief = replace(brief, draft=text(100), length_direction="decrease", min_words=None, max_words=None)
    job, backend, _ = job_for(tmp_path, brief, [text(110), text(90)])
    job.draft()
    final = job.finalize()
    feedback = current_pass(backend.calls[-1])["measured_length_feedback"]
    assert feedback["baseline_words"] == 100 and feedback["automatic_action"] == "shorten"
    assert backend.counter == 2 and final["length_feedback"]["direction_satisfied"]


def test_satisfied_original_direction_does_not_force_a_second_call(tmp_path, brief):
    brief = replace(brief, draft=text(100), length_direction="decrease", min_words=None, max_words=None)
    job, backend, _ = job_for(tmp_path, brief, [text(90)])
    job.draft()
    result = job.finalize()
    assert backend.counter == 1 and result["length_feedback"]["direction_satisfied"]


@pytest.mark.parametrize(
    "feedback",
    [
        {"quality_feedback": 1},
        {"word_range": (25,)},
        {"word_range": (10, 20)},
        {"length_direction": "longer", "word_range": (20, 30)},
    ],
)
def test_invalid_feedback_does_not_spend_the_revision(tmp_path, brief, feedback):
    job, backend, _ = job_for(tmp_path, brief, [text(50)])
    job.draft()
    with pytest.raises(WritingError):
        job.finalize(**feedback)
    assert backend.counter == 1 and job._revision_attempts == 0


def test_failed_revision_saves_partial_and_preserves_original(tmp_path, brief):
    job, backend, events = job_for(tmp_path, brief, [text(50), text(10), text(45)])
    job.draft()
    original = backend.complete

    def truncate(*args, **kwargs):
        result = original(*args, **kwargs)
        result["finish_reason"] = "length"
        return result

    backend.complete = truncate
    with pytest.raises(WritingError, match="truncated"):
        job.finalize(quality_feedback="Improve clarity.")
    assert job.initial["text"] == text(50) and job.final is None
    assert events[-1]["status"] == "failed" and events[-1]["text"] == text(10)
    saved = json.loads((job.output / "job.json").read_text())
    assert saved["attempted_completions"] == 2 and saved["initial"]["text"] == text(50)
    backend.complete = original
    result = job.revise(quality_feedback="Retry the improvement.")
    assert backend.counter == 3 and result["text"] == text(45)
    assert current_pass(backend.calls[-1])["draft"] == text(50)


def test_later_rounds_keep_the_latest_numeric_policy(tmp_path, brief):
    job, backend, _ = job_for(tmp_path, brief, [text(50), text(70), text(68)])
    job.draft()
    job.revise(word_range=(65, 75))
    job.revise(quality_feedback="Improve tone without changing coverage.")
    policy = current_pass(backend.calls[-1])["measured_length_feedback"]
    assert policy["word_range"] == [65, 75] and policy["target_words"] == 70
    assert current_pass(backend.calls[-1])["draft"] == text(70)


def test_each_new_direction_is_relative_to_the_latest_text(tmp_path, brief):
    job, backend, _ = job_for(tmp_path, brief, [text(50), text(30), text(40), text(39)])
    job.draft()
    job.revise(length_direction="shorter")
    job.revise(length_direction="longer")
    assert current_pass(backend.calls[-1])["measured_length_feedback"]["baseline_words"] == 30
    job.revise(quality_feedback="Improve the phrasing.")
    policy = current_pass(backend.calls[-1])["measured_length_feedback"]
    assert policy["baseline_words"] == 30 and policy["word_range"] is None
    assert current_pass(backend.calls[-1])["draft"] == text(40)


def test_many_revisions_do_not_accumulate_draft_history_in_prompt(tmp_path, brief):
    outputs = [" ".join(f"version{n}word{i}" for i in range(50)) for n in range(13)]
    job, backend, events = job_for(tmp_path, brief, outputs)
    job.draft()
    for index in range(12):
        job.revise(quality_feedback=f"Editorial change {index}.")
    assert backend.counter == len(events) == 13
    last = current_pass(backend.calls[-1])
    assert last["draft"] == outputs[-2]
    assert outputs[0] not in backend.calls[-1]["messages"][1]["content"]
    assert last["user_quality_feedback"] == "Editorial change 11."
    saved = json.loads((job.output / "job.json").read_text())
    assert saved["revision_limit"] is None and saved["accepted_revisions"] == 12


def test_interactive_rounds_show_each_generation_and_stop_on_accept(tmp_path, brief, monkeypatch):
    job, backend, events = job_for(tmp_path, brief, [text(50), text(48), text(30)])
    job.draft()
    replies = iter(["Improve the opening.", "/shorter", ""])
    monkeypatch.setattr("builtins.input", lambda _: next(replies))
    result = review_interactively(job)
    assert backend.counter == len(events) == 3 and result["word_count"] == 30
    assert result["length_feedback"]["word_range"] is None


def test_original_request_cannot_be_mutated_after_job_creation(tmp_path, brief):
    mutable = replace(brief, samples=list(brief.samples))
    job, backend, _ = job_for(tmp_path, mutable, [text(50)])
    mutable.samples.append("A later mutation")
    job.draft()
    assert "A later mutation" not in backend.calls[0]["messages"][1]["content"]


def test_native_cache_is_enabled_without_changing_other_payload_fields(tmp_path, monkeypatch):
    native = FastLlamaServer(
        RuntimeConfig(server=tmp_path / "server", model=tmp_path / "model", device="cpu")
    )
    captured = []
    monkeypatch.setattr(
        "qwen_writer.runtime.LlamaServer.post",
        lambda self, path, payload: captured.append(copy.deepcopy(payload)),
    )
    native.post("/v1/chat/completions", {"cache_prompt": False, "max_tokens": 512})
    assert captured[-1] == {"cache_prompt": True, "max_tokens": 512}
    native.post("/tokenize", {"content": "example"})
    assert captured[-1] == {"content": "example"}


def text(words):
    return " ".join(f"word{i}" for i in range(words))


class MeasuredFake:
    effective_context_size = 32768
    case = "interactive"

    def __init__(self, output, results):
        self.output, self.results = output, iter(results)
        (output / "round_outputs").mkdir()
        self.counter = 0
        self.rounds, self.calls = [], []
        self.stage = "unlabelled"
        self.closed = False

    def prompt_tokens(self, messages):
        return sum(len(m["content"].split()) for m in messages)

    @contextmanager
    def labelled(self, case, stage):
        self.stage = stage
        yield

    def complete(self, messages, **kwargs):
        self.calls.append({"messages": copy.deepcopy(messages), **kwargs})
        self.counter += 1
        result = next(self.results)
        row = {
            "profile": "qwen35_9b",
            "round_id": self.counter,
            "stage": self.stage,
            "latency_seconds": 0.01,
            "total_device_peak_gb": 6.5,
            "total_device_peak_bytes": 6500000000,
            "error": None,
            "usage": {"prompt_tokens": self.prompt_tokens(messages), "completion_tokens": 8},
            "finish_reason": "stop",
            "pipeline_validation_status": "pending",
        }
        self.rounds.append(row)
        response = {
            "text": json.dumps(result) if isinstance(result, dict) else result,
            "finish_reason": "stop",
            "usage": row["usage"],
        }
        (self.output / "round_outputs" / f"{self.counter:04d}.json").write_text(json.dumps(response))
        return response

    def validation(self, index, status, exc=None):
        self.rounds[-1]["pipeline_validation_status"] = status

    def close(self):
        self.closed = True
