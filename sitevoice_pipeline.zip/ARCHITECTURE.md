# Architecture notes

## Why deterministic slots instead of letting the LLM choose timing?

The LLM is good at semantic emphasis and prose, but timing is an optimization constraint. Fixed slots make the timing problem measurable and local. The model receives a target duration, target word band, and only evidence overlapping that slot.

## Why scene-level VLM calls?

Whole-video inference couples runtime, visual-token count, and VRAM to montage length. Scene-level calls bound failure size and make the vision stage resumable. They also make evidence IDs naturally timestamped.

## Why one resident GPU model?

11.5 GiB is enough for useful 4B quantized models, but not enough to assume Qwen-VL, Qwen text, ASR, and Chatterbox can coexist safely. `ModelPool` therefore evicts before switching families.

## Why calibrate TTS before writing?

Word count is only a proxy for duration. A measured words-per-second value for the selected voice/style gives the writer a much better first target and reduces expensive rewrite/TTS cycles.

## Why batch duration repairs?

A naive fitting loop alternates Qwen -> TTS for each segment. On a small GPU that means repeated model load/unload. This repository finds every off-target segment first, loads Qwen once to rewrite them all, then loads Chatterbox once to synthesize them all.

## Token budgeting

The default text context is intentionally 8192 rather than the model maximum. KV cache grows linearly with context. The writer only receives evidence for the current slot plus a small previous-text tail, so it should not need a huge context window.

For long montages, the pipeline's evidence representation remains on disk and each segment query is local. This keeps prompt size nearly constant with video duration.

## Extending backends

Create another adapter with the same semantic methods:
- VLM: `analyze(scene, topic, description) -> VisionObservation`
- LLM: `generate_json(model_type, system, user)`
- ASR: `transcribe(path) -> Transcript`
- TTS: `synthesize(text, out_path) -> duration`

Then switch construction in `orchestrator.py`. Nothing else should need to know the inference library.
