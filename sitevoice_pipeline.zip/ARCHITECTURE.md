# SiteVoice architecture 0.2

## Four-mode model graph

The mandatory generation path is always:

```text
Qwen3-4B -> Chatterbox Multilingual V3
```

Two optional evidence producers may be enabled independently:

```text
Qwen3-VL      -> visual evidence --+
                                |-> Qwen3-4B -> Chatterbox V3
faster-whisper -> speech evidence --+
```

This creates exactly four modes: `text`, `vision`, `asr`, and `full`.

## Stage skipping

Optional means computationally optional, not merely ignored after execution.

- No vision: no scene detection, no frame extraction, no Qwen3-VL import/model download.
- No ASR: no faster-whisper import/model download/inference.
- No source audio in ASR/full: transcript remains empty without failure.

## Evidence invariants

`U_TOPIC` always exists and contains the user-supplied general subject. `U_DESC` exists when a description is supplied. Therefore text-only jobs still have explicit evidence IDs and can pass the same QA system as richer modes.

## GPU sequencing

Full mode uses the heaviest sequence but still never intends to keep all models loaded together:

```text
Qwen3-VL -> evict -> faster-whisper -> evict -> Chatterbox calibration
-> evict -> Qwen3-4B -> evict -> Chatterbox synthesis
```

Text mode avoids both optional model loads entirely.

## Dependency isolation

The Python modules for Qwen3-VL and faster-whisper are imported lazily inside the branches that need them. The package exposes self-contained extras:

```text
.[text]
.[vision]
.[asr]
.[full]
```

This means a text-only deployment does not need `qwen-vl-utils` or `faster-whisper` installed.

## Timing loop

All modes share the same timing architecture:

1. Calibrate the selected Chatterbox voice/style.
2. Convert slot duration into an empirical word budget.
3. Qwen writes each slot against that budget.
4. Chatterbox synthesizes each segment.
5. Measure actual WAV duration.
6. Batch-rewrite off-target segments with Qwen.
7. Batch-resynthesize with Chatterbox.
8. Use only small residual time correction.
