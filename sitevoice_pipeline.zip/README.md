# SiteVoice Pipeline 0.2

SiteVoice turns a construction/job-site montage into duration-fitted educational narration and a final narrated MP4.

This version supports four explicit execution modes. Qwen3-4B and Chatterbox Multilingual V3 are always present; Qwen3-VL and faster-whisper are optional evidence channels.

| Mode | Qwen3-4B | Chatterbox V3 | Qwen3-VL | faster-whisper | Use when |
|---|---:|---:|---:|---:|---|
| `text` | yes | yes | no | no | Topic/description/sample text are enough |
| `vision` | yes | yes | yes | no | Narration should reflect visible footage |
| `asr` | yes | yes | no | yes | Original spoken audio matters |
| `full` | yes | yes | yes | yes | Use both visual and spoken evidence |

The default is `text`, so the optional models are not downloaded or instantiated unless you choose a mode that needs them.

## Important behavior

- `text`: skips scene detection, frame extraction, Qwen3-VL, and Whisper.
- `vision`: runs scene detection/frame sampling + Qwen3-VL, but never imports/loads Whisper.
- `asr`: runs Whisper when source audio exists, but skips scene detection/frame extraction and never imports/loads Qwen3-VL.
- `full`: uses both optional evidence channels sequentially.
- All modes use the same text Qwen writer and Chatterbox Multilingual V3 duration-fitting loop.
- GPU-heavy models are still single-resident through `ModelPool` for ~11.5 GiB cards.

## Install exactly one mode

Install FFmpeg separately and put `ffmpeg`/`ffprobe` on PATH.

```bash
python -m venv .venv
source .venv/bin/activate

# Install the CUDA-enabled PyTorch build appropriate for your machine first if needed.

# Minimal two-model system:
pip install -e ".[text]"

# Add visual understanding:
pip install -e ".[vision]"

# Add source-speech understanding:
pip install -e ".[asr]"

# Both optional channels:
pip install -e ".[full]"
```

The old `.[ml]` extra is retained as an alias of `.[full]`.

## Run

### 1. Text-only: Qwen3-4B + Chatterbox V3

```bash
sitevoice run montage.mp4 \
  --mode text \
  --topic "maintenance of pipe handling systems" \
  --description "Preventive maintenance training montage" \
  --voice-ref narrator.wav \
  --domain-pack configs/domain_packs/pipe_handling.yaml
```

### 2. Vision mode

```bash
sitevoice run montage.mp4 \
  --mode vision \
  --topic "maintenance of pipe handling systems" \
  --voice-ref narrator.wav
```

### 3. ASR mode

```bash
sitevoice run montage.mp4 \
  --mode asr \
  --topic "maintenance of pipe handling systems" \
  --voice-ref narrator.wav
```

If the video has no audio, ASR mode simply produces an empty transcript and continues. It does not fail.

### 4. Full mode

```bash
sitevoice run montage.mp4 \
  --mode full \
  --topic "maintenance of pipe handling systems" \
  --voice-ref narrator.wav
```

You can also set the default in `configs/default.yaml`:

```yaml
pipeline:
  mode: text
```

A CLI `--mode` overrides the config for that run.

## Chatterbox V3

The default TTS configuration is now explicitly:

```yaml
tts:
  engine: multilingual_v3
  language_id: en
```

The adapter maps this to `ChatterboxMultilingualTTS.from_pretrained(..., t3_model="v3")`.

## Why text mode still passes grounding QA

The general job subject is now always stored as evidence `U_TOPIC`, and the optional description as `U_DESC`. Therefore text-only narration can be grounded in the information you actually supplied even when no vision or transcript evidence exists.

A domain pack can add approved general facts. This is especially useful in `text` mode.

## Caching and mode isolation

The automatically generated job ID includes the execution mode. Running the same video/topic in `text` and later in `full` therefore creates separate job directories and cannot accidentally overwrite one mode's output with another.

Within a mode, expensive stages remain resumable. TTS is content-addressed by text + voice + TTS settings.

## Preflight

```bash
sitevoice doctor --mode text
sitevoice doctor --mode vision
sitevoice doctor --mode asr
sitevoice doctor --mode full
```

`doctor` reports missing packages for the selected mode and gives the correct install extra.

## Resource policy

For an ~11.5 GiB GPU:

- Qwen3-4B: 4-bit
- Qwen3-VL-4B when enabled: 4-bit
- faster-whisper when enabled: `int8_float16`
- Chatterbox V3: loaded only when needed
- one heavyweight backend resident at a time
- bounded visual-token budget
- 8K text context by default
- batched duration repair to avoid Qwen/Chatterbox model thrashing

## Pipeline by mode

```text
TEXT
video -> ingest -> topic/description/domain evidence -> Qwen3-4B -> Chatterbox V3 -> fit -> mix

VISION
video -> ingest -> scenes/frames -> Qwen3-VL -> evidence -> Qwen3-4B -> Chatterbox V3 -> fit -> mix

ASR
video -> ingest/audio -> faster-whisper -> evidence -> Qwen3-4B -> Chatterbox V3 -> fit -> mix

FULL
video -> ingest -> [Qwen3-VL + faster-whisper] -> evidence -> Qwen3-4B -> Chatterbox V3 -> fit -> mix
```
