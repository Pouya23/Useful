# SiteVoice Pipeline

A resumable, evidence-grounded pipeline for turning construction/job-site montage videos into timed educational narration and a final narrated MP4.

## Design goals

- One GPU-heavy model resident at a time.
- Works on ~11.5 GiB VRAM by defaulting Qwen text/VL models to 4-bit.
- Every expensive stage is cached and resumable.
- Visual claims, source-audio transcript, user context, and approved domain knowledge stay separate until the evidence assembly stage.
- Narration is written in fixed time slots, synthesized in chunks, measured, rewritten when needed, and only lightly time-stretched.
- Backends are adapters; the orchestration code does not depend directly on Transformers/Chatterbox/faster-whisper APIs.

## Pipeline

```text
input video
  -> ingest / ffprobe / split source audio
  -> adaptive scene detection
  -> adaptive representative-frame sampling
  -> Qwen3-VL scene observations
  -> faster-whisper transcript
  -> evidence timeline
  -> voice calibration
  -> optional example-text style extraction
  -> deterministic narration slots
  -> Qwen3-4B segment writing
  -> Chatterbox synthesis
  -> duration-fit loop (rewrite -> resynthesize)
  -> narration timeline
  -> source-audio ducking + mix
  -> final MP4 + QA report
```

## Recommended environment

Python 3.11.

Install FFmpeg separately and make sure `ffmpeg` and `ffprobe` are on PATH.

Create a virtual environment, install the correct CUDA-enabled PyTorch build for your GPU, then install this package:

```bash
python -m venv .venv
source .venv/bin/activate

# Install the CUDA-enabled torch build appropriate for your machine first.
# Then:
pip install -e ".[ml,dev]"
```

For 4-bit Qwen inference, `bitsandbytes` is required.

## Check the machine first

```bash
sitevoice doctor --config configs/default.yaml
```

This reports FFmpeg availability, selected GPU/VRAM, and an approximate text-model KV-cache cost for the configured context window.

## Run

```bash
sitevoice run input.mp4 \
  --topic "maintenance of pipe handling systems" \
  --description "Preventive maintenance montage for operator training" \
  --voice-ref narrator.wav \
  --sample-text previous_script.txt \
  --domain-pack configs/domain_packs/pipe_handling.yaml \
  --config configs/default.yaml
```

Outputs are written under:

```text
runs/<job_id>/
  source/
  stages/
  frames/
  tts/
  final/
```

The final directory contains the narration track, mixed audio, MP4, script JSON, and QA report.

## Important defaults for ~11.5 GiB VRAM

- Qwen3-VL-4B-Instruct: 4-bit
- Qwen3-4B-Instruct-2507: 4-bit
- Text context budget: 8192 tokens, with 6144-token prompt budget
- Scene-level VL calls rather than whole-video VL calls
- One GPU model resident at once
- 80-90% narration occupancy rather than continuous speech
- 2 fitting passes maximum
- Rewrite before time-stretching
- At most ~3% speed-up for residual timing error

## Caching

Each stage stores a fingerprint sidecar. A fingerprint includes:
- relevant config
- stage version
- upstream artifact identity
- source file fingerprint

If it matches, the stage is skipped. Delete a stage directory to force only that stage and downstream work to re-run.

## Resource strategy

`ModelPool` enforces a single resident GPU backend. Consecutive calls using the same backend reuse it. When switching backend families, the previous model is released, Python GC is run, and the CUDA cache is cleared.

The duration-fitting loop batches all rewrites before switching from Qwen back to Chatterbox. This avoids model thrashing once per segment.

## Safety / factuality

This code never treats a visual inference as a verified maintenance diagnosis. Observations contain confidence and `do_not_claim` fields. Domain packs should contain approved site/company terminology and facts. Exact limits, torque values, inspection intervals, safety requirements, and equipment-clearance statements should only be narrated when they come from an approved source.
