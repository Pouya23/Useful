from __future__ import annotations

from pathlib import Path

import numpy as np
import soundfile as sf

from .schemas import MediaInfo, Script, SynthesisManifest
from .utils import run


def audio_duration(path: str | Path) -> float:
    return float(sf.info(path).duration)


def time_stretch_ffmpeg(source: str | Path, dest: str | Path, speed_factor: float) -> None:
    if not 0.5 <= speed_factor <= 2.0:
        raise ValueError("This implementation deliberately limits atempo to 0.5-2.0")
    run([
        "ffmpeg", "-y", "-i", str(source),
        "-filter:a", f"atempo={speed_factor:.8f}",
        "-c:a", "pcm_s16le", str(dest)
    ])


def build_narration_track(
    script: Script,
    synth: SynthesisManifest,
    duration: float,
    out_path: str | Path,
    sample_rate: int,
) -> str:
    out_path = Path(out_path)
    total_samples = int(round(duration * sample_rate))
    canvas = np.zeros(total_samples, dtype=np.float32)
    synth_by_id = {s.id: s for s in synth.segments}

    for seg in script.segments:
        syn = synth_by_id[seg.id]
        # Normalize every segment to target timeline sample rate/mono through FFmpeg.
        normalized = out_path.parent / f".{seg.id}_normalized.wav"
        run([
            "ffmpeg", "-y", "-i", syn.path, "-ac", "1", "-ar", str(sample_rate),
            "-c:a", "pcm_f32le", str(normalized)
        ])
        wav, sr = sf.read(normalized, dtype="float32", always_2d=False)
        normalized.unlink(missing_ok=True)
        if wav.ndim > 1:
            wav = wav.mean(axis=1)

        spare = max(0.0, seg.interval.duration - len(wav) / sample_rate)
        lead = min(0.35, spare / 2.0)
        start = int(round((seg.interval.start + lead) * sample_rate))
        end = min(total_samples, start + len(wav))
        if end > start:
            canvas[start:end] += wav[: end - start]

    peak = float(np.max(np.abs(canvas))) if canvas.size else 0.0
    if peak > 0.98:
        canvas *= 0.98 / peak

    sf.write(out_path, canvas, sample_rate, subtype="PCM_16")
    return str(out_path)


def mix_and_render(
    media: MediaInfo,
    narration_track: str | Path,
    out_dir: Path,
    sample_rate: int,
    source_gain_db: float,
    narration_gain_db: float,
    enable_ducking: bool,
    duck_threshold: float,
    duck_ratio: float,
    duck_attack_ms: int,
    duck_release_ms: int,
    target_lufs: float,
) -> tuple[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    mixed = out_dir / "mixed_audio.wav"
    final = out_dir / "final.mp4"

    if media.source_audio_path:
        if enable_ducking:
            filt = (
                f"[0:a]volume={source_gain_db}dB[src];"
                f"[1:a]volume={narration_gain_db}dB[vox];"
                f"[src][vox]sidechaincompress="
                f"threshold={duck_threshold}:ratio={duck_ratio}:"
                f"attack={duck_attack_ms}:release={duck_release_ms}[ducked];"
                f"[ducked][vox]amix=inputs=2:duration=longest:normalize=0,"
                f"loudnorm=I={target_lufs}:TP=-1.5:LRA=11[mix]"
            )
            run([
                "ffmpeg", "-y",
                "-i", media.source_audio_path,
                "-i", str(narration_track),
                "-filter_complex", filt,
                "-map", "[mix]", "-ar", str(sample_rate),
                "-c:a", "pcm_s16le", str(mixed)
            ])
        else:
            filt = (
                f"[0:a]volume={source_gain_db}dB[a0];"
                f"[1:a]volume={narration_gain_db}dB[a1];"
                f"[a0][a1]amix=inputs=2:duration=longest:normalize=0,"
                f"loudnorm=I={target_lufs}:TP=-1.5:LRA=11[mix]"
            )
            run([
                "ffmpeg", "-y", "-i", media.source_audio_path, "-i", str(narration_track),
                "-filter_complex", filt, "-map", "[mix]",
                "-ar", str(sample_rate), "-c:a", "pcm_s16le", str(mixed)
            ])
    else:
        run([
            "ffmpeg", "-y", "-i", str(narration_track),
            "-filter:a", f"loudnorm=I={target_lufs}:TP=-1.5:LRA=11",
            "-ar", str(sample_rate), "-c:a", "pcm_s16le", str(mixed)
        ])

    run([
        "ffmpeg", "-y", "-i", media.video_only_path, "-i", str(mixed),
        "-map", "0:v:0", "-map", "1:a:0",
        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
        "-shortest", str(final)
    ])
    return str(mixed), str(final)
