from __future__ import annotations

import random
from pathlib import Path

import numpy as np
import soundfile as sf

from ..config import AppConfig


class ChatterboxBackend:
    def __init__(self, cfg: AppConfig, voice_ref: str | None = None):
        import torch
        import torchaudio as ta
        from chatterbox.tts import ChatterboxTTS
        from chatterbox.mtl_tts import ChatterboxMultilingualTTS

        self.cfg = cfg
        self.ta = ta
        self.torch = torch
        self.voice_ref = voice_ref
        device = f"cuda:{cfg.resources.gpu_index}" if torch.cuda.is_available() else "cpu"

        if cfg.tts.engine == "multilingual":
            self.model = ChatterboxMultilingualTTS.from_pretrained(device=device, t3_model="v3")
            self.multilingual = True
        else:
            self.model = ChatterboxTTS.from_pretrained(device=device)
            self.multilingual = False

        # Both current Original and Multilingual implementations expose this method.
        if voice_ref:
            self.model.prepare_conditionals(voice_ref, exaggeration=cfg.tts.exaggeration)

    def _seed(self, seed: int) -> None:
        self.torch.manual_seed(seed)
        if self.torch.cuda.is_available():
            self.torch.cuda.manual_seed_all(seed)
        random.seed(seed)
        np.random.seed(seed)

    def synthesize(self, text: str, out_path: str | Path, seed_offset: int = 0) -> float:
        self._seed(self.cfg.tts.seed + seed_offset)
        kwargs = dict(
            exaggeration=self.cfg.tts.exaggeration,
            temperature=self.cfg.tts.temperature,
            cfg_weight=self.cfg.tts.cfg_weight,
            # Conditionals were prepared once in __init__, so no per-segment voice embedding.
            audio_prompt_path=None,
        )
        if not self.multilingual:
            kwargs.update(
                min_p=self.cfg.tts.min_p,
                top_p=self.cfg.tts.top_p,
                repetition_penalty=self.cfg.tts.repetition_penalty,
            )
        if self.multilingual:
            kwargs.update(
                language_id=self.cfg.tts.language_id,
                min_p=self.cfg.tts.min_p,
                top_p=self.cfg.tts.top_p,
                repetition_penalty=self.cfg.tts.repetition_penalty,
            )

        wav = self.model.generate(text, **kwargs)
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        self.ta.save(str(out_path), wav.cpu(), self.model.sr)
        return float(sf.info(out_path).duration)

    def close(self):
        self.model = None
