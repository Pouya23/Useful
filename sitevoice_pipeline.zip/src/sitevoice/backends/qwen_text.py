from __future__ import annotations

import json
from typing import TypeVar, Type

from pydantic import BaseModel, ValidationError

from ..config import AppConfig
from ..utils import digest, extract_json_object

T = TypeVar("T", bound=BaseModel)


class QwenTextBackend:
    def __init__(self, cfg: AppConfig):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

        self.cfg = cfg
        self.tokenizer = AutoTokenizer.from_pretrained(cfg.llm.model_id)
        kwargs = {"device_map": {"": cfg.resources.gpu_index}, "torch_dtype": "auto"}
        if cfg.llm.load_in_4bit:
            compute_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=compute_dtype,
            )
        self.model = AutoModelForCausalLM.from_pretrained(cfg.llm.model_id, **kwargs)
        self.model.eval()

    def count_tokens(self, text: str) -> int:
        return len(self.tokenizer(text, add_special_tokens=False)["input_ids"])

    def generate(self, system: str, user: str, max_new_tokens: int | None = None) -> str:
        import torch

        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        inputs = self.tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            tokenize=True,
            return_dict=True,
            return_tensors="pt",
        )
        device = next(self.model.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        input_tokens = int(inputs["input_ids"].shape[-1])
        if input_tokens > self.cfg.llm.max_prompt_tokens:
            raise ValueError(
                f"Prompt budget exceeded: {input_tokens} tokens > "
                f"{self.cfg.llm.max_prompt_tokens}. Reduce evidence/sample text."
            )

        seed = int(digest({"system": system, "user": user})[:8], 16)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

        with torch.inference_mode():
            out = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens or self.cfg.llm.max_new_tokens,
                do_sample=True,
                temperature=self.cfg.llm.temperature,
                top_p=self.cfg.llm.top_p,
                top_k=self.cfg.llm.top_k,
            )
        generated = out[0, inputs["input_ids"].shape[-1]:]
        return self.tokenizer.decode(generated, skip_special_tokens=True).strip()

    def generate_json(self, model_type: Type[T], system: str, user: str) -> T:
        schema = json.dumps(model_type.model_json_schema(), ensure_ascii=False)
        instruction = (
            user
            + "\n\nReturn ONLY one JSON object. It must validate against this JSON schema:\n"
            + schema
        )
        last_error: Exception | None = None
        raw = ""
        for attempt in range(self.cfg.llm.json_repair_attempts + 1):
            if attempt:
                instruction = (
                    "Repair the following invalid JSON/model output. Return ONLY the corrected JSON.\n\n"
                    f"VALIDATION ERROR:\n{last_error}\n\nOUTPUT:\n{raw}\n\nSCHEMA:\n{schema}"
                )
            raw = self.generate(system, instruction)
            try:
                return model_type.model_validate_json(extract_json_object(raw))
            except (ValueError, ValidationError) as exc:
                last_error = exc
        raise ValueError(f"Unable to obtain valid {model_type.__name__}: {last_error}")

    def close(self):
        self.model = None
        self.tokenizer = None
