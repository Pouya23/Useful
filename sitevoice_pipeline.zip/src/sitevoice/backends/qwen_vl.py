from __future__ import annotations

import json
from pathlib import Path

from pydantic import BaseModel, Field

from ..config import AppConfig
from ..schemas import Scene, VisionObservation
from ..utils import extract_json_object


class ObservationBody(BaseModel):
    location_context: str = ""
    visible_actions: list[str] = Field(default_factory=list)
    visible_equipment: list[str] = Field(default_factory=list)
    visible_text: list[str] = Field(default_factory=list)
    supported_inferences: list[str] = Field(default_factory=list)
    do_not_claim: list[str] = Field(default_factory=list)
    confidence: float = Field(default=0.5, ge=0, le=1)


class QwenVLBackend:
    def __init__(self, cfg: AppConfig):
        import torch
        from transformers import AutoProcessor, BitsAndBytesConfig, Qwen3VLForConditionalGeneration

        self.cfg = cfg
        kwargs = {
            "device_map": {"": cfg.resources.gpu_index},
            "dtype": "auto",
        }
        if cfg.vision.load_in_4bit:
            compute_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=compute_dtype,
            )
        self.processor = AutoProcessor.from_pretrained(cfg.vision.model_id)

        # Official Qwen3-VL processor semantics: this is a total video-pixel budget.
        compression = 32 * 32 * 2
        self.processor.video_processor.size = {
            "shortest_edge": cfg.vision.min_visual_tokens * compression,
            "longest_edge": cfg.vision.max_visual_tokens * compression,
        }
        self.model = Qwen3VLForConditionalGeneration.from_pretrained(cfg.vision.model_id, **kwargs)
        self.model.eval()

    def analyze(self, scene: Scene, topic: str, description: str | None) -> VisionObservation:
        import torch
        from qwen_vl_utils import process_vision_info

        if not scene.frames:
            return VisionObservation(
                scene_id=scene.id,
                start=scene.interval.start,
                end=scene.interval.end,
                confidence=0.0,
                do_not_claim=["No representative frames were available for this scene."],
            )

        schema = json.dumps(ObservationBody.model_json_schema(), ensure_ascii=False)
        timestamp_note = ", ".join(f"{f.timestamp:.2f}s" for f in scene.frames)
        prompt = f"""
Analyze ONLY what is supported by these ordered frames from one construction/job-site scene.

Job topic: {topic}
User description: {description or "none"}
Scene interval: {scene.interval.start:.2f}-{scene.interval.end:.2f}s
Frame timestamps in order: {timestamp_note}

Rules:
- Separate directly visible facts from cautious supported inferences.
- Do not invent a defect, repair, component replacement, measurement, safety state, torque,
  operating limit, or procedural requirement.
- Use `do_not_claim` for plausible but unsupported claims a later narrator must avoid.
- `confidence` is confidence in the observation, not a probability of safety.
- Keep lists concise.
- Return ONLY JSON matching this schema:
{schema}
""".strip()

        messages = [{
            "role": "user",
            "content": [
                {
                    "type": "video",
                    "video": [Path(f.path).resolve().as_uri() for f in scene.frames],
                },
                {"type": "text", "text": prompt},
            ],
        }]

        text = self.processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        images, videos, video_kwargs = process_vision_info(
            messages,
            image_patch_size=self.processor.image_processor.patch_size,
            return_video_kwargs=True,
            return_video_metadata=True,
        )
        if videos is not None:
            videos, video_metadata = zip(*videos)
            videos, video_metadata = list(videos), list(video_metadata)
        else:
            video_metadata = None

        inputs = self.processor(
            text=text,
            images=images,
            videos=videos,
            video_metadata=video_metadata,
            return_tensors="pt",
            do_resize=False,
            **video_kwargs,
        )
        inputs = inputs.to(self.model.device)

        generation_kwargs = {"max_new_tokens": self.cfg.vision.max_new_tokens}
        if self.cfg.vision.temperature > 0:
            generation_kwargs.update(
                do_sample=True,
                temperature=self.cfg.vision.temperature,
            )
        else:
            generation_kwargs["do_sample"] = False

        with torch.inference_mode():
            out = self.model.generate(**inputs, **generation_kwargs)

        trimmed = out[:, inputs.input_ids.shape[-1]:]
        raw = self.processor.batch_decode(
            trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0]
        body = ObservationBody.model_validate_json(extract_json_object(raw))
        return VisionObservation(
            scene_id=scene.id,
            start=scene.interval.start,
            end=scene.interval.end,
            **body.model_dump(),
        )

    def close(self):
        self.model = None
        self.processor = None
