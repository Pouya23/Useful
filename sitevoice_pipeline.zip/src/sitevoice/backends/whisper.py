from __future__ import annotations

from ..config import AppConfig
from ..schemas import Transcript, TranscriptSegment, TranscriptWord


class WhisperBackend:
    def __init__(self, cfg: AppConfig):
        from faster_whisper import WhisperModel
        self.cfg = cfg
        self.model = WhisperModel(
            cfg.asr.model_id,
            device=cfg.asr.device,
            device_index=cfg.resources.gpu_index if cfg.asr.device == "cuda" else 0,
            compute_type=cfg.asr.compute_type,
        )

    def transcribe(self, audio_path: str) -> Transcript:
        segments, info = self.model.transcribe(
            audio_path,
            beam_size=self.cfg.asr.beam_size,
            word_timestamps=self.cfg.asr.word_timestamps,
            vad_filter=self.cfg.asr.vad_filter,
            vad_parameters={"min_silence_duration_ms": self.cfg.asr.min_silence_duration_ms},
            condition_on_previous_text=False,
        )
        items = []
        for s in segments:
            words = [
                TranscriptWord(
                    start=w.start,
                    end=w.end,
                    text=w.word.strip(),
                    probability=getattr(w, "probability", None),
                )
                for w in (s.words or [])
            ]
            items.append(TranscriptSegment(start=s.start, end=s.end, text=s.text.strip(), words=words))
        return Transcript(
            language=getattr(info, "language", None),
            language_probability=getattr(info, "language_probability", None),
            segments=items,
        )

    def close(self):
        self.model = None
