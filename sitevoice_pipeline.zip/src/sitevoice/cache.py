from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, TypeVar, Type

from pydantic import BaseModel

from .utils import digest

T = TypeVar("T", bound=BaseModel)


class StageCache:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def run(
        self,
        name: str,
        version: str,
        fingerprint_payload: dict,
        output_model: Type[T],
        fn: Callable[[Path], T],
    ) -> T:
        stage_dir = self.root / name
        stage_dir.mkdir(parents=True, exist_ok=True)
        fingerprint = digest({"version": version, **fingerprint_payload})
        meta_path = stage_dir / "meta.json"
        result_path = stage_dir / "result.json"

        if meta_path.exists() and result_path.exists():
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if meta.get("fingerprint") == fingerprint:
                return output_model.model_validate_json(result_path.read_text(encoding="utf-8"))

        result = fn(stage_dir)
        result_path.write_text(result.model_dump_json(indent=2), encoding="utf-8")
        meta_path.write_text(
            json.dumps({"fingerprint": fingerprint, "version": version}, indent=2),
            encoding="utf-8",
        )
        return result
