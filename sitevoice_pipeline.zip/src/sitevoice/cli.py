from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from .config import load_config
from .orchestrator import PipelineRunner

app = typer.Typer(no_args_is_help=True)
console = Console()


@app.command()
def run(
    video: Path = typer.Argument(..., exists=True, readable=True),
    topic: str = typer.Option(..., "--topic"),
    description: str | None = typer.Option(None, "--description"),
    voice_ref: Path | None = typer.Option(None, "--voice-ref", exists=True, readable=True),
    sample_text: Path | None = typer.Option(None, "--sample-text", exists=True, readable=True),
    domain_pack: Path | None = typer.Option(None, "--domain-pack", exists=True, readable=True),
    style: Path | None = typer.Option(None, "--style", exists=True, readable=True),
    config: Path = typer.Option(Path("configs/default.yaml"), "--config", exists=True, readable=True),
    job_id: str | None = typer.Option(None, "--job-id"),
):
    cfg = load_config(config)
    runner = PipelineRunner(cfg)
    result = runner.run(
        source=video,
        topic=topic,
        description=description,
        voice_ref=str(voice_ref) if voice_ref else None,
        sample_text_path=str(sample_text) if sample_text else None,
        domain_pack_path=str(domain_pack) if domain_pack else None,
        style_path=str(style) if style else None,
        job_id=job_id,
    )

    console.print(f"job_id: {result.job_id}")
    console.print(f"final video: {result.final_video}")
    console.print(f"narration: {result.narration_track}")
    console.print(f"QA: {result.qa_json}")


@app.command()
def doctor(
    config: Path = typer.Option(Path("configs/default.yaml"), "--config", exists=True, readable=True),
):
    from .doctor import inspect

    cfg = load_config(config)
    report = inspect(cfg)
    console.print(f"ffmpeg: {'ok' if report.ffmpeg else 'missing'}")
    console.print(f"ffprobe: {'ok' if report.ffprobe else 'missing'}")
    console.print(f"CUDA: {'yes' if report.cuda else 'no'}")
    if report.gpu_name:
        console.print(f"GPU: {report.gpu_name}")
        console.print(f"VRAM total/free: {report.total_vram_gib:.2f}/{report.free_vram_gib:.2f} GiB")
    if report.estimated_text_kv_gib is not None:
        console.print(f"Estimated text KV cache: {report.estimated_text_kv_gib:.2f} GiB")
    for note in report.notes:
        console.print(f"- {note}")


if __name__ == "__main__":
    app()
