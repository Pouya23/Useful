from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field


class PipelineConfig(BaseModel):
    mode: Literal["text", "vision", "asr", "full"] = "text"


class PathsConfig(BaseModel):
    runs_dir: str = "runs"


class ResourcesConfig(BaseModel):
    gpu_index: int = 0
    exclusive_gpu_model: bool = True
    min_free_vram_gib_before_load: float = 7.0
    clear_cuda_cache_on_evict: bool = True


class IngestConfig(BaseModel):
    audio_sample_rate: int = 48000
    audio_channels: int = 1


class ScenesConfig(BaseModel):
    adaptive_threshold: float = 3.5
    window_width: int = 3
    min_scene_len_seconds: float = 0.6
    short_scene_seconds: float = 3.0
    medium_scene_seconds: float = 10.0
    long_scene_sample_fps: float = 0.75
    max_frames_per_scene: int = 8
    frame_max_width: int = 960
    jpeg_quality: int = 90
    ahash_hamming_min: int = 6


class VisionConfig(BaseModel):
    model_id: str = "Qwen/Qwen3-VL-4B-Instruct"
    load_in_4bit: bool = True
    max_new_tokens: int = 650
    temperature: float = 0.0
    min_visual_tokens: int = 256
    max_visual_tokens: int = 4096


class ASRConfig(BaseModel):
    model_id: str = "distil-large-v3"
    device: str = "cuda"
    compute_type: str = "int8_float16"
    beam_size: int = 5
    vad_filter: bool = True
    min_silence_duration_ms: int = 500
    word_timestamps: bool = True


class LLMConfig(BaseModel):
    model_id: str = "Qwen/Qwen3-4B-Instruct-2507"
    load_in_4bit: bool = True
    max_context_tokens: int = 8192
    max_prompt_tokens: int = 6144
    max_new_tokens: int = 1600
    temperature: float = 0.6
    top_p: float = 0.8
    top_k: int = 20
    json_repair_attempts: int = 2


class NarrationConfig(BaseModel):
    language: str = "en"
    speech_occupancy: float = Field(default=0.86, gt=0.4, le=0.95)
    target_slot_seconds: float = 22.0
    min_slot_seconds: float = 12.0
    max_slot_seconds: float = 32.0
    min_words_per_segment: int = 12
    max_words_per_segment: int = 90
    planning_window_seconds: float = 180.0
    previous_context_chars: int = 280


class TTSConfig(BaseModel):
    # multilingual_v3 is the default and maps to ChatterboxMultilingualTTS(..., t3_model="v3").
    engine: Literal["multilingual_v3", "multilingual", "original"] = "multilingual_v3"
    language_id: str = "en"
    exaggeration: float = 0.45
    cfg_weight: float = 0.40
    temperature: float = 0.80
    min_p: float = 0.05
    top_p: float = 1.0
    repetition_penalty: float = 1.2
    seed: int = 1337
    calibration_text: str
    default_words_per_second: float = 2.25


class FittingConfig(BaseModel):
    rewrite_tolerance_ratio: float = 0.04
    accept_short_ratio: float = 0.06
    max_passes: int = 2
    max_speedup_ratio: float = 0.03


class MixConfig(BaseModel):
    sample_rate: int = 48000
    source_gain_db: float = -8.0
    narration_gain_db: float = 0.0
    enable_ducking: bool = True
    duck_threshold: float = 0.02
    duck_ratio: float = 8.0
    duck_attack_ms: int = 20
    duck_release_ms: int = 300
    target_lufs: float = -16.0


class QAConfig(BaseModel):
    require_evidence_ids: bool = True
    fail_on_unknown_evidence: bool = True
    max_segment_overrun_seconds: float = 0.15


class AppConfig(BaseModel):
    pipeline: PipelineConfig = PipelineConfig()
    paths: PathsConfig = PathsConfig()
    resources: ResourcesConfig = ResourcesConfig()
    ingest: IngestConfig = IngestConfig()
    scenes: ScenesConfig = ScenesConfig()
    vision: VisionConfig = VisionConfig()
    asr: ASRConfig = ASRConfig()
    llm: LLMConfig = LLMConfig()
    narration: NarrationConfig = NarrationConfig()
    tts: TTSConfig
    fitting: FittingConfig = FittingConfig()
    mix: MixConfig = MixConfig()
    qa: QAConfig = QAConfig()


def load_config(path: str | Path) -> AppConfig:
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    return AppConfig.model_validate(data)


def load_yaml(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    return yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
