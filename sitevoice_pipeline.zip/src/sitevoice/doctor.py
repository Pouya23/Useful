from __future__ import annotations

import shutil
from dataclasses import dataclass

from .config import AppConfig


@dataclass
class DoctorReport:
    ffmpeg: bool
    ffprobe: bool
    cuda: bool
    gpu_name: str | None
    total_vram_gib: float | None
    free_vram_gib: float | None
    estimated_text_kv_gib: float | None
    notes: list[str]


def _kv_cache_gib(model_id: str, context: int) -> float | None:
    try:
        from transformers import AutoConfig
        cfg = AutoConfig.from_pretrained(model_id)
        layers = int(cfg.num_hidden_layers)
        kv_heads = int(getattr(cfg, "num_key_value_heads", cfg.num_attention_heads))
        head_dim = int(getattr(cfg, "head_dim", cfg.hidden_size // cfg.num_attention_heads))
        # K + V, FP16/BF16 cache => two tensors * two bytes.
        bytes_per_token = layers * kv_heads * head_dim * 2 * 2
        return bytes_per_token * context / (1024 ** 3)
    except Exception:
        return None


def inspect(cfg: AppConfig) -> DoctorReport:
    notes = []
    cuda = False
    gpu_name = None
    total = free = None
    try:
        import torch
        cuda = torch.cuda.is_available()
        if cuda:
            idx = cfg.resources.gpu_index
            torch.cuda.set_device(idx)
            props = torch.cuda.get_device_properties(idx)
            gpu_name = props.name
            free_b, total_b = torch.cuda.mem_get_info(idx)
            free = free_b / (1024 ** 3)
            total = total_b / (1024 ** 3)
            if free < cfg.resources.min_free_vram_gib_before_load:
                notes.append("Free VRAM is below the configured pre-load threshold.")
    except Exception as exc:
        notes.append(f"CUDA inspection failed: {exc}")

    kv = _kv_cache_gib(cfg.llm.model_id, cfg.llm.max_context_tokens)
    if kv is not None:
        notes.append(
            f"Approximate text-model KV cache at {cfg.llm.max_context_tokens} tokens: "
            f"{kv:.2f} GiB (FP16/BF16 cache only; weights/activations are additional)."
        )

    return DoctorReport(
        ffmpeg=shutil.which("ffmpeg") is not None,
        ffprobe=shutil.which("ffprobe") is not None,
        cuda=cuda,
        gpu_name=gpu_name,
        total_vram_gib=total,
        free_vram_gib=free,
        estimated_text_kv_gib=kv,
        notes=notes,
    )
