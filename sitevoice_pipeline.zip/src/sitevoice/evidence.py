from __future__ import annotations

from .schemas import (
    EvidenceItem, EvidenceTimeline, Interval, MediaInfo, Transcript, VisionObservations
)


def build_evidence(
    media: MediaInfo,
    topic: str,
    description: str | None,
    observations: VisionObservations,
    transcript: Transcript,
    domain_pack: dict,
) -> EvidenceTimeline:
    items: list[EvidenceItem] = []

    if description:
        items.append(EvidenceItem(
            id="U001", kind="user", text=description, source="user_description"
        ))

    for i, obs in enumerate(observations.observations, 1):
        parts = []
        if obs.location_context:
            parts.append(f"Context: {obs.location_context}")
        if obs.visible_actions:
            parts.append("Visible actions: " + "; ".join(obs.visible_actions))
        if obs.visible_equipment:
            parts.append("Visible equipment: " + "; ".join(obs.visible_equipment))
        if obs.visible_text:
            parts.append("Visible text: " + "; ".join(obs.visible_text))
        if obs.supported_inferences:
            parts.append("Supported inferences: " + "; ".join(obs.supported_inferences))
        if obs.do_not_claim:
            parts.append("Do not claim: " + "; ".join(obs.do_not_claim))
        items.append(EvidenceItem(
            id=f"V{i:04d}",
            kind="visual",
            interval=Interval(start=obs.start, end=obs.end),
            text=" | ".join(parts),
            confidence=obs.confidence,
            source=obs.scene_id,
        ))

    for i, seg in enumerate(transcript.segments, 1):
        if seg.text.strip():
            items.append(EvidenceItem(
                id=f"T{i:04d}",
                kind="transcript",
                interval=Interval(start=seg.start, end=seg.end),
                text=seg.text.strip(),
                confidence=0.9,
                source="source_audio_asr",
            ))

    for i, fact in enumerate(domain_pack.get("safe_general_facts", []), 1):
        items.append(EvidenceItem(
            id=f"K{i:04d}", kind="domain", text=str(fact),
            source=f"domain_pack:{domain_pack.get('topic', 'unknown')}"
        ))

    avoid = domain_pack.get("avoid_without_direct_approved_evidence", [])
    if avoid:
        items.append(EvidenceItem(
            id="K_AVOID", kind="domain",
            text="Do not assert without direct approved evidence: " + "; ".join(map(str, avoid)),
            source=f"domain_pack:{domain_pack.get('topic', 'unknown')}"
        ))

    return EvidenceTimeline(
        topic=topic, description=description, duration=media.duration, items=items
    )


def evidence_for_interval(evidence: EvidenceTimeline, interval: Interval) -> list[EvidenceItem]:
    result = []
    for item in evidence.items:
        if item.interval is None:
            result.append(item)
            continue
        overlap = min(item.interval.end, interval.end) - max(item.interval.start, interval.start)
        if overlap > 0:
            result.append(item)
    return result
