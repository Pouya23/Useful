from __future__ import annotations

import json
import math
from pathlib import Path

import cv2
import numpy as np
from scenedetect import detect
from scenedetect.detectors import AdaptiveDetector

from .config import AppConfig
from .schemas import FrameSample, Interval, MediaInfo, Scene, SceneSet
from .utils import evenly_spaced, run


def probe_media(path: str | Path) -> dict:
    cp = run([
        "ffprobe", "-v", "error", "-print_format", "json",
        "-show_streams", "-show_format", str(path)
    ], capture=True)
    return json.loads(cp.stdout)


def _parse_fps(value: str) -> float:
    if "/" in value:
        a, b = value.split("/", 1)
        return float(a) / max(float(b), 1.0)
    return float(value)


def ingest_video(source: str | Path, out_dir: Path, cfg: AppConfig) -> MediaInfo:
    source = Path(source).resolve()
    info = probe_media(source)
    streams = info["streams"]
    video = next(s for s in streams if s.get("codec_type") == "video")
    audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
    duration = float(info.get("format", {}).get("duration") or video.get("duration"))
    fps = _parse_fps(video.get("avg_frame_rate") or video.get("r_frame_rate") or "0/1")

    source_dir = out_dir / "source"
    source_dir.mkdir(parents=True, exist_ok=True)
    video_only = source_dir / "video_only.mp4"
    run(["ffmpeg", "-y", "-i", str(source), "-map", "0:v:0", "-an", "-c:v", "copy", str(video_only)])

    source_audio = None
    if audio is not None:
        source_audio = source_dir / "source_audio.wav"
        run([
            "ffmpeg", "-y", "-i", str(source), "-map", "0:a:0",
            "-ac", str(cfg.ingest.audio_channels),
            "-ar", str(cfg.ingest.audio_sample_rate),
            "-c:a", "pcm_s16le", str(source_audio)
        ])

    return MediaInfo(
        source_path=str(source),
        duration=duration,
        width=int(video["width"]),
        height=int(video["height"]),
        fps=fps,
        has_audio=audio is not None,
        video_only_path=str(video_only),
        source_audio_path=str(source_audio) if source_audio else None,
    )


def detect_scenes(media: MediaInfo, cfg: AppConfig) -> list[tuple[float, float]]:
    detector = AdaptiveDetector(
        adaptive_threshold=cfg.scenes.adaptive_threshold,
        window_width=cfg.scenes.window_width,
        min_scene_len=f"{cfg.scenes.min_scene_len_seconds}s",
    )
    detected = detect(media.video_only_path, detector, show_progress=False)
    scenes = [(a.get_seconds(), b.get_seconds()) for a, b in detected]
    if not scenes:
        scenes = [(0.0, media.duration)]
    # Cover any tiny unreported tail.
    if scenes[-1][1] < media.duration - 0.05:
        scenes[-1] = (scenes[-1][0], media.duration)
    return scenes


def _ahash(frame: np.ndarray) -> str:
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    small = cv2.resize(gray, (8, 8), interpolation=cv2.INTER_AREA)
    bits = small > small.mean()
    packed = 0
    for bit in bits.flatten():
        packed = (packed << 1) | int(bit)
    return f"{packed:016x}"


def _hamming_hex(a: str, b: str) -> int:
    return (int(a, 16) ^ int(b, 16)).bit_count()


def _sample_count(duration: float, cfg: AppConfig) -> int:
    if duration < cfg.scenes.short_scene_seconds:
        return 2
    if duration < cfg.scenes.medium_scene_seconds:
        return 3
    return min(
        cfg.scenes.max_frames_per_scene,
        max(3, math.ceil(duration * cfg.scenes.long_scene_sample_fps)),
    )


def sample_scene_frames(media: MediaInfo, ranges: list[tuple[float, float]], out_dir: Path, cfg: AppConfig) -> SceneSet:
    frames_root = out_dir / "frames"
    frames_root.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(media.video_only_path)
    results: list[Scene] = []

    try:
        for idx, (start, end) in enumerate(ranges):
            scene_id = f"scene_{idx:04d}"
            scene_dir = frames_root / scene_id
            scene_dir.mkdir(parents=True, exist_ok=True)
            samples: list[FrameSample] = []
            prev_hash: str | None = None

            for j, ts in enumerate(evenly_spaced(start, end, _sample_count(end - start, cfg))):
                cap.set(cv2.CAP_PROP_POS_MSEC, ts * 1000.0)
                ok, frame = cap.read()
                if not ok:
                    continue

                h, w = frame.shape[:2]
                if w > cfg.scenes.frame_max_width:
                    new_h = round(h * cfg.scenes.frame_max_width / w)
                    frame = cv2.resize(frame, (cfg.scenes.frame_max_width, new_h), interpolation=cv2.INTER_AREA)

                ah = _ahash(frame)
                if prev_hash is not None and _hamming_hex(prev_hash, ah) < cfg.scenes.ahash_hamming_min:
                    continue

                frame_path = scene_dir / f"{j:02d}_{ts:.3f}.jpg"
                cv2.imwrite(
                    str(frame_path),
                    frame,
                    [int(cv2.IMWRITE_JPEG_QUALITY), cfg.scenes.jpeg_quality],
                )
                samples.append(FrameSample(timestamp=ts, path=str(frame_path), ahash=ah))
                prev_hash = ah

            results.append(Scene(id=scene_id, interval=Interval(start=start, end=end), frames=samples))
    finally:
        cap.release()

    return SceneSet(scenes=results)
