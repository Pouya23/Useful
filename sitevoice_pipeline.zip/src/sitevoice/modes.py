from __future__ import annotations

import importlib.util
from enum import Enum


class PipelineMode(str, Enum):
    TEXT = "text"
    VISION = "vision"
    ASR = "asr"
    FULL = "full"

    @property
    def uses_vision(self) -> bool:
        return self in {PipelineMode.VISION, PipelineMode.FULL}

    @property
    def uses_asr(self) -> bool:
        return self in {PipelineMode.ASR, PipelineMode.FULL}

    @property
    def label(self) -> str:
        return {
            PipelineMode.TEXT: "Qwen3-4B + Chatterbox V3",
            PipelineMode.VISION: "Qwen3-4B + Qwen3-VL + Chatterbox V3",
            PipelineMode.ASR: "Qwen3-4B + faster-whisper + Chatterbox V3",
            PipelineMode.FULL: "Qwen3-4B + Qwen3-VL + faster-whisper + Chatterbox V3",
        }[self]


def resolve_mode(value: PipelineMode | str | None, default: str = "text") -> PipelineMode:
    if value is None:
        value = default
    if isinstance(value, PipelineMode):
        return value
    aliases = {
        "core": "text",
        "text-only": "text",
        "audio": "asr",
        "audio-only": "asr",
        "vision-only": "vision",
    }
    normalized = aliases.get(str(value).strip().lower(), str(value).strip().lower())
    try:
        return PipelineMode(normalized)
    except ValueError as exc:
        choices = ", ".join(m.value for m in PipelineMode)
        raise ValueError(f"Unknown pipeline mode {value!r}. Choose one of: {choices}") from exc


def required_modules(mode: PipelineMode, *, quantized: bool = True) -> dict[str, str]:
    modules = {
        "torch": "torch",
        "transformers": "transformers",
        "accelerate": "accelerate",
        "chatterbox": "chatterbox-tts",
    }
    if quantized:
        modules["bitsandbytes"] = "bitsandbytes"
    if mode.uses_vision:
        modules["qwen_vl_utils"] = "qwen-vl-utils"
    if mode.uses_asr:
        modules["faster_whisper"] = "faster-whisper"
    return modules


def missing_modules(mode: PipelineMode, *, quantized: bool = True) -> list[str]:
    missing = []
    for module, package in required_modules(mode, quantized=quantized).items():
        if importlib.util.find_spec(module) is None:
            missing.append(package)
    return missing


def install_extra(mode: PipelineMode) -> str:
    return mode.value
