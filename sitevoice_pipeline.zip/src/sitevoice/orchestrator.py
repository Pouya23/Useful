from __future__ import annotations

import json
import uuid
from pathlib import Path

from .audio import audio_duration, build_narration_track, mix_and_render, time_stretch_ffmpeg
from .backends.chatterbox import ChatterboxBackend
from .backends.qwen_text import QwenTextBackend
from .backends.qwen_vl import QwenVLBackend
from .backends.whisper import WhisperBackend
from .cache import StageCache
from .config import AppConfig, load_yaml
from .evidence import build_evidence
from .media import detect_scenes, ingest_video, sample_scene_frames
from .planning import build_slots
from .qa import run_qa
from .resources import ModelPool
from .schemas import (
    EvidenceTimeline, MediaInfo, PipelineResult, QAReport, SceneSet, Script,
    SynthesisManifest, SynthesizedSegment, Transcript, VisionObservations,
    VoiceCalibration, StyleProfile, NarrationPlan
)
from .utils import fast_file_fingerprint, digest, word_count
from .writing import derive_style, rewrite_for_duration, write_script


class PipelineRunner:
    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.pool = ModelPool(
            clear_cuda_cache=cfg.resources.clear_cuda_cache_on_evict,
            gpu_index=cfg.resources.gpu_index,
            min_free_vram_gib=cfg.resources.min_free_vram_gib_before_load,
        )

    def _job_id(self, source: Path, topic: str) -> str:
        fp = fast_file_fingerprint(source)
        return digest({"source": fp, "topic": topic})[:12]

    def run(
        self,
        source: str | Path,
        topic: str,
        description: str | None = None,
        voice_ref: str | None = None,
        sample_text_path: str | None = None,
        domain_pack_path: str | None = None,
        style_path: str | None = None,
        job_id: str | None = None,
    ) -> PipelineResult:
        source = Path(source).resolve()
        job_id = job_id or self._job_id(source, topic)
        run_root = Path(self.cfg.paths.runs_dir) / job_id
        run_root.mkdir(parents=True, exist_ok=True)
        cache = StageCache(run_root / "stages")

        source_fp = fast_file_fingerprint(source)
        voice_fp = fast_file_fingerprint(voice_ref) if voice_ref else None
        sample_text = Path(sample_text_path).read_text(encoding="utf-8") if sample_text_path else None
        domain_pack = load_yaml(domain_pack_path)
        base_style = load_yaml(style_path) if style_path else {
            "name": "instructional",
            "tone": "clear, educational, measured",
            "technicality": 0.65,
            "energy": 0.45,
            "sentence_length": "medium",
            "explanation_density": "high",
            "avoid": ["unsupported diagnoses", "hype", "repetitive visual description"],
        }

        media = cache.run(
            "ingest", "2",
            {"source": source_fp, "cfg": self.cfg.ingest.model_dump()},
            MediaInfo,
            lambda _: ingest_video(source, run_root, self.cfg),
        )

        def make_scenes(_):
            ranges = detect_scenes(media, self.cfg)
            return sample_scene_frames(media, ranges, run_root, self.cfg)

        scenes = cache.run(
            "scenes", "3",
            {"source": source_fp, "media": media.model_dump(), "cfg": self.cfg.scenes.model_dump()},
            SceneSet,
            make_scenes,
        )

        # VLM first. One load, all scenes.
        def make_vision(_):
            model = self.pool.get(
                f"vl:{self.cfg.vision.model_id}",
                lambda: QwenVLBackend(self.cfg),
                lambda m: m.close(),
            )
            return VisionObservations(
                observations=[model.analyze(scene, topic, description) for scene in scenes.scenes]
            )

        vision = cache.run(
            "vision", "3",
            {"source": source_fp, "scenes": scenes.model_dump(), "topic": topic, "description": description,
             "cfg": self.cfg.vision.model_dump()},
            VisionObservations,
            make_vision,
        )

        # ASR is a different GPU family, so the pool evicts VL.
        def make_transcript(_):
            if not media.source_audio_path or not self.cfg.asr.enabled:
                return Transcript()
            model = self.pool.get(
                f"asr:{self.cfg.asr.model_id}:{self.cfg.asr.compute_type}",
                lambda: WhisperBackend(self.cfg),
                lambda m: m.close(),
            )
            return model.transcribe(media.source_audio_path)

        transcript = cache.run(
            "transcript", "2",
            {"source": source_fp, "audio": media.source_audio_path, "cfg": self.cfg.asr.model_dump()},
            Transcript,
            make_transcript,
        )

        evidence = cache.run(
            "evidence", "2",
            {"source": source_fp, "vision": vision.model_dump(), "transcript": transcript.model_dump(),
             "topic": topic, "description": description, "domain_pack": domain_pack},
            EvidenceTimeline,
            lambda _: build_evidence(media, topic, description, vision, transcript, domain_pack),
        )

        # Calibrate TTS before loading the text model so all text calls can then be contiguous.
        def make_calibration(stage_dir: Path):
            tts = self.pool.get(
                f"tts:{self.cfg.tts.engine}:{voice_fp}",
                lambda: ChatterboxBackend(self.cfg, voice_ref),
                lambda m: m.close(),
            )
            cal_path = stage_dir / "calibration.wav"
            dur = tts.synthesize(self.cfg.tts.calibration_text, cal_path)
            words = word_count(self.cfg.tts.calibration_text)
            wps = words / dur if dur > 0 else self.cfg.tts.default_words_per_second
            return VoiceCalibration(
                key=digest({"voice": voice_fp, "tts": self.cfg.tts.model_dump()}),
                words=words,
                duration_seconds=dur,
                words_per_second=wps,
                sample_path=str(cal_path),
            )

        calibration = cache.run(
            "voice_calibration", "2",
            {"voice": voice_fp, "tts": self.cfg.tts.model_dump()},
            VoiceCalibration,
            make_calibration,
        )

        # Load Qwen text once and reuse it through style + writing.
        llm = self.pool.get(
            f"llm:{self.cfg.llm.model_id}",
            lambda: QwenTextBackend(self.cfg),
            lambda m: m.close(),
        )

        style = cache.run(
            "style", "2",
            {"base_style": base_style, "sample_text": sample_text, "llm": self.cfg.llm.model_dump()},
            StyleProfile,
            lambda _: derive_style(llm, base_style, sample_text),
        )

        plan = cache.run(
            "plan", "3",
            {"evidence": evidence.model_dump(), "wps": calibration.words_per_second,
             "cfg": self.cfg.narration.model_dump()},
            NarrationPlan,
            lambda _: build_slots(evidence, calibration.words_per_second, self.cfg),
        )

        script = cache.run(
            "script", "4",
            {"plan": plan.model_dump(), "style": style.model_dump(),
             "evidence": evidence.model_dump(), "llm": self.cfg.llm.model_dump()},
            Script,
            lambda _: write_script(llm, plan, evidence, style, self.cfg),
        )

        # TTS in one model residency.
        self.pool.evict()
        tts_root = run_root / "tts"
        tts_root.mkdir(exist_ok=True)

        tts_cache = tts_root / "cache"
        tts_cache.mkdir(exist_ok=True)

        def synthesize_script(current: Script, pass_index: int) -> SynthesisManifest:
            tts = self.pool.get(
                f"tts:{self.cfg.tts.engine}:{voice_fp}",
                lambda: ChatterboxBackend(self.cfg, voice_ref),
                lambda m: m.close(),
            )
            out = []
            for seg in current.segments:
                # Stable across reruns; a text/style/voice change gets a new file automatically.
                seed_offset = int(digest({"segment": seg.id})[:8], 16) % 100000
                tts_key = digest({
                    "text": seg.text,
                    "voice": voice_fp,
                    "tts": self.cfg.tts.model_dump(),
                    "seed_offset": seed_offset,
                })
                p = tts_cache / f"{tts_key}.wav"
                if p.exists():
                    dur = audio_duration(p)
                else:
                    dur = tts.synthesize(seg.text, p, seed_offset=seed_offset)
                out.append(SynthesizedSegment(
                    id=seg.id,
                    path=str(p),
                    raw_duration_seconds=dur,
                    final_duration_seconds=dur,
                    target_speech_seconds=seg.target_speech_seconds,
                ))
            return SynthesisManifest(segments=out)

        synth = synthesize_script(script, 0)

        # Fit loop: batch all rewrites, then batch all resynthesis. Never swap models per segment.
        for pass_index in range(1, self.cfg.fitting.max_passes + 1):
            synth_by_id = {x.id: x for x in synth.segments}
            off = []
            for seg in script.segments:
                actual = synth_by_id[seg.id].raw_duration_seconds
                target = seg.target_speech_seconds
                too_long = actual > target * (1 + self.cfg.fitting.rewrite_tolerance_ratio)
                too_short = actual < target * (1 - self.cfg.fitting.accept_short_ratio)
                if too_long or too_short:
                    desired = max(
                        5,
                        round(seg.word_count * target / max(actual, 0.25)),
                    )
                    off.append((seg.id, desired))

            if not off:
                break

            self.pool.evict()
            llm = self.pool.get(
                f"llm:{self.cfg.llm.model_id}",
                lambda: QwenTextBackend(self.cfg),
                lambda m: m.close(),
            )
            desired_by_id = dict(off)
            revised = []
            for seg in script.segments:
                if seg.id in desired_by_id:
                    revised.append(rewrite_for_duration(
                        llm, seg, desired_by_id[seg.id], evidence
                    ))
                else:
                    revised.append(seg)
            script = Script(segments=revised)

            self.pool.evict()
            synth = synthesize_script(script, pass_index)

        # Residual policy: only speed up slight overruns. Short segments retain natural silence.
        final_segments = []
        for seg, syn in zip(script.segments, synth.segments):
            actual = syn.raw_duration_seconds
            target = seg.target_speech_seconds
            speed = 1.0
            final_path = Path(syn.path)
            if actual > target:
                required = actual / target
                if required <= 1 + self.cfg.fitting.max_speedup_ratio:
                    speed = required
                    stretched = final_path.with_name(final_path.stem + "_fit.wav")
                    time_stretch_ffmpeg(final_path, stretched, speed)
                    final_path = stretched
                    actual = audio_duration(final_path)

            final_segments.append(SynthesizedSegment(
                id=syn.id,
                path=str(final_path),
                raw_duration_seconds=syn.raw_duration_seconds,
                final_duration_seconds=actual,
                target_speech_seconds=target,
                speed_factor=speed,
            ))
        synth = SynthesisManifest(segments=final_segments)

        # Persist the final post-fit script/manifest explicitly.
        final_dir = run_root / "final"
        final_dir.mkdir(exist_ok=True)
        script_path = final_dir / "script.json"
        synth_path = final_dir / "synthesis.json"
        script_path.write_text(script.model_dump_json(indent=2), encoding="utf-8")
        synth_path.write_text(synth.model_dump_json(indent=2), encoding="utf-8")

        narration_track = build_narration_track(
            script, synth, media.duration, final_dir / "narration.wav", self.cfg.mix.sample_rate
        )

        qa = run_qa(evidence, script, synth, self.cfg)
        qa_path = final_dir / "qa.json"
        qa_path.write_text(qa.model_dump_json(indent=2), encoding="utf-8")

        mixed, final_video = mix_and_render(
            media=media,
            narration_track=narration_track,
            out_dir=final_dir,
            sample_rate=self.cfg.mix.sample_rate,
            source_gain_db=self.cfg.mix.source_gain_db,
            narration_gain_db=self.cfg.mix.narration_gain_db,
            enable_ducking=self.cfg.mix.enable_ducking,
            duck_threshold=self.cfg.mix.duck_threshold,
            duck_ratio=self.cfg.mix.duck_ratio,
            duck_attack_ms=self.cfg.mix.duck_attack_ms,
            duck_release_ms=self.cfg.mix.duck_release_ms,
            target_lufs=self.cfg.mix.target_lufs,
        )

        self.pool.evict()

        return PipelineResult(
            job_id=job_id,
            final_video=final_video,
            narration_track=narration_track,
            mixed_audio=mixed,
            script_json=str(script_path),
            qa_json=str(qa_path),
        )
