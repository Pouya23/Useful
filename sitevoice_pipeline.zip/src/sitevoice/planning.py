from __future__ import annotations

import math

from .config import AppConfig
from .evidence import evidence_for_interval
from .schemas import EvidenceTimeline, Interval, NarrationPlan, NarrationSlot


def build_slots(evidence: EvidenceTimeline, words_per_second: float, cfg: AppConfig) -> NarrationPlan:
    total = evidence.duration
    target = cfg.narration.target_slot_seconds
    n = max(1, round(total / target))
    raw = total / n

    # Keep slots within configured bounds by adjusting count.
    if raw > cfg.narration.max_slot_seconds:
        n = math.ceil(total / cfg.narration.max_slot_seconds)
    elif raw < cfg.narration.min_slot_seconds and n > 1:
        n = max(1, math.floor(total / cfg.narration.min_slot_seconds))

    slots = []
    for i in range(n):
        start = total * i / n
        end = total * (i + 1) / n
        interval = Interval(start=start, end=end)
        speech_s = interval.duration * cfg.narration.speech_occupancy
        center_words = max(1, round(speech_s * words_per_second))
        lo = max(cfg.narration.min_words_per_segment, round(center_words * 0.92))
        hi = min(cfg.narration.max_words_per_segment, round(center_words * 1.05))
        if hi < lo:
            hi = lo

        ev = evidence_for_interval(evidence, interval)
        ids = [x.id for x in ev]
        slots.append(NarrationSlot(
            id=f"seg_{i:04d}",
            interval=interval,
            target_speech_seconds=speech_s,
            target_words_min=lo,
            target_words_max=hi,
            evidence_ids=ids,
        ))
    return NarrationPlan(slots=slots)
