from __future__ import annotations

from .config import AppConfig
from .schemas import EvidenceTimeline, QAItem, QAReport, Script, SynthesisManifest


def run_qa(
    evidence: EvidenceTimeline,
    script: Script,
    synth: SynthesisManifest,
    cfg: AppConfig,
) -> QAReport:
    items: list[QAItem] = []
    known = {e.id for e in evidence.items}
    synth_by_id = {s.id: s for s in synth.segments}

    for seg in script.segments:
        if cfg.qa.require_evidence_ids and not seg.evidence_ids:
            items.append(QAItem(
                level="error", code="NO_EVIDENCE",
                message="Narration segment has no supporting evidence IDs.", segment_id=seg.id,
            ))
        unknown = [x for x in seg.evidence_ids if x not in known]
        if unknown:
            items.append(QAItem(
                level="error" if cfg.qa.fail_on_unknown_evidence else "warning",
                code="UNKNOWN_EVIDENCE",
                message=f"Unknown evidence IDs: {unknown}", segment_id=seg.id,
            ))

        syn = synth_by_id.get(seg.id)
        if not syn:
            items.append(QAItem(
                level="error", code="MISSING_AUDIO",
                message="No synthesized audio for segment.", segment_id=seg.id,
            ))
            continue

        max_allowed = seg.interval.duration + cfg.qa.max_segment_overrun_seconds
        if syn.final_duration_seconds > max_allowed:
            items.append(QAItem(
                level="error", code="SEGMENT_OVERRUN",
                message=(
                    f"Audio duration {syn.final_duration_seconds:.2f}s exceeds "
                    f"slot duration {seg.interval.duration:.2f}s."
                ),
                segment_id=seg.id,
            ))

    return QAReport(
        passed=not any(x.level == "error" for x in items),
        items=items,
    )
