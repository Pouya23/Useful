from __future__ import annotations

import gc
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class LoadedModel:
    key: str
    value: Any
    close: Callable[[Any], None] | None = None


class ModelPool:
    """Single-resident GPU model pool with an explicit free-VRAM guard."""

    def __init__(
        self,
        clear_cuda_cache: bool = True,
        gpu_index: int = 0,
        min_free_vram_gib: float = 0.0,
    ):
        self.current: LoadedModel | None = None
        self.clear_cuda_cache = clear_cuda_cache
        self.gpu_index = gpu_index
        self.min_free_vram_gib = min_free_vram_gib

    def _prepare_cuda(self) -> None:
        try:
            import torch
            if not torch.cuda.is_available():
                return
            torch.cuda.set_device(self.gpu_index)
            free, _ = torch.cuda.mem_get_info(self.gpu_index)
            free_gib = free / (1024 ** 3)
            if free_gib < self.min_free_vram_gib:
                raise RuntimeError(
                    f"Only {free_gib:.2f} GiB VRAM free on cuda:{self.gpu_index}; "
                    f"{self.min_free_vram_gib:.2f} GiB is required before loading a GPU model. "
                    "Close other GPU processes or reduce the configured budget."
                )
        except ImportError:
            return

    def get(self, key: str, loader: Callable[[], Any], close: Callable[[Any], None] | None = None):
        if self.current and self.current.key == key:
            return self.current.value
        self.evict()
        self._prepare_cuda()
        value = loader()
        self.current = LoadedModel(key=key, value=value, close=close)
        return value

    def evict(self) -> None:
        if self.current is not None:
            if self.current.close:
                try:
                    self.current.close(self.current.value)
                except Exception:
                    pass
            self.current = None
        gc.collect()
        if self.clear_cuda_cache:
            try:
                import torch
                if torch.cuda.is_available():
                    torch.cuda.set_device(self.gpu_index)
                    torch.cuda.empty_cache()
                    torch.cuda.ipc_collect()
            except Exception:
                pass

    def free_vram_gib(self) -> float | None:
        try:
            import torch
            if not torch.cuda.is_available():
                return None
            free, _ = torch.cuda.mem_get_info(self.gpu_index)
            return free / (1024 ** 3)
        except Exception:
            return None
