from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, model_validator


class Interval(BaseModel):
    start: float = Field(ge=0)
    end: float = Field(gt=0)

    @model_validator(mode="after")
    def validate_order(self):
        if self.end <= self.start:
            raise ValueError("end must be > start")
        return self

    @property
    def duration(self) -> float:
        return self.end - self.start


class MediaInfo(BaseModel):
    source_path: str
    duration: float
    width: int
    height: int
    fps: float
    has_audio: bool
    video_only_path: str
    source_audio_path: str | None = None


class FrameSample(BaseModel):
    timestamp: float
    path: str
    ahash: str


class Scene(BaseModel):
    id: str
    interval: Interval
    frames: list[FrameSample] = Field(default_factory=list)


class SceneSet(BaseModel):
    scenes: list[Scene]


class TranscriptWord(BaseModel):
    start: float
    end: float
    text: str
    probability: float | None = None


class TranscriptSegment(BaseModel):
    start: float
    end: float
    text: str
    words: list[TranscriptWord] = Field(default_factory=list)


class Transcript(BaseModel):
    language: str | None = None
    language_probability: float | None = None
    segments: list[TranscriptSegment] = Field(default_factory=list)


class VisionObservation(BaseModel):
    scene_id: str
    start: float
    end: float
    location_context: str = ""
    visible_actions: list[str] = Field(default_factory=list)
    visible_equipment: list[str] = Field(default_factory=list)
    visible_text: list[str] = Field(default_factory=list)
    supported_inferences: list[str] = Field(default_factory=list)
    do_not_claim: list[str] = Field(default_factory=list)
    confidence: float = Field(default=0.5, ge=0, le=1)


class VisionObservations(BaseModel):
    observations: list[VisionObservation]


class EvidenceItem(BaseModel):
    id: str
    kind: Literal["visual", "transcript", "user", "domain"]
    interval: Interval | None = None
    text: str
    confidence: float = Field(default=1.0, ge=0, le=1)
    source: str


class EvidenceTimeline(BaseModel):
    topic: str
    description: str | None = None
    duration: float
    items: list[EvidenceItem]


class StyleProfile(BaseModel):
    name: str = "instructional"
    tone: str = "clear, educational, measured"
    technicality: float = Field(default=0.6, ge=0, le=1)
    energy: float = Field(default=0.45, ge=0, le=1)
    sentence_length: str = "medium"
    explanation_density: str = "high"
    rhetorical_traits: list[str] = Field(default_factory=list)
    avoid: list[str] = Field(default_factory=list)


class VoiceCalibration(BaseModel):
    key: str
    words: int
    duration_seconds: float
    words_per_second: float
    sample_path: str


class NarrationSlot(BaseModel):
    id: str
    interval: Interval
    target_speech_seconds: float
    target_words_min: int
    target_words_max: int
    evidence_ids: list[str]


class NarrationPlan(BaseModel):
    slots: list[NarrationSlot]


class SegmentDraft(BaseModel):
    id: str
    interval: Interval
    target_speech_seconds: float
    text: str
    word_count: int
    evidence_ids: list[str]
    purpose: str = ""


class Script(BaseModel):
    segments: list[SegmentDraft]


class SynthesizedSegment(BaseModel):
    id: str
    path: str
    raw_duration_seconds: float
    final_duration_seconds: float
    target_speech_seconds: float
    speed_factor: float = 1.0


class SynthesisManifest(BaseModel):
    segments: list[SynthesizedSegment]


class QAItem(BaseModel):
    level: Literal["info", "warning", "error"]
    code: str
    message: str
    segment_id: str | None = None


class QAReport(BaseModel):
    passed: bool
    items: list[QAItem] = Field(default_factory=list)


class PipelineResult(BaseModel):
    job_id: str
    mode: str
    final_video: str
    narration_track: str
    mixed_audio: str
    script_json: str
    qa_json: str
