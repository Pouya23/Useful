from __future__ import annotations

import hashlib
import json
import math
import re
import subprocess
from pathlib import Path
from typing import Any


def run(cmd: list[str], *, capture: bool = False) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        check=True,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
    )


def stable_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str, ensure_ascii=False)


def digest(value: Any) -> str:
    return hashlib.blake2b(stable_json(value).encode("utf-8"), digest_size=20).hexdigest()


def fast_file_fingerprint(path: str | Path, chunk: int = 4 * 1024 * 1024) -> dict[str, Any]:
    p = Path(path)
    stat = p.stat()
    h = hashlib.blake2b(digest_size=20)
    h.update(str(stat.st_size).encode())
    with p.open("rb") as f:
        if stat.st_size <= chunk * 3:
            h.update(f.read())
        else:
            h.update(f.read(chunk))
            f.seek(max(0, stat.st_size // 2 - chunk // 2))
            h.update(f.read(chunk))
            f.seek(max(0, stat.st_size - chunk))
            h.update(f.read(chunk))
    return {"path": str(p.resolve()), "size": stat.st_size, "sample_hash": h.hexdigest()}


def extract_json_object(text: str) -> str:
    text = text.strip()
    fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    if fenced:
        return fenced.group(1)
    start = text.find("{")
    if start < 0:
        raise ValueError("No JSON object found")
    depth = 0
    in_string = False
    escaped = False
    for i in range(start, len(text)):
        c = text[i]
        if escaped:
            escaped = False
            continue
        if c == "\\" and in_string:
            escaped = True
            continue
        if c == '"':
            in_string = not in_string
        if in_string:
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    raise ValueError("Unterminated JSON object")


def word_count(text: str) -> int:
    return len(re.findall(r"\b[\w'-]+\b", text, flags=re.UNICODE))


def db_to_linear(db: float) -> float:
    return 10.0 ** (db / 20.0)


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def evenly_spaced(start: float, end: float, n: int, margin_ratio: float = 0.08) -> list[float]:
    if n <= 1:
        return [(start + end) / 2]
    duration = end - start
    margin = min(duration * margin_ratio, max(0.05, duration / 4))
    a, b = start + margin, end - margin
    if b <= a:
        return [(start + end) / 2]
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]
