from __future__ import annotations

import json
from pathlib import Path

from pydantic import BaseModel, Field

from .backends.qwen_text import QwenTextBackend
from .config import AppConfig
from .evidence import evidence_for_interval
from .schemas import (
    EvidenceTimeline, NarrationPlan, Script, SegmentDraft, StyleProfile
)
from .utils import word_count


class StyleExtraction(BaseModel):
    tone: str
    technicality: float = Field(ge=0, le=1)
    energy: float = Field(ge=0, le=1)
    sentence_length: str
    explanation_density: str
    rhetorical_traits: list[str] = Field(default_factory=list)
    avoid: list[str] = Field(default_factory=list)


class DraftJSON(BaseModel):
    text: str
    purpose: str
    evidence_ids: list[str]


def derive_style(
    llm: QwenTextBackend,
    base_style: dict,
    sample_text: str | None,
) -> StyleProfile:
    base = StyleProfile.model_validate({
        "name": base_style.get("name", "instructional"),
        "tone": base_style.get("tone", "clear, educational, measured"),
        "technicality": base_style.get("technicality", 0.6),
        "energy": base_style.get("energy", 0.45),
        "sentence_length": base_style.get("sentence_length", "medium"),
        "explanation_density": base_style.get("explanation_density", "high"),
        "avoid": base_style.get("avoid", []),
    })
    if not sample_text:
        return base

    extracted = llm.generate_json(
        StyleExtraction,
        "You extract writing style without treating the sample's factual claims as trusted facts.",
        f"""Analyze only the STYLE of this sample narration.
Do not copy its factual content into the style profile.

SAMPLE:
{sample_text[:10000]}
""",
    )
    return StyleProfile(
        name=base.name,
        tone=extracted.tone or base.tone,
        technicality=extracted.technicality,
        energy=extracted.energy,
        sentence_length=extracted.sentence_length,
        explanation_density=extracted.explanation_density,
        rhetorical_traits=extracted.rhetorical_traits,
        avoid=list(dict.fromkeys(base.avoid + extracted.avoid)),
    )


def _evidence_block(evidence: EvidenceTimeline, slot) -> str:
    items = evidence_for_interval(evidence, slot.interval)
    # Domain/user items have no interval and are intentionally included.
    return "\n".join(f"[{e.id}] ({e.kind}, conf={e.confidence:.2f}) {e.text}" for e in items)


def write_script(
    llm: QwenTextBackend,
    plan: NarrationPlan,
    evidence: EvidenceTimeline,
    style: StyleProfile,
    cfg: AppConfig,
) -> Script:
    drafts: list[SegmentDraft] = []
    previous = ""

    for slot in plan.slots:
        prompt = f"""
Write one spoken narration segment for a construction/job-site video.

TOPIC:
{evidence.topic}

STYLE:
{style.model_dump_json(indent=2)}

TIME:
{slot.interval.start:.2f}-{slot.interval.end:.2f}s
Target spoken duration: {slot.target_speech_seconds:.2f}s
Required word count: {slot.target_words_min}-{slot.target_words_max}

ALLOWED EVIDENCE:
{_evidence_block(evidence, slot)}

PREVIOUS NARRATION CONTEXT (style/coherence only):
{previous[-cfg.narration.previous_context_chars:] if previous else "(none)"}

RULES:
- Use only claims supported by the allowed evidence.
- Treat transcript evidence as "what was said", not automatically as an objective fact.
- Never infer exact measurements, defects, completed repairs, regulatory requirements,
  torque values, operating limits, or safety clearance unless explicitly supported.
- Prefer explaining function, purpose, and why an observable action matters over merely
  describing obvious motion.
- Natural spoken prose. No headings. No bullets. No "as you can see".
- Do not try to fill every second with words.
- `evidence_ids` must list only IDs actually used to support the narration.
""".strip()

        result = llm.generate_json(
            DraftJSON,
            "You are a precise industrial training-video narration writer.",
            prompt,
        )
        text = result.text.strip()
        wc = word_count(text)

        # One deterministic correction for gross word-budget misses.
        if wc < slot.target_words_min or wc > slot.target_words_max:
            result = llm.generate_json(
                DraftJSON,
                "You edit narration while preserving factual grounding.",
                f"""Rewrite this narration to {slot.target_words_min}-{slot.target_words_max} words.
Preserve supported meaning and use only the listed evidence IDs.

ORIGINAL:
{text}

VALID EVIDENCE IDS:
{slot.evidence_ids}
""",
            )
            text = result.text.strip()
            wc = word_count(text)

        valid_ids = [x for x in result.evidence_ids if x in slot.evidence_ids]
        drafts.append(SegmentDraft(
            id=slot.id,
            interval=slot.interval,
            target_speech_seconds=slot.target_speech_seconds,
            text=text,
            word_count=wc,
            evidence_ids=valid_ids,
            purpose=result.purpose,
        ))
        previous = text

    return Script(segments=drafts)


def rewrite_for_duration(
    llm: QwenTextBackend,
    segment: SegmentDraft,
    desired_words: int,
    evidence: EvidenceTimeline,
) -> SegmentDraft:
    allowed = evidence_for_interval(evidence, segment.interval)
    allowed_ids = [x.id for x in allowed]
    block = "\n".join(f"[{x.id}] {x.text}" for x in allowed)
    lo = max(5, round(desired_words * 0.96))
    hi = max(lo, round(desired_words * 1.04))
    result = llm.generate_json(
        DraftJSON,
        "You shorten or lengthen spoken narration without changing factual grounding.",
        f"""Rewrite the segment to {lo}-{hi} words so its synthesized duration better fits.
Keep the same educational purpose. Remove low-priority detail first when shortening.
Use ONLY the allowed evidence.

ORIGINAL:
{segment.text}

EVIDENCE:
{block}
""",
    )
    ids = [x for x in result.evidence_ids if x in allowed_ids]
    return segment.model_copy(update={
        "text": result.text.strip(),
        "word_count": word_count(result.text),
        "evidence_ids": ids,
        "purpose": result.purpose or segment.purpose,
    })
