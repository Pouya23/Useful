from pydantic import BaseModel
from sitevoice.cache import StageCache


class Out(BaseModel):
    value: int


def test_cache_reuses_matching_fingerprint(tmp_path):
    cache = StageCache(tmp_path)
    calls = {"n": 0}

    def work(_):
        calls["n"] += 1
        return Out(value=7)

    assert cache.run("x", "1", {"a": 1}, Out, work).value == 7
    assert cache.run("x", "1", {"a": 1}, Out, work).value == 7
    assert calls["n"] == 1

    assert cache.run("x", "1", {"a": 2}, Out, work).value == 7
    assert calls["n"] == 2
