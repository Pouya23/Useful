from sitevoice.evidence import build_evidence
from sitevoice.schemas import MediaInfo, Transcript, VisionObservations


def test_text_only_always_has_topic_evidence():
    media = MediaInfo(
        source_path="x.mp4",
        duration=30.0,
        width=1920,
        height=1080,
        fps=30.0,
        has_audio=False,
        video_only_path="video.mp4",
    )
    evidence = build_evidence(
        media=media,
        topic="pipe maintenance",
        description=None,
        observations=VisionObservations(observations=[]),
        transcript=Transcript(),
        domain_pack={},
    )
    assert evidence.items[0].id == "U_TOPIC"
    assert "pipe maintenance" in evidence.items[0].text
