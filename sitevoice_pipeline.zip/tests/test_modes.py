from sitevoice.modes import PipelineMode, resolve_mode


def test_mode_capabilities():
    assert not PipelineMode.TEXT.uses_vision
    assert not PipelineMode.TEXT.uses_asr
    assert PipelineMode.VISION.uses_vision
    assert not PipelineMode.VISION.uses_asr
    assert not PipelineMode.ASR.uses_vision
    assert PipelineMode.ASR.uses_asr
    assert PipelineMode.FULL.uses_vision
    assert PipelineMode.FULL.uses_asr


def test_mode_aliases():
    assert resolve_mode("core") is PipelineMode.TEXT
    assert resolve_mode("audio") is PipelineMode.ASR
