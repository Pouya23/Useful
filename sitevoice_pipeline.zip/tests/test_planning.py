from sitevoice.config import AppConfig
from sitevoice.planning import build_slots
from sitevoice.schemas import EvidenceItem, EvidenceTimeline


def cfg():
    return AppConfig.model_validate({
        "tts": {
            "calibration_text": "Calibration text here."
        }
    })


def test_slots_cover_duration():
    evidence = EvidenceTimeline(
        topic="test",
        duration=60.0,
        items=[EvidenceItem(id="K1", kind="domain", text="fact", source="test")],
    )
    plan = build_slots(evidence, words_per_second=2.2, cfg=cfg())
    assert plan.slots[0].interval.start == 0.0
    assert abs(plan.slots[-1].interval.end - 60.0) < 1e-6
    assert all(s.target_words_min <= s.target_words_max for s in plan.slots)
