from sitevoice.utils import extract_json_object, word_count


def test_extract_json_object():
    assert extract_json_object('blah {"a": 1} trailing') == '{"a": 1}'


def test_word_count():
    assert word_count("Routine maintenance checks wear-points carefully.") == 5
